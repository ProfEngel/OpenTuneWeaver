## 3: Bilanz

## 3.1 Einführung

Die Bilanz als Teil des Jahresabschlusses ist eine Gegenüberstellung der an einem Bilanzstichtag  (z.  B.  dem  31.12.01)  vorhandenen,  nach  bestimmten  Grundsätzen bewerteten und in Gruppen zusammengefassten Vermögensgegenstände (Aktiva), Kapital, mit dem Fremdkapital und der Saldogröße Eigenkapital (Passiva). Sie stellt am Ende eines Geschäftsjahres Vermögen und Kapital bzw. Aktiva und Passiva eines Unternehmens  gegenüber.  Die  Passivseite der Bilanz zeigt die Herkunft der finanziellen Mittel in einem Unternehmen. Die Aktivseite enthält das Vermögen, d. h. die Mittelverwendung, und zeigt die Investitionen. Die Grundlage für die Bilanz bildet die  Inventur  mit  einer  körperlichen  und  buchmäßigen  Bestandsaufnahme  des Vermögens  und  der  Schulden.  Bei  der  Bilanz  unterscheidet  man  zwischen  der Handelsbilanz, diese wird nach den handelsrechtlichen Vorschriften gemäß §§ 238 ff. HGB erstellt, und der Steuerbilanz, die den steuerrechtlichen Vorschriften entspricht. Die Gliederung der Bilanz nach der Kontoform hat das Aussehen wie unten (Abb. 3.1). Die Gliederung der Bilanz dient der Klarheit und der übersichtlichen Darstellung aller in der Bilanz enthaltenen Informationen. Ein einheitliches System der Gliederung dient nicht nur dem Vergleich der Bilanzen innerhalb eines Unternehmens, sondern auch dem Vergleich der Bilanzen unterschiedlicher Unternehmen. Dabei werden die Aktiva (  Vermögensgegenstände)  entsprechend  dem  Grad  ihrer  üblichen  Bindungsdauer (Liquidierbarkeit) und die Passiva entsprechend ihrer Fälligkeit (Überlassungsdauer) gegliedert.

## 3.2 Bilanzarten

Es gibt verschiedene Merkmale, nach denen Bilanzen kategorisiert werden können: nach  der  Häufigkeit  der  Bilanzerstellung, nach  dem  Adressatenkreis  und  dem Bilanzierungsanlass, nach der gesetzlichen Bestimmung zur Bilanzerstellung. Die folgende Tabelle stellt die Gruppierung der oben genannten drei Merkmale und die dazugehörigen Bilanzarten dar.

Zu  den  laufenden  Bilanzen,  die  auch  als  ordentliche  Bilanzen  bezeichnet  werden, gehören  die  Monats-,  die  Quartals-  und  die  Jahresbilanz.  Die  Jahresbilanz  ist  die wichtigste und am häufigsten verwendete Bilanzart. Sonderbilanzen werden auch als außerordentliche  Bilanzen  bezeichnet,  da  sie,  wie  z.  B.  die  Gründungsbilanz,  nur einmalig und nicht für jede Periode erstellt werden.

## 3.3 Handelsbilanz und Steuerbilanz im Vergleich

Handelsbilanz  und  Steuerbilanz  im  Vergleich  Handels-  und  Steuerbilanz  können übereinstimmen, sie müssen es aber nicht. Falls beide Bilanzen übereinstimmen, so spricht man von einer Einheitsbilanz. 3.3.1 Die Handelsbilanz Die Handelsbilanz ist eine Bilanz, deren Vorschriften aus dem Handelsrecht hervorgehen. Sie wird jährlich aufgestellt und dient einerseits als Erfolgsbilanz, um das Bilanzergebnis, also den.

Bilanzgewinn oder den Bilanzverlust, einer Periode auszuweisen. Zum anderen weist sie als Vermögensbilanz das Vermögen, Eigenund Fremdkapital aus. Das Bilanzergebnis wird mithilfe des Jahresergebnisses, das entweder als Jahresüberschuss oder als Jahresfehlbetrag vorliegt, ermittelt. Ein Jahresüberschuss entsteht, wenn die Erträge die Aufwendungen während einer Rechnungslegungsperiode übersteigen. Dementsprechend gilt, dass ein Jahresfehlbetrag aus einem Überschuss an Aufwendungen gegenüber den Erträgen hervorgeht.6  Das  Bilanzergebnis  wird  folgendermaßen  ermittelt:  Jahresüberschuss bzw.  Jahresfehlbetrag  +  Gewinnvortrag  aus  dem  Vorjahr  -  Verlustvortrag  aus  dem Vorjahr  +  Entnahme  aus  der  Kapitalrücklage  zum  Ausgleich  +  Entnahme  aus Gewinnrücklagen a) aus der gesetzlichen Rücklage b) aus der Rücklage für Anteile an dem herrschenden oder mit Mehrheit beteiligten Unternehmen c) aus satzungsmäßigen  Rücklagen  d)  aus  anderen  Gewinnrücklagen  -  Einstellungen  in Gewinnrücklagen a) in die gesetzliche Rücklage b) in die Rücklage für Anteile an dem herrschenden  oder  mit  Mehrheit  beteiligten  Unternehmen  c)  in  satzungsmäßige Rücklagen  d)  in  andere  Gewinnrücklagen  =  Bilanzergebnis  (Bilanzgewinn  bzw. Bilanzverlust) Abb.  3.3:  Ermittlung  des  Bilanzgewinns  bzw.  des  Bilanzverlusts  Der Bilanzgewinn ist der Restgewinn des Jahresüberschusses, der nicht in die Gewinnrücklagen  eingestellt  wurde.  Er  wird  von  der  Hauptversammlung  oder Gesellschafterversammlung den Anteilseignern zur Ausschüttung vorgeschlagen.

## 3.3.2 Die Steuerbilanz

Die Steuerbilanz Die Steuerbilanz wird nach steuerrechtlichen Vorschriften gemäß § 60 Abs. 2 EStDV erstellt und dient der Ermittlung der Steuerlast für das Finanzamt. Die Aufgabe der Steuerbilanz besteht darin, gemäß § 5 Abs. 1 EStG den steuerrechtlichen

Gewinn,  oder  anders  ausgedrückt:  das  zu  versteuernde  Einkommen,  mithilfe  der ertragsteuerlichen Grundlagen zu ermitteln. Zur Gruppe der Ertragsteuern gehören die Einkommensteuer  (ESt),  die Körperschaftsteuer (KSt)  und  die  Gewerbesteuer (GewSt).

Laut  §  4  Abs.  1  Satz  1  EStG  berechnet  sich  der  Gewinn/Verlust  wie  folgt: Betriebsvermögen am Ende des Wirtschaftsjahres - Betriebsvermögen am Ende des vorangegangenen Wirtschaftsjahres + Entnahmen - Einlagen = Gewinn oder Verlust Abb. 3.4: Steuerrechtliche Gewinnermittlung nach § 4 Abs. 1 Satz EstG

Die Handels- und Steuerbilanz sind in Deutschland eng miteinander verbunden. Dies ergibt sich aus dem Maßgeblichkeitsprinzip nach § 5 Abs. 1 Satz 1 EStG, welches besagt, dass die meisten Wertansätze der Handelsbilanz auch für die Steuerbilanz gelten.7 Abweichungen zwischen der Handels- und der Steuerbilanz entstehen vor allem deshalb, weil die steuerrechtlichen Bilanzierungs- und Bewertungsvorschriften oft  weniger  Spielraum  zulassen  als  die  handelsrechtlichen  Vorschriften.  Diese strengeren Regelungen in der Steuerbilanz stammen daher, dass der steuerrechtliche Jahresabschluss andere Ziele verfolgt als der handelsrechtliche Jahresabschluss. Da die Handelsbilanz vor allem die Aufgabe der Transparenz eines Unternehmens und des Informationsflusses zwischen Unternehmen und Außenstehenden erfüllt, werden bei  der  Aufstellung  einige  Ermessensspielräume  zugelassen.  Der  steuerrechtliche Jahresabschluss hingegen hat sich an die allgemein geltenden Besteuerungsprinzipien zu halten. Die beiden Prinzipien Gleichmäßigkeit der Besteuerung und Prinzip der objektivierten Gewinnermittlung besagen einerseits, dass für gleiche Wirtschaftssubjekte immer die gleichen Besteuerungsgrundlagen gelten, und andererseits, dass dem  Bilanzierenden so wenig Freiraum wie möglich zugestanden wird. Das soll verhindern, dass der Steuerpflichtige die Möglichkeit hat, seine  Steuerbelastung  zeitlich  zu  verschieben.  Durch  diese  Vorbehalte  kommt  es meist  zu  höheren  bzw.  zeitlich  früheren  Gewinnen  in  der  Steuerbilanz  als  in  der Handelsbilanz.

## 3.4 Bilanztheorien

Aus der Betriebswirtschaftslehre gehen verschiedene Bilanztheorien hervor, die den Zweck  der  Bilanzen  erklären  sollen.  Die  Bilanztheorien  beschäftigen  sich  mit  dem Inhalt,  der  Aufgabe  und  der Ausgestaltung  des  Jahresabschlusses.  Obwohl  diese Theorien oder Auffassungen nicht unbedingt maßgeblich für die praxisrelevante Bilanz im  Rechtssinne  sind,  beeinflussen  sie  die  Gesetzgebung,  Rechtsfortbildung  und Rechtsanwendung. Das ist vor allem der Fall, wenn die Zwecksetzungen einer Bilanz gesetzlich und betriebswirtschaftlich übereinstimmen oder Gesetzeslücken geschlossen werden sollen.11 Die statische, dynamische und organische Bilanzauffassung stellen die drei klassischen Bilanztheorien dar.

## 3.4.1 Statische Bilanzauffassung

Die statische Bilanztheorie besagt, dass die Aufgabe der Bilanz primär darin liegt, das Reinvermögen  (Vermögen  minus  Schulden)  eines  Unternehmens,  überwiegend  im Interesse  der  Gläubiger,  zu  einem  bestimmten  Bilanzstichtag  zu  ermitteln.  Daher werden  nur  selbstständige  Vermögensbestandteile  und  Schulden  in  der  Bilanz ausgewiesen, die außerdem eindeutig zu bewerten sind. Die Vermögensbestandteile werden  mit  den Anschaffungs-  oder  Herstellungskosten  bzw.  mit  dem  niedrigeren beizulegenden Wert bewertet. Für die Vermögensgegenstände gilt das Niederstwertprinzip. Die Schulden sind mit ihrem Erfüllungsbetrag am Bilanzstichtag anzusetzen, hier gilt das Höchstwertprinzip. Ziel der statischen Bilanz ist vor allem die Vermögensbestandsermittlung. Die Vermögensmehrung innerhalb einer Periode wird als Gewinn bezeichnet.

## 3.4.2 Dynamische Bilanzauffassung

Im Gegensatz zur statischen Bilanztheorie liegt das Ziel der dynamischen Bilanztheorie darin, den Erfolg eines Unternehmens zu analysieren. Der Jahresabschluss stellt  nach der  dynamischen  Bilanztheorie  eine Zeitraumrechnung dar.  Der  Erfolg  wird  definiert  als  Differenzbetrag  zwischen  Ertrag  und Aufwand.12 Aufwendungen ergeben sich innerhalb eines Geschäftsjahres durch den Verbrauch von  Gütern  und  Dienstleistungen  (z.  B.  durch Abschreibungen,  Materialverbrauch, Löhne  und  Gehälter,  Zinsen  etc.).  Der  Ertrag  (z.  B.  Umsatzerlöse,  Mieterträge, Zuschreibungen, Zinserträge etc.) steht dem Aufwand gegenüber und bezeichnet den

Wertezuwachs, den ein Unternehmen innerhalb einer Periode erzielt. Die Aufstellung der Bilanz findet über die verursachungsgerechte Periodenzurechnung von Einnahmen und  Ausgaben statt. Dies erfolgt durch die Erfassung künftiger Aufwendungen  und  Einnahmen  auf  der  Aktivseite  sowie  künftiger  Ausgaben  und Erträge auf der Passivseite.13 Die dynamische Bilanzauffassung folgt dem Prinzip der Verursachung.  Es  ist  von  größter  Bedeutung,  dass  die Ausgaben  und  Einnahmen zeitlich  korrekt  zugeordnet  werden.  Auch  Rückstellungen,  dies  sind  ungewisse Verpflichtungen,  folgen  dem  Verursachungsprinzip,  d.  h.  sie  werden  in  dem  Jahr erfasst, in dem sie zustande gekommen sind. Sie werden, anders als bei der statischen Bilanztheorie,  auch  dann  erfasst,  wenn  zum  Zeitpunkt  des  Stichtags  noch  keine Verbindlichkeit besteht. Bei der dynamischen Bilanzauffassung werden Rechnungsabgrenzungsposten nicht vernachlässigt. Sie werden auch dann erfasst, wenn sie keine Verpflichtung darstellen. Ein Beispiel hierfür sind bezahlte Kfz-Steuern, die auch in der folgenden Periode wieder anfallen.

## 3.4.3 Organische Bilanzauffassung

Mit  der  organischen  Bilanzauffassung  werden  das  Vermögen  und  der  Erfolg  eines Unternehmens ermittelt. Hauptmerkmal dieser Bilanztheorie ist die Berücksichtigung der Verbindung zwischen dem Unternehmen und der volkswirtschaftlichen Geldwertänderung.  Daher  ist für  die  Bewertung  und  die  Abschreibungen  der Wiederbeschaffungswert am Bilanzstichtag maßgeblich. So sollen Geldwertschwankungen aus der Bilanz beseitigt werden. Das Ergebnis ist dann der Unterschiedsbetrag zwischen dem, jeweils nach Wiederbeschaffungskosten bewerteten Anfangsund Endvermögen.16 Mithilfe dieser Theorie sollen Scheingewinne  verhindert  werden.  Scheingewinne  entstehen,  wenn  der  Geldwert sinkt und die Wiederbeschaffungskosten, für z. B. Vorräte, steigen. Das bedeutet, dass der  Wert  der  Ware  zwar  nominal  gestiegen  ist,  real,  oder  anders  ausgedrückt: substanziell, aber gleich geblieben oder sogar gesunken ist.

## 3.5 Ausgewählte Posten des Anlagevermögens

Zum Anlagevermögen gehören alle Vermögensgegenstände, die dazu bestimmt sind, dauernd  ,  d.  h.  in  der  Regel  länger  als  12  Monate  dem  Geschäftsbetrieb  des Unternehmens zu dienen und die technische Betriebsbereitschaft zu sichern (§ 247 Abs. 2 HGB). Das Anlagevermögen besteht aus immateriellen Vermögensgegenständen, Sachund Finanzanlagen. 3.5.1 Immaterielle Vermögensgegenstände  Diese  sind  nicht  materiell,  d.  h.,  sie  sind  nicht  körperlich fassbar, und stellen keine finanziellen Vermögensgegenstände dar. Es handelt sich bei ihnen überwiegend um Wissen, Rechte, rechtsähnliche Werte und sonstige Vorteile; siehe folgende Abbildung: Rechte rechtsähnliche Werte sonstige Vorteile · Markenrechte · Patente · Gebrauchsmuster · Urheberrechte · Lizenzen · Nutzungsrechte · Konzessionen · Wettbewerbsrechte · Vertriebsrechte · Vorkaufsrechte  ·  Geheimverfahren  ·  Fertigungsverfahren  Abb.  3.5:  Beispiele  für immaterielle Vermögensgegenstände Bei den immateriellen Vermögensgegenständen besteht: eine Aktivierungspflicht für entgeltlich erworbene immaterielle Vermögensgegenstände sowie für selbst geschaffenes immaterielles Umlaufvermögen, und ein Aktivierungswahlrecht für selbst geschaffene immaterielle Vermögensgegenstände des Anlagevermögens (§ 248 Abs. 2 HGB), wenn sie einzeln verwertbar  sind,  sei  es  durch  Veräußerung  oder  anderweitig  (beispielsweise  durch Verarbeitung,  Verbrauch  oder  Nutzungsüberlassung17).  Um  eine  Ausschüttung solcher Beträge auszuschließen, wurde in § 268 Abs. 8 HGB eine Ausschüttungssperre eingebaut, wonach das Volumen selbst erstellter immaterieller Vermögensgegenstände  abzüglich  der  dafür  gebildeten  passiven  latenten  Steuern nicht ausschüttbar ist. Für selbsterstelltes immaterielles Vermögen gilt gemäß §§ 248 und 255 Abs. 2a HGB Folgendes:

Ansatzverbot für: Aufwendungen für die Gründung eines Unternehmens Aufwendungen  für  die  Beschaffung  des  Eigenkapitals Aufwendungen  für  den Abschluss von Versicherungsverträgen selbst erstellte Marken, Drucktitel, Verlagsrechte, Kundenlisten, vergleichbare immaterielle Vermögensgegenstände des Anlagevermögens (§ 248 Abs. 2 Satz 2 HGB) Forschungs- und Vertriebskosten (§ 255 Abs. 2 Satz 4 HGB) Ausgaben, bei  denen  sich die  Zwecke  Forschung und Entwicklung nicht verlässlich voneinander unterscheiden lassen (§ 255 Abs. 2a Satz 4 HGB)  Ansatzpflicht für: entgeltlich erworbene immaterielle Rechte (z. B. Konzessionen, gewerbliche Schutzrechte) entgeltlich erworbenen Geschäfts- oder

Firmenwert  (§  246  Abs.  1  Satz  4  HGB) selbst  geschaffenes  immaterielles Umlaufvermögen (z. B. Software zum Verkauf an Dritte bestimmt, Forschungstätigkeit im Auftrag nach Weisung und Rechnung Dritter) Ansatzwahlrecht für: Ausgaben von Entwicklungskosten, d. h. Anwendung der Forschungsergebnisse.

## 3.5.1.1 Selbst geschaffene gewerbliche Schutzrechte und ähnliche Rechte und Werte

Hierbei handelt es sich um immaterielle Vermögensgegenstände, die das Unternehmen nicht entgeltlich von Dritten erworben, sondern selbst hergestellt hat. Typische  Beispiele  für  solche  immateriellen  Vermögensgegenstände  sind  selbst erstellte Entwicklungsprozesse, Produktionsverfahren und Software. Die Aktivierung beschränkt sich auf die  angefallenen  Herstellungsaufwendungen  während  der Entwicklungsphase. Kosten für die Forschung dürfen nach § 255 Abs. 2 Satz 4 HGB nicht  aktiviert  werden.  Oftmals  sind  Forschung  und  Entwicklung  nur  sehr  schwer voneinander abzugrenzen, z. B. wenn Forschung und Entwicklung nicht nacheinander, sondern parallel laufen. Ist eine Unterscheidung zwischen Forschungund Entwicklungskosten  nicht  möglich,  besteht  gemäß  §  255 Abs.  2a  Satz  4  HGB  ein Aktivierungsverbot.  Die  angefallenen  Kosten  sind  dann  als  Aufwendungen  in  der Gewinn- und Verlustrechnung erfolgswirksam zu verbuchen. Merke Handelsrechtlich besteht für selbst erstellte immaterielle Vermögensgegenstände des Anlagevermögens ein Aktivierungswahlrecht. Steuerrechtlich besteht aber ein Aktivierungsverbot.

Sachanlagen  Sachanlagen  sind  physisch  greifbare  Vermögensgegenstände,  die entweder keiner ständigen Wertminderung unterliegen (z. B. Grundstücke) oder deren Werte durch Nutzung und im Zeitablauf kontinuierlich abnehmen (z. B. Maschinen, Fahrzeuge, Gebäude und BGA). 3.5.2.1 Grundstücke, grundstücksgleiche Rechte und Bauten  einschl.  der  Bauten  auf  fremden  Grundstücken  Dieser  Posten  umfasst  die unbeweglichen Sachanlagen. Steuerrechtlich spricht man vom Posten des Grund und Bodens. Dazu gehören: Grundstücke: Hier ist eine festgelegte Fläche des Grund und Bodens gemeint. Man unterscheidet zwischen bebautem und unbebautem Grund und Boden, der im Eigentum des Unternehmens steht. Grundstücke gehören zu den nicht abnutzbaren Vermögensgegenständen, weshalb sie keiner planmäßigen

Abschreibung unterliegen. Grundstücksgleiche Rechte: Dies sind dingliche Rechte, die im BGB den Vorschriften über Grundstücke unterliegen19, wie z. B. Erbbaurecht, Bergwerkseigentum,  Dauerwohn-  und  Nutzungsrecht. Bauten:  Zu  den  Bauten zählen  Gebäude  und  (unselbstständige)  Gebäudeteile,  die  in  einem  einheitlichen Nutzungszusammenhang mit dem Gebäude stehen, wie z. B. Heizungs-, Beleuchtungs-,  Lüftungsanlagen,  Zuleitungen,  Rolltreppen,  Installationen  (wenn  sie wirtschaftlich als Teil des Gebäudes anzusehen sind und keine Betriebsvorrichtungen darstellen). Andere Bauten: Sie dienen besonderen Zwecken und sind gesondert zu aktivieren, wie z. B. Straßen, Parkplätze, Brücken, Eisenbahnanlagen, Hafenanlagen etc. Bauten auf fremden Grundstücken: wenn die Bebauung auf einem gemieteten bzw. gepachteten Grundstück erfolgt.

## 3.5.2.2 Technische Anlagen und Maschinen

Der  nächste  Posten  der  Sachanlagen  heißt  technische  Anlagen  und  Maschinen. Dieser  umfasst  'diejenigen  Vermögensgegenstände  des  Anlagevermögens,  die unmittelbar  dem  betrieblichen  Leistungserstellungsprozess  dienen.'20  D.  h.  diese Vermögensgegenstände werden für den Produktionsprozess benötigt. Sie können wie folgt unterschieden werden: T echnische Anlagen: z. B. Hochöfen, Tanks, Anlagen der chemischen Industrie, Kraftwerke, Transportanlagen, Krananlagen etc. Maschinen: z. B. Werkzeugmaschinen, Bohr-, Dreh-, Fräs-, Schleifund Stanzmaschinen,  Setzund  Druckmaschinen,  Bagger,  Arbeitsbühnen  etc.  3.5.2.3 Andere  Anlagen,  Betriebs-  und  Geschäftsausstattung  Zu  unterscheiden  von  den vorherigen  beiden  Posten  ist  der  Posten  der  anderen  Anlagen,  Betriebs-  und Geschäftsausstattung.  Er  kann  wie  folgt  differenziert  werden: Andere  Anlagen: Sammelposten für Sachanlagen, die nicht eindeutig einem anderen Posten zuzuordnen sind, wie z. B. Telefon-, Überwachungsanlagen, Feuerlöscheinrichtungen etc. Betriebs- und Geschäftsausstattung: Dies betrifft Vermögensgegenstände, die in  erster  Linie  der  Verwaltung  und  dem  Vertrieb  dienen,  wie  z.  B.  Büro-  und Lagereinrichtung, Fuhrpark, Kantinen, geringwertige Wirtschaftsgüter etc.

3.5.2.4 Geleistete  Anzahlungen und  Anlagen im Bau  Anzahlungen, die ein Unternehmer auf Sachanlagen leistet, werden auf dem Konto 'Geleistete Anzahlungen auf Sachanlagen' gebucht und in der Bilanz unter  dem  Posten 'Geleistete Anzahlungen und Anlagen im Bau' separat ausgewiesen. Geleistete Anzahlungen sind Vorleistungen auf eine vom anderen Vertragsteil zu erbringende Lieferung/Leistung, deren Lieferung bis zum Bilanzstichtag noch nicht erfolgt ist. Hier liegt  ein  schwebendes  Geschäft  vor,  das  erfolgsneutral  ausgewiesen  wird. Der Bilanzposten 'Anlagen im Bau' enthält sämtliche (aktivierungsfähige) Aufwendungen für Eigen- und Fremdleistungen, die zum Bilanzstichtag für unvollendete und damit noch nicht nutzbare Sachanlagegüter angefallen sind. Die Anzahlungen sind mit den tatsächlich geleisteten Beträgen und die Anlagen im Bau sind mit den Anschaffungsoder Herstellungskosten anzusetzen.

## 3.5.3 Finanzanlagen

Finanzanlagen sind Anteile an verbundenen Unternehmen, Beteiligungen an Unternehmen und Ausleihungen (z. B. Darlehens- und Hypothekenforderungen), die von  langfristiger  Natur  sind  und  nicht  nur  vorübergehend  gehalten  bzw.  gewährt werden sollen, sowie Wertpapiere des Anlagevermögens. Die Finanzanlagen lassen sich  in  die  Anteilsfinanzierung  und  die  Darlehensfinanzierung  aufteilen.  Bei  der Anteilsfinanzierung  ist  das  Unternehmen Anteilseigner,  d.  h.  das  investierte  Kapital wird im anderen Unternehmen, an dem eine Beteiligung gehalten wird, als Eigenkapital aufgeführt. Dies kommt bei Anteilen, Beteiligungen und Wertpapieren vor. Handelt es sich bei der Investition um Ausleihungen, spricht man von einer Darlehensfinanzierung.  Dabei  wird  das  investierte  Kapital  in  dem  nehmenden Unternehmen als Fremdkapital ausgewiesen.

3.5.3.1 Anteile an verbundenen Unternehmen Verbundene Unternehmen im Sinn des HGB  sind  solche  Unternehmen,  die  zwar  rechtlich  selbstständig  sind,  aber  im Verhältnis einer Mutter- und Tochtergesellschaft zueinanderstehen. Sie sind gemäß § 290 HGB in den Konzernabschluss einzubeziehen.

3.5.3.2 Ausleihungen an verbundene Unternehmen Sie stellen langfristige Finanzforderungen (i. d. R. über eine Dauer von mindestens 12 Monaten) gegenüber verbundenen Unternehmen dar. Bei den Ausleihungen an verbundene Unternehmen kann sich die Forderung sowohl von der Tochtergesellschaft an die Muttergesellschaft als  auch  von  der  Muttergesellschaft  an  die  Tochtergesellschaft  richten.22  3.5.3.3 Beteiligungen Beteiligungen sind Anteile an Unternehmen, die die Voraussetzungen des § 271 Abs. 1 HGB, nicht aber die des § 271 Abs. 2 HGB erfüllen. Nach § 271 Abs. 1  HGB  sind  Beteiligungen Anteile,  bei  denen  die  wirtschaftliche  und  nicht  die  rein finanzielle Verbindung im Vordergrund steht. Wenn die Anteile 20 % des Nennkapitals einer Kapitalgesellschaft überschreiten, geht man von einer Beteiligung aus. Allerdings gilt, dass die Anteilsrechte des Nennkapitals jedoch nicht mehr als 50 % (da es sich sonst um ein verbundenes Unternehmen handeln würde) betragen dürfen, damit eine Beteiligung an einer Kapitalgesellschaft besteht. 3.5.3.4 Ausleihungen an Beteiligungsunternehmen Der vierte Posten der Finanzanlagen heißt Ausleihungen an Unternehmen, mit denen ein Beteiligungsverhältnis besteht. Dabei handelt es sich um langfristige Finanzforderungen gegenüber den oben beschriebenen Beteiligungsunternehmen.

## 3.5.3.5 Wertpapiere des Anlagevermögens

Bei  den  Wertpapieren  des Anlagevermögens  handelt  es  sich  um  eine  langfristige Kapitalanlage. In der Regel dürfen die Anteile an anderen Unternehmen 20 % nicht übersteigen, damit sie den Wertpapieren des Anlagevermögens zugeordnet werden können. Als Beispiele können Aktien, Anleihen, Pfandbriefe, Wandelschuldverschreibungen, Investmentanteile oder Zero Bonds genannt werden.

## 3.5.3.6 Sonstige Ausleihungen

Dies  sind  langfristige  Kapitalüberlassungen  an  Dritte  in  Form  von  Darlehen  oder Krediten.  Das  bilanzierende  Unternehmen  ist  Gläubiger  einer  Finanzforderung  mit einer  Mindestlaufzeit  von  mehr  als  einem  Jahr.  3.6  Ausgewählte  Posten  des Umlaufvermögens Das Umlaufvermögen umfasst alles, was nicht zum Anlagevermögen, zu den aktiven Rechnungsabgrenzungsposten, den aktiven latenten Steuern  und  dem  aktiven  Unterschiedsbetrag  aus  der  Vermögensrechnung  zählt. Unter dem Umlaufvermögen werden alle Vermögensgegenstände erfasst, die nur kurz im  Unternehmen  verbleiben.  Es  erfolgt  die  Erläuterung  der  einzelnen  Posten  des Umlaufvermögens.

## 3.6.1 Vorräte

Unter Vorräten werden die Lagerbestände verstanden; sie umfassen: Roh-, Hilfsund Betriebsstoffe: Fremdbezogene, unverarbeitete Stoffe, die mittel- oder unmittelbar in Erzeugnisse eingehen. Rohstoffe stellen die Hauptbestandteile (z. B. Blech, Glas, Holz, Kunststoff), Hilfsstoffe die Nebenbestandteile (z. B. Farbe, Nägel, Schrauben, Kleber) dar.

Betriebsstoffe sind kein Bestandteil der  Erzeugnisse  (z.  B.  Strom,  Kühlmittel, Schmierstoffe  etc.),  sondern  werden  bei  der  Herstellung  verbraucht. Unfertige

Erzeugnisse: Vermögensgegenstände, die sich im Produktionsprozess befinden, noch nicht verkaufsfähig sind, aber bereits Aufwendungen (Fertigungs-, Materialkosten etc.) verursacht haben. Unfertige Leistungen: Aufträge, die sich bei Dienstleistungsunternehmen  in  Bearbeitung  befinden  und  vom  Kunden  noch  nicht abgenommen  wurden. Fertige Erzeugnisse: Selbst erstellte, versandfertige Vermögensgegenstände, die den Produktionsprozess schon vollständig durchlaufen haben. Waren (Handelswaren): Fremdbezogene Vorräte, die ohne wesentliche Bebzw. Verarbeitung zum Verkauf bestimmt sind. Geleistete Anzahlungen: Vorleistung auf eine, vom anderen Vertragsteil, zu erbringende Leistung, d. h. die Lieferung ist bis zum Bilanzstichtag vom Lieferanten noch nicht erfolgt.

## 3.6.2 Forderungen und sonstige Vermögensgegenstände

Eine Forderung entsteht grundsätzlich, wenn die geschuldete Leistung erbracht und die  Abrechnungsfähigkeit  gegeben  sind.  Sie  erlischt  bei  Erfüllung,  Aufrechnung, Erlass, Verkauf (Factoring), befreiender Schuldübernahme und Novation (Schuldumwandlung). Forderungen aus Lieferungen und Leistungen: Unter diesem Posten werden all jene Forderungen zusammengefasst, die aus der Umsatztätigkeit des  Unternehmens  resultieren.  Bewertet  werden  die  Forderungen  aLuL  zu  ihren Anschaffungskosten  inkl.  der  Umsatzsteuer,  jedoch  nach  Abzug  von  Rabatten, Gutschriften  oder  sonstigen  Preisnachlässen. Sonstige  Vermögensgegenstände: Dieser Sammelposten enthält alle Vermögensgegenstände eines Unternehmens, die sich keinem anderen Posten zuordnen lassen, wie z. B. Lohn- und Gehaltsvorschüsse, Kautionen, Steuererstattungsansprüche, Ansprüche auf Zulagen/Zu schüsse, Schadenersatzansprüche, Personaldarlehen und Ansprüche auf Boni.

## 3.6.3 Wertpapiere

Zu den Wertpapieren des Umlaufvermögens gehören alle Wertpapiere, die nicht im Anlagevermögen enthalten sind. Wertpapiere des Umlaufvermögens gehören zu den kurzfristigen Finanzanlagen, die jederzeit veräußert werden können. Es wird unterschieden zwischen: Anteile an verbundenen Unternehmen: Zum Umlaufvermögen gehören solche Anteile nur dann, wenn nur eine kurzfristige Anlage geplant  ist. Sonstige  Wertpapiere: Alle  Wertpapiere,  von  denen  ein Ausweis  an anderer Stelle nicht möglich ist.

- 3.6.4  Kassenbestand,  Bundesbankguthaben,  Guthaben  bei  Kreditinstituten  und Schecks Dies sind die flüssigen Mittel. Der Kassenbestand und die Bankguthaben sind zum  Nominalbetrag  anzusetzen.  Die  Schecks  sind  wie  Forderungen  zu  bewerten. Fremdwährungsbestände sind gemäß § 256a HGB mit dem Devisenkassamittelkurs am Bilanzstichtag umzurechnen. Die flüssigen Mittel können jederzeit in eine andere Vermögensform umgewandelt werden.
- 3.7 Aktive Rechnungsabgrenzungsposten Unter der Position 'Rechnungsabgrenzungsposten' sind nur sogenannte transitorische Posten auszuweisen  und  ausweispflichtig.  Ein  aktiver  Rechnungsabgrenzungsposten  wird gebildet,

wenn Ausgaben vor dem Abschlussstichtag, Aufwendungen für eine bestimmte Zeit nach dem Abschlussstichtag darstellen (z. B. Miet-, Pachtvorauszahlung, Versicherungsprämie, Honorare und Gebühren etc., die im Voraus bezahlt wurden).

## 3.8 Aktive latente Steuern

Latente  Steuern  entstehen  durch  unterschiedliche  handels-  und  steuerrechtliche Bilanzierung. Im Handelsrecht besteht für die aktiven latenten Steuern ein Aktivierungswahlrecht. Aktive latente Steuern stellen einen Vermögenswert dar, der auf einer Steuermehrzahlung beruht und eine zukünftige Steuerminderung hervorruft. Somit stellen aktive latente Steuern eine zukünftige Steuerentlastung dar, die in der Handelsbilanz berücksichtigt werden kann (Wahlrecht). Aktive Steuerabgrenzung: Es erfolgt eine p eriodengerechte Berücksichtigung von Steueraufwand bei Bewertungsdifferenzen zwischen Handels- und Steuerbilanz. Wenn diese Differenzen in nachfolgenden Geschäftsjahren abnehmen und dadurch zu einer Steuerentlastung führen,  kann  die  Entlastung  als  aktive  latente  Steuer  bilanziert  werden.  Mögliche Ursachen  für aktive latente Steuern sind: In der Handelsbilanz sind die Vermögensgegenstände niedriger bewertet als die Wirtschaftsgüter in der Steuerbilanz, bzw. Aktivposten sind in der Steuerbilanz, aber nicht in der Handelsbilanz angesetzt. In der Handelsbilanz  sind  Schulden  höher  bewertet  als  in  der Steuerbilanz, bzw. Schulden sind in der Handelsbilanz, aber nicht in der Steuerbilanz angesetzt. Aktive  latente  Steuern  sind  aufzulösen,  sobald  die  Steuerentlastung eintritt oder mit ihr nicht mehr zu rechnen ist.

3.9 Aktiver Unterschiedsbetrag aus der Vermögensverrechnung Vermögensgegenstände, die ausschließlich der Erfüllung von Schulden aus Altersversorgungsverpflichtungen oder vergleichbaren langfristig fälligen Verpflichtungen dienen und dem Zugriff aller übrigen Gläubiger entzogen sind (§ 246 Abs. 2 HGB), werden mit dem Zeitwert bewertet. In der Bilanz ist der Nettowert der korrespondierenden Vermögensgegenstände und Schulden aus Altersvorsorgeverpflichtungen auszuweisen. Übersteigt der Wert des Vermögens die Schulden,  verlangt  §  246  Abs.  2  Satz  3  HGB  i.  V.  m.  §  266  Abs.  2  HGB  den gesonderten Ausweis des Saldos als letzten Posten auf der Aktivseite der Bilanz unter der  Bezeichnung  'Aktiver  Unterschiedsbetrag  aus  der  Vermögensverrechnung'.  Es werden  die  beizulegenden  Zeitwerte  der  zur  Absicherung  der  Ansprüche  der Mitarbeiter dienenden Vermögensgegenstände mit den Werten der Altersversorgungsverpflichtungen  (Rückstellungen)  des  Unternehmens  gegenüber den Mitarbeitern saldiert. Ein aktiver Restbetrag aus der Verrechnung ist unter dem Posten 'aktiver Unterschiedsbetrag aus der Vermögensverrechnung auszuweisen. Ein passiver Unterschiedsbetrag ist unter den Rückstellungen auszuweisen.23 3.10 Nicht durch  Eigenkapital  gedeckter  Fehlbetrag  Ein  nicht  durch  Eigenkapital  gedeckter Fehlbetrag stellt einen rechnerischen Gegenposten zum Eigenkapital bei bilanzieller Überschuldung (§ 268 Abs. 3 HGB) dar. Dieser Posten entsteht, wenn das Eigenkapital durch Verluste aufgezehrt und vollständig vernichtet wurde. Es besteht im Handelsrecht die Pflicht zum Ausweis auf der Aktivseite am Ende der Bilanz.

## 3.11 Ausgewählte Posten des Eigenkapitals

Das Eigenkapital ist die Differenz zwischen der Summe der Aktiva und der Summe der Schulden  abzüglich  der  passiven  Rechnungsabgrenzungsposten  und  der  passiven latenten  Steuern.  Die  Höhe  des  Eigenkapitals  ergibt  sich  erst  nach  Ansatz  und Bewertung der restlichen Bilanzposten. Die Summe der finanziellen Mittel, die eine Unternehmung von ihren Eigentümern bzw. Anteilseignern ohne zeitliche Begrenzung zur Verfügung gestellt werden, stellt das Eigenkapital dar. Bei einer Kapitalgesellschaft wird in dem Gliederungsschema der Bilanz (§ 266 Abs. 3 HGB) das Eigenkapital wie folgt  zusammengefasst  ausgewiesen:  A.  Eigenkapital  I.  Gezeichnetes  Kapital  II. Kapitalrücklage III. Gewinnrücklagen 1. gesetzliche Rücklage 2. Rücklage für Anteile an einem herrschenden oder mehrheitlich beteiligten Unternehmen 3. satzungsmäßige Rücklagen 4. andere Gewinnrücklagen IV. Gewinnvortrag/Verlustvortrag V. Jahresüberschuss/Jahresfehlbetrag VI. Bilanzgewinn/Bilanzverlust, davon

Ergebnisvortrag  gemäß  §  268  Abs.  1  HGB  (als  Alternative  zu  den  Posten  des Eigenkapitals  A.  IV.  und  A.  V.)  3.11.1  Gezeichnetes  Kapital  Unter  dem  Posten 'Gezeichnetes  Kapital' ist der  Teil des  Eigenkapitals einer Kapitalgesellschaft auszuweisen,  zu  dessen  Einzahlung  sich  die  Gesellschafter  oder  Mitglieder  eines Unternehmens verpflichtet haben und auf den die Haftung für die Verbindlichkeiten des Unternehmens  beschränkt  ist  (§  272  Abs.  1  HGB).  Dem  gezeichneten  Kapital entsprechen bei der AG das Grundkapital [= (Nennbetrag) ⨯ (Zahl der Anteile)], bei der GmbH das Stammkapital, und bei der Genossenschaft das Geschäftsguthaben  der  Genossen.  Das  Grundkapital  einer  AG  muss  mindestens 50.000 € und das Stammkapital einer GmbH muss mindestens 25.000 € betragen. Nicht  eingeforderte  ausstehende  Einlagen  sind  offen  vom  gezeichneten  Kapital abzusetzen.

3.11.1.1 Ausstehende Einlagen Die nicht eingeforderten ausstehenden Einlagen sind zwingend vom gezeichneten Kapital offen abzusetzen. In der Hauptspalte der Bilanz wird  der  verbleibende  Betrag,  das  eingeforderte  Kapital,  unter  dieser  Bezeichnung ausgewiesen. Korrespondierend dazu ist der eingeforderte, aber noch nicht einbezahlte Betrag unter den Forderungen gesondert auszuweisen und entsprechend zu bezeichnen. Beispiel: Ausstehende Einlagen Von den ausstehenden Einlagen in Höhe von 700.000 € wurden 300.000 € eingefordert. Der folgende Bilanzausschnitt zeigt den Nettoausweis.

## 3.11.1.2 Ausweis von eigenen Anteilen

Der  Erwerb  eigener Anteile  stellt,  wirtschaftlich  betrachtet,  eine  Rückzahlung  von Einlagen und damit eine Verringerung der Haftungssumme dar. Aus diesem Grund unterliegt dieser Erwerb bestimmten Restriktionen (z. B. ist er nach § 71 AktG auf 10 % des Grundkapitals beschränkt) und Ausweispflichten.24 Eigene Anteile werden in der Höhe des Nennwertes25 oder des rechnerischen Wertes auf der Passivseite offen vom  gezeichneten  Kapital  abgesetzt.  Die  Differenzen  zu  den Anschaffungskosten werden mit den frei verfügbaren Rücklagen verrechnet. Nebenkosten des Kaufes und der Veräußerung von eigenen Anteilen sind gemäß § 272 Abs. 1a Satz 3 HGB und § 272 Abs. 1b Satz 4 HGB unmittelbar erfolgswirksam zu behandeln. Die Veräußerung der  eigenen  Anteile  wird,  im  Gegenzug  zum  Erwerb  der  eigenen  Anteile,  als Kapitalerhöhung behandelt. Verbleibt nach Rückgängigmachung der Verrechnung mit den frei verfügbaren Rücklagen noch ein Differenzbetrag, ist dieser in die Kapitalrücklage einzustellen.

- 3.11.2 Offene Rücklagen Die offenen Rücklagen unterscheiden sich in: Kapitalrücklage (Zuführung nicht erwirtschafteter Beträge von außen) und Gewinnrücklagen (Zuführung erwirtschafteter Beträge von innen).

3.11.2.1 Kapitalrücklage Als Kapitalrücklage sind im Einzelnen auszuweisen (§ 272 Abs.  2  HGB): Beträge,  die  bei  der Ausgabe  von Anteilen  über  den  Nennbetrag hinaus erzielt wurden (§ 272 Abs. 2 Nr. 1 HGB) (also die Differenz von Emissionskurs und Nennwert = Agio). Zuweisung von Agio-Beträgen bei der Emission (Ausgabe) von Wandel- und Optionsschuldverschreibungen über ihrem Rückzahlungsbetrag. Zuzahlungen,  die  Gesellschafter  gegen  Gewährung  eines  Vorzugs  für  ihre Anteile leisten (Zuzahlung von Gesellschaftern für Vorzugsrechte); andere Zuzahlungen, die Gesellschafter in das Eigenkapital leisten (Zahlungen bei Sanierungen, Nachschüsse  bei  der  GmbH).  Beispiel:  Einstellung  in  die  Kapitalrücklage  Die expandierende aim-AG erhöht ihr gezeichnetes Kapital um 200.000 € durch Ausgabe junger (neuer) Aktien . Für die Ausgabe der jungen Aktien (=Emission) schreibt die Bank  der aim-AG  300.000  €  (Ausgabekurswert) gut. Das  Aufgeld (Agio bei Aktienausgabe) in Höhe von 100.000 € ist der Kapitalrücklage zuzuführen und wie folgt zu buchen. Buchungssatz: Bank 300.000 an an gezeichnetes Kapital Kapitalrücklage 200.000 100.000 Für welche Zwecke kann die Kapitalrücklage verwendet werden? Zum  Ausgleich  eines  Jahresfehlbetrags/Verlustvortrags,  sofern  dieser  nicht  durch Auflösung  anderer  Gewinnrücklagen  gedeckt  werden  kann  (§  150  Abs.  3  AktG). Umwandlung in Grundkapital durch Gewährung von Berichtigungsaktien (Kapitalerhöhung aus Gesellschaftsmitteln), falls gesetzliche Rücklage und Kapitalrücklage zusammen 10 % des gezeichneten Kapitals übersteigen (§ 150 Abs. 4 Nr. 3 AktG). Beispiel: Kapitalerhöhung aus Gesellschaftsmitteln bei der Patrizia AG Augsburg,  10. Juli  2014  -  Die  ordentliche  Hauptversammlung  der  PATRIZIA Immobilien  AG  (ISIN  DE000PAT1AG3)  vom  27.  Juni  2014  hat  beschlossen,  das Grundkapital der Gesellschaft aus Gesellschaftsmitteln von 63.077.300,00 Euro um 6.307.730,00 Euro auf 69.385.030,00 Euro nach den Vorschriften der §§ 207 ff. AktG zu erhöhen. Die Kapitalerhöhung erfolgt durch Umwandlung eines Teilbetrags in Höhe von 6.307.730,00 Euro der in der Jahresbilanz der Gesellschaft zum 31. Dezember 2013 ausgewiesenen Kapitalrücklage in Grundkapital. Die Kapitalerhöhung wird durch Ausgabe von 6.307.730 neuen auf den Namen lautenden Stückaktien

(Berichtigungsaktien) mit einem rechnerischen Anteil am Grundkapital von 1,00 Euro je Aktie durchgeführt, die an die Aktionäre der PATRIZIA Immobilien AG im Verhältnis 10:1 ausgegeben  werden. Die neuen  Aktien sind ab dem  1. Januar 2014 gewinnberechtigt. Die entsprechende Satzungsänderung ist am 3. Juli 2014 in das Handelsregister der Gesellschaft beim Amtsgericht Augsburg eingetragen und damit wirksam geworden. Das Grundkapital der Gesellschaft beträgt nunmehr 69.385.030,00  Euro  und  ist  eingeteilt  in  69.385.030  auf  den  Namen  lautende Stückaktien. Die Transaktion wird von der VEM Aktienbank AG, München, begleitet.

3.11.2.2 Gewinnrücklagen In den Gewinnrücklagen werden die kumulierten thesaurierten (einbehaltenen) Gewinne nach Steuern, die im laufenden Geschäftsjahr oder in früheren Geschäftsjahren gebildet wurden, eingestellt. Dabei wird unterschieden zwischen: gesetzliche Rücklage bei der AG: Gemäß § 150 Abs. 2 AktG  sind  in  die  gesetzliche  Rücklage  so  lange  5  %  des  Jahresüberschusses einzustellen,  bis  diese  zusammen  mit  der  Kapitalrücklage  10  %  des  Grundkapitals erreicht hat. Ist aus den Vorjahren ein Verlustvortrag vorhanden, ist der Jahresüberschuss vor Verwendung entsprechend zu kürzen. gesetzliche Rücklage bei der Unternehmerg esellschaft (haftungsbeschränkt): Es sind 25 % des, um einen Verlustvortrag aus dem Vorjahr gemilderten, Jahresüberschusses einzustellen, bis das Stammkapital einer GmbH nach § 5 GmbHG von mindestens 25.000 € erreicht ist. Rücklage für Anteile an einem herrschenden oder mehrheitlich beteiligten Unternehmen: Für diese Anteile ist eine Rücklage zu bilden. In die Rücklage ist ein Betrag einzustellen, der dem auf der Aktivseite der Bilanz für diese Anteile entspricht. satzungsmäßige Rücklagen: Wird die Rücklagenbildung durch die Satzung einer AG oder  den  Gesellschaftsvertrag  einer  GmbH  bestimmt,  so  handelt  es  sich  um satzungsmäßige Rücklagen. Es können den satzungsmäßigen Rücklagen bestimmte Beträge aus dem Jahresüberschuss zugeführt werden. andere Gewinnrücklagen: Dies ist der Sammelposten all jener Rücklagen, die aus dem Jahresüberschuss ohne gesonderten Bilanzausweis eingestellt werden. Gesetzliche Rücklagen sind Rücklagen, die gesetzlich vorgeschrieben sind. In die gesetzliche Rücklage einer AG oder einer KGaA sind jährlich einzustellen 5 % des ggf. um einen Verlustvortrag des Vorjahres  geminderten  Jahresüberschusses,  bis  die  gesetzliche  Rücklage  und  die Kapitalrücklage zusammen 10 % des Grundkapitals erreichen (§ 150 Abs. 2 AktG). Beispiel:  Einstellung  in  die  gesetzliche  Rücklage  Die  Dienstleistungs-AG  hat  ein Grundkapital von 5.000.000 €. Die gesetzliche Rücklage einschließlich Kapitalrücklage beträgt am Schluss des Vorjahres 300.000 €. Im abgelaufenen Geschäftsjahr haben die Erträge 20.000.000 € und die Aufwendungen 19.000.000 € betragen. Es ist ein Verlust aus dem Vorjahr von 200.000 € vorhanden. Berechnung der Einstellung der gesetzlichen  Rücklage:  Erträge  20.000.000  €  -  Aufwendungen  -19.000.000  €  = Jahresüberschuss = 1.000.000 € - Verlustvortrag -200.000 € = Berechnungsgrundlage = 800.000 € davon 5 % = Einstellung in die gesetzliche Rücklage = 40.000 € Diese 40.000  €  sind  in  die  gesetzliche  Rücklage  einzustellen,  da  die  bisher  gebildete gesetzliche  Rücklage  den  zehnten  Teil  des  Grundkapitals  noch  nicht  erreicht  hat. 3.11.2.3  Gewinn-/Verlustvortrag  Unter  diesem  Posten  werden  nicht  verwendete Gewinne oder nicht ausgeglichene Verluste aus den Vorjahren vorgetragen. Falls das Vorjahr mit einem Verlust abgeschlossen wurde, wird dieser Verlust unter dem Posten 'Verlustvortrag' ausgewiesen. Im Falle eines nicht komplett ausgeschütteten

Bilanzgewinns im Vorjahr wird, in dem  Posten 'Gewinnvortrag', der Betrag aufgenommen, der nach einer Gewinnausschüttung bzw. Zuführung zu den Gewinnrücklagen  übrig  geblieben  ist.  Der  Gewinn-/Verlustvortrag  wird  wie  folgt ermittelt:  Jahresüberschuss/-fehlbetrag  +/-  Gewinnvortrag/Verlustvortrag  aus  dem Vorjahr + Entnahmen aus der Kapitalrücklage + Entnahmen aus den Gewinnrücklagen = Gewinnvortrag/Verlustvortrag  Diese  40.000  €  sind  in  die  gesetzliche  Rücklage einzustellen,  da  die  bisher  gebildete  gesetzliche  Rücklage  den  zehnten  Teil  des

- -Einstellung in die Gewinnrücklagen -auszuschüttender Betrag Grundkapitals noch nicht erreicht hat.

## 3.11.2.4 Jahresüberschuss/-fehlbetrag

Der Jahresüberschuss stellt den Gewinn des laufenden Geschäftsjahres nach Steuern vor  der  Gewinnausschüttung  dar.  Der  Jahresfehlbetrag  bildet  den  Verlust  des laufenden Geschäftsjahres nach Steuern ab. Diese Posten erscheinen nur dann in der Bilanz, wenn diese vor Verwendung des Jahresergebnisses aufgestellt wird. 3.11.2.5 Bilanzergebnis  (Bilanzgewinn/-verlust)  Die  Mindestgliederungsschemata  der  GuV sowie der Bilanz nach HGB (§§ 275 Abs. 2 und 3 bzw. 266 Abs. 3 HGB) enthalten lediglich  die  Posten  Jahresüberschuss  bzw.  -fehlbetrag.  Sofern  die  Bilanz  unter Berücksichtigung  der  teilweisen  Ergebnisverwendung  aufgestellt  wird,  werden  die Posten 'Jahresüberschuss/Jahresfehlbetrag' und 'Gewinn-/Verlustvortrag' durch die Posten 'Bilanzgewinn/Bilanzverlust' ersetzt.26 3.11.2.6 Ermittlung des Bilanzgewinns Bei Aktiengesellschaften wird das Jahresergebnis nach Steuern in der Regel bereits bei der Aufstellung der Bilanz auf Beschluss des Vorstandes teilweise verwendet und ist in der GuV oder im Anhang darzustellen. Der Ausweis des Bilanzgewinns bedeutet, dass  der  Vorstand  von  seinem  Recht  Gebrauch  gemacht  hat,  einen  Teil  des Jahresüberschusses (bei Aktiengesellschaften gemäß § 58 AktG bis zu 50 %) in die Rücklagen einzustellen. Der Rest wird 'als Bilanzgewinn' der Hauptversammlung oder Gesellschafterversammlung zur Disposition gestellt, wobei oft ein Verwendungsvorschlag  gemacht  wird.  Den  zur  Ausschüttung  vorgesehenen  Teil rechnet man den kurzfristigen Verbindlichkeiten zu. Im Übrigen stellt der Bilanzgewinn Eigenkapital dar. Merke Der Bilanzgewinn ist der Gewinn, der zur Ausschüttung zur Verfügung steht. Der Bilanzverlust ist der Verlust, der das Eigenkapital reduziert, er wird  als  Korrekturposten  mit  negativem  Vorzeichen  ausgewiesen  und  wird  in  der nachfolgenden Periode als Verlustvortrag behandelt.

Der Bilanzgewinn wird wie folgt berechnet: Gewinnverwendung Kompetenzabgrenzung  bei  der  AG  Jahresüberschuss/-fehlbetrag  gesetzlich  oder satzungsmäßig  bestimmte  Beträge  +/-  Gewinn-/Verlustvortrag  aus  dem  Vorjahr  Einstellungen in die Gewinnrücklagen aufgrund von Gesetz und Satzung (§ 150 Abs. 2 AktG) + Entnahmen der Kapitalrücklage27 Kompetenz von Vorstand und Aufsichtsrat vor Jahresabschlussfeststellung + Entnahmen aus den Gewinnrücklagen28 -Einstellungen  in  die  Gewinnrücklagen  (§  58 Abs.  2  und  2a AktG) =  Bilanzgewinn/verlust Kompetenz  der  Hauptversammlung  nach  Jahresabschlussfeststellung -Einstellungen in die Gewinnrücklagen (§ 58 Abs. 3 AktG) - Gewinnvortrag ins neue Jahr (§ 58 Abs. 3 AktG) = Ausschüttung Abb. 3.7: Jahresüberschuss, Bilanzgewinn, Ausschüttung29  Nach  §  158  Abs.  1  Satz  1  AktG  sind  dem  Jahresergebnis  der Gewinnvortrag aus dem Vorjahr und Entnahmen aus der Kapitalrücklage oder aus Gewinnrücklagen hinzuzurechnen, während der Verlustvortrag aus dem Vorjahr und Einstellungen  in  die  Gewinnrücklagen  abzuziehen  sind.  Somit  errechnet  sich  das Bilanzergebnis nach folgendem Schema (§ 158 Abs. 1 Satz 1 AktG): Jahresüberschuss/Jahresfehlbetrag -Verlustvortrag (aus der Vorperiode) = Bemessungsgrundlage 1 - Pflichteinstellung in die gesetzliche Rücklage (so lange 5 %  von  der  positiven  Bemessungsgrundlage  1,  bis  gesetzliche  Rücklage  und Kapitalrücklage  zusammen  10  %  des  Grundkapitals  erreicht  haben)  =  korrigierter Jahresüberschuss: Bemessungsgrundlage 2 - Einstellung in andere Gewinnrücklagen (max.  50  %  der  positiven  Bemessungsgrundlage  2)  =  Bemessungsgrundlage  3  Einstellung  in  die  Rücklage  für  Anteile  an  einem  herrschenden  oder  mehrheitlich beteiligten Unternehmen -Einstellung in satzungsmäßige Rücklagen = Bemessungsgrundlage + Gewinnvortrag (aus der Vorperiode) + Entnahme aus der Kapitalrücklage + Entnahmen aus den Gewinnrücklagen = Bilanzgewinn/Bilanzverlust (Bilanzergebnis) Abb. 3.8: Ermittlung des Bilanzergebnisses.

3.11.2.7 Die Problematik beim Bilanzgewinn Der Bilanzgewinn ist einerseits für den Aktionär bedeutend, da er die Höhe der Dividende bestimmt. Andererseits sagt der Bilanzgewinn nichts über die Ertragskraft des Unternehmens aus. Der Bilanzgewinn kann, beispielsweise über Entnahmen aus den Gewinnrücklagen oder der Kapitalrücklage, ein negatives Jahresergebnis gut kaschieren , um so Aktionäre bei Laune zu halten (siehe Beispielrechnung unten). Ein gutes Beispiel hierfür ist die RWE AG,  die ihren  Aktionären für das Geschäftsjahr 2013, trotz eines negativen Nettoergebnisses in Höhe von -2.757 Mrd. €30, eine Dividende von einem Euro je Aktien ausgeschüttet haben. Die RWE AG wies einen Bilanzgewinn in Höhe von 615 Mio.  €  aus.  Beispiel:  Ausweis  eines  höheren  Bilanzgewinns  Die  ABC  AG  hat  im vergangenen  Geschäftsjahr einen Jahresüberschuss  in Höhe  von  30  Mio. € erwirtschaftet. Allerdings verfügt die ABC AG noch über einen Verlustvortrag in Höhe von  2  Mio.  €.  Damit  den Aktionären  wie  in  den  vergangenen  Jahren  wieder  eine Dividende in Höhe von 2 € je Aktie ausgeschüttet werden kann, muss der Bilanzgewinn 40  Mio.  €  betragen.  Um  einen  Bilanzgewinn  in  Höhe  von  40  Mio.  €  auszuweisen, entnimmt der Vorstand aus den Gewinnrücklagen 8 Mio. € und aus den Kapitalrücklagen noch weitere 4 Mio. €. Der Bilanzgewinn in Höhe von 40 Mio. € wird wie folgt ermittelt: Jahresüberschuss 30 Mio. € - Verlustvortrag -2 Mio. € + Entnahme aus den Gewinnrücklagen + 8 Mio. € + Entnahme aus der Kapitalrücklage + 4 Mio. € Einstellung in die Gewinnrücklagen 0 € = Bilanzgewinn = 40 Mio. € Der Bilanzgewinn der ABC AG in Höhe von 40 Mio. € liegt deutlich über dem Jahresüberschuss in Höhe von 30 Mio. €. Der Vorstand kann aufgrund der Entnahmen aus den offenen Rücklagen auf der Hauptversammlung einen Bilanzgewinn in Höhe von 40 Mio. € vorweisen. Auf der Hauptversammlung  entscheiden die  Aktionäre über die  Verwendung  des Bilanzgewinns. In der Regel erhalten die Aktionäre den Bilanzgewinn als Dividende.

## 3.11.3 Stille Rücklagen (stille Reserven)

Stille Rücklagen (Reserven) sind Rücklagen, die aus der Bilanz nicht ersichtlich sind. Sie können als Zwangs-, Ermessensund Willkürreserven vorkommen. Zwangsreserven entstehen durch gesetzliche Bilanzierungs -und

Bewertungsvorschriften  (z.  B.  darf  ein  Vermögensgegenstand  bei  einem  höheren Marktwert, wie bei Grundstücken oder Gebäuden) nicht über den Anschaffungs- oder Herstellungskosten  bewertet  werden). Ermessensreserven  resultieren  aus  der Ausübung von Wahlrechten (z. B. Nichtaktivierung von Entwicklungskosten oder dem Wahlrecht zur außerplanmäßigen Abschreibung bei einer voraussichtlich vorübergehenden Wertminderung gemäß § 253 Abs. 2 Satz 2 HGB bei Finanzanlagen). Unzulässig sind Willkürreserven. Sie basieren auf Verstößen gegen Bilanzierungs- und Bewertungsnormen (z. B. Ansatz von Vermögensgegenständen mit Werten, die unter den zulässigen handelsrechtlichen Wertuntergrenzen liegen, oder Bildung  unzulässig  hoher  Rückstellungen).  Stille  Reserven  stellen  den  positiven Unterschiedsbetrag zwischen dem tatsächlichen Wert eines Vermögensgegenstandes und  seinem  Bilanzwert  dar.  Sie  entstehen  durch  Unterbewertung  von Aktivposten (Vermögen)  und  Überbewertung  von  Passivposten  (Schulden).  Beispiele  für  stille Reserven  a)  Ein  Unternehmer  hat  vor  zehn  Jahren  ein  unbebautes  Grundstück gekauft. Die Anschaffungskosten betrugen 20.000 €. Heute hat das Grundstück infolge von Preissteigerungen einen Wert von 50.000 €. In der Bilanz darf das Grundstück nur mit  den  Anschaffungskosten  von  20.000  €  angesetzt  werden.  Die  zwangsläufig gebildete stille Reserve beträgt 30.000 €. b) Ein Unternehmen entscheidet sich für die Nichtaktivierung  der  selbstgeschaffenen  immateriellen  Vermögenswerte  oder  der Nichtaktivierung von geringwertigen Wirtschaftsgütern. c) Ein Unternehmen wählt bei kontinuierlich steigenden Preisen für die Rohstoffe als Bewertungsmethode das Lifo Verfahren.  Dies  bedeutet,  dass  die  Bestände  der  vorhandenen  Rohstoffe  mit  den ältesten, d. h. den niedrigeren Einkaufspreisen bewertet werden. Dadurch entstehen stille Reserven, da der tatsächliche Wert der Rohstoffe höher ist als die Rohstoffe in der Bilanz ausgewiesen sind. 3.12 Ausgewählte Posten des Fremdkapitals Schulden stellen  Fremdkapital dar. Das Fremdkapital wird von Dritten zur Verfügung gestellt. Diese haben Ansprüche auf Zahlungen jedoch ohne Beteiligungsrechte (z. B. Banken, Lieferanten, Inhaber von Anleihen). Das Fremdkapital setzt sich aus Rückstellungen und Verbindlichkeiten zusammen.

## 3.12.1 Rückstellungen

Rückstellungen sind Verpflichtungen eines Unternehmens, die am Abschlussstichtag zwar dem Grunde nach, aber hinsichtlich der Höhe und/oder des Fälligkeitszeitpunkts, noch nicht genau.

Sie  dienen  der  periodengerechten  Erfolgsermittlung  des  Jahresabschlusses  und stellen spätere Ausgaben dar, die bereits am Abschlussstichtag als Aufwand erfasst werden.  Grundsätzlich  lassen  sich  Rückstellungen  in  zwei  Arten  unterscheiden. Rückstellungen aufgrund von Außenverpflichtungen und Rückstellungen aufgrund von Innenverpflichtungen. 3.12.1.1  Rückstellungsarten Verbindlichkeitsrückstellungen: Es besteht eine rechtliche oder faktische Außenverpflichtung, d. h. eine Inanspruchnahme ist wahrscheinlich und die rechtliche Entstehung bzw. wirtschaftliche Verursachung lag vor dem Bilanzstichtag (§ 249 Abs. 1 Satz 1, 2 und Nr. 2 HGB).  Hierbei handelt es sich beispielsweise um  Pensions-, Steuer-, Prozesskosten-, Kulanz-, Drohverlustoder Garantierückstellungen. -Drohverlustrückstellungen: Antizipation von Verlusten aus schwebenden Geschäften (§  249  Abs.  1  Satz  1  HGB;  steuerlich  nicht  zulässig).  Voraussetzungen  wie  bei Verbindlichkeitsrückstellung.  -  Kulanzrückstellungen:  Sie  sind  zu  bilden,  wenn  ein Unternehmen über die gesetzlichen Verpflichtungen hinaus freiwillig Gewährleistungen übernimmt.

Aufwandsrückstellungen: Hierbei handelt es sich um eine Innenverpflichtung, d. h. es besteht eine Schuld gegenüber  sich selbst, welche  als  Aufwandsrückstellung bezeichnet  wird.  Hier  hat  der  Gesetzgeber  in  §  249  Abs.  1  Nr.  1  HGB  eine abschließende Vorschrift erlassen, für welche Arten der Innenverpflichtung Rückstellungen  gebildet  werden  dürfen,  z.  B.  für  unterlassene  Instandhaltung,  die innerhalb der ersten drei Monate des folgenden Geschäftsjahres nachgeholt wird, oder für Abraumbeseitigung, die im folgenden Geschäftsjahr nachgeholt wird. In Abbildung 3.9 wurden die Rückstellungen anhand ihres Verpflichtungscharakters systematisiert. 3.12.1.2 Ausweis der Rückstellungen in der Handelsbilanz In dem § 264a HGB ist der bilanzielle Ausweis der Rückstellungen für Kapitalgesellschaften und haftungsbeschränkte Personengesellschaften (KapCoRiLiG, z. B. GmbH &amp; Co. KG) geregelt.  Demnach  müssen  die  Rückstellungen  nach  §  266  Abs.  3  HGB  in  drei Unterposten  ausgewiesen  werden: Rückstellungen  für  Pensionen  und  ähnliche Verpflichtungen, Steuerrückstellungen und sonstige Rückstellungen. Auf den

Posten der sonstigen Rückstellungen muss gemäß § 285 Nr. 12 HGB im Anhang näher eingegangen werden, soweit diese einen nicht unerheblichen Umfang haben. Kleine Kapitalgesellschaften und Kleinstkapitalgesellschaften können gemäß § 266 Abs. 1 Satz 3 HGB alle Rückstellungen unter einem Posten ausweisen und müssen diese auch nicht näher erläutern. 3.12.1.3 Beispiele: Häufige rückstellungspflichtige Sachverhalte Pensionsrückstellungen - Dies sind Rückstellungen für unmittelbare Versorgungsleistungen (Alters-, Invalidenund Hinterbliebenenversorgung) gegenüber versorgungsberechtigten Arbeitnehmern. Pensionsverpflichtungen entstehen, wenn ein Unternehmen seinen Arbeitnehmern bzw. anderen Personen die Zusage auf einmalige (Kapitalzusage) oder wiederkehrende Geldoder Sachleistungen (Rentenzusage) gibt, die ihnen nach Beendigung der Erwerbstätigkeit gewährt werden. Im Regelfall erfolgt die Rentenzahlung lebenslänglich bis zum Tode des  Empfängers,  sie  kann  aber  auch  befristet  sein.  Diese  Rückstellungen  können ebenso  als  Leistungen  für  die  Versorgung  bei  Invalidität  oder  Hinterbliebenen angesehen werden, hauptsächlich beschränken sie sich aber auf die Altersversorgung.32 Steuerrückstellungen - Die Höhe der Steuerrückstellung ergibt sich aus der Differenz zwischen der voraussichtlichen Jahressteuerschuld und den bis zum Abschlussstichtag  schon  geleisteten  Vorauszahlungen.33 Zu  den  sonstigen Rückstellungen gehören beispielsweise: -Gratifikationen (Tantiemen, Gewinnbeteiligungen): Diese sind rückstellungspflichtig, sofern vor dem Abschlussstichtag  den  Arbeitnehmern  eine  Erfolgsprämie  zugesagt  wurde.  Die Erfolgsprämie ist z. B. an den Jahresüberschuss oder das EBIT geknüpft. - Urlaub: Häufig  ist  es  nicht  möglich,  dass  die  Arbeitnehmer  ihren  Urlaub  im  laufenden Geschäftsjahr  in  Anspruch  nehmen.  Für  die  Verpflichtung  des  Arbeitgebers  zur Gewährung von bezahltem Alturlaub im folgenden Geschäftsjahr ist eine Rückstellung zu bilden, da dem für diese Zeit gezahlten Gehalt keine Arbeitsleistung seitens des Arbeitnehmers  gegenübersteht.  Die  Urlaubsrückstellungen  sind  in  Höhe  der  zu zahlenden Lohnund Gehaltsanteile einschließlich Sozialabgaben, Nebenverpflichtungen  (Urlaubs-  und  Weihnachtsgeld,  Altersversorgung  etc.)  zu bilden.

Überstunden: Für diese Mehrstunden, die erst im folgenden Geschäftsjahr entweder abgebaut oder ausbezahlt werden, sind Rückstellungen für ungewisse Verbindlichkeiten zu bilden. Diese Rückstellungen sind genauso zu bewerten wie die Urlaubsrückstellungen. - Berufsgenossenschaftsbeiträge: Für Unternehmen besteht gesetzlich  die  Verpflichtung  zur  Mitgliedschaft  in  der  Berufsgenossenschaft.  Die Jahresbeiträge bemessen sich nach den Jahresbruttoentgelten, die erst nach dem Abschlussstichtag  feststehen  und  erst  dann  an  den  Versicherungsträger  gemeldet werden können. Die Beiträge sind regelmäßig im Mai des folgenden Geschäftsjahres fällig. Die Rückstellung ist in Höhe der für das abgelaufene Geschäftsjahr zu leistende Beiträge  zu  bilden.  -  Jubiläumsaufwendungen:  Handelsrechtlich  sind  für  sämtliche rechtsverbindlich zugesagten Leistungen des Arbeitgebers anlässlich von Dienstjubiläen der Arbeitnehmer Rückstellungen zu bilden. Dadurch wird der Aufwand für  die  Jubiläumsgeldzahlungen  in  die  Jahre  verlagert,  in  denen  er  wirtschaftlich verursacht wurde, d. h. in denen der Arbeitnehmer seine Arbeitsleistung erbracht hat. Die Jubiläumsgeldzahlung ist quasi ein nachträgliches Entgelt für geleistete Arbeit. Freistellung und  Ausscheiden von Mitarbeitern: Vereinbaren Arbeitgeber und Arbeitnehmer vor dem Abschlussstichtag die Beendigung des Arbeitsverhältnisses, so können  hieraus  rückstellungspflichtige  Sachverhalte  resultieren.  Eine  im  Folgejahr fällige Abfindung ist zurückzustellen. Wird ein Arbeitnehmer für eine bestimmte Zeit im neuen Jahr bis zum Ende des Arbeitsverhältnisses von der Arbeitsleistung freigestellt, so ist  zum anderen für sämtliche auf diesen Zeitraum entfallenden Personalkosten (Lohn und Gehalt, Sozialversicherungsanteil des Arbeitgebers, anteiliges Urlaubs- und Weihnachtsgeld  etc.)  eine  Rückstellung  zu  bilden.  -  Gewährleistung:  Beruht  eine Garantieleistung auf einer verbindlichen Zusage gegenüber dem Kunden, so liegt eine rückstellungspflichtige Verpflichtung vor. - Kulanz: Kulanzrückstellungen sind gemäß § 249 A bs. 1 Satz 2 Nr. 2 HGB zu bilden für Gewährleistungen, die ohne rechtliche Verpflichtungen erbracht werden. -Prozessrisiko und Prozesskosten: Eine Rückstellung, bei der die tatsächliche Inanspruchnahme in der Regel ungewiss ist. Ihre Bildung steht nicht im Ermessen des Kaufmanns. Muss er nach den Verhältnissen am Abschlussstichtag damit rechnen, dass ein Kunde gegen ihn Schadensersatzansprüche geltend machen wird, so muss er eine Rückstellung bilden. -Buchführung  und  Jahresabschluss:  Der Jahresabschluss  wird im Folgejahr aufgestellt und geprüft. Wegen der gesetzlichen Verpflichtung liegen hier der Höhe nach ungewisse Verbindlichkeiten vor, die zurückzustellen sind. Hierzu gehören die Kosten  der  Inventurdurchführung,  die  eigentlichen  Abschlussarbeiten,  Kosten  des Abschlussprüfers sowie die Kosten der Veröffentlichung beim elektronischen Bundesanzeiger.  -  Ausstehende  Rechnungen:  Rechnungen  von  Lieferanten  für Wareneingänge  vor  dem  Abschlussstichtag,  die  bis  zum  Buchungsschluss  nicht

vorliegen oder nicht mehr erfasst werden können, müssen entweder als Verbindlichkeit aus Lieferungen und Leistungen oder sofern Ungewissheit bezüglich des Eingangs und/oder  Höhe  besteht  -  als  Rückstellung  für  ungewisse  Verbindlichkeit  bilanziert werden. - Abbruchkosten: Besteht eine vertragliche Verpflichtung zum Abbruch von Gebäuden auf fremdem Grund und Boden, ist eine Rückstellung für die voraussichtlichen Abbruchkosten zu bilden. -Instandhaltungsund Abraumbeseitigungsrückstellungen: Diese Aufwandsrückstellungen stellen eine Verpflichtung des Unternehmens gegen sich selbst dar. Handelsrechtlich besteht eine Bilanzierungspflicht, sofern die unterlassene Instandhaltung im folgenden Geschäftsjahr innerhalb von drei Monaten nachgeholt wird bzw. die Abraumbeseitigung im folgenden Geschäftsjahr vorgenommen wird (§ 249 Abs. 1 Satz 2 Nr. 1 HGB).

## Gewinn- und Verlustrechnung

Lernziele Nachdem Sie dieses Kapitel bearbeitet haben, werden Sie wissen, was eine Gewinn-  und  Verlustrechnung  (GuV)  ist,  wie  diese  aufgebaut  ist  und  welche Aussagekraft  eine  GuV  hat.  Ferner  lernen  Sie  den  Unterschied  zwischen  der Kontoform und der Staffelform mit den Varianten des Gesamtund Umsatzkostenverfahrens der GuV kennen. Sie werden erfahren, welche Posten sich in  der  GuV  befinden  und  wie  sie  gegliedert  ist,  sowie  die  größenabhängigen Erleichterungen kennenlernen. 7.1 Einführung Im Gegensatz zur zeitpunktbezogenen Bilanz handelt es sich bei der Gewinnund Verlustrechnung um eine Zeitraumrechnung, die der Erfolgsanalyse des Unternehmens dient. Die Gewinn- und Verlustrechnung  (GuV)  gibt Auskunft  über  die  Erfolgslage  des  Unternehmens.  Sie erfasst die Erträge und Aufwendungen der jeweiligen Geschäftsperiode unabhängig davon, wann die entsprechenden Ein- und Auszahlungen stattfinden. Der § 242 Abs. 2 HGB schreibt für alle Kaufleute verpflichtend vor, dass der Kaufmann für den Schluss eines  jeden  Geschäftsjahres  die Aufwendungen  und  Erträge  des  Geschäftsjahres gegenüberzustellen hat. Der Saldo zwischen den Erträgen und den Aufwendungen zeigt den Jahreserfolg (Gewinn und Verlust) wieder. Dieser Saldo erscheint dann in einer Summe auch in der Bilanz und erhöht bei einem Gewinn oder vermindert bei einem Verlust das Eigenkapital. Die GuV kann entweder in der Konto- oder in der Staffelform aufgestellt werden. Die folgende Abbildung zeigt die GuV in der Kontoform. Gewinn-  und  Verlustrechnung  in  Kontoform Aufwendungen  Erträge Aufwandsarten

Saldo = Gewinn

\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_

Ertragsarten

(Saldo

=

Verlust)

\_\_\_\_\_\_\_\_\_\_\_  \_\_\_\_\_\_\_\_\_\_\_  Summe  \_\_\_\_\_\_\_\_\_\_  Summe  \_\_\_\_\_\_\_\_\_\_\_ Abb.  7.1:

Gewinn- und Verlustrechnung in Kontoform Bei der GuV in der Kontoform fehlt die Möglichkeit, zusammenhängende Erfolgskomponenten in Zwischensummen zusammenzufassen. Deshalb ist für die Gewinnund Verlustrechnung der Kapitalgesellschaften  die  Staffelform  entweder  nach  dem  Gesamtkostenverfahren oder nach dem Umsatzkostenverfahren als Gliederungsschema gesetzlich vorgeschrieben  (§  275 Abs.  1  Satz  1  HGB).  Bei  der  Staffelform  können  sachlich zusammengehörige Aufwands-  und  Ertragsposten  zusammengefasst  und  jeweilige Zwischensummen (z. B. Betriebsergebnis, Finanzergebnis, Ergebnis nach Steuern) ausgewiesen werden.

Beim Gesamtkostenverfahren erfolgt die Gegenüberstellung der gesamten Aufwendungen  und  gesamten  Erträge,  die  um  die  Bestandsveränderungen  der fertigen  und  unfertigen  Erzeugnisse  sowie  der  anderen  aktivierten  Eigenleistungen korrigiert werden. Dagegen werden beim Umsatzkostenverfahren den Erträgen nur die Aufwendungen  der  abgesetzten  Produkte  gegenübergestellt.  Damit  besteht  der Unterschied in der Berücksichtigung der Bestandserhöhungen und Bestandsminderungen der fertigen und unfertigen Erzeugnisse sowie der aktivierten Eigenleistungen. Die folgende Abbildung zeigt den Unterschied der beiden Verfahren bei  Bestandserhöhung  der  fertigen  und  unfertigen  Erzeugnisse  sowie  bei  anderen aktivierten Eigenleistungen.

## 7.3 Gesamtkostenverfahren

Beim Gesamtkostenverfahren handelt es sich um eine Produktionserfolgsrechnung, d. h. es werden sämtlichen Erträgen der Periode (Umsatzerlöse, Bestandserhöhungen bei fertigen und unfertigen Erzeugnissen sowie anderen aktivierten Eigenleistungen) alle Aufwendungen der produzierten Mengeneinheiten der gleichen Periode gegenübergestellt. Das Gesamtkostenverfahren ist pro duktionsorientiert, die Gliederung der  Aufwendungen erfolgt nach Aufwandsarten (Materialaufwand, Personalaufwand, Abschreibung). Es lässt sich beispielsweise die Lagerumschlaghäufigkeit ermitteln und es wird ein Einblick in die einzelnen Aufwandsarten gewährt. Die Gesamtleistung fasst die Umsatzerlöse, die Bestandsänderungen der fertigen und unfertigen Erzeugnisse sowie die aktivierten Eigenleistungen zusammen. Bei den Erträgen handelt es sich um:65 Umsatzerlöse, die aus den Ausgangsrechnungen resultieren und mit den vereinbarten Verkaufspreisen zu berücksichtigen sind. Von den Erlösen sind die Erlösschmälerungen  wie  z.  B.  Rabatte,  Skonti,  direkt  zurechenbare  Boni  oder Rücknahmen  sowie  die  mit  dem  Umsatz  direkt  verbundenen  Steuern  abzuziehen. Hierunter fallen insbesondere die Verbrauchs- und Verkehrssteuern (z. B. Energie-, Strom-, Mineralöl-, Tabak- und Biersteuer). Bestandsveränderungen der fertigen und unfertigen Erzeugnisse, die zu Herstellungskosten bewertet werden. Sie sind bei einer Bestandserhöhung erfolgserhöhend (+) und bei einer Bestandsminderung erfolgsmindernd (-) zu berücksichtigen. Die jeweilige n Bestände zum

Abschlussstichtag  werden  in  den  Bilanzposten  'fertige  Erzeugnisse'  und  'unfertige Erzeugnisse' ausgewiesen. Andere aktivierte Eigenleistungen, die zu Herstellungskosten bewertet werden. Es handelt sich um selbst erstellte Vermögensgegenstände des Anlagevermögens zur betrieblichen Nutzung, die nicht für  die  Weiterveräußerung  bestimmt  sind  und  daher  nicht  den  Vorräten  bzw.  dem Umlaufvermögen zuzurechnen sind. Zu den aktivierten Eigenleistungen zählen z. B. selbst erstellte Maschinen oder Gebäude, selbst durchgeführte Großreparaturen und Erweiterungen. Die GuV nach dem Gesamtkostenverfahren ermittelt das Jahresergebnis in fünf Schritten: 1. Die Posten 1 bis 5 ergeben das Rohergebnis, das in der Gliederung nicht explizit ausgewiesen wird. 2. Die Posten 1 bis 8 ergeben das Betriebsergebnis, das in der Gliederung nicht gesondert ausgewiesen wird. 3. Über die  Posten  9  bis  13  lässt  sich  das  Finanzergebnis  errechnen,  das  jedoch  nicht gesondert  ausgewiesen  wird.  4.  Betriebsergebnis  und  Finanzergebnis  führen  zum Gesamtergebnis. 5. Die Posten 1 bis 14 ergeben das Ergebnis nach Steuern (Posten 15). 6. Nach Abzug der sonstigen Steuern (Posten 15 minus Posten 16) ermittelt das Gesamtkostenverfahren in Posten 17 das Jahresergebnis (Jahresüberschuss/Jahresfehlbetrag). Die Vorteile des Gesamtkostenverfahrens sind: Die  Gewinn-  und  Verlustrechnung  kann  auf  der  Grundlage  einer  in  Kostenarten eingeteilten  Buchführung  erstellt  werden. Die  periodengerechte Abgrenzung  von Aufwendungen  und  Erträgen  kommt  besser  zum  Ausdruck. Es  lässt  sich  die Gesamtleistung des Unternehmens errechnen (Umsatz +/- Bestandsveränderung der fertigen und unfertigen Erzeugnisse + andere aktivierte Eigenleistungen). Es werden die  wesentlichen Aufwandsarten,  wie  z.  B.  Materialaufwand,  Personalaufwand  und Abschreibungen,  als  wichtige  Bestimmungsgröße  für  die  Ertragskraft  gesondert ausgewiesen. Die  Abschreibungen  werden  offen  ausgewiesen,  wodurch  die Selbstfinanzierungskraft des Unternehmens deutlicher wird. Es ist keine Kostenstellenrechnung erforderlich.

7.3.2 Inhalt und Aussagen der Gewinnund Verlustrechnung nach dem Gesamtkostenverfahren Umsatzerlöse: Erlöse aus dem Verkauf von Umlaufvermögen und der Vermietung oder Verpachtung sowie aus der Erbringung von Dienstleistungen. Erträge aus Schrottverkäufen, oder Kantinenerlöse sowie Erträge aus Provisionen, Lizenzen und Patenten. Die auf die Erlöse entfallende Umsatzsteuer, Erlösschmälerungen  (Rabatte,  Boni  und  Skonti)  oder  direkt  mit  dem  Umsatz verbundene  Steuern  sind  zum Abzug  zu  bringen. Erhöhung/Verminderung  des

Bestands  an  fertigen  und  unfertigen  Erzeugnissen:  Dieser  Posten  entsteht  durch Mengen- oder Wertänderungen. Mengenänderungen stellen sich beispielsweise ein, wenn der Verkauf größer oder kleiner als die Produktion war. Wertänderungen können sich aus einer Veränderung der Herstellungskosten oder durch Qualitätsabschläge, Bewertungsabschläge auf Ladenhüter oder Abschreibungen nach dem Niederstwertprinzip ergeben. Andere aktivierte Eigenleistungen: Hierbei handelt es sich um selbst hergestellte Vermögensgegenstände des Anlagevermögens, die nicht an Dritte verkauft werden, sondern zur Eigennutzung dienen, wie beispielsweise selbst erstellte Gebäude, Maschinen, Werkzeuge oder aktivierungspflichtige Großreparaturen, die der eigentlichen betrieblichen Nutzung dienen. Der Ausweis der aktivierten Eigenleistungen stellt einen Ertragsausweis dar. Die aktivierten Eigenleistungen  werden  in  der  Bilanz  als  Vermögensgegenstände  erfasst,  also 'aktiviert'. Sonstige betriebliche Erträge: Sammelposten, in dem alle Erträge, die nicht  unter  den  Umsatzerlösen  ausgewiesen  sind,  erfasst  werden.  Hierzu  zählen beispielsweise Erträge aus der Auflösung von Rückstellungen, Erträge aus abgeschriebenen Forderungen, Erträge aus der Herabsetzung von Pauschalwertberichtigungen zu Forderungen, Erträge aus Zuschreibungen auf Vermögensgegenstände des Anlageund Umlaufvermögens, Erträge aus Versicherungsentschädigungen, Aktivierung von unentgeltlich erworbenen Vermögensgegenständen, Erträge aus dem Verkauf von Gegenständen des Anlagevermögens,  z.  B.  der  Buchgewinn  aus  einem  Grundstücksverkauf  etc. Materialaufwand: Hierzu zählen der Materialverbrauch aus dem Fertigungsbereich für die Roh-, Hilfs- und Betriebsstoffe, aber auch die Aufwendungen für bezogene Waren und  die  bezogenen  Fremdleistungen. Rohergebnis:  Das  Rohergebnis  ist  eine Zwischensumme der Gewinn - und Verlustrechnung und umfasst in der GuV nach dem Gesamtkostenverfahren (§ 275 Abs. 2 HGB) die Posten Nr. 1 bis Nr. 5 sowie in der GuV nach dem Umsatzkostenverfahren (§ 275 Abs. 3 HGB) die Posten Nr. 1 bis Nr. 3 und Nr. 6. Personalaufwand: Hierunter werden Löhne und Gehälter (brutto), soziale Abgaben (Arbeitgeberanteil zur Sozialversicherung und Beiträge zur Berufsgenossenschaft),  Aufwendungen für die  Altersvorsorge (Zuführungen zu Pensionsrückstellungen und Beiträge zu selbstständigen Versorgungseinrichtungen) sowie  Unterstützung  en  (Unterstützungszahlungen  für  Inva  liden,  Heirats-  und Geburtsbeihilfen) gefasst. Abschreibungen: Antizipierte Wertminderung von Vermögensgegenständen  des  Anlage-  und  Umlaufvermögens.  Es  ist  zwischen planmäßigen und außerplanmäßigen Abschreibungen zu unterscheiden. Sonstige betriebliche  Aufwendungen: Sammelpo sten für alle  Aufwendungen aus der gewöhnlichen Geschäftstätigkeit, die nicht an anderer Stelle ausgewiesen werden. Sie umfassen  u.  a.  übliche Abschreibungen  auf  Forderungen, Aufwendungen  aus  der Währungsumrechnung, Verluste aus Anlagenabgängen, Mieten, Leasingraten, Fahrzeugkosten, Versicherungen, Kommunikationsaufwand, Rechtsanwaltsund Beratungskosten, Zuführung zu Rückstellungen.

(wenn die Aufwandsart noch nicht endgültig hinreichend bestimmbar ist). Zuführungen zu Pensionsrückstellungen bei Inanspruchnahme des Streckungswahlrechts im Zuge der BilMoG-Umstellung (Ausweis als Posten 'Aufwendungen nach Art. 67 Abs. 1 und 2 EGHGB). Betriebsergebnis: Das Betriebsergebnis setzt sich beim Gesamtkostenverfahren aus den Posten 1 bis 8 und beim Umsatzkostenverfahren aus den Posten 1 bis 7 zusammen. Es hat von allen Ergebnissen die größte Aussagekraft hinsichtlich Beurteilung der Ertragsentwicklung. Das Betriebsergebnis enthält betriebliche Erträge und betriebliche Aufwendungen. Mischposten sind die sonstigen betrieblichen Erträge und die sonstigen betrieblichen Aufwendungen. Erträge aus Beteiligungen: Hierunter sind die laufenden Erträge auszuweisen, die im Beteiligungsverhältnis  begründet  sind  (z.  B.  Dividenden  von  Kapitalgesellschaften, Gewinnanteile von Personengesellschaften etc.). Erträge aus der Veräußerung von Beteiligungen  gehören  nicht  dazu. Erträge  aus  anderen  Wertpapieren  und Ausleihungen des Finanzanlagevermögens: Hierzu gehören Zinsen aus langfristigen Ausleihungen und Dividenden aus Aktien sowie ähnliche Ausschüttungen, die nicht Beteiligungen, Gewinngemeinschaften oder Gewinnabführungsverträgen zuzuordnen sind. Sonstige  Zinsen  und  ähnliche  Erträge:  Ertragszinsen  für  Guthaben  bei Kreditinstituten, Zinsen, Dividenden und dergleichen auf Wertpapiere des Umlaufvermögens etc. und zinsähnliche Erträge, wie z. B. Agio, Disagio, Kreditprovisionen, Kreditgebühren, sind hierunter gefasst, sofern sie nicht an anderer Stelle ausgewiesen werden. Abschreibung auf Finanzanlagen und auf Wertpapiere des  Umlaufvermögens:  Da  es  sich  beim  Finanzvermögen  nicht  um  abnutzbares Vermögen  handelt,  werden  hier  ausschließlich  außerplanmäßige  Abschreibungen berücksichtigt. Zinsen  und  ähnliche Aufwendungen:  Hierzu  zählen  insbesondere Zinsen für Verbindlichkeiten bei Kreditinstituten oder Lieferanten, Kreditprovisionen, Abschreibungen für ein aktiviertes Disagio und Aufwendungen aus der Aufzinsung von in Vorjahren abgezinsten Rückstellungen. Finanzergebnis: Das Finanzergebnis ist als neutrales Ergebnis zum einen von den Gegebenheiten des Geldund Kapitalmarkts und zum anderen von den Beteiligungen abhängig, weniger von der Leistung des Managements. Es steht in keinem Zusammenhang mit der eigentlichen betrieblichen Tätigkeit (dem Zweck des Unternehmens). Der Saldo aus den Erträgen und den Aufwendungen, die sich aus den Anlagen am Geld- und Kapitalmarkt und der Inanspruchnahme  der  Fremdkapitalfinanzierung  ergeben,  stellt  das  Finanzergebnis dar. Gesamtergebnis: Dieses Zwischenergebnis umfasst den Saldo aller Erträge und Aufwendungen vor Steuern der abgelaufenen Periode, d. h. es umfasst das Betriebsund  Finanzergebnis  des  Unternehmens  vor  Steuern.  Das  Betriebsergebnis  steht tendenziell  für  Nachhaltigkeit  und  Beeinflussbarkeit.  Das  Finanzergebnis  ist  zwar nachhaltig erzielbar, aber meist nicht beeinflussbar. Steuern vom Einkommen und vom Ertrag: Diese werden vom Ergebnis vor Steuern abgezogen, dabei handelt es sich im Wesentlichen um die nicht abzugsfähigen Betriebssteuern. Im Einzelnen sind dies die Körperschafts-, die Gewerbe-  und  die  Kapitalertragsteuer  sowie der Solidaritätszuschlag. Ebenfalls unter diesem Posten werden für die zuvor genannten Steuern auch Steuervorauszahlungen, Steuernachzahlungen und Steuererstattungen, für Vorjahre sowie für die Bildung und  Auflösung von Steuerrückstellungen, ausgewiesen. Gemäß § 274 Abs. 2 Satz 3 HGB sind unter dem Posten 'Steuern vom Einkommen  und  Ertrag'  auch  sämtliche  Aufwendungen  und  Erträge  aus  der Passivierung und Aktivierung latenter Steuern gesondert auszuweisen. Ergebnis nach Steuern: Dies entspricht dem  Betriebsergebnis zuzüglich  dem  Finanzergebnis abzüglich der Steuern von Einkommen und Ertrag. Sonstige Steuern: Alle anderen Steuern, soweit sie handelsrechtlichen Aufwand darstellen und nicht aktivierungspflichtig bzw. durchlaufend sind, dürfen  hier  ausgewiesen  werden, beispielsweise Kfz-Steuer, Grundsteuer,  Ausfuhrzölle, Versicherungssteuer und Verbrauchssteuern  (z.  B.  Mineralöl-,  Bier-,  Tabak-,  Kaffee-,  Branntweinsteuer). Jahresüberschuss/Jahresfehlbetrag: Bei dem Jahresüberschuss bzw. Jahresfehlbetrag handelt es sich um das handelsrechtliche Ergebnis eines Geschäftsjahres nach Steuern. Dieser Betrag ergibt sich als Saldo aller in der GuV ausgewiesenen Erträge, Aufwendungen und Steuern. Der Jahresüberschuss bzw. der Jahresfehlbetrag stellen die Ausgangsgrundlage für die Gewinnverwendung dar. 7.4 Umsatzkostenverfahren  Beim  Umsatzkostenverfahren  handelt  es  sich  um  eine Absatzerfolgsrechnung. Es werden den Verkaufserlösen der Periode nur die Umsatzkosten der verkauften Produkte/Leistungen gegenübergestellt. Die

Bestandserhöhungen  der  fertigen  und  unfertigen  Erzeugnisse  sowie  die  selbst erstellten  Vermögensgegenstände  des Anlagevermögens  werden  nicht  als  Erträge und  die  dafür  angefallenen  Aufwendungen  nicht  als  Aufwendungen  erfasst.  Die Bestandsminderungen an fertigen und unfertigen Erzeugnissen werden als Aufwendungen für abgesetzte Erzeugnisse ausgewiesen. Das Umsatzkostenverfahren ist kostenstellenorientiert aufgebaut, daher müssen die Daten aus  der  Kosten-  und  Leistungsrechnung  abgeleitet  werden.  Im  Vergleich  zum Gesamtkostenverfahren werden die  Aufwendungen nicht nach  Aufwandsarten (Material, Personal, Abschreibungen), sondern nach den Funktionsbereichen (Herstellung, Verwaltung, Vertrieb) unterteilt. Die Gewinn- und Verlustrechnung nach dem  Umsatzkostenverfahren  (§  275 Abs.  3  HGB)  ermittelt  das  Jahresergebnis  in grundsätzlich sechs Schritten: 1. Die Posten 1 und 2 ermitteln das Bruttoergebnis vom Umsatz  (Posten  3).  2.  Über  die  Posten  1  bis  7  lässt  sich  das  Betriebsergebnis errechnen (nicht gesondert ausgewiesen). 3. Aus den Posten 8 bis 12 ergibt sich das Finanzergebnis (nicht gesondert ausgewiesen). 4. Betriebsergebnis und Finanzergebnis  führen  zum  Gesamtergebnis.  5.  Die  Posten  1  bis  13  ergeben  das Ergebnis nach Steuern (Posten 14). 6. Nach Abzug der sonstigen Steuern (Posten 14 minus Posten 15) ermittelt das Umsatzkostenverfahren in Posten 16 das Jahresergebnis (Jahresüberschuss/Jahresfehlbetrag)

## 7.5 Gewinn- und Verlustrechnung nach dem Umsatzkostenverfahren

- 1. Umsatzerlöse  -  2. Herstellungskosten  der  zur  Erzielung  der  Umsatzerlöse erbrachten  Leistungen  =  3.  Bruttoergebnis  vom  Umsatz  (Posten  1  bis  2)  -  4. Vertriebskosten - 5. allgemeine Verwaltungskosten + 6. sonstige betriebliche Erträge 7.  sonstige betriebliche Aufwendungen = Betriebsergebnis (vor Steuern und Zinsen (EBIT))*  (Posten  1  bis  7)  +  8.  Erträge  aus  Beteiligungen,  davon  aus  verbundenen Unternehmen  +  9.  Erträge  aus  anderen  Wertpapieren  und  Ausleihungen  des Finanzanlagevermögens,  davon  aus  verbundenen  Unternehmen  +  10.  sonstige Zinsen und ähnliche Erträge, davon aus verbundenen Unternehmen -11. Abschreibungen auf Finanzanlagen und auf Wertpapiere des Umlaufvermögens - 12. Zinsen und ähnliche  Aufwendungen, davon an verbundene Unternehmen = Finanzergebnis (vor Steuern)* (Posten 8 bis 12) (1 bis 12) Gesamtergebnis* (Posten 1 bis 12) +/- 13. Steuern vom Einkommen und vom Ertrag = 14. Ergebnis nach Steuern

- 15. sonstige Steuern = 16. Jahresüberschuss/Jahresfehlbetrag (Jahresergebnis nach Steuern) *Diese Posten werden im Grundschema des Umsatzkostenverfahrens nicht explizit ausgewiesen . Abb. 7.6: Gewinnund Verlustrechnung nach dem Umsatzkostenverfahren Als Vorteile des Umsatzkostenverfahrens werden angeführt: Das  Umsatzkostenverfahren  führt  zu  einem  aussagefähigeren  Betriebsergebnis, insbesondere  für  die  kurzfristige  (z.  B.  monatliche)  Erfolgsrechnung. Bei  einer entsprechenden  Gliederung  der  Aufwendungen  nach  den  Produktarten  kann  der Erfolgsbeitrag  einzelner  Produktarten  aufgezeigt  werden. Der  Zusammenhang zwischen Kosten und Leistung des Unternehmens wird sichtbar. Es  erfolgt  eine 'verursachungsgerechte' Zuordnung von Aufwendungen zu den Funktionsbereichen des Unternehmens. Die internationale Vergleichbarkeit von Gewinnund Verlustrechnungen  wird  erleichtert. Das  Umsatzkostenverfahren  entspricht  dem Kalkulationsschema  des  Unternehmens. Das  Umsatzkostenverfahren  ist  gut geeignet für Industriebetriebe mit Serienfertigung und für Handelsbetriebe. Es müssen der Materialaufwand (GKV-Posten 5) und der Personalaufwand (GKV-Posten 6) im Anhang angegeben werden.

## 7.5.1 Ergebnisrechnung nach dem Umsatzkostenverfahren

Das 'Bruttoergebnis vom Umsatz' (Posten 3) ergibt sich aus der Differenz zwischen 'Umsatzerlösen'  (Posten  1)  und  den  'Herstellungskosten  der  zur  Erzielung  der Umsatzerlöse erbrachten Leistungen (Posten Nr. 2). Im Vergleich zu den Posten 1 bis 3 des Gesamtkostenverfahrens (§ 275 Abs. 2 HGB), die die betriebliche Gesamtleistung darstellen, bezieht sich die Größe 'Bruttoergebnis vom Umsatz' die Absatzleistung  des  Unternehmens.  Die  'Herstellungskosten  der  zur  Erzielung  der Umsatzerlöse erbrachten Leistungen' enthalten die gesamten, auf die Absatzleistung entfallenden  Herstellungsaufwendungen  des  laufenden  Geschäftsjahres  und  die  in früheren  Perioden  im  Rahmen  der  Vorratsbewertung  aktivierten  Aufwendungen, soweit diese Vorräte (fertige und unfertige Erzeugnisse) in das abgesetzte Leistungsvolumen eingehen. Im Falle des Lagerabgangs, bei dem die Vorräte verkauft wurden, ist zu berücksichtigen, dass der Umfang der unter Posten 2 zu verrechnenden Aufwendungen davon abhängt, welche Aufwendungen bzw. Kosten im Zeitpunkt des Lageraufbaus in der Bilanz aktiviert wurden. Unter dem Posten 2 erscheinen somit: soweit die Produktion der abgesetzten Leistungen durch Vorräteabbau bestritten wird, die  -  in  früheren  Perioden  des  Lageraufbaus  im  Rahmen  der  Vorratsbewertung  tatsächlich aktivierten Aufwendungen, und die gesamten fertigungsund materialbezogenen  laufenden  Aufwendungen  des  ablaufenden  Geschäftsjahres, soweit sie auf die Absatzleistung entfallen. 7.6 Überblick über die beiden Verfahren Gliederung der Gewinnund Verlustrechnung in verkürzter Form Gesamtkostenverfahren (§ 275 Abs. 2 HGB) Umsatzkostenverfahren (§ 275 Abs. 3 HGB) Posten Posten 1 bis 8 9 bis 13 = Betriebsergebnis + Finanzergebnis 1 bis 7 8 bis 12 Gesamtergebnis 14 - Steuern von Einkommen und Ertrag 13 15 = Ergebnis nach Steuern 14 16 - sonstige Steuern 15 17 = Jahresüberschuss/Jahresfehlbetrag 16 Abb. 7.7: Gegenüberstellung von Gesamt- und Umsatzkostenverfahren

Produktionserfolgsrechnung  beim  Gesamtkostenverfahren  Ertrag  =  Gesamtleistung der  Periode  (Umsatzerlöse  -  Bestandsabnahme  +  Bestandserhöhung  +  andere aktivierte Eigenleistungen) - Aufwand = Produktionsaufwand der Periode = Ergebnis (Gewinn oder Verlust) Abb. 7.8: Produktionserfolgsrechnung nach dem Gesamtkostenverfahren Umsatzerfolgsrechnung beim Umsatzkostenverfahren Ertrag =  Umsatzerlöse  der  Periode  - Aufwand  =  Umsatzaufwand  (Produktionsaufwand  + Bestandsabnahme - Bestandserhöhung der fertigen und unfertigen Erzeugnisse) = Ergebnis (Gewinn oder Verlust) Abb. 7.9: Absatzerfolgsrechnung nach dem Umsatzkostenverfahren Im Ergebnis stimmen die Produktionsrechnung (Gesamtkostenverfahren)  und  die  Absatzerfolgsrechnung  (Umsatzkostenverfahren) überein.  Erfassung  der  Bestandsveränderungen  in  der  GuV  Das  Betriebsergebnis nach dem Gesamtkostenverfahren ergibt sich, indem der gesamte Produktionsertrag (= Gesamtleistung) zuzüglich der sonstigen Erträge den gesamten in einer Periode entstandenen betrieblichen  Aufwendungen gegenübergestellt wird. Nach dem Umsatzkostenverfahren ergibt sich das Bruttoergebnis vom Umsatz durch Gegenüberstellung der Umsatzerlöse E(Xa) und der hierfür aufgebrachten Aufwendungen (umsatzbezogene Herstellungskosten A(Xa)). Gesamtkostenverfahren Umsatzkostenverfahren Umsatzerlöse E(Xa) Umsatzerlöse E(Xa) +/-Bestandsveränderung [E(Xp) - E(Xa)] - umsatzbezogene Herstellungskosten A(Xa) + andere  aktivierte  Eigenleistungen  =  Gesamtleistung  E(Xp)  =  Bruttoergebnis  vom Umsatz  +  sonstige  betriebliche  Erträge -  Vertriebskosten  -  Materialaufwand  allgemeine  Verwaltungskosten  -  Personalaufwand  +  sonstige  betriebliche  Erträge  Abschreibungen -sonstige betriebliche  Aufwendungen -sonstige betriebliche Aufwendungen = Betriebsergebnis = Betriebsergebnis.

7.7 Rohergebnis Kleine und mittelgroße Kapitalgesellschaften unterliegen geringeren Publizitätsanforderungen bei der Gewinn- und Verlustrechnung (GuV). Sie müssen bei der GuV nur das Rohergebnis ausweisen. Das Rohergebnis wird wie folgt ermittelt: Rohergebnis nach dem Gesamtkostenverfahren (GKV): Umsatzerlöse +/-Bestandsveränderungen der fertigen und unfertigen Erzeugnisse + andere aktivierte Eigenleistungen  +  sonstige  betriebliche  Erträge  -  Materialaufwand  =  Rohergebnis (GKV) Abb. 7.11: Ermittlung des Rohergebnisses nach dem Gesamtkostenverfahren Rohergebnis nach dem Umsatzkostenverfahren (UKV): Umsatzerlöse -Herstellungskosten der zur Erzielung der Umsätze erbrachten Leistungen + sonstige betriebliche Erträge = Rohergebnis (UKV)

Kapitalflussrechnung Lernziele In diesem Kapitel werden Sie den Aufbau, den Inhalt und die wesentlichen Posten der Kapitalflussrechnung kennenlernen. Sie werden die Dreiteilung der Kapitalflussrechnung in laufende Geschäftstätigkeiten sowie Investitions- und Finanzierungstätigkeiten unterscheiden können. 11.1 Einführung Die Kapitalflussrechnung wird häufig als dritte Jahresabschlussrechnung bezeichnet, da in  ihr  eine  sinnvolle  Ergänzung  zur  Bilanz  und  zur  Gewinn-  und  Verlustrechnung gesehen  wird.  Es  handelt  sich  um  eine  Bewegungsrechnung,  die  die  wichtigsten Investitions- und Finanzierungsvorgänge während des Geschäftsjahres darstellt. Sie verbessert den Einblick in die Vermögens- und Finanzstruktur eines Unternehmens, insbesondere bezüglich. der Liquidität und  Solvenz. Ferner werden bilanzpolitische Einflüsse eliminiert. Dies führt zu einer verbesserten Darstellung der Ertragskraft eines Unternehmens. Die Kapitalflussrechnung ermöglicht eine detaillierte Darstellung und Analyse  von  Mittelherkunft  und  Mittelverwendung.  Es  werden  die  Posten  zweier aufeinanderfolgender  Bilanzen  gegenübergestellt  und  die  sich  hierbei  ergebenden Differenzen je Posten in einer Veränderungsbilanz erfasst. Sie stellt die Herkunft und die Verwendung der Finanzmittel eines Unternehmens dar. Ergänzend zum Jahresabschluss stellt die Kapitalflussrechnung eine liquiditätsbezogene Zeitraumrechnung, die nicht Bestände an Vermögen und Kapital, sondern Bestandsveränderungen  bzw.  die  zugrunde  liegenden  Bewegungen  ausweist.  Im Gegensatz  zur  GuV  erfasst  die  Kapitalflussrechnung  auch  die  erfolgsunwirksamen Bewegungen und bildet somit einen Teilbereich des liquiditätsorientierten Rechnungswesens ab. Sie soll einen Einblick in die Finanzlage eines Unternehmens gewähren, indem Investitions-  und  Finanzierungsvorgänge und  ihr  Einfluss  auf  die Liquidität  dargestellt  werden.142  Die  folgende Abbildung  zeigt  die Abgrenzung  der

Kapitalflussrechnung zur Bilanz und GuV.  Abb. 11.1: Kapitalflussrechnung -Abgrenzung zur Bilanz und GuV Die Kapitalflussrechnung ist zwingender Bestandteil des Konzernabschlusses von Kapitalgesellschaften gemäß § 297 Abs. 1 HGB und beim Einzelabschluss kapitalmarktorientierter Kapital.

gesellschaften, die nicht zur Aufstellung eines Konzernabschlusses verpflichtet sind, gemäß § 264 Abs. 1 Satz 2 HGB. Unternehmen, die nach HGB verpflichtet sind, eine Kapitalflussrechnung durchzuführen, müssen sich an den Deutschen Rechnungslegungsstandard Nr. 21 (DRS 21) halten. Dieser Rechnungslegungsstandard  wurde  im  April  2014  veröffentlicht  und  gibt  wichtige Grundsätze zur Erstellung einer Kapitalflussrechnung vor143. Die Kapitalflussrechnung  steht  in  enger  Verbindung  mit  der  Bilanz  und  der  GuV  eines Unternehmens.  Die  folgende  Abbildung  veranschaulicht,  wie  sie  zusammen  ein 'integrales Ganzes' bilden. Die Kapitalflussrechnung ist mit der Aktivseite der Bilanz verknüpft, während die GuV die Passivseite der Bilanz beeinflusst.144 A Bilanz P S GuV-Konto  H  S  Kapitalflussrechnung  H  Vermögen  Eigenkapital  Aufwendungen Erträge  Einzahlungen  Auszahlungen  Veränderung  Eigenkapital  Jahresüberschuss Fremdkapital  Einzahlungsüberschuss  Veränderung  Finanzmittelfonds  S  =  Soll A  = Aktiva  H  =  Haben  P  =  Passiva Abb.  11.2:  Verknüpfung  von  Kapitalflussrechnung, Bilanz und GUV145 Ein Einzahlungsüberschuss wirkt sich zum Bilanzstichtag in der Bilanz auf der Aktivseite als Erhöhung des Finanzmittelfonds aus. Dagegen führt ein Auszahlungsüberschuss zu einer Minderung des Finanzmittelfonds. 11.2 Beständedifferenzen-, Veränderungsund Bewegungsbilanz Eine Beständedifferenzenbilanz  ergibt  sich  aus  der  Saldierung  von  Beständen  zweier aufeinanderfolgender  Bilanzen.  Die  Gliederung  der  Stichtagsbilanzen  wird  für  die Bewegungsbilanz beibehalten. Bestandsmehrungen  werden  mit positivem und Bestandsminderungen mit negativem Vorzeichen dargestellt. Sie ist der erste Schritt für die Erstellung einer derivativen Kapitalflussrechnung. Jedoch ist ihre Aussagekraft sehr  begrenzt,  da  das  Aufzeigen  der  Bestandsveränderungen  keinen  weiteren Informationsgehalt gegenüber dem Jahresabschluss enthält. Bei einer Bewegungsbilanz handelt es sich um  eine bestimmte Erscheinungsform der Kapitalflussrechnung. Sie zeigt die Veränderung der Bestandskonten zwischen zwei Bilanzstichtagen;  d.  h.  als Ausgangspunkt  dienen  die  Bilanzen  am Anfang  und  am Ende eines Geschäftsjahres. Aus beiden Bilanzen wird die Differenz der einzelnen Bilanzposten gebildet. Dadurch erhält man die sogenannte Beständedifferenzenbilanz:

Veränderungen Aktivposten Veränderungen Passivposten Erhöhung der Aktivposten (+)  Erhöhung  der  Passivposten  (+)  Minderung  der  Aktivposten  (-)  Minderung  der Passivposten  (-)  Abb.  11.3:  Grundaufbau  der  Beständedifferenzenbilanz  11.3  Die Bewegungsbilanz als Sonderform der Kapitalflussrechnung Wenn man die Beständedifferenzenbilanz umstellt, erhält man die Bewegungsbilanz. Sie zeigt, aus welchen Quellen des Unternehmens Mittel zugeflossen sind (Mittelherkunft) und wofür diese verwendet wurden (Mittelverwendung). Die Bewegungsbilanz kann sowohl in Kontenform als auch in Staffelform dargestellt werden. Ist letzteres der Fall, spricht man von einer Kapitalflussrechnung. 11.3.1 Darstellung in Kontenform Der folgende Grundaufbau ergibt sich bei einer Darstellung der Bewegungsbilanz in Kontenform: Bewegungsbilanz  Mittelverwendung  Mittelherkunft  Erhöhung  der  Aktivposten  (+)  · Erhöhung Anlagevermögen · Erhöhung Umlaufvermögen = Investition Erhöhung der Passivposten (+) · Eigenkapitalmehrungen · Fremdkapitalmehrungen = Finanzierung Minderung der Passivposten (-) · Eigenkapitalminderungen · Fremdkapitalminderungen = Definanzierung Minderung von Aktivposten (-) · Minderung Anlagevermögen  ·  Minderung  Umlaufvermögen  =  Desinvestition  Wohin sind  Mittel  geflossen?  Woher  stammen  die  Mittel?  Abb.  11.4:  Grundaufbau  der Bewegungsbilanz Die Mittelherkunft setzt sich aus der Zunahme der Passiva und der Abnahme von Aktiva zusammen. Eine Zunahme der Passiva kann durch Erhöhung von Schulden erfolgen, d. h. z. B. Aufnahme von Fremdkapital, oder durch Zuführung von Eigenkapital. Eine Minderung der Aktiva kann erfolgen durch die Veräußerung von Anlagen oder Beteiligungen, Abschreibungen, Reduzierung der Vorräte, Forderungen und  Kasse.  Die  Abschreibung  der  Produktionsanlage  verringert  den  Wert  der Produktionsanlage  und  führt  zu  einer  Freisetzung  finanzieller  Mittel.  Auch  die Verringerung der Bestände an Fertigerzeugnissen erhöht die verfügbaren finanziellen Mittel. Die Mittelverwendung wird aus der Abnahme von Passiva und der Zunahme von Aktiva abgebildet. Eine Minderung der Passiva resultiert aus der Verringerung der Verbindlichkeiten, z. B. durch die Tilgung eines Kredits oder einer Gewinnausschüttung bzw. einer Kapitalentnahme. Die Zu nahme von Aktiva ergibt sich durch Investitionen in das Anlagevermögen (z. B. den Kauf einer Produktionsanlage) oder in Vorräte bzw. Erhöhung der Forderungen aLuL. Die Bewegungsbilanz ist eine zeitraumbezogene Rechnung.  Durch  die  nicht  mehr  statische,  sondern  dynamische  Interpretation  der Veränderungen wird hier ein Übergang zur stromgrößenorientierten Finanzierungsrechnung  gebildet.  11.3.2  Kritikpunkte  bei  der  Bewegungsbilanz  Das

Problem der Bewegungsbilanz besteht darin, dass aufgrund von Informationsmängeln, welche buchhaltungstechnisch bedingt sind, keine Trennung von liquiditätswirksamen und  liquiditätsunwirksamen  Bewegungen  möglich  ist.  Bei  der  Bewegungsbilanz handelt es sich lediglich um eine Rechnung, die aus zwei Stichtagsbilanzen abgeleitet wird, die jedoch keine Informationen über die eigentliche Finanzlage eines Unternehmens liefert. Daher sind Bewegungsbilanzen nicht gut als Finanzierungsrechnungen geeignet. Die alleinige Aussage der Bewegungsbilanz ist, dass Veränderungen von Bilanzposten dargestellt werden. Bewegungsbilanzen sind deshalb nur als Vorstufe zur aufschlussreicheren Kapitalflussrechnung anzusehen.146 Die Informationen aus der Bewegungsbilanz können mithilfe der Kapitalflussrechnung genauer analysiert werden. 11.4 Grundlagen der Kapitalflussrechnung Die Kapitalflussrechnung  stellt  die  Quelle,  aus  denen  der  Finanzmittelfonds  gespeist wurde, und die Verwendung der Finanzmittel in den unterschiedlichen Bereichen des Unternehmens bzw. des Konzerns dar. Sie verfolgt das Ziel, Transparenz über den Zahlungsmittelstrom eines Unternehmens herzustellen. Sie ist eine liquiditätsbezogene  Zeitraumrechnung  und  stellt  alle  in  einer  Periode  angefallenen, Ein- und Auszahlungen gegenüber. Die Kapitalflussrechnung wird in eine Ursachenund eine Fondsveränderungsrechnung untergliedert. Die folgende Abbildung zeigt die Bestandteile  der  Kapitalflussrechnung:  Ursachenrechnung  Cashflow  aus  laufender Geschäftstätigkeit (a) Cashflow aus Investitionstätigkeit (b) Cashflow aus Finanzierungstätigkeit (c) Fondsveränderungsrechnung Anfangsbestand an Zahlungsmitteln und Zahlungsmitteläquivalenten147 Veränderung der Zahlungsmittel (a + b + c) Endbestand an Zahlungsmitteln und Zahlungsmitteläquivalenten Abb. 11.5: Bestandteile der Kapitalflussrechnung 11.4.1 Ursachenrechnung Die drei Teilbereiche der Ursachenrechnung setzen sich aus der laufenden Geschäftstätigkeit, Investitionstätigkeit und Finanzierungstätigkeit zusammen. Die Sachverhalte bezüglich der Zu ordnung der Zahlungsströme sind im DRS 21 geregelt. Jedoch gibt es auch  Geschäftsvorfälle, bei denen  sich die Ein-  und  Auszahlungen  nicht überschneidungsfrei einem der drei Tätigkeitsbereiche der Ursachenrechnung zuordnen lassen. Die Unternehmen haben dann die Möglichkeit, sie sachgemäß nach ihrem Verständnis aufzuteilen. Die Aufgabe der Ursachenrechnung ist es die Quellen zu  visualisieren,  aus  denen  der  Finanzmittelfond  gespeist  wird.  Zudem  wird  die Herkunft und Verwendung der Finanzmittel in den unterschiedlichen Tätigkeitsbereichen aufgezeigt. Hinsichtlich der Datendarstellung kann zwischen der

Brutto- und Nettomethode unterschieden werden. Bei der direkten bzw. Bruttomethode ergibt sich der Cashflow aus der Differenz aller zahlungswirksamen  Erträge (Bruttoeinzahlungen) und aller zahlungswirksamen Aufwendungen (Bruttoauszahlungen). Die indirekte bzw. Nettomethode ist nur zur Berechnung des Cashflows aus der laufenden Geschäftstätigkeit erlaubt. Bei der indirekten Methode werden vom  Periodenergebnis (Jahresüberschuss oder -fehlbetrag) alle nicht zahlungswirksamen  Erträge  subtrahiert,  während  alle  nicht  zahlungswirksamen Aufwendungen  addiert  werden.  In  der  Praxis  wird  die  indirekte  Methode  häufiger verwendet, obwohl die direkte Methode eine genauere Aufstellung der Zahlungsströme liefert und somit aussagekräftiger ist.148 11.4.2 Fondsveränderungsrechnung Der zweite Bestandteil der Kapitalflussrechnung ist die Fondsveränderungsrechnung. Unter einem Fonds verschmelzen bestimmte Bilanzposten zu einer buchhalterischen Einheit.  Der Finanzmittelfond  soll  über  das Liquiditätspotenzial  eines  Unternehmens  Aufschluss  geben  und  setzt  sich  aus Zahlungsmitteln  und  Zahlungsmitteläquivalenten  zusammen.  Die  Zahlungsmittel umfassen die Barmittel und die täglich fälligen Sichteinlagen. Zu den Zahlungsmitteläquivalenten gehören kurzfristige, besonders liquide Finanzmittel, die zu  jedem  Zeitpunkt  in  Zahlungsmittel  umgewandelt  werden  können  und  geringen Wertschwankungsrisiken ausgesetzt sind. Die Restlaufzeit zum Zeitpunkt des Erwerbs sollte dabei drei Monate nicht überschreiten, um in den Fonds einbezogen zu werden. Die Summe der Cashflows aus den Teilbereichen der Ursachenrechnung entspricht der Gesamtveränderung des Finanzmittelfonds. Dieser ist um wechselkurs-, konsolidierungskreis- und bewertungsbedingte Änderungen noch zu korrigieren und anschließend  mit  dem  Anfangsbestand  des  Finanzmittelfonds  zu  addieren.  Unter Konsolidierungskreis  versteht  man  die  in  den  Konzernabschluss einzubeziehenden Unternehmungen.  Als  Ergebnis  der  Fondsveränderungsrechnung  erhält  man  den Endbestand  der  Finanzmittel  wie  aus  der  folgenden  Abbildung  ersichtlich  ist.149 Zahlungswirksame  Veränderungen  des  Finanzmittelfonds  +/-  Wechselkurs-,  und bewertungsbedingte Änderungen des Finanzmittelfonds +/-Konsolidierungskreisbedingte Änderungen des Finanzmittelfonds + Finanzmittelfonds am  Anfang  der  Periode  =  Finanzmittelfonds  am  Ende  der  Periode  Abb.  11.6: Gliederung der Fondsveränderungsrechnung150 11.4.3 Cashflow aus der laufenden Geschäftstätigkeit Der Cashflow aus der laufenden Geschäftstätigkeit umfasst nach DRS  21.9  die  Aktivitäten in Verbindung mit wesentlichen, auf Erlöserzielung ausgerichteten  Tätigkeiten  sowie  sonstige  Aktivitäten,  die  nicht  unmittelbar  der Investitions- oder Finanzierungstätigkeit zuzuordnen sind. Darunter fallen in der Regel Geschäftsvorfälle, die das Periodenergebnis als Ertrag oder Aufwand beeinflussen. Diese Zahlungsvorgänge treten üblicherweise im Zusammenhang mit der Erlöserzielung  auf  z.  B.  im  Produktions-,  Verkaufs-  und  Dienstleistungsbereich.  In diesen Teilbereich der Ursachenrechnung fallen zudem die Ein- und Auszahlungen aus Ertragssteuern.  Cashflows  aus  Sicherungsgeschäften,  z.  B.  bei  Zahlungen  für  die Absicherung von Umsatzeinzahlungen, können dem Cashflow aus laufender Geschäftstätigkeit zugeordnet werden. Die folgende Abbildung zeigt den Cashflow aus der laufenden Geschäftstätigkeit nach der direkten Methode gemäß DRS 21.39.151 Einzahlungen von Kunden für den Verkauf von Erzeugnissen, Waren und Dienstleistungen -  Auszahlungen  an Lieferanten und Beschäftigte + sonstige Einzahlungen, die nicht der Investitions- und Finanzierungstätigkeit zuzuordnen sind sonstige  Auszahlungen, die nicht der Investitionsund Finanzierungstätigkeit zuzuordnen sind + Einzahlungen aus außerordentlichen Posten - Auszahlungen für außerordentliche Posten +/- Ertragssteuerzahlungen = Cashflow aus der laufenden Geschäftstätigkeit Abb. 11.7: Ermittlung des Cashflows aus laufender Geschäftstätigkeit 11.4.4 Cashflow aus der Investitionstätigkeit Zum Cashflow aus der Investitionstätigkeit  gehören  die  Aktivitäten,  die  mit  den  Zu-  und  Abgängen  von Vermögensgegenständen des Anlagevermögens in Verbindung stehen. Dazu gehören der Kauf und Verkauf von langfristigen Vermögensgegenständen sowie die sonstigen Finanzinvestitionen, die nicht zu den Zahlungsmitteläquivalenten zählen. Des Weiteren sind Zahlungsströme im Zusammenhang  mit  der Veränderung des Konsolidierungskreises sowie erhaltene Zinsen und Dividenden zu berücksichtigen.152 Die folgende Tabelle zeigt die Mindestgliederung des Cashflows nach der direkten Methode aus der Investitionstätigkeit gemäß  DRS  21.46. Einzahlungen aus Abgängen von Gegenständen des immateriellen Anlagevermögens - Auszahlungen für Investitionen in das immaterielle Anlagevermögen + Einzahlungen aus Abgängen  von  Gegenständen  des  Sachanlagevermögens  - Auszahlungen  für Investitionen  in  das  Sachanlagevermögen  +  Einzahlungen  aus  Abgängen  von Gegenständen des Finanzanlagevermögens - Auszahlungen für Investitionen in das Finanzanlagevermögen + Einzahlungen aus Abgängen aus dem Konsolidierungskreis - Auszahlungen für Zugänge zum Konsolidierungskreis + Einzahlungen aufgrund von Finanzmittelanlagen im Rahmen  der  kurzfr. Finanzdisposition -  Auszahlungen

aufgrund von Finanzmittelanlagen im Rahmen  der  kurzfr. Finanzdisposition + Einzahlungen aus außerordentlichen Posten .

- -  Auszahlungen  aus  außerordentlichen  Posten  +  erhaltene  Zinsen  -  erhaltene Dividenden  =  Cashflow  aus  der  Investitionstätigkeit  Abb. 11.8:  Cashflow  aus Investitionstätigkeit 11.4.5 Cashflow aus der Finanzierungstätigkeit Der Cashflow aus der Finanzierungstätigkeit umfasst alle Aktivitäten, die eine Auswirkung auf die Höhe und/oder  Zusammensetzung  der  Eigenkapitalposten  und/oder  der  Finanzschulden haben. Beispielsweise gehören Einzahlungen aus der Ausgabe von Anteilen oder aus der Aufnahme von Darlehen ebenso wie Auszahlungen zum Erwerb von Aktien oder für  die Tilgung von Darlehen zum Finanzierungsbereich. Zudem sind die gezahlten Zinsen und Dividenden zu erfassen.153 Einzahlungen aus Eigenkapitalzuführungen von Gesellschaftern des Mutterunternehmens -Einzahlungen aus Eigenkapitalzuführungen von anderen Gesellschaftern -Auszahlungen aus Eigenkapitalherabsetzungen an Gesellschafter des Mutterunternehmens -Auszahlungen aus Eigenkapitalherabsetzungen an andere Gesellschafter + Einzahlungen  aus  der  Begebung  von  Anleihen  und  der  Aufnahme  von  (Finanz)Krediten  -  Auszahlungen  aus  der  Tilgung  von Anleihen  und  (Finanz-)  Krediten  + Einzahlungen aus erhaltenen Zuschüssen/Zuwendungen + Einzahlungen aus außerordentlichen Posten - Auszahlungen aus außerordentlichen Posten - gezahlte Zinsen - gezahlte Dividenden an Gesellschafter des Mutterunternehmens - gezahlte Dividenden an andere Gesellschafter = Cashflow aus der Finanzierungstätigkeit

Die Kapitalflussrechnung verfolgt das Ziel, Transparenz über den Zahlungsmittelstrom eines Unternehmens herzustellen. Die Kapitalflussrechnung zeigt, ob ein Unternehmen in der Lage ist: künftig finanzielle Überschüsse zu erwirtschaften, seine Zahlungsverpflichtungen zu erfüllen, und Ausschüttungen an die Anteilseigner zu  leisten.  11.5  Aufbau  der  Kapitalflussrechnung  Die  Kapitalflussrechnung  ist  in Staffelform aufzustellen, unter Beachtung der durch den Standard DRS  21 vorgegebenen Mindestgliederungen. Sie ist in direkter oder indirekter Form aufzustellen,  wobei  meist  die  indirekte  Methode  angewandt  wird.  Gemäß  den Empfehlungen des Deutschen Rechnungslegungs Standards Commitee  e. V. Standardisierungsrats (DRSC) ist die indirekte Kapitalflussrechnung gemäß DRS 21 wie  folgt  aufgebaut.154  1.  Periodenergebnis  (Konzernjahresüberschuss/-fehlbetrag einschließlich Ergebnisanteilen anderer Gesellschafter) 2. +/-Abschreibungen/Zuschreibungen  auf  Gegenstände  des  Anlagevermögens  3.  +/-

Zunahme/Abnahme der Rückstellungen 4. +/-sonstige zahlungsunwirksame Aufwendungen/Erträge 5. -/+ Zunahme/Abnahme der Vorräte, der Forderungen aus Lieferungen  und  Leistungen  sowie  anderer Aktiva,  die  nicht  der  Investitions-  oder Finanzierungstätigkeit zuzuordnen sind 6. +/-Zunahme/Abnahme der Verbindlichkeiten aus Lieferungen und Leistungen sowie anderer Passiva, die nicht der  Investitions-  oder  Finanzierungstätigkeit  zuzuordnen  sind  7.  -/+  Gewinn/Verlust aus Abgang von Gegenständen des Anlagevermögens 8. +/-Zinsaufwendungen/Zinserträge 9. -sonstige Beteiligungserträge 10. +/-Aufwendungen/Erträge aus außerordentlichen Posten 11. +/- Ertragssteueraufwand/ertrag  12.  +  Einzahlungen  aus  außerordentlichen  Posten  13.  - Auszahlungen  aus außerordentlichen Posten 14. -/+ Ertragsteuerzahlungen 15. = Cashflow aus laufender Geschäftstätigkeit  (Summe  aus  1  bis  14)  16.  +  Einzahlungen  aus Abgängen  von Gegenständen des immateriellen Anlagevermögens 17. -Auszahlungen für Investitionen in das immaterielle Anlagevermögen 18. + Einzahlungen aus Abgängen von Gegenständen des Sachanlagevermögens 19. - Auszahlungen für Investitionen in das Sachanlagevermögen 20. + Einzahlungen aus Abgängen von Gegenständen des Finanzanlagevermögens 21. -Auszahlungen für Investitionen in das Finanzanlagevermögen 22. + Einzahlungen aus dem Abgang aus dem Konsolidierungskreis 23. - Auszahlungen für Zugänge zum Konsolidierungskreis 24. + Einzahlungen aufgrund von Finanzmittelanlagen im Rahmen  der  kurzfristigen Finanzdisposition 25. - Auszahlungen aufgrund von Finanzmittelanlagen im Rahmen der kurzfristigen Finanzdisposition 26. + Einzahlungen aus außerordentlichen Posten 27.  -  Auszahlungen  aus  außerordentlichen  Posten  28.  +  erhaltene  Zinsen  29.  + erhaltene Dividenden 30. = Cashflow aus der Investitionstätigkeit (Summe aus 16 bis 29)  31.  +  Einzahlungen  aus  Eigenkapitalzuführungen  von  Gesellschaftern  des Mutterunternehmens 32. + Einzahlungen aus Eigenkapitalzuführungen von anderen Gesellschaftern 33. -Auszahlungen aus Eigenkapitalherabsetzungen an Gesellschafter des Mutterunternehmens 34. -Auszahlungen aus Eigenkapitalherabsetzungen  an  andere  Gesellschafter  35.  +  Einzahlung  aus  der Begebung  von  Anleihen  und  aus  der  Aufnahme  von  (Finanz-)  Krediten  36.  Auszahlungen aus der Tilgung von Anleihen und (Finanz-)Krediten 37. + Einzahlungen aus erhaltenen Zuschüssen/Zuwendungen 38. + Einzahlungen aus außerordentlichen Posten 39. - Auszahlungen aus außerordentlichen Posten 40. - gezahlte Zinsen 41. gezahlte  Dividenden  an  Gesellschafter  des  Mutterunternehmens  42.  -  gezahlte

Dividenden an andere Gesellschafter 43. = Cashflow aus der Finanzierungstätigkeit (Summe aus 31 bis 42) 44. zahlungswirksame Veränderungen des Finanzmittelfonds (Summe aus 15, 30, 43) 45. +/- wechselkurs- und bewertungsbedingte Änderungen des Finanzmittelfonds 46. +/-Konsolidierungskreisbedingte Änderungen des Finanzmittelfonds 47. + Finanzmittelfonds am Anfang der Periode 48. = Finanzmittelbestand am Ende der Periode (Summe aus 44 bis 47)

Die Kapitalflussrechnung ist eine Zeitraumrechnung, bei der Bestandsveränderungen und  die  ihnen  zugrunde  liegenden  Finanzmittelbewegungen  ausgewiesen  werden. Merke Die Kapitalflussrechnung informiert über die Herkunft und die Verwendung der finanziellen Mittel eines Unternehmens.

## 11.6 Aussagegehalt der Kapitalflussrechnung

In der Praxis findet die Kapitalflussrechnung immer mehr Zuspruch. Sowohl intern im Finanzwesen  als  auch  für  externe  Analysten  dient  die  Kapitalflussrechnung  als wesentliche Entscheidungshilfe. Sie liefert darüber hinaus wichtige Informationen, um die  Liquiditätssituation  eines  Unternehmens  besser  einschätzen  zu  können.  Im Allgemeinen  hat  die  Kapitalflussrechnung  eine  Steuerungs-,  Dokumentations-  und Kontrollfunktion. Sie zeigt, ob die Finanzierung der Investitionen aus dem Umsatzprozess  heraus  erfolgte,  sprich  aus  der  laufenden  Geschäftstätigkeit155. Ebenso ist zu berücksichtigen, dass die Kapitalflussrechnung sowohl als Vergangenheitsrechnung  als  auch  als  Planungsrechnung  verwendet  werden  kann. Hierbei spricht man  dann  von  der  retrospektiven  oder von  der  prospektiven Kapitalflussrechnung.  Wird  sie  als  vergangenheitsorientierte  Rechnung  verwendet, gibt sie Informationen über Liquiditätsänderungen und die jeweiligen Ursachen. Dabei gilt  als  Informationsbasis  der  vorliegende  Jahresabschluss. Als  Planungsrechnung kann  man  hingegen  untersuchen,  ob  sich,  bei  den  vorhandenen  Teilplänen,  die Liquidität im Budgetjahr verbessert oder verschlechtert hat und wo mögliche Ursachen dieser  Veränderungen  liegen.  Hierbei  dienen  als  Informationsbasis  eine  Planbilanz bzw. Plan-Gewinn-  und  -Verlustrechnung.  Weiterhin  ist festzuhalten, dass  die Kapitalflussrechnung vor allem dazu dient, einen besseren Einblick in den Jahresabschluss zu erhalten, da eine bessere Beurteilung der Finanzund Kapitalsituation des Unternehmens möglich ist.156 Mithilfe der Kapitalflussrechnung kann die Zahlungsfähigkeit eines Unternehmens besser beurteilt werden, da sowohl

Ein-  und Auszahlungen als auch die Zahlungsströme innerhalb des Unternehmens analysiert werden.

## 2.2.3 Bildung einer Vergleichsgruppe

Bei  der  Unternehmensbewertung  mit  einer  Vergleichsgruppe  ist  die  Bildung  einer wirklich guten Peer Group immer die schwierigste Aufgabe, was auf eine Vielzahl von Problemen  zuruckzufiihren  ist:  1.  In  einem  ersten  Schritt  gilt  es,  direkt  mit  der  zu analysierenden  Gesellschaft  vergleichbare  Unternehmen  zu  identifizieren.  Viele Unternehmen verftigen aber tiber ein Produkt- bzw. Dienstleistungsportfolio, was in exakt  dieser  Zusammensetzung  bei  keinem  Wettbewerber  vorzufinden  ist.  Zudem kann  die regionale Umsatz-  bzw.  Ertragsaufteilung  teilweise  deutlich von  der vergleichbarer Unternehmen abweichen. Dies konnte entsprechend dazu fiihren, dass bei einem ahnlichen Produktportfolio die Ertragsstrukturen von zwei auf den ersten Blick  ahnlichen  Gesellschaften  trotzdem  stark  voneinander  abweichen.  Vor  diesem Hintergrund  ist  es  spater  haufig  sinnvoll,  die  Bewertung  auch  nicht  nur  auf  einen einzigen Multiplikator abzustellen, sondern mehrere Vergleiche parallel durchzufiihren. In  der  Praxis  bedeutet  dies,  dass  der  faire  Kurs  einer Aktie  auf  "unterschiedlichen Ebenen" (z. B. Umsatz-, EBIT- und/ oder JahresuberschussBasis etc.) in der Gewinnund  Verlustrechnung  ermittelt  werden  sollte.  2.  In  einem  zweiten  Schritt  muss  der Analyst  versuchen,  nationale  und  internationale  Unternehmen  zu  identifizieren,  die gewisse Ahnlichkeiten  zu  der  zu  analysierenden  Gesellschaft  haben.  In  der  Praxis spricht  man  in  diesem  Zusammenhang  von  der  Zusammenstellung  der  "Closest Comparables",  also  der  Unternehmen,  die  der  zu  analysierenden  Gesellschaft  am ahnlichsten  sind.  3. Aus  der  Sicht  des  Kapitalmarktes  ist  es  zudem  erforderlich  zu beachten, dass sich die Bewertungsniveaus der einzelnen Aktien teilweise deutlich voneinander unterscheiden. Ais Faustregel gilt, dass die DAX-Werte aus der gleichen Branche  tendenziell  uber  hohere  Multiplikatoren  verfugen  als  die  entsprechenden MDAX- oder SDAX-Werte dieser Branche. Dies ist sicherlich in gewissem MaBe auf die Borsenliquiditat zuruckzufiihren, da die Investoren bei liquideren Titeln tendenziell bereit  sind,  im  Gegenzug  hOhere  Risikopramien,  d.  h.  z.  B.  ein  hoheres  KGV  zu akzeptieren. Zudem  gibt es natiirlich auch branchenbzw. landerspezifische Multiplikatoren, die einen Vergleich der Gesellschaften zweifelsohne erschweren. Da haufig jedoch unter Portfolioaspekten nicht nur die Frage im Mittelpunkt steht, jetzt in bestimmte Branchen zu investieren, sondern in mittelstandische Werte und nicht in Standardwerte, ist es gerechtfertigt, die entsprechende Bewertung des Marktsegmentes mit in der Analyse zu berticksichtigen. 4. Bei der Gewichtung der einzelnen  Gruppen  zur  Ermittlung  des  Gesamtergebnisses  kann  jedoch  keine Faustregel angewendet werden. Ideal ware es, wenn es in jeder Gruppe die nahezu gleichen Ergebnisse gibt. Aber haufig zeigt die Praxis auch schon, dass sich bei der Eliminierung  von AusreiBern  die  Werte  tend  ziell  angleichen.  Solche  Extremwerte konnen z. B. dadurch entstehen, dass die Gesellschaft nach dem Turn-around gerade wieder in die Gewinnzone zuruckgekehrt ist, der Kurs jedoch mit Blick auf eine sehr positive  Zukunft  schon  wieder  deutlich  angezogen  hat,  sodass  sich  aus  diesem Zusammenhang  ein  nicht  wirklich  reprasentativer  Multiplikator  errechnet.  5.  Der Schliissel fur die wirklich gute Zusammenstellung einer Peer Group liegt insgesamt jedoch darin, nur auf verlassliche Daten zuruckzugreifen. Ein Blick auf die ConsensusSchatzungen  zeigt,  dass  es  vor  allem  bei  den  Nicht-Standardwerten  auf  dem Kurszettel haufig veraltete Schatzungen und damit dann auch verzerrte Ergebnisse gibt, gerade weil sich heute deutlich weniger Analysten urn die Aktien auf5erhalb des DAX kummern und auch die Zeitnahe bei der Aktualisierung haufig nicht gegeben ist. Eine Faustregel, welche Daten moglicherweise zu eliminieren sind und welche nicht, gibt  es  aber  auch  hier nicht. In der Praxis ist es  jedoch  sinnvoll, sich die Unternehmensnachrichten  anzuschauen,  urn  dann  eventuell  nur  die  Daten  zu nehmen, die nach einer veranderten Guidance des Managements zum Umsatz oder Ertrag  in  den  jeweiligen  Borseninformationssystemen  eingestellt  worden  sind.  Urn auch  auf  einen  breiteren  Datenkranz  zuruckgreifen  zu  konnen  ist  es  sinnvoll,  die Analyse  mindestens  auf  der  Basis  der  erwarteten  Werte  fUr  die  nachsten  zwei Perioden  durchzufuhren.  Das  Gesamtergebnis  dieses  Vergleichs  wird  je  nach  den Bewertungsanforderungen  aus  der  Praxis  meist  als  Mittelwert  oder  Median  der einzelnen Ergebnisse ermittelt. Wichtig und damit entscheidend fur die Qualitat des Gesamtergebnisses sind hier die Zusammenstellung der Vergleichsunternehmen und nicht  zuletzt  die  Qualitat  bzw.  Verlasslichkeit  der  DatenjPrognosen,  die  in  das Zahlenwerk einflief5en.  Ein  wichtiger  Punkt  dieser  Wertpapieranalyse  muss  jedoch immer beachtet werden: die Bewertung beinhaltet immer einen relativen Ansatz, d. h. wurden alle Unternehmen doppelt so hoch notieren, dann musste auch das analysierte Unternehmen  doppelt  so  hoch  notieren,  obwohl  die  Gesellschaft  sich  unverandert darstellen wurde.

## 2.2.4 Weitere Verfahren Alternative Modelle

In der Literatur und in der Praxis (hauptsachlich der Praxis der Unternehmensberatung) werden seit einigen Jahren alternative Bewertungsmodelle diskutiert. Die wohl bekanntesten sind das CFROI-Modell, das von der Unternehmensberatung Holt Value Associates entwickelt wurde sowie das EVA-Modell der  Unternehmens  beratung  Stern  Stewart  &amp;  Co.,  auf  die  im  folgenden  aus Komplexitatsgriinden jedoch nur sehr kurz eingegangen werden solI, da sie im Bereich der Aktienanalyse  bisher  erst  sehr  gering  angewandt  werden.  Cashflow  Return  on Investment (CFROI)-Modell Der CFROI-Ansatz zielt insbesondere auf eine vergangenheitsbezogene Performanceanalyse borsennotierter Unternehmen abo Bei dem CFROI handelt es sich urn einen internen ZinsfuB, der als eine Nachkalkulation der  Investitionsprojekte  aus  der  Vergangenheit  eines  Unternehmens  betrachtet werden  kann.  Mithilfe  des  Free-Cash-Flow-/Konvergenz-Verfahrens  werden  jedoch die zukiinftigen Brutto Cash Flows prognostiziert, die nach der fUr den CFROI giiltigen Definition aus Gewinn nach Steuern, Zinsaufwand und Abschreibungen bestehen. Das Free-Cash-Flow-Konvergenz-Verfahren basiert auf der Grundannahme, dass sowohl der CFROI als auch die Wachstumsrate der Investitionen eines Unternehmens iiber einen bestimmten Zeitraum (Konvergenzzeitraum) sich einem gesamtwirtschaftlichen oder Branchendurchschnitt nahern. Die urn die Investitionen der jeweiligen Periode gekiirzten Brutto Cash Flows (freie Cash Flows) sind anschlieBend bei der Ermittlung des Unternehmenswerts auf den Bewertungszeitpunkt zu diskontieren. Dabei wird der Kapitalisierungszins  aus  den  Marktwerten  und  den  mittels  des  Free-CashflowKonvergenz-Verfahrens prognostizierten freien Cashflows ermittelt. Economic-Valuebzw. Market-Value-Added-Konzept (EVA- bzw. MVA-Konzept) 1m Gegensatz zu den DCF-Modellen  und  dem  CFROI  basiert  das  EVA-Konzept  (sowie  aIle  weiteren, ahnlichen  Added-Value-Konzepte)  nicht  auf  Cashflows.  Grundsatzlich  wird  beim Added-Value  zunachst  eine  ErfolgsgroBe  ermittelt,  die  vom  operativen  Ergebnis ausgeht. Von dieser werden dann die Nutzungskosten des eingesetzten Kapitals, die so  genannte  "Capital  Charge"  abgezogen.  Bei  dem  EVA  handelt  es  sich  urn  eine PeriodenerfolgsgroBe, auch Residualeinkommensgro15e, die, sofern positiv, anzeigt, welcher  Unternehmenswert  in  der  betreffenden  Periode  geschaffen  wurde.  Fiir  die Berechnung des EVA werden als Ausgangsbasis die Kapitalrendite (Rate of Return), der Kapitalkostensatz (Cost of Capital) sowie das Betriebskapital (Capital, auch EBV Economic Book Value) benotigt. Das EVA errechnet sich dann wie folgt: EVA = (rate of return - cost of capital). capital Da cost of capital. capital die Capital Charge ergibt, erhiilt man durch Ausmultiplizieren: EVA = NOPAT - capital charge.

Hervorstechendes Merkmal des EVA ist dabei seine vollstandige Orientierung an den Daten des externen Rechnungswesens (jahresabschlussbasiert), wodurch es auch fi.ir externe Analysten  errechenbar  ist.  Dariiber  hinaus  ist  der  EVA  allerdings  ex-postorientiert  und  dient  daher  eher  der  Performance-Messung  des  Managements.  Zur Berechnung eines Unternehmenswertes bzw. Marktwert des Eigenkapitals miissen auf der Grundlage von Plan-Jahresabschliissen Planwerte fi.ir NOPAT und Capital Charge bzw. EBV bestimmt werden. Der Kapitalwert, der sich auf Grundlage der abgezinsten EVA  des  Planungszeitraumes  und  der  ewigen  EVAs  ergibt,  wird  als  Market  Value Added (MVA) bezeichnet. Der Marktwert des Eigenkapitals ergibt sich aus der Addition des MVA, des EBV sowie des Marktwertes des nicht betriebsnotwendigen Vermogens abziiglich des Marktwertes des verzinslichen Fremdkapitals.

## Bilanzkennzahlen

## Bilanzkennzahlen Definition

Bilanzkennzahlen sollen im Rahmen  der Bilanzanalyse einen Einblick in die Vermögens-, Finanz- und Ertragslage eines Unternehmens gewähren.

Bilanzkennzahlen  werden  vom  Unternehmen selbst, aber auch von Banken, Gläubigern, Investoren und Analysten berechnet und für Entscheidungen genutzt.

In den folgenden Artikeln sollen die wichtigsten Bilanzkennzahlen jeweils inklusive Formeln und Interpretation erläutert werden.

## Bilanzkennzahlen - nur Bilanz?

Der Begriff Bilanzkennzahlen wird nicht immer in dem Sinne trennscharf verwendet, als nur Kennzahlen auf Basis der Bilanz gemeint sind.

Vgl. in dem Zusammenhang auch Kennzahlen der GuV sowie Rentabilität.

ALTERNATIVE BEGRIFFE: Bilanzanalyse-Kennzahlen, Bilanzauswertung, Bilanzkennziffern, Bilanzkritik, Bilanzstrukturanalyse, Finanzkennzahlen, Kennzahlen Rechnungswesen.

## Zweck der Bilanzkennzahlen

Einzelne Bilanzposten (z.B.: Anlagevermögen in Höhe von 10 Mio. €) sind i.d.R. wenig aussagekräftig. Interessanter sind damit in Zusammenhang stehende Fragestellungen, z.B.

- · wie viel  macht das Anlagevermögen vom Gesamtvermögen aus? (Kennzahl: Anlagenintensität) oder
- · ist  das Anlagevermögen auch entsprechend langfristig finanziert? (Kennzahl: Goldene Bilanzregel).

Die Bilanzkennziffern setzen  Posten  der  Bilanz  in  ein  Verhältnis  zueinander.  Dies kann "vertikal" (d.h.  Posten  der  Aktivaseite  der  Bilanz  werden  in  ein  Verhältnis zueinander gesetzt; oder entsprechend Posten der Passivaseite) oder "horizontal" (Posten  der  Aktivaseite  werden  in  Beziehung  zu  Posten  der Passivaseite gesetzt) geschehen.

Daraus lassen sich Erkenntnisse über die Finanzierung , die Flexibilität (bei rückläufigem Geschäft), die Bonität (Kreditwürdigkeit) oder die finanzielle Stabilität eines Unternehmens gewinnen.

## Bilanzkennzahlen Übersicht

Die Bilanzkennzahlen stellen sich in der Übersicht und gegliedert nach Bilanzzusammenhängen wie folgt dar:

## Bilanzanalyse-Kennzahlen in der Übersicht:

- · Vertikale Bilanzstruktur
- · Vermögensstruktur
- o Anlagenintensität
- o Umlaufintensität
- · Kapitalstruktur
- o Eigenkapitalquote
- o Fremdkapitalquote
- o Verschuldungsgrad
- · Horizontale Bilanzstruktur
- o Horizontale Finanzierungsregeln
- ▪ Goldene Bilanzregel
- ▪ Goldene Finanzierungsregel
- ▪ Working Capital
- o Liquiditätsgrade

## Bilanzkennzahlen: Interpretation richtig gemacht

Die Analyse der Bilanzkennzahlen befasst sich mit der Untersuchung der derzeitigen und zukünftigen wirtschaftlichen Lage von Unternehmen anhand des Jahresabschlusses.

Dieser ergibt sich aus der Bilanz, der Gewinn- und Verlustrechnung sowie dem Anhang und eventuell einem Lagebericht. Diese Analyse kann intern, also vom Unternehmen selbst, oder extern, also von einem Analysten durchgeführt werden.

Mithilfe der Bilanzanalyse können außerdem einige Kennzahlen eines Unternehmens ermittelt werden, die auch über die Möglichkeiten zur Erfüllung externer Forderungen Auskunft geben können.

Bilanzkennzahlen: Was man bei der Interpretation beachten sollte

Bei der Interpretation  von  Bilanzkennzahlen  kann  es  Probleme  geben,  denn betriebswirtschaftliche Kennzahlen sind nicht gesetzlich definiert.

Dadurch  ist  es  möglich,  dass  beispielsweise  ein  Unternehmen  die  Umsatzrendite als Gewinn anders bestimmt als ein anderes Unternehmen, das nicht den Gewinn, sondern  den  Gewinn  vor  Steuern  (Earnings  Before  Taxes,  abgekürzt  EBT)  im Verhältnis zum Umsatz angibt.

Außerdem können die Kennzahlen als absolute Größen (also den Gewinn in €) oder als Verhältniskennzahlen beziehungsweise relative Kennzahlen (also den Gewinn im Verhältnis zum Umsatz in Prozent ausgedrückt) angegeben werden. Das kann jedes Unternehmen für sich entscheiden.

Bei  einem  Unternehmensvergleich  sollte  also  darauf  geachtet  werden,  wie  die Unternehmen die Bilanzkennzahlen bestimmt haben.

## Interpretation von Bilanzkennzahlen

Für eine Beurteilung der Unternehmenskennzahlen muss ein Maßstab vorliegen, mit dem die Bilanzkennzahlen verglichen werden können. Dafür gibt es 3 verschiedene Möglichkeiten:

- 1. Die Vorjahresvergleiche: Vergleiche mit den vergangenen Jahren.
- 2. Soll-Ist-Vergleiche: Vergleiche mit Soll-, Budget- und Planwerten.
- 3. Branchenvergleiche: Vergleiche mit anderen Unternehmen derselben Branche.

## Beispiel:

Nehmen wir an, ein Automobilhersteller stellt fest, dass sein Umsatz im Geschäftsjahr 2010  5%  betragen  hat.  Diese  Bilanzkennzahl  sagt  uns  ohne  einen  Maßstab  nicht besonders viel.

Wenn man aber weiß, dass der Umsatz im vorherigen Jahr, also 2009, 6% betragen hat, der Planumsatz bei 7% lag und ähnliche Unternehmen derselben Branche einen Umsatz  von  9%  erwirtschaftet  haben,  wird  klar,  dass  der  Automobilhersteller  im Vergleich einen schlechten Umsatz erzielt hat.

## Bilanzkennzahlen und ihre Aussagekraft

Einzelne Bilanzkennzahlen sind in der Regel nur wenig aussagekräftig. Interessant wird es erst, sobald man sie mit anderen Unternehmen, Vorjahren oder Planwerten vergleicht.

Die  Bilanzkennzahlen  setzen  Posten  der  Bilanz  in  ein  Verhältnis  zueinander  und erhalten dadurch ihre Aussagekraft.

Es  lassen  sich  so  Erkenntnisse  über  die  Finanzierung,  die  Flexibilität,  die  Bonität (Kreditwürdigkeit) oder die finanzielle Stabilität eines Unternehmens gewinnen.

Fazit: Insgesamt  muss  bei  der  Interpretation  von  Bilanzkennzahlen  also  einiges beachtet werden, aber ein Blick auf die Zahlen ist insbesondere vor einer Investition in ein Unternehmen sehr wichtig.

Denn so können genügend Informationen über die Wirtschaftslage eines Unternehmens sowie deren Kreditwürdigkeit ermittelt werden.

## Bilanzkennzahlen

Enthält: Definition · Grafiken · Übungsfragen

Unter Bilanzkennzahlen versteht man Kennzahlen, mit deren Hilfe Unternehmen und sonstige Stakeholder die Lage des Unternehmens überprüfen können. Zudem helfen derartige  Kennziffern  dabei,  Entscheidungen  auf  fundierter  Datenbasis  zu  treffen. Insbesondere in der Bilanzanalyse kommen die Bilanzkennzahlen zum Einsatz.

In der folgenden Lektion erfährst du alles rund um das Thema Bilanzkennzahlen. Am Ende der Lektion kannst du mit Hilfe einiger Übungsaufgaben das gelernte Wissen wiederholen und vertiefen.

- Bilanzanalyse-
- · Synonyme: Bilanzkennziffern | Kennzahlen | Finanzkennzahlen
- · Englisch: balance sheet

Inhalt dieser Lektion

- · Warum sind Bilanzkennzahlen wichtig?
- · Die Bilanzkennzahlen
- o Sinn und Zweck der Bilanzkennzahlen
- o Unterschiedliche Bilanzkennzahlen
- o Aussagekraft der Bilanzkennzahlen
- · Bilanzkennzahlen - Vor und Nachteile
- o Die Vorteile der Verwendung von Bilanzkennzahlen
- o Die Nachteile der Verwendung von Bilanzkennzahlen
- · Übungsfragen
- · Results

Warum sind Bilanzkennzahlen wichtig?

Die Bilanz ist für Unternehmen von enormer Bedeutung.

Dabei fungiert die Bilanz zum Erreichen zweiter unterschiedlicher Zwecke :

- · Einhaltung der handelsrechtlichen Vorschriften
- · Bewertung des Unternehmens

Allerdings ist eine Bilanz nur begrenzt geeignet, um aussagekräftige Bewertungen zu ermöglichen. Hier kommen die unterschiedlichen Bilanzkennzahlen zum Einsatz. Zum einen weisen diese Bilanzkennzahlen eine autonome  Aussagekraft auf und ermöglichen darüber hinaus den Vergleich unterschiedlicher Unternehmen sowie des eigenen Unternehmens innerhalb einer fortschreitenden zeitlichen Periode.

## Die Bilanzkennzahlen

Bilanzkennzahlen  ermöglichen  eine  definitive Aussage  in  Zeiten  der  umfassenden Informationen. Bilanzkennzahlen dienen dabei als wichtiges Instrument zur Bewertung der Bilanz und der grundsätzlichen Lageanalyse für das gesamte Unternehmen. Dabei unterscheiden sich die Bilanzkennzahlen in ihrer Ausprägung und Art.

## Sinn und Zweck der Bilanzkennzahlen

Einzelne Posten in der verpflichtenden Bilanz der Unternehmen weisen häufig eine geringe  Aussagekraft auf. Demgegenüber  helfen Bilanzkennzahlen dabei, die Aussagekraft zu erhöhen. Durch das Aufzeigen eines Verhältnisses von unterschiedlichen Posten der Bilanz ist es möglich, die Lage des Unternehmens zu bewerten.

Verantwortliche  im  Unternehmen  oder  unterschiedliche  Stakeholder  haben  ein ureigenes Interesse daran, aufschlussreiche und aussagekräftige Daten zu gewinnen.

Erkenntnisse  über  verschiedene  Bereiche  sind  somit  mit  Bilanzkennzahlen möglich, woraus sich Sinn und Zweck dieser Nutzung ergibt :

- · Bonität des Unternehmens
- · finanzielle Stabilität des Unternehmens
- · Finanzierung des Unternehmens

Unterschiedliche Bilanzkennzahlen

Bilanzkennzahlen betreffen unterschiedliche Bereiche der Bilanz.

## Eine grundsätzliche Unterteilung erfolgt in :

- · Kennzahlen der vertikalen Bilanzstruktur
- · Kennzahlen der horizontalen Bilanzstruktur

Die  Kennzahlen  der  vertikalen  Bilanzstruktur  betreffen  sowohl  die  Struktur  des Vermögens als auch des Kapitals eines Unternehmens.

## Insbesondere die folgenden Bilanzkennzahlen sind vertikaler Natur :

- · Anlagenintensität
- · Umlaufintensität
- · Eigenkapitalquote
- · Fremdkapitalquote

Demgegenüber betreffen die Bilanzkennzahlen der horizontalen Natur insbesondere die Regeln der Finanzierung eines Unternehmens sowie die Liquidität.

## Bilanzkennzahlen Vertikale und horizontale Bilanzkennzahlen

![Image](CON01_Jahresabschluss_artifacts/image_000000_6e97a7571ed453447793871d7540cd5ee5c7f5c3b63e905a3f9499b6fbf94fd4.png)

**Bildbeschreibung:** Das Bild zeigt eine grafische Darstellung von Bilanzkennzahlen, gegliedert in zwei Hauptbereiche: "Vertikale Bilanzkennzahlen" und "Horizontale Bilanzkennzahlen". Die Darstellung hat eine hierarchische Struktur, die durch die Anordnung der Kästchen verdeutlicht wird.

**Hier ist eine detaillierte Beschreibung der einzelnen Elemente:**

1.  **Hauptüberschrift:** "Bilanzkennzahlen" befindet sich oben im Bild und dient als allgemeine Bezeichnung des Themas.

2.  **Vertikale Bilanzkennzahlen (linker Bereich):**
    *   **Überschrift:** "Vertikale Bilanzkennzahlen" kennzeichnet diesen Bereich.
    *   **Analyse der Kapitalstruktur:** Dieser Eintrag deutet auf eine Untersuchung der Zusammensetzung des Eigen- und Fremdkapitals hin.
    *   **Eigenkapitalquote:** Ein wichtiger Finanzkennwert, der das Verhältnis von Eigenkapital zu Gesamtkapital angibt.
    *   **Fremdkapitalquote:** Das Gegenstück zur Eigenkapitalquote, da sie das Verhältnis von Fremdkapital zu Gesamtkapital anzeigt.
    *   **Statistischer Verschuldungsgrad:** Zeigt die Höhe der Schulden im Verhältnis zum Eigenkapital an.

3.  **Horizontale Bilanzkennzahlen (rechter Bereich):**
    *   **Überschrift:** "Horizontale Bilanzkennzahlen" kennzeichnet diesen Bereich.
    *   **Deckungsgrad:** Ein Maß für die Fähigkeit eines Unternehmens, seine finanziellen Verpflichtungen zu begleichen.
    *   **Liquiditätsgrad:** Misst die Fähigkeit eines Unternehmens, seine kurzfristigen Schulden aus dem laufenden Geschäft zu bezahlen.
    *   **Working Capital:**  Ein englischer Begriff, der auf Deutsch üblicherweise als "laufendes Geschäftskapital" oder "operatives Kapital" übersetzt wird und die Differenz zwischen Umlaufvermögen und kurzfristigen Verbindlichkeiten darstellt.

**Bedeutung:**

Das Bild zeigt eine Art Übersicht über verschiedene Kennzahlen zur Beurteilung der finanziellen Situation eines Unternehmens. Es unterscheidet zwischen Kennzahlen, die die *Vertikale* Struktur der Bilanz (d.h. die Zusammensetzung des Kapitals) und Kennzahlen, die die *Horizontale* Bilanzstruktur


Bilanzkennzahlen: Vertikale und horizontale Bilanzkennzahlen

Aussagekraft der Bilanzkennzahlen

Mithilfe  der  Bilanzkennzahlen  können  Unternehmen  bewerten,  ob  das  eigene Unternehmen wirtschaftlich gesund ist. Das unmittelbare Verhältnis der unterschiedlichen Posten einer Bilanz ermöglicht die Beleuchtung diverser Aspekte, die  letztendlich  alle  Verbesserungsbedarf  identifizieren  und  Aussagen  über  die wirtschaftliche Leistungsfähigkeit des Unternehmens ermöglichen.

Bilanzkennzahlen - Vor und Nachteile

Bilanzkennzahlen kommen in vielen Unternehmen zum Einsatz. Dabei gibt es sowohl Vor- als auch Nachteile bei der Verwendung von Bilanzkennzahlen für die betroffenen Akteure.

Die Vorteile der Verwendung von Bilanzkennzahlen

Durch die regelmäßige Nutzung von Bilanzkennzahlen für die Bewertung von Unternehmen profitieren diese von unterschiedlichen Vorteilen :

- · Erkennung von Abweichungen beim Unternehmen
- · einfache Entwicklung von Zielgrößen für das Unternehmen
- · vereinfachte Unternehmenssteuerung
- · Identifizierung von Schwachstellen

Die Nachteile der Verwendung von Bilanzkennzahlen

Andererseits sind der Nutzung von Bilanzkennzahlen jedoch auch Nachteile inhärent.

Insbesondere  die  folgenden  Aspekte  der  Nutzung  werden  als  nachteilig bewertet :

- · beliebige Manipulation durch Wahl der Kennzahlen
- · Fokussierung auf kurzfristigen Erfolg und Vernachlässigung langfristiger Erfolge
- · Risiko einer einseitigen Fokussierung

## Welche Bilanzkennzahlen gibt es und welche sind wirklich wichtig?

In  einem  Jahresabschluss  werden  zahlreiche  Informationen  über  ein  Unternehmen vorgestellt. So enthält der Abschluss regelmäßig eine Bilanz und eine Gewinn- und Verlustrechnung. Je nach Unternehmen werden auch ein Anhang und ein Lagebericht veröffentlicht. In diesen Unterlagen finden sich zahlreiche Daten, Zahlen und Fakten über  ein  Unternehmen.  Sowohl  für  das  Unternehmen  selbst  als  auch  externe Stakeholder,  wie  beispielsweise  Aktionäre  oder  Investoren,  kann  es  von  großem Interesse sein, eine Analyse vorzunehmen und noch mehr über das Unternehmen zu erfahren. Bilanzkennzahlen kommen hierbei regelmäßig zum Einsatz. Doch welche Kennzahlen sind besonders wichtig?

## Bilanzkennzahlen: Definition

In  einem  Jahresabschluss  werden  viele  Positionen  und  Zahlen  aufgelistet.  Diese liefern bereits eine ganze Menge Informationen über ein Unternehmen. Doch mithilfe von  Kennzahlen  können  häufig  noch  viel  tiefgehendere  Erkenntnisse  gewonnen werden. Durch Bilanzkennzahlen werden also verschiedene Bilanzpositionen miteinander  ins  Verhältnis  gesetzt.  Das  Ergebnis  kann  positive  Entwicklungen  des Unternehmens aufzeigen oder auch auf mögliche Probleme hinweisen. Deshalb sind Bilanzkennzahlen für das Controlling von großer Bedeutung. Sie werden regelmäßig ermittelt und  im  Idealfall  über  einen  langen  Zeitraum hinweg  betrachtet  und miteinander verglichen.

Hinweise  auf  Liquiditätsschwierigkeiten  lassen  sich  so  frühzeitig  identifzieren.  Im Liquiditätsmanagement  können  so  beispielsweise  mögliche  Probleme  durch  ein unzureichendes  Working  Capital  Management  erkannt  und  Maßnahmen  ergriffen werden.

In  der  Literatur  wird  häufig  zwischen  vertikalen  und  horizontalen  Bilanzkennzahlen unterschieden. Bei den vertikalen Bilanzkennzahlen werden beispielsweise verschiedene  Bilanzpositionen nur von  der  Aktiva oder  nur  von  der  Passiva miteinander in Beziehung gesetzt. Bei horizontalen Bilanzkennzahlen werden sowohl Positionen der  Aktiva als auch Positionen der Passiva bei der  Berechnung miteinbezogen.

## Bilanzkennzahlen berechnen

Bilanzkennzahlen werden insbesondere für eine Bilanzanalyse ermittelt. Die Kennzahlen werden durch verschiedene Bilanzpositionen ermittelt. Hinweis: Bei dem Begriff  Bilanzanalyse  könnte  man  nun  meinen,  dass  ausschließlich  die  Daten  der Bilanz  untersucht  werden.  Doch  tatsächlich  wird  der  gesamte  Jahresabschluss  als Datenquelle  herangezogen  -  und  damit  auch  beispielsweise  die  Gewinn-  und Verlustrechnung.

Die Berechnung erfolgt auf der Basis verschiedener Formeln. Nachfolgend werden beispielhaft einige wichtige Bilanzkennzahlen vorgestellt:

## Wichtige Bilanzkennzahlen: Übersicht

Vorweg  sei  darauf  hingewiesen:  Es  gibt  zahlreiche  Kennzahlen  und  damit  auch verschiedene Möglichkeiten, welche Daten analysiert werden sollen. Welche Bilanzkennzahlen also konkret ermittelt werden, hängen individuell vom Unternehmen und dem Zweck der Kennzahlen ab.

So  können  beispielsweise  konkrete  Einzelfragen  beantwortet  werden,  wie:  Zu welchem Anteil ist das Unternehmensvermögen eigenkapitalfinanziert? Doch bei einer Bilanzanalyse wird eine umfangreichere Betrachtung vorgenommen.  Sie zielt regelmäßig  darauf  ab,  ein  konkretes  Bild  über  das  Unternehmen  als  Ganzes  zu bekommen.  Es  gibt  deshalb  keinen  einheitlichen  Standard,  wie  viele  oder  welche Kennzahlen ein Unternehmen genau berechnen sollte.

Es gibt jedoch einige Kennzahlen, die sich besonders bewährt haben in der Praxis und deshalb vergleichsweise häufig ermittelt werden. Hier ein kleiner Überblick zu einigen wichtigen Bilanzkennzahlen:

- · Eigenkapitalquote
- · Fremdkapitalquote
- · Verschuldungsgrad
- · Anlagendeckungsgrad
- · Liquidität 1. Grades
- · Liquidität 2. Grades
- · Liquidität 3. Grades
- · Working Capital
- · Anlagenintensität
- · Umlaufintensität
- · Vorratsintensität

## Bilanzkennzahlen: Formeln

Wichtige Formeln zu Bilanzkennzahlen sind beispielsweise:

- · Eigenkapitalquote = (Eigenkapital / Bilanzsumme) x 100
- · Fremdkapitalquote = (Fremdkapital / Bilanzsumme) x 100
- · Verschuldungsgrad = Fremdkapital / Eigenkapital x 100
- · Anlagenintensität = Anlagevermögen / Gesamtvermögen x 100
- · Umlaufintensität = Umlaufvermögen / Gesamtvermögen * 100

Es  gibt  jedoch  zahlreiche  Kennzahlen  und  damit  auch  viele  Formeln.  Bei  einer Bilanzanalyse  kommt es  darauf  an,  was  genau  betrachtet  werden  soll.  So  können beispielsweise Kennzahlen berechnet werden, die die Produktion des Unternehmens genauer unter die Lupe nehmen. Andere Kennzahlen betrachten das Personalwesen. Und bestimmte Kennzahlen können die finanzielle Situation des Unternehmens näher analysieren.

## Bilanzkennzahlen zur Liquidität

Auch zur Liquiditätssituation eines Unternehmens können Kennzahlen interessante Informationen liefern. So gibt es beispielsweise die Kennzahlen:

- · Liquidität 1. Grades
- · Liquidität 2. Grades
- · Liquidität 3. Grades

Mit der Liquidtät 1. Grades wird ermittelt, ob das Unternehmen seinen kurzfristigen Verbindlichkeiten mit den vorhandenen liquiden Mitteln nachkommen kann. Die Formel lautet:

Liquide Mittel / kurzfristige Verbindlichkeiten × 100

Mit der Liquidität 2. Grades wird ermittelt, ob das Unternehmen seinen kurzfristigen Verbindlichkeiten  mit  den  vorhandenen  liquiden  Mitteln  zuzüglich  der  kurzfristigen Forderungen nachkommen kann. Die Formel lautet:

(Liquide Mittel + kurzfristige Forderungen) / kurzfristige Verbindlichkeiten × 100

Mit der Liquidität 3. Grades wird ermittelt, inwiefern die kurzfristigen Verbindlichkeiten durch Mittel des Umlaufvermögens finanziert werden könnten. Die Formel lautet hier:

## Umlaufvermögen / kurzfristige Verbindlichkeiten x 100

Diese Liquiditätskennzahlen können also mithilfe der Bilanz ermittelt werden. Sie sind sowohl für externe Stakeholder interessant,  um beispielsweise  die  Kreditwürdigkeit eines Unternehmens zu beurteilen. Doch auch für interne Zwecke sind diese Daten relevant. Das Liquiditätsmanagement sollte immer sicherstellen, dass das Unternehmen seinen Verbindlichkeiten nachkommen kann und zahlungsfähig bleibt. Im Idealfall kann das Liquiditätsmanagement in Echtzeit verschiedene Kennzahlen im Blick  behalten.  Moderne Technologien ermöglichen dies bereits und beschleunigen das Controlling dadurch erheblich.

## Interpretation der Bilanzkennzahlen

Bei der Interpretation von Bilanzkennzahlen ist Fingerspitzengefühl erforderlich. Eine Kennzahl allein lässt noch kein Urteil darüber zu, ob ein Unternehmen sich positiv entwickelt oder möglicherweise krisengefährdet ist. Wichtig ist, einen Gesamteindruck zu erhalten. Und dazu sollten verschiedene Aspekte betrachtet werden.

Zudem  spielt  der  Betrachtungszeitraum  eine  große  Rolle.  Wenn  beispielsweise bestimmte Kennzahlen über einen längeren Zeitraum ermittelt und analysiert werden, lassen sich bestimmte Trends besser abzeichnen. Wenn hingegen lediglich ein Quartal betrachtet wird, ist das für sich nicht unbedingt repräsentativ für die Gesamtentwicklung eines Unternehmens.

Bilanzkennzahlen  können  auch  danach  beurteilt  werden,  ob  bestimmte  Richtwerte erreicht  oder  unterschritten  werden.  Das  ist  beispielsweise  insbesondere  bei  der Kapitalstruktur  des  Unternehmens  interessant.  Branchenspezifische  Unterschiede müssen hierbei beachtet werden.

Nimmt man beispielsweise die Fremdkapitalquote, so wird regelmäßig als Richtwert eine  Quote  von  max.  60-70  %  empfohlen.  Doch  in  manchen  Branchen  ist  die

Fremdverschuldung regelmäßig höher als in anderen. Das sollte bei der Beurteilung daher miteinbezogen werden.

Wichtig: Bilanzkennzahlen werden beispielsweise insbesondere von Banken analysiert. Sie sind bei Kreditwürdigkeitsprüfungen eine wichtige Informationsquelle. Doch auch Investoren und Aktionäre interessieren sich häufig für Bilanzkennzahlen, um Investitionsrisiken besser einschätzen zu können. Für Unternehmen ist es deshalb wichtig, die Bilanzkennzahlen im Blick zu halten und ggf. Maßnahmen zu ergreifen, um  diese  zu  optimieren.  Denn  das  kann  sich  erheblich  auf  die  Finanzierung  des Unternehmens auswirken.

## Kritik an Bilanzkennzahlen

Bilanzkennzahlen können ohne Frage interessante Informationen liefern. Sie können dazu beitragen, dass Unternehmen sich messbare Ziele setzen und diese entsprechend verfolgen. Zudem tragen Kennzahlen zur Transparenz bei und liefern Informationen zur Entwicklung eines Unternehmens. Allerdings bringen Kennzahlen auch Schwächen mit sich, wenn sie fehlerhaft zur Anwendung kommen.

Kennzahlen wirken sehr faktenbasiert und damit unerschütterlich. Doch im Umgang mit Kennzahlen wird ein Bewusstsein benötigt, wie diese ermittelt wurden. Entscheidend ist, dass die Bilanzkennzahlen nicht fehlinterpretiert werden. Auch bei Kennzahlenanalysen  gibt  es  Grenzen!  Wichtig  ist  zum  Beispiel  die  Frage,  welche Daten herangezogen werden.

Wenn die Liquiditätssituation eines Unternehmens beurteilt werden soll, jedoch dafür die Daten des letzten Jahresabschlusses als Informationsquelle genutzt werden, dann kann die Realität diese Ergebnisse schon längst überholt haben. Die Kennzahlenanalyse kann dann zu einer Fehlinterpretation führen. Auf diese Weise lassen sich sogar Kennzahlen manipulativ einsetzen und ein wesentlich positiveres Bild eines Unternehmens zeichnen, als es der aktuellen Situation entspricht. Deshalb sollten auch Kennzahlen kritisch hinterfragt werden.

## Bilanzkennzahlen

Bilanzkennzahlen  sind  die  Grundlage  des  Controllings!  Hier  bekommst  du  eine Übersicht der wichtigsten Kennzahlen und die grundlegendsten Formeln erklärt.

Du  möchtest  alles  audiovisuell  zusammengefasst  bekommen?  Dann  schau  dir unser Video dazu an.

Inhaltsübersicht

## Bilanzkennzahlen Übersicht

Bilanzkennzahlen gehören zu den betriebswirtschaftlichen Kennzahlen .  Sie fassen die  wichtigsten  Zahlen  aus  der  Bilanz  zusammen  und  stellen  diese  ins  Verhältnis. Dadurch  lässt  sich  die  wirtschaftliche  Lage  des  Unternehmens  darstellen  und  mit Konkurrenten aus der gleichen Branche vergleichen.

Bilanzkennzahlen sind zu unterschiedlichen Zwecken von Bedeutung:  Sie lassen sich zur internen Erfolgsmessung verwenden, um Unternehmenstätigkeiten zu vorherigen Jahren in Vergleich zu setzen. Bilanzkennzahlen besitzen außerdem eine Controllingfunktion und dienen im Rahmen von Soll - Ist - Vergleichen dem Zweck einer  internen  Unternehmenssteuerung.  Darüber  hinaus  lassen  sich  mit  ihrer  Hilfe auch  die  wirtschaftliche  Lage  von  Unternehmen  extern  bewerten.  Hier  ist  eine Übersicht über die wichtigsten Kennzahlen, die die Aussagekraft der Bilanz steigern und übersichtlich zusammenfassen:

Neben  den  Bilanzkennzahlen  spielen  in  der  Analyse  der Wirtschaftlichkeit von Unternehmen auch Erfolgskennzahlen , Finanzkennzahlen und Rentabilitätskennzahlen eine wichtige Rolle. Vor allem die Rentabilitätskennzahlen werden unter Umständen zu den Bilanzkennzahlen gezählt. Zu ihnen gehören die Eigenkapitalrentabilität , die Fremdkapitalrentabilität, die Gesamtkapitalrentabilität und

die

Umsatzrentabilität.

Wiedergabe starten oder stoppenWebseite öffnen

## Bilanzkennzahlen Formel

Im  Folgenden  schauen  wir  uns  die  Berechnung  und  Formeln  der  wichtigsten Bilanzkennzahlen am Beispiel einer Bilanz an. Stell dir vor, du machst ein Praktikum bei  der  Büroflix  GmbH  und  wurdest  gebeten  die  wirtschaftliche  Situation  des Unternehmens übersichtlich zusammenzufassen. Da fällt dir ein, dass Bilanzkennzahlen wichtige Zusammenhänge  aus  der  Bilanz hervorheben. Du beschließt  deshalb  die  wichtigsten  Bilanzkennzahlen  zu  berechnen.  Dabei  liegt  dir folgende Bilanz des letzten Jahres vor.

| Aktiva                                | Passiva                                 |
|---------------------------------------|-----------------------------------------|
| Anlagevermögen: 500.000               | Eigenkapital: 300.000                   |
| davon Maschinen 500.000               |                                         |
| Umlaufvermögen: 200.000               | Fremdkapital: 400.000                   |
| davon Flüssige Mittel 150.000         | davon kurzfristige Bankkredite 150.000  |
| davon kurzfristige Forderungen 50.000 | davon langfristige Bankdarlehen 250.000 |
| Gesamtvermögen: 700.000               | Gesamtvermögen: 700.000                 |

Dann gehen wir die Berechnung der Bilanzkennzahlen Stück für Stück durch. Fangen wir zuerst mit den vertikalen Bilanzkennzahlen zur Kapitalstruktur an.

## Eigenkapitalquote

Mit der Eigenkapitalquote bestimmst du den Anteil vom eigen Kapital am Gesamtkapital. Dazu teilst du das Eigenkapital durch das Gesamtkapital und nimmst die Zahl mal 100, um den Wert in Prozent zu erhalten.

## Die Formel lautet:

In unserem Beispiel ergibt sich durch Einsetzen der Werte eine Eigenkapitalquote von 42,86%:

Die Büroflix GmbH ist mit 42,86 % Eigenkapitalquote solide aufgestellt, da sie viele Mittel aus dem firmeneigenen Anlagevermögen selbst besitzt.

## Fremdkapitalquote

Die Fremdkapitalquote ist der Gegenpart zur Eigenkapitalquote und gibt den Anteil des Fremdkapitals am Gesamtvermögen wieder. Dabei teilst du das Fremdkapital durch das Gesamtkapital und multiplizierst das Ergebnis mit 100.

Die Formel für die Fremdkapitalquote ist:

<!-- formula-not-decoded -->

In unserem Beispiel ergibt sich durch Einsetzen der Werte eine Fremdkapitalquote von 57,14%:

<!-- formula-not-decoded -->

Die Eigenkapitalquote und Fremdkapitalquote zusammen gerechnet muss stets 100% ergeben! Ein Unternehmen gilt in der Regel als 'gesund' , wenn die Fremdkapitalquote nicht höher als 66% ist.

## Verschuldungsgrad

Der Verschuldungsgrad gibt das Verhältnis von Eigenkapital und Fremdkapital wieder. Hierbei teilst du das Fremdkapital durch das Eigenkapital und multiplizierst die Zahl mit 100. Der Verschuldungsgrad gibt an, inwiefern ein Unternehmen fremdfinanziert ist. Als allgemeine Faustregel sagt man, dass der Verschuldungsgrad nicht höher als 200%  sein  sollte,  da  sonst  das  Fremdkapital  mehr  als  doppelt  so  hoch  wie  das Eigenkapital wäre.

Die Formel für den Verschuldungsgrad ist:

<!-- formula-not-decoded -->

In unserem Beispiel ergibt sich durch Einsetzen der Werte ein Verschuldungsgrad von 133%:

<!-- formula-not-decoded -->

Die Büroflix GmbH ist offensichtlich nicht übertrieben fremdfinanziert sondern besitzt einen Verschuldungsgrad von weniger als 200 %.

## Umlaufintensität

Neben  den  Bilanzkennzahlen  der Kapitalstruktur gehören  zu den wichtigsten Kennziffern auch die der Vermögensstruktur. Diese werden unterteilt in die Umlaufintensität und die Anlagenintensität.

Die Umlaufintensität bezeichnet den Anteil vom Umlaufvermögen am Gesamtvermögen. Die Kennzahl berechnet also den Teil des Gesamtvermögens, der in  kurzfristigen  Vermögensgegenständen  wie  Beständen,  Vorräten  oder  liquiden Mitteln gebunden ist. Dazu verwendest du folgende Formel:

<!-- formula-not-decoded -->

Die Umlaufintensität für die Bilanz aus unserem Beispiel lautet:

<!-- formula-not-decoded -->

Somit ergibt sich eine Umlaufintensität von 28,57%. Eine hohe Umlaufintensität ist positiv,  da  somit  sicher  gestellt  ist,  dass  das  Unternehmen  flexibel  aufgestellt  und liquide ist.

## Anlagenintensität

Die Anlagenintensität ermittelt den Anteil vom Anlagevermögen am Gesamtvermögen. Im Gegensatz zum Umlaufvermögen berechnet die Anlagenintensität also den Teil des Gesamtvermögens, der in langfristigen Vermögensgegenständen  wie  Lizenzen,  Maschinen  oder  Grundstücken  gebunden ist. Die Formel der Anlagenintensität ist:

Anlagenintensität Gesamtvermogen

Die Anlagenintensität aus obiger Bilanz lautet:

<!-- formula-not-decoded -->

Für  unser  Beispiel  ergibt  sich  so  eine  Anlagenintensität  von  71,43%.  Da  die Umlaufintensität  und  die  Anlagenintensität  beide  das  Gesamtvermögen  ergeben, müssen beide Werte zusammengerechnet 100% sein.

## Goldene Bilanzregel

Schauen wir uns nun noch die horizontalen Bilanzkennzahlen an. Diese beschreiben das Verhältnis von Werten aus der Aktiva und Passiva Seite. Starten wir doch mit der goldenen Bilanzregel. Diese  gibt Aufschluss über die einzelnen Deckungsgrade.  Laut ihr soll langfristig gebundenes Vermögen (= Anlagevermögen ), langfristig finanziert werden, kurzfristiges Vermögen (= Umlaufvermögen ) hingegen soll kurzfristig gedeckt werden. Diese Werte werden mittels der einzelnen Deckungsgrade berechnet

Die Formeln lauten hierzu:

Deckungsgrad 1 = Eigenkapital

Deckungsgrad 2 = Anlagevermogen

Für unser Beispiel ergibt sich so:

Deckungsgrad 1

<!-- formula-not-decoded -->

Die Büroflix GmbH hat demnach einen Deckungsgrad 1 von 0,6, was bedeutet, dass das  Anlagevermögen überwiegend durch das Eigenkapital finanziert ist. Das Unternehmen besitzt darüber hinaus einen Deckungsgrad 2 von 1,1. Je weiter der Deckungsgrad 2 über eins liegt, desto mehr ist auch das Umlaufvermögen langfristig finanziert. Für eine nähere Erklärung sieh dir unseren extra Video dazu an!

## Liquiditätsgrade

Drei weitere interessante Bilanzkennzahlen fasst du in den sogenannten Liquiditätsgraden  zusammen.  In  der  Praxis  wird  zwischen  drei  Liquiditätsgraden unterschieden:

Die Liquidität ersten Grades beschreibt das Verhältnis von flüssigen Geldmitteln zu kurzfristigen Verbindlichkeiten. Somit lautet die Formel dazu:

<!-- formula-not-decoded -->

Die Liquidität  zweiten  Grades berechnet  das  Verhältnis  von  flüssigen  Mitteln, kurzfristigen  Forderungen  und  Wertpapieren  zu  kurzfristigen  Verbindlichkeiten.  Die Formel lautet:

<!-- formula-not-decoded -->

Die Liquidität dritten Grades gibt das Verhältnis des Umlaufvermögens zu kurzfristigen Verbindlichkeiten wieder. Die Formel dazu lautet:

<!-- formula-not-decoded -->

Für unser Beispiel ergeben sich folgende Werte:

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

Liquiditätsgrad 3 100

Für die Büroflix GmbH ergibt sich daher eine Liquidität ersten Grades von 100%, das heißt, alle kurzfristigen Verbindlichkeiten könnten mit liquiden Mitteln gedeckt werden. Demnach  besitzt  das  Unternehmen  eine  hohe  Zahlungsfähigkeit.  Die  Liquidität zweiten  Grades  beträgt  133%  und  ist damit ein weiteres Indiz für für eine ausreichende Liquidität der Firma. Die Liquidität dritten Grades ist ebenfalls 133%, da sich das Umlaufvermögen des Betriebs vollständig aus kurzfristigen Forderungen und flüssigen Mitteln zusammensetzt.

## Working Capital

Das  Working  Capital  berechnet  sich  aus  dem  Umlaufvermögen  abzüglich  der kurzfristigen Verbindlichkeiten. Dabei bedeutet ein positiver Wert, dass das Umlaufvermögen eines Unternehmens die kurzfristigen Verbindlichkeiten abdeckt. Die Formel für das Working Capital ist:

Working Capital Umlaufvermögen

Berechnen wir nun das Working Capital für die Büroflix GmbH, kommen wir auf diese Werte:

Working Capital = 200,000 150.000 =

Für das Unternehmen ergibt sich so ein Ergebnis von + 50.000. Dies ist positiv zu bewerten, da ein Teil des Umlaufvermögens mit langfristigem Kapital finanziert wird.

Zusammenfassend stellst du fest, dass die Büroflix GmbH finanziell bestens aufgestellt ist und eine gesunde Bilanz vorweisen kann.

## Bilanzkennzahlen

Bilanzkennzahlen

Die Bilanz ist nicht nur eine Vorschrift des Handelsgesetzbuches, sondern auch ein Instrument zur Unternehmensbewertung.Auf den ersten Blick kann man erkennen, ob es sich um ein gesundes Unternehmen handelt.

Die einzelnen Positionen der Bilanz haben nur begrenzte Aussagekraft. Aus diesem Grund wurden diverse Kennzahlen entwickelt mit denen man weitere Aussagen über ein Unternehmen treffen kann.

Diese Kennzahlen  haben sowohl eigenständige  Aussagekraft, aber auch die Entwicklung  des  Unternehmens  über  mehrere  Perioden  hinweg  kann  durch  diese Werte beurteilt werden.

Übersicht der

Bilanzkennzahlen

Auf den folgenden Seiten erhaltet Ihr einen Überblick über die wichtigsten Bilanzkennzahlen Neben  der  einer  eine  Definition,  der  dazugehörige Formel gehen wir natürlich auch auf die Bedeutung dieser Werte ein.

| Bilanzkennzahl                 | Bedeutung                                      |
|--------------------------------|------------------------------------------------|
| Konstitution (Vermögensaufbau) | Verhältnis zwischen Anlage- und Umlaufvermögen |
| Anlageintensität / Anlagequote | Anteil Anlagevermögen am Gesamtvermögen        |
| Umlageintensität (Umlaufquote) | Anteil Umlaufvermögen am Gesamtvermögen        |

| Liquidität ersten Grades                  | Verhältnis flüssige Geldmittel zu kurzfristigem Fremdkapital              |
|-------------------------------------------|---------------------------------------------------------------------------|
| Liquidität zweiten Grades                 | Verhältnis flüssige Mittel und Forderungen zu kurzfristigem Fremdkapital  |
| Liquidität dritten Grades                 | Verhältnis Umlaufvermögen zu kurzfristiges + mittelfristiges Fremdkapital |
| Nettoumlaufvermögen (Net Working Capital) | siehe Unterseite                                                          |
| Eigenkapitalquoute                        | Anteil vom Eigenkapital am Gesamtkapital                                  |
| Fremdkapitalquote                         | Anteil vom Fremdkapital am Gesamtkapital                                  |
| Kapitalaufbau (Finanzierung)              | Verhältnis vom Eigenkapital zum Fremdkapital                              |
| Verschuldungsgrad                         | Verhältnis Fremdkapital zu Eigenkapital                                   |
| Deckungsgrad I                            | Wie viel Prozent vom AV werden durch das Eigenkapital gedeckt?            |
| Deckungsgrad 2                            | Wie viel Prozent vom AV weden langfristig finanziert?                     |
| Eigenkapitalrendite                       | Verzinsung vom Eigenkapital                                               |

| Gesamtkapitalrendite                   | Gesamtkapitalrendite                                           | Rendite vom eingesetzten Eigenkapital + Fremdkapital           |
|----------------------------------------|----------------------------------------------------------------|----------------------------------------------------------------|
| Return on Investment (ROI)             | Return on Investment (ROI)                                     | Verzinsung des eingesetzten Eigenkapitals                      |
| Umsatzrentabilität                     | Umsatzrentabilität                                             | Gewinn pro Euro Umsatz                                         |
| Wirtschaftlichkeit                     | Wirtschaftlichkeit                                             | Verhältnis von Leistung zu Kosten                              |
| Umschlagshäufigkeit des Eigenkapitals  | siehe Unterseite                                               | siehe Unterseite                                               |
| Umschlagshäufigkeit der Forderungen    | siehe Unterseite                                               | siehe Unterseite                                               |
| Umschlagshäufigkeit des Gesamtkapitals | siehe Unterseite                                               | siehe Unterseite                                               |
| Cash Flow                              | Cash Flow = Finanzmittelüberschuss eines Geschäftsjahres       |                                                                |
| Abschreibungsquote                     | Anteil von Abschreibungen auf Anlagevermögen                   | das                                                            |
| Dynamischer Verschuldungsgrad          | Wie lange dauert es, bis ein Unternehmen Schulden tilgen kann? | Wie lange dauert es, bis ein Unternehmen Schulden tilgen kann? |
| Leverage Effekt                        | siehe Beschreibung                                             | siehe Beschreibung                                             |

| Positiver / negativer Leverage   | umangreiche Erklärung mit Beispielen vom   |
|----------------------------------|--------------------------------------------|
| Effekt                           | positiven / negativen Leverage Effekt      |

## Bilanzanalyse: Einfache Erklärung und praktische Anleitung für Unternehmen

Erfahren  Sie,  wie  Sie  eine  Bilanzanalyse  durchführen,  die  finanzielle  Stärke  eines Unternehmens entschlüsseln und strategische Entscheidungen treffen können. Unser Leitfaden führt Sie durch die notwendigen  Schritte und  erklärt, wie Sie die umfangreichen Daten aus dem Jahresabschluss effektiv nutzen.

## Das Wichtigste auf einen Blick

- · Die Bilanzanalyse ist ein kritisches Werkzeug zur Bewertung der finanziellen Lage  eines  Unternehmens,  das  interne  und  externe  Stakeholder  bei  der Entscheidungsfindung unterstützt.
- · Bilanzanalysen beinhalten das Sammeln von Daten, Berechnen und Interpretieren von Kennzahlen, um ein umfassendes Verständnis der unternehmerischen Vermögens-, Finanz- und Ertragslage zu erlangen.
- · Verschiedene Arten der Bilanzanalyse (horizontal, vertikal, intern, extern) liefern jeweils unterschiedliche Einblicke, können aber durch subjektive Bewertungen und unterschiedliche Rechnungslegungsstandards in ihrer Aussagekraft begrenzt sein.

## Definition und Bedeutung der Bilanzanalyse

Die Bilanzanalyse ist eine Methode, die verwendet wird, um die finanzielle Situation eines Unternehmens zu untersuchen. Dabei werden die verschiedenen Positionen der Bilanz in Beziehung zueinander gesetzt. Sie umfasst die Auswertung und Relationierung  verschiedener  Daten  aus  dem  Jahresabschluss,  einschließlich  der Jahresabschlussanalyse, die sich auf:

- · der Bilanz
- · der Gewinn- und Verlustrechnung
- · des Anhangs
- · des Lageberichts bezieht.

Die Bilanzanalyse hilft, die wirtschaftliche Lage eines Unternehmens zu bewerten und gibt Auskunft über die Vermögens- und Ertragssituation. Sie ermöglicht das Aufdecken von Potenzialen und Risiken und dient als Entscheidungsgrundlage für Management, Investoren  und  Gläubiger.  Durch  einen  Betriebsvergleich  kann  die  Position  des Unternehmens im Branchenkontext besser eingeschätzt werden.

Daher ist die Bilanzanalyse sowohl für interne Stakeholder, wie das Management, als auch für externe Stakeholder, wie Investoren und Kreditgeber, von großer Bedeutung.

## Ziele einer Bilanzanalyse

Die Ziele der Bilanzanalyse sind vielfältig und umfassen:

- · die Beurteilung der Ertragslage
- · die Vermögensstruktur
- · die Kapitalstruktur
- · die Liquiditätssituation eines Unternehmens.

Diese Kennzahlen ermöglichen eine fundierte Bewertung der Finanz-Gesundheit und bieten eine solide Grundlage für fundierte Geschäftsentscheidungen.

Für interne Zwecke unterstützt die Bilanzanalyse die unternehmerische Entscheidungsfindung und strategische Planung mittels einer klaren Darstellung der Unternehmenssituation. Durch die Beurteilung von Rentabilitätskennzahlen trägt die Bilanzanalyse  dazu  bei,  die  Wirtschaftlichkeit  des  Unternehmens  zu  bewerten  und Investitionsentscheidungen zu fundieren.

## Grundlegende Schritte zur Durchführung einer Bilanzanalyse

Die Durchführung einer Bilanzanalyse kann in vier Schritten unterteilt werden: Das Sammeln von Bilanzdaten, die Berechnung von Kennzahlen, die Interpretation der Ergebnisse  und  die  abschließende  Bewertung.  Jeder  dieser  Schritte  spielt  eine entscheidende  Rolle  im  gesamten  Prozess  und  trägt  dazu  bei,  ein  klares  und ganzheitliches Bild der finanziellen Lage des Unternehmens zu vermitteln.

Zunächst ist es wichtig, relevante Bilanzdaten zu sammeln, die als Grundlage für die weitere Analyse dienen. Diese Daten stammen aus verschiedenen Quellen, darunter der Bilanz, der Gewinn- und Verlustrechnung und anderen finanziellen Berichten des Unternehmens. Anschließend werden diese Daten verwendet, um eine Vielzahl von Kennzahlen zu berechnen, die verschiedene Aspekte der finanziellen Leistung des Unternehmens aufzeigen.

Schließlich werden diese Kennzahlen interpretiert, um fundierte Einschätzungen und Prognosen über die zukünftige finanzielle Gesundheit und Rentabilität des Unternehmens zu ermöglichen.

## Bilanzdaten sammeln

Das  Sammeln  von  Bilanzdaten  ist  der  erste  und  entscheidende  Schritt  in  der Bilanzanalyse. Bei diesem Prozess werden relevante Daten aus dem Jahresabschluss und anderen wichtigen finanziellen Berichten des Unternehmens gesammelt. Diese Daten umfassen verschiedene Elemente, darunter:

- · Vermögenswerte
- · Verbindlichkeiten
- · Eigenkapital
- · Umsatz
- · Gewinn des jahresabschlusses

Die Vorbereitung der Daten  für die Bilanzanalyse kann  die Saldierung oder Zusammenfassung von Posten beinhalten, um eine bessere Übersichtlichkeit und eine leichtere  Berechnung  von  Kennzahlen  wie  dem  Eigenkapital  zu  gewährleisten.  Im Rahmen der Buchführung ist es wichtig, alle relevanten Daten gründlich zu sammeln und zu ordnen, um eine genaue und effektive Analyse zu gewährleisten.

## Kennzahlen berechnen

Nachdem  die  relevanten  Daten  gesammelt  wurden,  ist  der  nächste  Schritt  in  der Bilanzanalyse die Berechnung von Kennzahlen. Kennzahlen sind statistische Maße, die  verwendet  werden,  um  bestimmte  Aspekte  der  finanziellen  Leistung  eines Unternehmens zu quantifizieren und zu evaluieren.

Es  gibt  eine  Vielzahl  von  Kennzahlen,  die  in  der  Bilanzanalyse  verwendet  werden können, einschließlich der Eigenkapitalquote, der Liquidität und der Rentabilität. Jede dieser Kennzahlen liefert wertvolle Einblicke in verschiedene Aspekte der finanziellen Gesundheit und Leistungsfähigkeit des Unternehmens.

## Ergebnisse interpretieren

Nachdem die Kennzahlen berechnet wurden, folgt der letzte und vielleicht wichtigste Schritt in der Bilanzanalyse: die Interpretation der Ergebnisse. Dieser Schritt beinhaltet das Verständnis und die Beurteilung der Bedeutung der berechneten Kennzahlen und deren Auswirkungen auf die finanzielle Lage des Unternehmens.

Die  Interpretation  der  Bilanzkennzahlen  ermöglicht  eine  fundierte  Beurteilung  der finanziellen Lage des Unternehmens und dient als Grundlage für Entscheidungen. Bei der Interpretation der Kennzahlen aus der Bilanzanalyse sollten auch der Vergleich mit Branchenkennzahlen umfassen, um die Position des Unternehmens im Wettbewerbsumfeld zu beurteilen.

## Arten der Bilanzanalyse

Es  gibt  verschiedene  Arten  der  Bilanzanalyse,  die  unterschiedliche  Aspekte  der finanziellen Situation eines Unternehmens beleuchten. Dazu gehören:

- · Die horizontale Bilanzanalyse
- · Die vertikale Bilanzanalyse
- · Die interne Bilanzanalyse
- · Die externe Bilanzanalyse

Jede dieser Arten hat ihre spezifischen Stärken und wird in verschiedenen Kontexten und zu unterschiedlichen Zwecken eingesetzt.

Die horizontale Bilanzanalyse fokussiert auf die Entwicklung der Bilanzpositionen über mehrere Perioden hinweg und hilft bei der Aufdeckung von Entwicklungstrends. Die vertikale Bilanzanalyse untersucht die Bilanzstruktur zu einem bestimmten Zeitpunkt, indem sie die Bilanzpositionen in Relation zueinander setzt. Interne Bilanzanalysen werden vorwiegend von der Unternehmensführung zur Entscheidungsfindung genutzt, während  externe  Analysen  von Stakeholdern wie Investoren, Gläubigern  und Analysten durchgeführt werden.

## Horizontale Bilanzanalyse

Die  horizontale  Bilanzanalyse  ist  eine  Methode  der  Bilanzanalyse,  bei  der  die Entwicklung von Bilanzdaten über einen bestimmten Zeitraum hinweg analysiert wird. Diese Art der Analyse ist besonders nützlich, um Trends und Entwicklungen in der finanziellen Performance eines Unternehmens zu erkennen.

Bei der horizontalen Bilanzanalyse werden kurzfristig liquidierbare Vermögenswerte den  kurzfristig  fälligen  Verbindlichkeiten  gegenübergestellt  und  die  Veränderungen über einen Zeitraum, vorzugsweise fünf Jahre, beobachtet. Eine Umgliederung von Bilanzposten kann notwendig sein, um die Finanzsituation des Unternehmens besser zu verstehen und insbesondere die Bindungsdauer des Kapitals zu betrachten.

Die  dynamische  Komponente  der  horizontalen  Bilanzanalyse  berücksichtigt  die Veränderungen über die Zeit und liefert damit wichtige Erkenntnisse zur Zukunftsfähigkeit und Entwicklung des Unternehmens.

## Vertikale Bilanzanalyse

Die vertikale Bilanzanalyse ist eine weitere wichtige Methode der Bilanzanalyse. Sie untersucht  die  Struktur  der  Bilanz  zu  einem  bestimmten  Stichtag  und  setzt  die Bilanzpositionen in Relation zueinander.

Diese Art der Untersuchung liefert wichtige Informationen über die Vermögens- und Kapitalstruktur  eines  Unternehmens  und  hilft  bei  der  Beurteilung  der  finanziellen Stabilität des Unternehmens. Sie liefert Informationen über die Anlagendichte und die Kapitalstruktur, insbesondere den Eigenkapitalanteil und die Verschuldung.

## Interne Bilanzanalyse

Die interne Bilanzanalyse ist eine Methode der Bilanzanalyse, die hauptsächlich von der Unternehmensführung verwendet wird. Sie nutzt interne Daten und Informationen, um  die  finanzielle  Leistung  des  Unternehmens  zu  beurteilen  und  strategische Entscheidungen zu treffen.

Die  erfolgswirtschaftliche Analyse  ist  eine  Methode  der  internen  Bilanzanalyse.  Sie zeigt den Unternehmenserfolg unbeeinflusst von steuerlichen oder bilanzpolitischen Einflüssen.  Interne  Bilanzanalysen  dienen  als  Verhandlungsbasis  und  steigern  die Planungssicherheit bei Investitionen oder Unternehmensverkäufen.

## Externe Bilanzanalyse

Die externe Bilanzanalyse ist eine Methode der Bilanzanalyse, die hauptsächlich von externen Stakeholdern wie:

- · Investoren
- · Kreditgebern
- · Lieferanten
- · Kunden

verwendet wird. Sie nutzen öffentlich zugängliche Informationen, um die finanzielle Lage eines Unternehmens zu beurteilen und Entscheidungen zu treffen.

Bei der externen Bilanzanalyse werden Instrumente wie die Bewegungsbilanz und die Beständedifferenzbilanz herangezogen, um Veränderungen in den Bilanzpositionen zu  untersuchen.  Darüber  hinaus  berücksichtigt  die  qualitative  Bilanzanalyse  die verbale  Berichterstattung  des  Unternehmens  und  nutzt  dazu  Dokumente  wie  den Lagebericht und den Anhang zum Jahresabschluss oder Konzernabschluss.

## Bilanzanalyse-Tools und -Ressourcen

Bei der Durchführung einer Bilanzanalyse können verschiedene Tools und Ressourcen helfen. Sie reichen von Softwarelösungen wie Microsoft Excel und Tally ERP 9 bis hin zu  Online-Tools  wie  App4Finance  und  FINTIBI.  Diese  Tools  bieten  umfangreiche Funktionen,  die  eine  detaillierte  und  effektive  Analyse  von  finanziellen  Berichten ermöglichen. Sie unterstützen bei der Erstellung von Berichten und bei strategischen Entscheidungen.

Neben diesen bezahlten Softwarelösungen gibt es auch kostenlose Vorlagen, die bei der Analyse helfen können, wie die Bilanzvorlage von sevDesk.

## Fallstricke und Herausforderungen bei der Bilanzanalyse

Trotz ihrer Vorteile hat die Bilanzanalyse auch ihre Grenzen und Herausforderungen.

Dazu gehören:

- · subjektive Bewertungen
- · die zunehmende Bedeutung immaterieller Werte
- · die  Beschränkung  auf  vergangenheitsbezogene  Daten  ohne  Aussagen  zur zukünftigen Entwicklung
- · unterschiedliche Rechnungslegungssysteme, die die Vergleichbarkeit einschränken können.

Um die Bilanzanalyse  erfolgreich  anzuwenden,  muss neben  fachlichem  Know-how und  Verständnis  auch  die  Sensibilität  für  bilanzpolitische  Maßnahmen  sowie  ein kritischer  Blick  für  die  verwendeten  Zahlen  und  Methoden  entwickelt  werden.  Die Aussagekraft  von  Bilanzanalyse-Kennzahlen  kann  in  verschiedenen  Situationen eingeschränkt sein, beispielsweise durch bilanzpolitische Entscheidungen, wirtschaftliche Veränderungen oder außergewöhnliche Ereignisse, die nicht direkt in den Zahlen reflektiert werden.

## Praktisches Beispiel: Anwendung der Bilanzanalyse in einem Unternehmen

Um die Anwendung der Bilanzanalyse in der Praxis zu veranschaulichen, kann ein konkretes Beispiel herangezogen werden. Stellen Sie sich vor, ein Unternehmen plant eine Investition in neue Produktionsanlagen. Diese Entscheidung könnte verschiedene Auswirkungen auf die finanzielle Situation des Unternehmens haben.

Das Unternehmen, eine Kapitalgesellschaft, könnte beispielsweise:

- · stärker auf Fremdkapital angewiesen sein
- · mehr als die Hälfte seines Vermögens über Eigenkapital finanzieren
- · nur 50 % seiner kurzfristigen Verbindlichkeiten durch flüssige Mittel decken
- · den Großteil des Vermögens in langfristigen Anlagen gebunden haben.

## Zusammenfassung

Zusammenfassend  lässt  sich  sagen,  dass  die  Bilanzanalyse  ein  unverzichtbares Instrument für die Beurteilung der finanziellen Gesundheit eines Unternehmens ist. Sie ermöglicht es, die Vermögens-, Ertrags- und Kapitalstruktur eines Unternehmens zu beurteilen, Trends zu identifizieren und fundierte Entscheidungen zu treffen. Trotz ihrer Herausforderungen und Grenzen liefert die Bilanzanalyse wertvolle Erkenntnisse, die zur strategischen Planung und Entscheidungsfindung beitragen.

## Häufig gestellte Fragen

## Warum macht man eine Bilanzanalyse?

Man  macht  eine  Bilanzanalyse,  um  fundierte  Entscheidungen  für  Investitionen, Finanzierung und Risikomanagement treffen zu können und die finanzielle Situation eines Unternehmens zu beurteilen.

Wer macht eine Bilanzanalyse?

Die Bilanzanalyse wird vom  Unternehmen  selbst  sowie von Investoren oder Kreditgebern durchgeführt, um die wirtschaftliche Lage und mögliche Risiken besser einschätzen zu können.

## Wie erkennt man eine gute Bilanz?

Eine gute Bilanz erkennt man daran, dass ein Unternehmen die Aktivposten zahlen kann  und  gewinnorientiert  agiert,  beispielsweise  durch  eine  Umsatzrentabilität  von über 10%. Dies zeigt, dass das Unternehmen erfolgreich wirtschaftet.

## Wie funktioniert eine bilanz?

Eine Bilanz besteht aus der Aktivseite und der Passivseite, die eine T-Form bilden und deren  Summen  immer  übereinstimmen  müssen,  um  einen  Überblick  über  die finanzielle Situation eines Unternehmens zu ermöglichen.

Aktienkennzahlen verstehen: Die 10 wichtigsten Finanzkennzahlen zur Aktienanalyse

Aktienkennzahlen helfen  dir  bei  der  Analyse  von Aktien .  Mithilfe  verschiedener Finanzkennzahlen  kannst  du  im  Rahmen  der quantitativen  Fundamentalanalyse, basierend auf Daten und Statistiken, eine Bewertung von Aktien vornehmen.

In diesem Ratgeber stellen wir dir unterschiedliche Kategorien von Aktienkennzahlen vor und gehen dabei auf drei Aspekte ein:

- · Kennzahlen zu Rentabilität und Ertrag
- · Bewertungskennzahlen (Multiplikatoren)
- · Kennzahlen zur Analyse der finanziellen Stabilität

Außerdem werfen wir einen Blick auf die wichtigsten Basiskennzahlen und Begriffe im Kontext der fundamentalen Aktienanalyse. Du erhältst zu allen Fachbegriffen eine ausführliche  Definition  sowie  eine  Übersicht,  mit  Formeln  zur  Berechnung  der Kennzahlen.

Los geht es mit den Vorteilen einer Analyse mit Finanzkennzahlen.

## 1. Warum soll ich eine Analyse mit Aktienkennzahlen durchführen?

Neben der quantitativen Fundamentalanalyse auf Basis von Daten und Statistiken hast du auch die Möglichkeit  Aktien mithilfe von qualitativen  Merkmalen  zu untersuchen. Dazu zählt die Analyse des Geschäftsmodells eines Unternehmens. Da  die  qualitative  Fundamentalanalyse  jedoch  eher  subjektiv  ist,  führt  das  bei  der Bewertung von Aktien zu ungenauen Ergebnissen.

Dennoch  ist  die  Analyse  des  Geschäftsmodells  sinnvoll,  um  das  zu  bewertende Unternehmen und dessen Geschäftstätigkeit besser zu verstehen. Ergänzt man die qualitative mit der quantitativen Bewertung, erhält man  eine vollumfängliche Fundamentalanalyse. Auf Grundlage dieser Ergebnisse kannst du rationale Anlageentscheidungen treffen. Es ist wichtig, dass du die Investition in ein Unternehmen ausführlich begründen kannst.

## Diese Vorteile bieten die Aktien Finanzkennzahlen

Die Analyse  mithilfe  von  verschiedenen  Aktienkennzahlen erlaubt  es  dir,  ein Unternehmen, dessen Geschäftstätigkeit und den wirtschaftlichen Erfolg in Zahlen zu verpacken. Dadurch kannst du den Erfolg oder auch Misserfolg eines Unternehmens  sowie  die  Entwicklung  in  bestimmten  Zeiträumen  messen . Außerdem kannst  du  mit  einer Analyse  basierend  auf  Finanzkennzahlen,  mehrere Aktien innerhalb einer Branche vergleichen und somit die besten Unternehmen eines Wirtschaftszweigs identifizieren.

Des Weiteren ermöglicht dir eine Aktienanalyse mit Kennzahlen, dass du nicht nur eine rationale Anlageentscheidung zum Zeitpunkt der ersten Investition triffst, sondern auch noch in 5 oder 10 Jahren deine Aktien bewerten kannst. Dies macht die wirtschaftliche Entwicklung  messbar  und  zudem  hast  du  die  Gelegenheit  zu  prüfen,  ob  manche Konkurrenten inzwischen ein besseres Investment darstellen.

Die  Aktienkennzahlen berechnet man  auf Basis der von den Unternehmen veröffentlichten  Geschäftszahlen  und  Prognosen.  Das  bedeutet,  dass  sie  öffentlich zugänglich und jederzeit einsehbar sind.

In den folgenden Abschnitten befassen wir uns mit den wichtigsten Aktienkennzahlen. Zu Beginn erhältst du eine Übersicht zu den Grundlagen und den Basiskennzahlen.

Dein Finanzwissen-Newsletter

Jeden Freitag: Kostenloser Finanzwissen-Newsletter mit allen wichtigen Themen für deine privaten Finanzen.

Deine E-Mail-Adresse

Abonnieren

Informationen zur Datenverarbeitung kannst Du unserer Datenschutzerklärung entnehmen.

## 2. Basiskennzahlen für die Aktienanalyse - wichtige Grundlagen einfach erklärt

Mit  Basiskennzahlen  sind  nicht  zwingend  Kennzahlen  im  herkömmlichen  Sinne gemeint,  dennoch  handelt  es  sich  hierbei  um  wichtige  Werte  und  Begriffe,  die  du unbedingt kennen solltest.

Hier siehst du eine Auflistung der grundlegenden Basiskennzahlen für eine Aktienanalyse:

- · Aktienkurs: Der Aktienkurs allein sagt zwar nichts über die Bewertung einer Aktie aus, aber er ist die Grundlage für die Berechnung zahlreicher Formeln,

denn  er  wird  häufig  mit  verschiedenen  Werten  ins  Verhältnis  gesetzt.  Als Aktienkurs bezeichnet man den aktuellen Preis eines börsennotierten Unternehmens. Zu diesem Preis wird ein Anteil, also eine Aktie, an der Börse gehandelt.

- · Marktkapitalisierung: Die  Marktkapitalisierung  bezeichnet  man  häufig  auch als  Börsenwert.  Sie  gibt  an,  wie  viel  die Aktien  eines  Unternehmens  an  der Börse wert sind. Dieser Wert schwankt natürlich, wie auch der Aktienkurs. Zur Berechnung der Marktkapitalisierung multiplizierst  du  einfach  den Aktienkurs mit der Anzahl aller ausgegebenen Aktien.
- · Umsatz: Der Umsatz gibt an, wie viel Geld ein Unternehmen innerhalb eines bestimmten Zeitraumes einnimmt. Der Umsatz ist die Basis zur Berechnung diverser Kennzahlen. Ein Unternehmen mit hohen Umsätzen ist nicht unbedingt wirtschaftlich  erfolgreich,  denn  es  könnte  trotz  hoher  Einnahmen  Verluste erzielen.
- · Gewinn: Ob  ein  Unternehmen  tatsächlich  profitabel  ist,  erkennst  du  am Gewinn. Von den Umsätzen sind noch die Kosten, Abschreibungen, Zinsaufwendungen  und  Steuern  abzuziehen.  Erst  dann  erhältst  du  den Jahresüberschuss. Das ist nur eine vereinfachte Darstellung. In einer Gewinnund-Verlust-Rechnung erfahren Investoren die Details.

Langfristig  orientierte  Anleger  achten  auf  ein  nachhaltiges  Umsatz-  und Gewinnwachstum , denn auf lange Sicht wird ein wirtschaftlich erfolgreicher Konzern auch an der Börse wertvoller.

Kurzfristig  sind  Schwankungen  nicht  auszuschließen  und  die  Finanzkennzahlen lassen  eventuell  eine  zu  hohe  oder  zu  niedrige  Bewertung  der  Aktie  vermuten, allerdings pendelt sich die Aktienbewertung mit der Zeit ein. Für dich als Investor ist es wichtig,  dass  ein  Unternehmen  auf  Dauer  profitabel  arbeitet  und  ein  nachhaltiges Wachstum erzielt.

Du kennst jetzt die wichtigsten Grundlagen, daher folgt als Nächstes die Vorstellung der Kennzahlen zu Ertrag und Rentabilität.

## 3. Aktienkennzahlen zu Ertrag und Rentabilität

Wie  zuvor  erwähnt,  betrachten  wir  in  unserem  Ratgeber  Finanzkennzahlen  aus unterschiedlichen Kategorien. In diesem Abschnitt geht es um Kennzahlen, die den Ertrag und die Rentabilität eines Unternehmens messen und ins Verhältnis setzen.

Bevor wir auf die einzelnen Kennzahlen, deren Bedeutung und Berechnung eingehen, klären wir zunächst, was Ertrag und Rentabilität bedeuten.

## Ertrag, Rentabilität, Profitabilität

Rentabel und profitabel sind zwei Begriffe, die gern synonym verwendet werden, aber das ist nicht  korrekt. Ein  Unternehmen ist profitabel,  sobald  es einen  Gewinn bzw. einen Überschuss erzielt. Die Rentabilität ist durch eine Profitabilität noch lange nicht gegeben .

Das klingt im ersten Moment etwas verwirrend, ist aber relativ schnell erklärt.

Ein Beispiel : Aktie X hat am Ende des Jahres einen Gewinn von 10 € erwirtschaftet. Damit ist das Unternehmen definitionsgemäß profitabel. Allerdings hat der Konzern 5 Millionen Euro Kapital eingesetzt, um diesen kleinen Gewinn zu erzielen. Daher ist das Unternehmen nicht rentabel.

Wir  können  also  festhalten :  Je  größer  der  Gewinn  und  je  niedriger  das  dafür eingesetzte Kapital ausfällt, desto rentabler ist das Unternehmen. Folglich können zwei Unternehmen,  die  man  vergleicht,  profitabel  sein,  jedoch  wirtschaftet  das  eine rentabel, der andere Betrieb wiederum nicht.

Folglich  ist  es  wichtig,  nicht  nur  auf  den  Jahresüberschuss  bzw.  die  Profitabilität, sondern auch auf die Rentabilität bei der Aktienanalyse zu achten.

Im Folgenden stellen wir dir drei Aktienkennzahlen zu Rentabilität/Ertrag genauer vor:

- 1. Eigenkapitalrendite
- 2. Umsatzrendite
- 3. EBIT/EBITDA-Marge

Los geht es mit der Eigenkapitalrendite.

Eigenkapitalrendite: Verzinsung des eingebrachten Eigenkapitals

Mithilfe der Kennzahl Eigenkapitalrendite findest du heraus, wie sich das eingebrachte Eigenkapital verzinst bzw. welche Rendite erzielt wird.

Diese  Kennzahl  wird  berechnet,  indem  man  den  Jahresüberschuss  und  das durchschnittliche Eigenkapital des Geschäftsjahres ins Verhältnis setzt. Lediglich den Gewinn mehrerer Unternehmen miteinander zu vergleichen, sagt noch nichts darüber aus,  wie  rentabel  mit  dem  eingebrachten  Kapital  gewirtschaftet  wird.  Daher  ist  die Eigenkapitalrendite eine gute Vergleichsgröße.

## Umsatzrendite: wie viel Gewinn von einem Euro Umsatz?

Zur  Berechnung  der Umsatzrendite benötigt  man  ebenfalls  den  Jahresüberschuss. Diesen teilt man durch die Umsatzerlöse. Dadurch erfährst du, wie viel Cent an Gewinn ein Unternehmen pro Euro Umsatz generiert.

Eine hohe Umsatzrendite deutet auf  Alleinstellungsmerkmale und eine hohe Marktmacht hin, während eine niedrige Umsatzrentabilität bedeuten könnte, dass eher ein intensiver Wettbewerb herrscht.

## EBIT/EBITDA-Marge: wichtige Kennzahl in der Aktienanalyse

Zur Berechnung der EBIT/EBITDA-Marge setzt man das EBIT bzw. das EBITDA ins Verhältnis  zu  den  Umsatzerlösen  eines  Unternehmens.  Das EBIT  wird  häufig  als operatives Ergebnis oder Betriebsergebnis bezeichnet, denn dieser Wert ist der Gewinn vor Steuern und Zinsen. Das EBITDA liegt noch zwei Stufen darüber, hier kommen noch Abschreibungen von Sachanlagen und immateriellen Vermögensgegenständen hinzu.

Beide  Margen  ermöglichen  einen  Vergleich  über  Branchen  und  Regionen  hinweg, denn unterschiedliche Steuerbelastungen, Rechnungslegung oder Abschreibungsmethoden spielen hierbei keine Rolle und man vergleicht tatsächlich die Leistung des operativen Geschäfts.

Als Nächstes werfen wir einen Blick auf die wichtigsten Bewertungskennzahlen.

## 4. Die wichtigsten Bewertungskennzahlen für Aktien im Überblick

In diesem Kapitel bekommst du eine Übersicht zu fünf Bewertungskennzahlen. Wer sich  mit  der  Fundamentalanalyse  auseinandersetzt,  wird  zwangsläufig  auf  diese Aktienkennzahlen stoßen. Diese Bewertungsmultiplikatoren (EquityMultiplikatoren) setzen die wichtigsten Positionen aus der Bilanz und der Gewinnund-Verlust-Rechnung (GuV) ins Verhältnis zur Marktkapitalisierung.

- 1. Kurs-Gewinn-Verhältnis (KGV)
- 2. Kurs-Umsatz-Verhältnis (KUV)
- 3. Kurs-Buchwert-Verhältnis (KBV)
- 4. Kurs-Cashflow-Verhältnis (KCV)
- 5. Price-Earning-to-Growth-Ratio (PEG)

Die  erste  Bewertungskennzahl,  die  wir  dir  vorstellen,  ist  eine  der  beliebtesten  im Bereich der Aktienanalyse.

## Aktienkennzahl KGV (Kurs-Gewinn-Verhältnis)

Eine der am häufigsten genannten und verwendeten Aktienkennzahlen im Kontext der Fundamentalanalyse  ist  das  KGV.  Diese  Kennzahl  berechnest  du,  indem  du  die Marktkapitalisierung durch den Jahresüberschuss teilst. Bezogen auf eine einzelne Aktie könntest du auch den Aktienkurs und den Gewinn je Aktie ins Verhältnis setzen.

Wenn möglich, sollte man beim KGV den erwarteten Gewinn als Basis verwenden. Sollte  keine  plausible  Prognose  vorliegen,  nimmst  du  einfach  den  Gewinn  des vergangenen Geschäftsjahres.

Auf  den  ersten  Blick  erscheint  ein  Unternehmen  mit niedrigem  KGV  als  günstig bewertet .  Ein hohes KGV deutet dann auf eine Überwertung hin? So einfach ist es nicht. Daher ist es wichtig, niemals allein auf das KGV bei einer umfangreichen Analyse zu vertrauen.

Entscheidend bei der Betrachtung ist zum einen, in welchem Bereich das Unternehmen tätig  ist  und  ob  es  ein  Wachstumsunternehmen  oder  ein  etabliertes, langsam  wachsendes  Unternehmen  ist.  Ein  hohes  KGV  könnte  durch  ein  starkes Gewinnwachstum relativiert werden.

Demzufolge ist es beim Kurs-Gewinn-Verhältnis besonders wichtig, die Entwicklung des Gewinns und die Hintergründe zu prüfen.

## Finanzkennzahl KUV (Kurs-Umsatz-Verhältnis)

Ein  weiterer  beliebter  Multiplikator  ist  das  Kurs-Umsatz-Verhältnis.  Das  KUV  ist besonders relevant, wenn du dir die Bewertung von Unternehmen anschaust, die ein starkes Umsatzwachstum verzeichnen, jedoch noch keine Gewinne erzielen.

Dadurch kannst du Unternehmen, die noch nicht profitabel sind, jedoch ein starkes Wachstum erzielen, bewerten und miteinander vergleichen.

## Bewertungskennzahl KBV (Kurs-Buchwert-Verhältnis)

Das Kurs-Buchwert-Verhältnis ist eine Aktienkennzahl, die früher sehr beliebt war, aber heute nicht mehr so viel Beachtung findet. Die anderen Bewertungskennzahlen sind ertragsorientiert, wohingegen das KBV auf einer Bilanzgröße basiert. Als Grundlage zur Berechnung dient hierbei das Eigenkapital.

Eine  KBV  über  1  könnte  auf  eine  Überbewertung  hindeuten,  während  ein  KursBuchwert-Verhältnis  unter  1  eine  Unterbewertung  signalisiert. Allerdings  wäre  dies eine  zu  einseitige  und  nicht  zielführende  Betrachtung.  Ein  niedriges  KBV  könnte ebenso bedeuten, dass der Markt anhaltende Verluste einpreist.

Für eine umfassende Aktienanalyse benötigst du daher weitere Kennzahlen.

## KCV (Kurs-Cashflow-Verhältnis)

Zur Berechnung des Kurs-Cashflow-Verhältnisses zieht man die Marktkapitalisierung und den Cashflow eines Unternehmens heran.

Den Cashflow und die Cashflowrechnung stellen  wir  dir  in  separaten  Ratgebern ausführlicher vor,  da  es  ein  wichtiges Thema  ist,  das  eine umfangreiche  Erklärung erfordert.  Bei  der  Berechnung  verwendet  man  in  der  Regel  den  Cashflow  aus laufender Geschäftstätigkeit (operativer Cashflow).

Im  Gegensatz  zum  Jahresüberschuss  können  wir  erst  durch  die  Analyse  des Cashflows  beurteilen,  welche  Mittel  einem  Unternehmen  in  einem  bestimmten Zeitraum zu- und abgeflossen sind.

## Aktienkennzahl PEG-Ratio (Price-Earnings-to-Growth-Ratio)

Zum Schluss werfen wir noch einen Blick auf das PEG-Ratio. Hierbei wird das KGV ins Verhältnis zum erwarteten Gewinnwachstum gesetzt.

Insbesondere bei jungen Unternehmen oder Wachstumsaktien ist eine Einschätzung, die lediglich auf dem  KGV  basiert, zu kurz gegriffen. Daher gibt es eine Bewertungskennzahl, die zusätzlich das Gewinnwachstum  in  die Betrachtung einbezieht.

Ein starkes Gewinnwachstum kann ein auf den ersten Blick zu hoch erscheinendes KGV relativieren. Demzufolge lohnt es sich vor allem bei Wachstumswerten das PEGRatio genauer anzuschauen.

Das war es mit den wichtigsten Bewertungskennzahlen für Aktien. Jetzt stellen wir dir zwei Kennzahlen in Bezug auf die finanzielle Stabilität vor.

## 5. Kennzahlen zur finanziellen Stabilität eines Unternehmens

Im Folgenden  bekommst  du  eine kurze Übersicht zur Eigenkapitalquote und dem Verschuldungsgrad .  Beide Kennzahlen geben Aufschluss über die finanzielle Stabilität eines Unternehmens.

## Eigenkapitalquote: Eigenkapital im Verhältnis zum Gesamtkapital

Die Eigenkapitalquote berechnest  du,  indem  du  das  Eigenkapital  in  Relation  zur Bilanzsumme setzt.

Eine niedrige Eigenkapitalquote (EK-Quote) bedeutet, dass das betrachtete Unternehmen  zur  Finanzierung  überwiegend  Fremdkapital  nutzt  und  nur  wenig Eigenkapital in der Bilanz ausweist. Im Gegensatz dazu deutet eine hohe EK-Quote auf ein eher konservativ finanziertes Unternehmen hin, weil der Anteil des Fremdkapitals geringer ausfällt.

Jetzt kann man weder eine hohe noch eine niedrige EK-Quote pauschal als gut oder schlecht bezeichnen. Ein gewisser Fremdkapitalanteil ist ohnehin in jedem Unternehmen vorzufinden.

Einerseits verringert eine hohe Eigenkapitalquote die Eigenkapitalrendite , da das Unternehmen hauptsächlich Eigenkapital statt Fremdkapital eingebracht hat. Andererseits  birgt  ein  zu  hoher  Anteil  an  Fremdkapital  das  Potenzial  für  eine Überschuldung.

Letztlich  hängt  vieles  davon  ab,  wie  stabil  das  Geschäftsmodell  und  die  daraus resultierenden Umsätze und Gewinne der Aktie sind. Folglich sind die Faktoren Risiko und Rendite sowie der Preis für Fremdkapital entscheidend.

## Aktienkennzahl Verschuldungsgrad: Verhältnis von Fremdkapital zu Eigenkapital

Eine weitere Kennzahl zur Einschätzung der finanziellen Stabilität einer Aktie ist der Verschuldungsgrad.

Für die Berechnung des Verschuldungsgrades benötigst du zwei Angaben:

- 1.  Fremdkapital
- 2.  Eigenkapital

Diese Finanzkennzahl bezeichnet das Verhältnis von Fremdkapital zu Eigenkapital . Sie ist eine Alternative zur Fremdkapitalquote. Auch bei dieser Kennzahl gilt ohne  nähere  Betrachtung, dass  ein höherer Verschuldungsgrad  auf eine risikoreichere  Aufstellung  des  Unternehmens  hindeutet.  Allerdings  hat  ein  sehr niedriger Verschuldungsgrad zur Folge, dass die Eigenkapitalrendite sinkt.

Du kennst jetzt unsere Top zehn Aktienkennzahlen . Zu diesen und vielen weiteren Kennzahlen findest du bei uns ausführliche Artikel.

## Verwalte dein gesamtes Portfolio mit Parqet

- · Live-Übersicht sämtlicher Depots
- · Automatisch mit Banken verbunden
- · Steuerreports

## 6. Fazit: Aktienkennzahlen unterstützen dich bei der Bewertung von Aktien

Abschließend bekommst du von uns eine Zusammenfassung der wichtigsten Inhalte unseres Ratgebers über Aktienkennzahlen:

- 1.  Mithilfe von Finanzkennzahlen kannst du eine quantitative Fundamentalanalyse durchführen. Dies ermöglicht es dir, Aktien vor einem Investment zu bewerten und basierend auf Daten eine rationale Anlageentscheidung zu treffen.
- 2.  Es gibt  zahlreiche  Finanzkennzahlen,  die  im  Bereich  der Aktienanalyse  zum Einsatz kommen. Daher ist es besonders wichtig, die Kennzahlen in Kategorien einzuordnen.
- 3.  Die wichtigsten Kennzahlen der Aktienanalyse messen die finanzielle Stabilität und die Rentabilität eines Unternehmens. Ferner besteht die Möglichkeit, mit diversen Bewertungskennzahlen (KGV, KUV) zu ermitteln, ob eine Aktie eher teuer oder günstig bewertet ist.
- 4.  Ein  Unternehmen kann zwar profitabel sein, muss aber deshalb  noch lange nicht rentabel wirtschaften. Die Rentabilität setzt den Gewinn/Jahresüberschuss ins Verhältnis zum eingesetzten Kapital.
- 5.  Neben  der  quantitativen Aktienanalyse  mittels  Kennzahlen  gibt  es  noch  die qualitative Fundamentalanalyse. Dabei wird primär das Geschäftsmodell eines Unternehmens betrachtet.

Aktienkennzahlen sind ein ausgezeichnetes Werkzeug für die Unternehmensanalyse und die Bewertung von Aktien, allerdings gibt es eine große Auswahl an Kennzahlen, wodurch insbesondere Einsteiger den Überblick verlieren könnten. Hinzu kommt noch der Faktor Zeit. Eine umfangreiche  Aktienanalyse  ist stets  mit  einem  hohen Zeitaufwand verbunden.

Ein nicht zu vernachlässigender Faktor ist die Datenqualität. Schließlich sind die Daten die  Grundlage  für  die  Berechnung  der  Aktienkennzahlen,  die  dann  wiederum  als Argument für oder gegen ein Investment herangezogen werden.

Wenn man all diese Punkte näher betrachtet, so könnte man zum Schluss gelangen, dass eine quantitative Fundamentalanalyse auf Grundlage von Finanzkennzahlen nur für Fortgeschrittene und professionelle Anleger geeignet ist.

Einsteiger  sollten  sich  daher  zunächst  mit  den  Grundlagen  vertraut  machen  und sukzessive ihr  Wissen  zu  den  einzelnen  Kennzahlen  erweitern.  Bei  uns  findest  du separate Ratgeber zu allen aufgeführten Finanzkennzahlen.

## Kennzahlen zu den Basisdaten

## #1 - Aktienkurs

Der Aktienkurs gibt den Preis an, für den ein Unternehmensanteil aktuell gehandelt wird.  Gleichzeitig  liefert  der Aktienkurs  durch  seine  vergangene  Entwicklung  einen Einblick in den Erfolg oder Misserfolg der letzten Jahre und Jahrzehnte der Aktiengesellschaft.

Dabei ist ein Unternehmen, dessen Aktie für 100€ gehandelt wird, nicht automatisch mehr wert als eine Aktie, die für 10€ gehandelt wird.

Der Grund: Die  Aktienunternehmen  geben  unterschiedliche  Mengen  an  Aktien heraus.

Wenn  ein  Unternehmen  5  Millionen  Euro  wert  ist,  aber  nur  eine  einzige  Aktie herausgibt, kostet diese eine Aktie 5 Millionen Euro. Trotzdem sind die großen DAXKonzerne, deren Aktien sich meistens im 1- bis 3-stelligen Bereich bewegen, natürlich viel wertvoller.

## Merke

Der Aktienkurs allein sagt nichts über die Bewertung einer Aktie aus!

Die entscheidende Kennzahl für die aktuelle Bewertung eines Unternehmens ist die…

## #2 - Marktkapitalisierung

## Berechnung

Marktkapitalisierung = Aktienkurs x Anzahl ausgegebene Aktien

Bedeutung: Die Marktkapitalisierung gibt an, wie viel ein Unternehmen aktuell an der Börse wert ist. Deshalb wird diese Kennzahl auch oft als Börsenwert bezeichnet.

Fällt der Aktienkurs mal um 10%, hat sich also auch der Börsenwert um 10% (was oft mehreren Milliarden Euro entspricht) verringert.

## #3 - Streubesitz

Der Streubesitz gibt an, wie viele der ausgegebenen Aktien dem Börsenhandel zur Verfügung stehen.

Welche Aktien stehen dem Handel nicht zur Verfügung? Alle Aktien, die in den Händen von Großaktionären sind. Dazu gehören oft Firmengründer, Großinvestoren, Vermögensverwalter und Investmentfonds.

Die Vorteile bei einem großen Streubesitz liegen meistens bei einer hohen Handelbarkeit einer Aktie und einer geringeren Abhängigkeit von den Großaktionären.

Allerdings können auch gerade Großaktionäre oft langfristiger denken als die breite Masse  an  Anlegern  und  lassen  sich  nicht so schnell verunsichern, was  die Schwankungen des Aktienkurses senken kann.

## #4 - Umsatz

Der Umsatz sagt noch nichts über die Profitabilität eines Unternehmens aus, ist aber ein Indikator für die Größe eines Unternehmens und fließt in viele andere Kennzahlen mit ein.

Es ist schlichtweg die Kennzahl, die ohne Berücksichtigung der Kosten angibt: Wie viel hat das Unternehmen eingenommen?

Gerade bei Wachstumsunternehmen, die noch nicht profitabel sind, ist vor allem das Umsatzwachstum  relevant  und  aussagekräftig,  sodass  du  es  dort  umso  stärker  in deiner Aktienanalyse berücksichtigen solltest.

## Aktienkennzahlen zur Profitabilität

## #5 - Gewinn

Der Gewinn ist eine der wichtigsten Kennzahlen.

Aber Gewinn ist nicht gleich Gewinn. Hier sind die gängigsten Unterscheidungen das EBITDA, EBIT und der Jahresüberschuss.

Du verstehst nur Bahnhof? Keine Angst, das ändern wir sofort.

Gewinnberechnung (vereinfacht)

## Umsatz

- - Produktionskosten
- = EBITDA (Gewinne vor Zinsen, Steuern und Abschreibungen)
- - Abschreibungen (Wertverlust von Sachanlagen und immateriellen Gütern)
- = EBIT (Gewinne vor Zinsen und Steuern)
- - Zinsen
- - Steuern
- = Jahresüberschuss

Bedeutung: Das EBITDA sagt noch nicht viel über den tatsächlichen Gewinn aus, zeigt aber, ob ein Unternehmen aus dem reinen Produktverkauf profitabel ist und lässt dabei andere Kostenpunkte außen vor.

Das EBIT korrigiert diese Kennzahl um die Abschreibungen (also Wertverluste), die keine  Ausgabe darstellen, aber durch einen gesunkenen Wert  vom Gewinn abzuziehen sind. Das EBIT wird auch oft als "operatives Ergebnis" bezeichnet.

Schlussendlich werden als letzte Ausgaben noch die Zinsen für Kredite und die zu zahlenden Steuern abgezogen um festzustellen, wie hoch der letztendliche Gewinn insgesamt war.

## Merke

Das  EBITDA  gibt   an  wie  profitabel  das  Kerngeschäft  ist,  das  EBIT  inkludiert Abschreibungen und verringert den Gewinn gerade bei kapitalintensiven Unternehmen deutlich, der Jahresüberschuss gibt an, was letztendlich für dich als Aktionär von den Einnahmen übrig bleibt.

## #6 - Gewinnwachstum

Das Gewinnwachstum ist schnell erklärt: Diese Aktienkennzahl gibt an, wie stark die Gewinne in einem bestimmten Zeitraum gestiegen sind oder schätzungsweise steigen werden.

Du kannst es also in zwei Richtungen betrachten: Du schaust in die Zukunft oder in die Vergangenheit.

In jedem Fall sind die Schätzungen, die meistens von Analysten aufgestellt werden, mit großer Unsicherheit verbunden: Niemand hat eine Glaskugel.

Nichtsdestotrotz kann das Betrachten des Gewinnwachstums als groben Indikator aus zwei Gründen interessant sein:

- 1.  Es zeigt dir, ob du es tendenziell mit einem schrumpfenden, stagnierenden oder wachsenden Unternehmen zu tun hast.
- 2.  Du kannst grob erkennen, welche Gewinnerwartungen die Anlegerwelt an die jeweilige Aktie hat, worauf meistens ein Großteil der Aktienbewertung an der Börse beruht, und dies mit deiner eigenen Einschätzung abgleichen.

## #7 - Eigenkapitalrendite

## Berechnung

Eigenkapitalrendite = Gewinn / Eigenkapital

Bedeutung: Als  Aktionär eines Unternehmens bist du Eigenkapitalgeber. Das bedeutet, dass du am Gewinn beteiligt wirst, aber das Risiko der Wertschwankungen und im schlimmsten Fall des Wertverlustes eingehst.

Das  Gegenstück  zum  Eigenkapital  ist  das Fremdkapital.  Dabei  handelt  es  sich meistens um festverzinsliche Kredite, wie bspw. der klassische Bankkredit.

Die  Eigenkapitalrendite  als Aktienkennzahl  setzt  dabei  den  Gewinn  (üblicherweise EBIT oder Jahresüberschuss) ins Verhältnis zu dem von den Aktionären eingesetzten Geld um zu ermitteln, wie rentabel das Aktionärsgeld eingesetzt wird.

## Merke

Je höher die Eigenkapitalrendite, desto rentabler wirtschaftet das Unternehmen mit deinem Geld.

Kennzahlen zur Aktienbewertung

## #8 - Kurs-Gewinn-Verhältnis (KGV)

Berechnung

Kurs-Gewinn-Verhältnis = Aktienkurs / Gewinn je Aktie

Bedeutung: Das KGV ist die Mutter aller Kennzahlen zur Aktienbewertung.

Sie setzt den Preis, den du für eine Aktie zahlst (= Aktienkurs) ins Verhältnis zu dem Gewinn, der aktuell auf diese Aktie entfällt (= Gewinn pro Aktie).

## Beispiel

Beträgt  der  Gewinn  pro Aktie  10€  und  du  zahlst  120€  pro Aktie,  beträgt  das  KGV 12. Bei einem KGV von 12 zahlst du also das 12-fache der aktuellen Gewinne.

Ein niedriges KGV spricht dabei für eine günstige Bewertung, ein hohes für eine teure.

Ein  niedriges  KGV  ist  gleichzeitig  oft  ein  Indikator  für  schwierige  oder  unsichere Zukunftsausschichten, wohingegen ein hohes KGV oft bei Unternehmen zu sehen ist, denen ein hohes und starkes Wachstum prognostiziert wird.

Trotzdem  -  oder  viel  mehr  gerade  wegen  dieser  Schwierigkeiten  und  der  damit einhergehenden günstigeren Bewertung - haben sich in Studien Aktien mit niedrigem KGV statistisch  eher  bewährt  und es  stellt  gleichzeitig  eine  zentrale  Kennzahl  im beliebten Value-Investing nach Warren Buffett dar.

Beispiele dafür  sind  Unternehmen  wie Amazon, Tesla oder  auch  Facebook in  der Anfangsphase.

## Merke

Kurs-Gewinn-Verhältnisse  von 12  -  16  gelten  als  durchschnittlich. Alles  darunter spricht  für eine  niedrige  Bewertung  und pessimistischere  Zukunftserwartungen, alle Werte  darüber  für  eine  höhere  Bewertung  und  damit  einhergehend  eine  höhere Erwartungshaltung an die Gewinne der Zukunft.

## #9 - Kurs-Umsatz-Verhältnis (KUV)

## Berechnung

Kurs-Umsatz-Verhältnis = Aktienkurs / Umsatz je Aktie

Bedeutung: Das KUV verfährt nach dem gleichen Prinzip wie das KGV, nur das hier der Umsatz statt des Gewinns ins Verhältnis zum Aktienkurs gesetzt wird.

Die Aussage ist also: Wie viel Geld nimmt das Unternehmen pro Euro, den du in die Aktie investierst, ein?

Dabei solltest du beachten, dass der Vergleich von Unternehmen mit dieser Kennzahl in erster Linie branchenintern Sinn macht:

Kapitalintensive Unternehmen wie bspw. Automobilhersteller haben tendenziell höhere KUVs als Technologieunternehmen, die oft mit wenig Kapital auskommen.

## #10 - Kurs-Cashflow-Verhältnis (KCV)

## Berechnung

Kurs-Cashflow-Verhältnis = Aktienkurs / Cashflow je Aktie

Bedeutung: Die Aktienkennzahlen des KCVs und des KGVs sind ähnlich - mit einem kleinen, aber feinen Unterschied:

Hier beim KCV werden nicht die Gewinne betrachtet, sondern die Zahlungsflüsse. Ein simples Beispiel:

Kauft ein Unternehmen ein Auto für 50.000€, ändert sich am Gewinn vorerst nichts bis auf den Wertverlust von womöglich 8.000€ im 1. Jahr, da das Auto einen Restwert von 42.000€ hat.

Der Cashflow sinkt dadurch jedoch um die vollen 50.000€, da dieses Geld aus dem Unternehmen heraus fließt. Es steht dem Unternehmen also nicht für andere Zwecke zur Verfügung.

Das zeigt uns, was die Vor- und Nachteile des KCVs sind:

Während ein Gewinn mit buchhalterischen Methoden beeinflusst werden kann, ist das beim KCV weniger möglich. Dies ist der Vorteil des KCVs und deshalb wird es oft zur Ergänzung bei der Aktienbewertung herangezogen.

Der Nachteil dieser Aktienkennzahl: Durch hohe einmalige Investitionen kann das KCV eines einzelnen Jahres starken Schwankungen unterliegen.

## #11 - Kurs-Buchwert-Verhältnis (KBV)

## Berechnung

Kurs-Buchwert-Verhältnis = Aktienkurs / Buchwert je Aktie

Bedeutung: Das KBV ist eine Kennzahl mit langer Tradition in der Fundamentalanalyse und Unternehmensbewertung.  Während  die  vorherigen  Aktienkennzahlen eher ertragsorientiert waren, ist das KBV substanzorientiert.

Der Buchwert besteht vereinfacht gesagt aus dem Eigenkapital, das ein Unternehmen besitzt.

Das KBV gibt also an, wie hoch das Vermögen ist, das auf jeden Euro entfällt, den du in das Aktienunternehmen investierst.

Beispiel

Auf eine Aktie der Aktienboss AG entfallen 30€ Buchwert. Notiert der Aktienkurs bei 30€ entspricht das einem KBV von 1, also entspricht der Buchwert dem Marktwert.

Liegt  der  Aktienkurs  höher  steigt  das  KBV  und  die  Aktie  ist  teurer  bewertet  und umgekehrt.

Ja, es gibt tatsächlich Aktien, bei denen du 1€ bezahlst und dafür mehr Geld, also bspw. 1,20€, an Unternehmenskapital erhältst. Das geht meistens mit Verlusterwartungen  für  die  nächsten  Jahre  einher,  die  das  Eigenkapital  senken können.

## #12 - Dividendenrendite

## Berechnung

Dividendenrendite = Dividende / Aktienkurs

Bedeutung: Die Dividendenrendite gibt an, wie hoch die Ausschüttung pro Euro, den du investierst, zuletzt ausgefallen ist.

## Beispiel

Beträgt der Aktienkurs 100€ und es werden 3€ pro Aktie ausgeschüttet, beträgt die Dividendenrendite 3%.

Eine Dividende wird vor allem von Dividenden-Investoren sehr geschätzt, die das Geld manuell reinvestieren wollen oder sich das Leben mit einem passiven Einkommen versüßen wollen.

Aktienkennzahlen zur finanziellen Stabilität

## #13 - Eigenkapitalquote (EKQ)

## Berechnung

Eigenkapitalquote = Eigenkapital / Bilanzsumme

Bedeutung: Was  Eigenkapital  ist  habe  ich  dir  bereits  bei  der  Eigenkapitalrendite erklärt.

Über  die  Rendite  hinaus  ist  die  Quote  des  Eigenkapitals  allerdings  eine  zentrale Kennzahl für die finanzielle Stabilität eines Unternehmens:

Merke

Je  höher  der  Eigenkapitalanteil  ist,  desto  kreditwürdiger  und  weniger  krisenanfällig wird ein Unternehmen eingeschätzt.

Liegt die EK-Quote bei 100%, bedeutet das, dass keine Schulden vorhanden sind und das gesamte Kapital von den Eigenkapitalgebern stammt.

Eine EK-Quote von 100% gibt es allerdings kaum, da sie meistens nicht wünschenswert ist: Oft ist es viel rentabler einen günstigen Kredit für eine profitable Investition aufzunehmen, statt neues Eigenkapital einzusetzen und den Gewinn mit mehr Anlegern teilen zu müssen.

Eine EK-Quote von 0% bedeutet dagegen, dass kein Kapital von Eigenkapitalgebern (mehr) vorhanden ist und das Unternehmen komplett auf geliehenem Geld aufgebaut ist.

## Merke

Die Eigenkapitalquote sollte dabei eher bei einem Vergleich innerhalb einer Branche verwendet werden, da die EK-Quoten bei Kreditinstituten üblicherweise viel geringer sind als bei kapitalintensiven Unternehmen.

## #14 - Verschuldungsgrad

## Berechnung

Verschuldungsgrad = Fremdkapital / Eigenkapital

Bedeutung: Der Verschuldungsgrad hat eine ähnliche Aussage wie die Eigenkapitalquote, unterscheidet sich aber in seiner Berechnung.

Hier  gelten  daher  die  gleichen  Gesetze:  Je  höher  der  Verschuldungsgrad,  desto riskanter ist ein Unternehmen generell einzuschätzen.

## Beispiel

Ein Unternehmen hat eine Bilanzsumme von 10 Mrd. Euro. Davon entfallen 4 Mrd. Euro auf das Eigenkapital und 6 Mrd. Euro auf das Fremdkapital. Damit beträgt der Verschuldungsgrad 150% (6 Mrd. Euro / 4 Mrd. Euro).

## #15 - Zinsdeckungsgrad

## Berechnung

Zinsdeckungsgrad = EBIT / Zinsaufwand

Bedeutung: Die letzte Aktienkennzahl, der Zinsdeckungsgrad, gibt an, inwiefern es ein Unternehmen schafft die Zinsen seiner Kredite zurückzubezahlen.

Dazu  wird  der  Gewinn  (meistens  EBIT  oder  EBITDA)  ins  Verhältnis  zu  den  zu zahlenden Zinsen für das Fremdkapital gesetzt.

Dabei greift  diese  Kennzahl  oft  Hand  in  Hand  mit  dem  Verschuldungsgrad,  da  die Zinsbelastung i.d.R. dann höher ist, wenn auch der Verschuldungsgrad höher ist.

Liegt der Zinsdeckungsgrad unter 1,0 sollten bei dir die Alarmglocken läuten:

Das Unternehmen hat es dann zuletzt nicht geschafft, einen Gewinn zu erwirtschaften, der ausreichen würde, um die Zinsen der Kredite zu decken.

## Kennzahlen zu Ertrag und Rentabilität

Gewinnmaximierung ist eines der wichtigsten Unternehmensziele in der Betriebswirtschaftslehre. Gewinn entsteht dabei durch den Einsatz von Kapital unter Unsicherheit. Ein Bäcker benötigt etwa eine Filiale, eine Backstube und Waren, um mit diesem Kapital die operative Tätigkeit durchzuführen und einen Gewinn zu erzielen. Um den Erfolg einer Unternehmung zu messen, müssen daher beide Seiten der Gleichung betrachtet werden: Gewinn und benötigtes Kapital. Je größer der Gewinn und je geringer die dazu notwendige Kapitalbasis, desto rentabler wirtschaftet ein Unternehmen. Die Rentabilität stellt daher ein wichtiges Maß der Unternehmensbewertung dar. Dieses Kapitel beschäftigt sich mit der Frage, wie Rentabilität gemessen werden kann und welche Aussagekraft diesen Ergebnissen zukommt. Anhand von Fallbeispielen werden verschiedene

Rentabilitätskennzahlen erläutert, die als grundlegende Werkzeuge der Unternehmensbewertung dienen. Der Gewinn oder Jahresüberschuss ist die meistbeachtete betriebswirtschaftliche Kenngröße. Die Aussagekraft dieser Erfolgsgröße lässt allerdings nur einen begrenzten Rückschluss auf den Wert eines Unternehmens zu, solange dieser nicht in Bezug zu anderen Kenngrößen gesetzt wird. Betrachten wir dazu die Entwicklung der Konzernergebnisse zweier fiktiver Unternehmen.

- 1. Eigenkapitalrendite

Die Eigenkapitalrendite gibt die Verzinsung des von den Eigenkapitalgebern eingebrachten Kapitals an. Zur Berechnung dieser wichtigen Kennzahl wird der erwirtschaftete Jahresüberschuss mit dem durchschnittlichen Eigenkapital des Geschäftsjahres ins Verhältnis gesetzt. Es ist wichtig, den Jahresüberschuss und das Eigenkapital nach Anteilen Dritter bei der Berechnung heranzuziehen, um nur Erfolgsgrößen zu berücksichtigen, die den Aktionären auch tatsächlich zustehen. In Nenner wird das durchschnittliche Eigenkapital herangezogen, da mit diesem über das Jahr verteilt der Gewinn erzielt wurde.

Das Ergebnis gibt die Verzinsung des eingebrachten Kapitals wieder und bietet Investoren eine Vergleichsgröße zwischen verschiedenen Anlagen. Auf Beispiel 2.1 angewandt ergibt sich für Unternehmen A im Jahr 2020 eine Eigenkapitalrendite von 2 % (100 € / 5.000 €). Hätten die Investoren dagegen das Kapital auf dem Bankkonto angelegt, wäre die Rendite bei vernachlässigbarem Risiko gegebenenfalls vorteilhafter gewesen. Unternehmen B lieferte seinen Eignern dagegen im selben Jahr trotz stagnierender Gewinne eine Verzinsung ihres Kapitals von 20 % (1.000 € / 5.000 €). Eine niedrige Eigenkapitalrendite lässt auf den ineffizienten Einsatz von Kapital oder eine Überbewertung der Aktiva (und damit des Eigenkapitals) schließen. Die Eigenkapitalrendite stellt aufgrund der Verbindung von Gewinn und Eigenkapital die zentrale Rentabilitätskennzahl für Eigenkapitalgeber dar. Wie in Kapitel 8 gezeigt wird, gewinnen Unternehmen an Wert, wenn diese ihr Eigenkapital mit einer hohen Rate bei geringem Risiko steigern können. Die Eigenkapitalrendite gibt diese Steigerungsrate an. Verteilung der Eigenkapitalrendite im S&amp;P 500 Die folgende Übersicht bildet die Verteilung der Eigenkapitalrenditen (3-jähriger Durchschnitt) der S&amp;P 500-Unternehmen ab. Diese Aufstellung soll einen Überblick verschaffen, wie eine gegebene Eigenkapitalrendite im Marktumfeld einzuschätzen ist. Der Median der Eigenkapitalrenditen liegt bei 15,2 %. Rund 72 % der Werte liegen unterhalb von 25 %.

Eine hohe Eigenkapitalrendite ist nicht zwingend Folge einer sehr guten operativen Leistung eines

Unternehmens, sondern unterliegt auch finanzpolitischen Entscheidungen. Die Betrachtung der Formel für die Eigenkapitalrendite ergibt zwei Wege zur Steigerung der Rentabilität: Einerseits kann die Eigenkapitalrendite durch eine Erhöhung des Gewinns, andererseits aber auch durch eine Reduktion der Eigenkapitalbasis gesteigert werden. Unternehmen mit ausreichender Stabilität reduzieren daher teilweise ihre Eigenkapitalbasis durch Aktienrückkäufe oder Dividendenausschüttungen, um die Eigenkapitalrendite zu steigern. Das nächste Beispiel verdeutlicht anhand der US-amerikanischen Yum! Brands, wie durch ausgeprägte Rückkäufe das Eigenkapital übermäßig stark gesenkt werden kann. Da diese Praxis vor allem im angelsächsischen Bereich verbreitet ist, sind dort sehr hohe Eigenkapitalrenditen keine Seltenheit. Diese Form der Rentabilitätssteigerung weist jedoch auch Risiken auf, da eine ausreichende Eigenkapitalbasis in Krisenzeiten als Sicherheitspuffer wirkt. Die Erhöhung der Eigenkapitalrendite durch Aktienrückkäufe geht also in der Regel mit einer Erhöhung des Risikos einher. Dieses Vorgehen sollte daher nur von Unternehmen mit sehr sicheren Zahlungsströmen durchgeführt werden. Die Eigenkapitalrendite sollte aus diesem Grund im Zusammenhang mit dem Verschuldungsgrad, der Eigenkapitalquote (beide Kapitel 3) und dem Geschäftsmodell (Kapitel 5) bewertet werden. Im Fall von Yum Brands!, der größten Fast-Food-Kette der Welt, ist dieses Vorgehen durchaus legitim. Zwar hat der Konzern sein bilanzielles Eigenkapital durch Aktienrückkäufe und andere Einflüsse bis tief in den negativen Bereich gesenkt, jedoch ist das Geschäftsmodell als äußerst robust einzuschätzen, sodass selbst diese extreme Art der Rentabilitätssteigerung als vertretbar einzustufen ist. Dieser Konzern bildet dabei jedoch eine Ausnahme. Zyklische Branchen wie der Maschinenbau benötigen beispielsweise eine ausreichende Eigenkapitalbasis, um auch in Abschwungphasen ihre Flexibilität zu wahren.

## 2. Umsatzrendite

Die Umsatzrentabilität gibt an, wie viel Cent Gewinn durch einen Euro an Umsatz erwirtschaftet werden. Insbesondere bei gering verschuldeten Unternehmen mit einer exzellenten Marktstellung sind sehr hohe Umsatzrenditen vorzufinden. Bei Konzernabschlüssen muss zur Berechnung der Umsatzrendite stets das Ergebnis vor dem Abzug von Minderheitsanteilen herangezogen werden. Maßgeblichen Einfluss auf die Umsatzrendite haben die Marktmacht und das Kostenmanagement des Unternehmens. Je ausgeprägter die Fähigkeit, die Preise anzupassen und gleichzeitig die Kosten zu senken, desto höher fällt die Umsatzrendite aus. Aus diesem Grund verfügen Unternehmen, die in einem Monopol oder Oligopol wirtschaften, in der Regel über hohe Umsatzrenditen. Zudem sind hohe oder zunehmende Umsatzrenditen oft ein Zeichen für das Vorliegen einer Fixkostendegression. Die Kehrseite bilden klassischerweise Händler, die keine Produkte herstellen, sondern als Intermediär auftreten. In dieser Branche liegen die Umsatzrenditen für gewöhnlich im niedrigen einstelligen Bereich. Eine Erhöhung der Rendite kann in der Regel nur über Kostensenkungen oder Volumenausdehnung stattfinden. Dies erklärt auch, weshalb im Massengütermarkt die absolute Größe einer der wichtigsten Einflussfaktoren ist, um annehmbare Renditen zu erzielen.

## 3. EBIT/EBITDA-Marge

In einigen Lehrbüchern wird die Berechnung der Umsatzrendite im Zähler, neben dem Jahresüberschuss,  noch  um  Steuern  und  Zinsen  erweitert.  Da  nun  aber  Zinsen  und  Steuern  reale Aufwendungen  darstellen,  sollten  diese  konsequenterweise  abgezogen  werden.  Eine  niedrige Steuerquote, beispielsweise aufgrund eines Konzernsitzes in der Schweiz, ist ein Wettbewerbsvorteil, da dem Unternehmen durch die geringeren Steuerzahlungen mehr Gewinn pro Einheit Umsatz zur Verfügung steht. Zum Vergleich von Unternehmen in einer Branche oder über verschiedene Regionen hinweg kann es dennoch hilfreich sein, die EBIT-Marge, also das Verhältnis von operativem Gewinn zu Umsatz,  zu  berechnen.  Ohne  Rücksicht  auf  Unterschiede  in  der  Zins-  und  Steuerlast  kann  so  die eigentliche  operative  Leistung  des  Unternehmens  quantifiziert  werden.  Eine  Erweiterung  der  EBITMarge  kann  durch  Hinzuzählen  der  Abschreibungen  zum  operativen  Ergebnis  erzielt  werden.  Das EBITDA gibt somit den Gewinn vor Zinsen, Steuern und Abschreibungen an.

Kapitalumschlag Die Umschlaghäufigkeit des Kapitals gibt Aufschluss darüber, wie produktiv Kapital im Unternehmen eingesetzt wird. Ein hoher Kapitalumschlag bedeutet, dass Kapital schnell wieder in das Unternehmen  zurückfließt  und  somit  insgesamt  weniger  Kapital  benötigt  wird,  um  ein  gegebenes Geschäftsvolumen durchzuführen. Aufgrund der engen Verknüpfung zwischen Geschäftsmodell und Kapitalbedarf  ist  eine  Vergleichbarkeit  dieser  Kennzahl  nur  im  Branchenkontext  zulässig.  Weiter verbreitet und aussagekräftiger ist die Anwendung der Kennzahl bei Einzelunternehmen im Zeitverlauf. Es  verwundert  daher  nicht,  dass  der  Return  on  Investment  (RoI)  und  der  Kapitalumschlag  eines Unternehmens  direkt  miteinander  verbunden  sind:  Dieses  Kennzahlensystem  wurde  1919  von Donaldson Brown, einem Ingenieur des US-Unternehmens Du Pont de Nemours, entwickelt und wird deshalb auch als Du-Pont-Schema bezeichnet. Das ausführliche Du-Pont-Schema gliedert den Return on  Investment  noch  weiter  in  seine  Einzelteile  auf  und  zeigt,  welche  Einflussfaktoren  auf  die  drei Bestandteile  der  RoI-Formel  (Umsatz,  Kapital,  Betriebsergebnis)  wirken.  Die  Analyse  der  oben angegebenen  Formel  ergibt,  dass  der  Return  on  Investment  zum  einen  durch  einen  hohen Kapitalumschlag  (erster  Bruch)  und  zum  anderen  durch  eine  hohe  Betriebsergebnismarge  (zweiter Bruch) gesteigert werden kann. Die Betriebsergebnismarge entspricht näherungsweise der Umsatzrendite  und  wird  durch  die  Marktstellung  und  das  Kostenmanagement  bestimmt.  Der Kapitalumschlag ist dagegen abhängig von Geschäftsmodell und Investitionspolitik. Wie kann in der Realität eine Verbesserung des Kapitalumschlags erreicht werden? Unternehmen können beispielsweise ihre Vorräte schlanker gestalten, nicht oder nur spärlich benutzte Maschinen verkaufen und Forderungen per Factoring abbauen oder durch Anreize wie Skonti schneller einfordern. Diese Maßnahmen, welche hauptsächlich das Working Capital Management betreffen, werden in Kapitel 4 näher beschrieben.

## 3. Gesamtkapitalrendite

Da der bereits vorgestellte Return on Investment in Abwandlungen auch mit dem Jahresüberschuss oder anderen Ergebnisgrößen anstatt dem Betriebsergebnis verrechnet wird, ist an dieser Stelle die Gesamtkapitalrendite noch einmal explizit aufgeführt. Die Gesamtkapitalrendite berücksichtigt neben dem Reingewinn des Unternehmens auch die gezahlten Zinsen und setzt diese ins Verhältnis mit dem von Fremd- und Eigenkapitalgebern eingebrachten Kapital. Wie auch bei der Eigenkapitalrendite oder dem Kapitalumschlag müssen die Ergebnisgrößten mit dem durchschnittlich gebundenen Kapital ins Verhältnis gesetzt werden, um die jährlichen Stromgrößten (hier: Jahresüberschuss und Fremdkapitalzinsen) mit den stichtagsabhängigen Bilanzzahlen (hier: Bilanzsumme) sinnvoll vergleichen zu können. Gegenüber der Eigenkapitalrendite hat die Gesamtkapitalrendite den Vorteil, nicht durch finanzpolitische Effekte verzerrt zu sein. Sie drückt also die Rendite aller Kapitalgeber aus, weshalb die Fremdkapitalzinsen als Ertrag der Fremdkapitalgeber hinzugerechnet werden. Der zuvor angesprochene Return on Investment ist eine Variante der Gesamtkapitalrendite.

## 4. Return on Capital Employed

Die zuvor dargestellten Kennzahlen zur Messung der Rentabilität haben allesamt Schwachpunkte. So kann beispielsweise die Eigenkapitalrendite durch fremdfinanzierte Aktienrückkäufe oder Sonderausschüttungen künstlich erhöht werden. Hohe Gewinnmargen sind dagegen grundsätzlich zu begrüßen, jedoch müssen diese stets vor dem Hintergrund des dazu eingesetzten Kapitals betrachtet werden. Die oben eingeführte Kennzahl zur Gesamtkapitalrendite löst dieses Problem teilweise, bildet jedoch nicht den Einfluss der Finanzierung durch die Zulieferer ab; schließlich stellen die Verbindlichkeiten aus Lieferungen und Leistungen eine Form der kostenlosen Finanzierung dar und sollten  daher  nicht  im  Zähler  mit  abgebildet  werden.  Die vollständigste  Kennzahl  zur  Messung  der Rentabilität  stellt  daher  der  Return  on  Capital  Employed  ('ROCE')  dar,  welcher  diese  Punkte miteinbezieht.  Der  Return  on  Capital  Employed  gibt  an,  wie  rentabel  das  gebundene  Kapital  eines Unternehmens eingesetzt wird. Das Capital Employed berechnet sich durch Addition von Anlagevermögen und Working Capital, abzüglich der Zahlungsmittel (Netto Working Capital). Diese Kenngröße  gibt  das  betriebsnotwendige,  gebundene  Kapital  an,  mit  dem  das  Unternehmen  das operative Geschäft betreibt. Die Verbindlichkeiten gegenüber Lieferanten werden abgezogen, da es sich hierbei um zinslose Kredite handelt. Der Abzug der Zahlungsmittel erfolgt, da diese zum Großteil nicht zur operativen Tätigkeit benötigt werden. Folglich ergibt das Capital Employed in Summe den Betrag, der netto tatsächlich investiert werden müsste, um das Unternehmen abzubilden. Eine zweite, simplere  Berechnungsart  des  Capital  Employed  ergibt  sich  durch  Addition  von  Eigenkapital  und NettoFinanzverbindlichkeiten, also dem durch das operative Geschäft zu verzinsende Kapital. In der Praxis empfiehlt sich die Berechnung des eingesetzten Kapitals über die Aktivseite, insbesondere bei der Betrachtung  im  Zeitverlauf, wie die untenstehenden  Beispiele  illustrieren. Je höher  die Kapitalrenditen  und  je  höher  das  absolut  intern  reinvestierbare  Kapital,  desto  attraktiver  das Unternehmen.  Zwar  ist  in  der  Theorie  ein  Unternehmen  mit  hohen  Wachstumsraten  ohne  der Notwendigkeit  von  Reinvestitionen noch  wertvoller (da die  gesamten  Zahlungsströme  sofort ausgeschüttet werden könnten), jedoch ist dies in der Praxis nur sehr selten vorzufinden. Wie bereits erwähnt kommt dem Return on Capital Employed, also der Rendite auf das eingesetzte Kapital, eine überragende Rolle in der Analyse von Unternehmen zu, da diese interne Verzinsung des Kapitals als regelrechter Turbo dienen kann, wenn Kapital schlau allokiert wird.

## 5. Umsatzverdienstrate

Die Umsatzverdienstrate (UVR) zeigt an, wie viel Cent Cashflow pro Euro Umsatz generiert werden. Im Gegensatz zu anderen Kennzahlen lässt sich für die Umsatzverdienstrate kein idealer Wert festlegen, es gilt  schlicht:  je  mehr,  desto  besser.  Die  Umsatzverdienstrate  weist  Ähnlichkeiten  mit  der Umsatzrendite auf, wobei letztere zahlungsunwirksame GuV-Positionen und Working-Capital-

Investitionen nicht berücksichtigt. Die Umsatzverdienstrate ist folglich die genauere Kennzahl, sie ist durch die vielen Einflussfaktoren aber auch schwankungsanfälliger und schwieriger zu interpretieren.

## Kennzahlen zur finanziellen Stabilität

Eine  langfristige  Kapitalanlage  muss  zwei  grundlegende  Kriterien  erfüllen:  Zum  einen  sollte  die Investition eine  angemessene Rendite auf das eingesetzte Kapital abwerfen. Messgrößen zu dieser Problematik wurden in Kapitel 2  bereits vorgestellt. Zum anderen kann ein Unternehmen nur dann langfristig erfolgreich wirtschaften, wenn es über eine solide Finanzierung und Kapitalstruktur verfügt. Das  folgende  Kapitel  liefert  Kennzahlen  zur  Überprüfung  und  Quantifizierung  der  finanziellen  Lage eines Unternehmens. Obwohl die Rentabilitätskennzahlen zuerst vorgestellt wurden, ist die Bedeutung der finanziellen Stabilität schwerlich zu überschätzen. Gerade in der Wirtschaft ist Murphys Gesetz aktueller denn je: Alles, was schiefgehen kann, wird auch irgendwann schiefgehen.

## Eigenkapitalquote

Die Eigenkapitalquote gibt den Anteil des Eigenkapitals am Gesamtkapital eines Unternehmens an. Eine hohe Eigenkapitalquote kennzeichnet in der Regel besonders konservativ finanzierte Unternehmen. Je höher die  Eigenkapitalquote,  desto  geringer  ist  die  Verschuldung  eines  Unternehmens.  Gegenüber Eigenkapital hat Fremdkapital jedoch den Vorteil der steuerlichen Abzugsfähigkeit, da Fremdkapitalzinsen  die  Steuerlast  eines  Unternehmens  senken  können.  Zudem  ist  Fremdkapital günstiger als Eigenkapital, da Gläubiger im Insolvenzfall vorrangig bedient werden und somit weniger Risiko ausgesetzt sind. Die Eigenkapitalgeber hingegen werden erst nach vollständiger Bedienung der Fremdkapitalgeber berücksichtigt. Ein gewisser Fremdkapitalanteil ist daher in jedem Unternehmen vorzufinden  und  auch  sinnvoll,  da  beispielsweise  die  Vorräte  teilweise  durch  Lieferantenkredite finanziert werden oder kurzfristig Liquidität aus Kreditlinien abgerufen werden muss. Mit steigendem Fremdkapitalanteil erhöht sich jedoch das Risiko einer Unternehmung, da die Zinslast zunimmt. Gerade in Abschwungphasen ist der fixe Charakter von Zinszahlungen problematisch für Unternehmen, die in zyklischen  oder  geringmargigen  Branchen  wirtschaften.  Die  These  von  Paracelsus  gilt  auch  für Fremdkapital: Allein die Menge macht das Gift. Im Gegensatz zu Fremdkapital weist Eigenkapital weder eine Endfälligkeit noch einen Zwang zu Dividendenzahlungen auf. So kann in schwierigen Marktphasen Liquidität  im  Unternehmen  gehalten  und  die  Flexibilität  substanziell  erhöht  werden.  Langfristig orientierte Anleger sollten Unternehmen bevorzugen, die eine ausreichend hohe Eigenkapitalquote aufweisen, um auch extreme Abschwungphasen zu überstehen. Die genaue Höhe richtet sich nach dem Geschäftsmodell  und  der  Volatilität  der  Gewinne.  Start-ups  mit  einem  besonders  großen  Maß  an Ungewissheit sollten daher eine möglichst hohe Eigenkapitalquote als Vorsorge für schlechte Zeiten anstreben, während etablierte und wenig volatile Geschäftsmodelle wie beispielsweise das von Nestlé oder Procter &amp; Gamble auch relativ geringe Eigenkapitalquoten überdauern können. Übersteigt die Eigenkapitalquote den je nach Geschäftsmodell angemessenen Zielkorridor, sinkt die Rentabilität, ohne die Sicherheit maßgeblich zu erhöhen. Die Eigenkapitalquote sollte daher sowohl aus Risiko- als auch aus Renditegesichtspunkten beurteilt werden. Da Fremdkapital günstiger als Eigenkapital ist, tendieren viele Unternehmenslenker in guten Zeiten dazu, den Wert ihres Unternehmens mit geliehenem Kapital zu erhöhen. Folgendes Beispiel soll diesen Hebel- oder Leverage-Effekt beschreiben, der in vielen Fällen Unternehmen bereits in Schieflage gebracht hat.

## Gearing

Zur Beurteilung der finanziellen Stabilität stellt das Gearing die wichtigste Kennzahl dar. Es gibt an, zu welchem  Grad  die  Nettofinanzverbindlichkeiten  (d.  h.  Finanzverbindlichkeiten  abzüglich  flüssiger Mittel)  durch  Eigenkapital  gedeckt  sind.  Durch  die  Verbindung  von  Finanzverbindlichkeiten,  CashBestand und Eigenkapital enthält diese Kennzahl alle elementaren Bilanzbestandteile hinsichtlich der finanziellen  Stabilität  eines  Unternehmens.  Im  Gegensatz  zur  Eigenkapitalquote,  die  indirekt  alle

Verbindlichkeiten mit einbezieht, beachtet das Gearing lediglich die zinstragenden Verbindlichkeiten (Finanzverbindlichkeiten).  Hohe  Bestände  an  Verbindlichkeiten  aus  Lieferungen  und  Leistungen werden  somit  positiv  gewertet,  da  diese  unverzinsliche  Kredite  darstellen.  Da  diesen  in  der  Regel Forderungen und Vorräte gegenüberstehen, ist ein hoher Bestand an Verbindlichkeiten aus Lieferungen und Leistungen unter normalen Umständen nicht kritisch zu sehen. Ein niedriges Gearing gibt somit eine geringe Nettoverschuldung an, folglich gilt bei dieser Kennzahl die Schlussfolgerung: Je niedriger das  Gearing,  desto  geringer  ist  die  tatsächliche  Verschuldung  des  Unternehmens.  Verfügt  ein Unternehmen  über  mehr  liquide  Mittel  als  Finanzverbindlichkeiten,  so  ist  es  als  schuldenfrei anzusehen. Das Gearing ist in diesem Fall negativ. Aus Rendite/Risiko-Gesichtspunkten ist ein Gearing von 10-20 % als ideal anzusehen, da in diesem Bereich weder zu viele liquide Mittel gehortet werden, noch die finanzielle Stabilität vernachlässigt wird. Werte zwischen 20 und 50 % sind weiterhin als gut einzustufen.  Ab  einem  Gearing  von  70  %  ist  die  finanzielle  Stabilität  des  Unternehmens  hingegen kritisch.  Übersteigt  der  Wert  100  %,  sollte  über  eine  Kapitalerhöhung  oder  eine  substanzielle Entschuldung  nachgedacht  werden,  da  in  diesem  Fall  die  Nettofinanzschulden  das  Eigenkapital übersteigen.

## Dynamischer Verschuldungsgrad

Diese Kennzahl gibt die theoretische Schuldentilgungsdauer in Jahren an, sofern das Unternehmen seinen gesamten Free-Cashflow zur Schuldentilgung nutzt. Da dieser mitunter deutlich schwankt, sollte ein sinnvoller Durchschnitt des FreeCashflows der letzten Jahre verwendet werden. Der dynamische Verschuldungsgrad hat gegenüber dem Gearing den Vorteil, dass auch die Einkommensseite betrachtet wird. Im Extremfall könnte auch ein Unternehmen mit niedrigem Gearing in finanzielle Schwierigkeiten geraten,  sobald  keine  Cashflows  mehr erwirtschaftet  werden,  um  die  Schulden  zu  bedienen.  Beim dynamischen Verschuldungsgrad sind Werte unter 2 Jahren als sehr gut anzusehen, ab 5 Jahren ist der Verschuldungsgrad als kritisch einzustufen.  Bei  Wachstumsunternehmen,  die  aufgrund  hoher Investitionen  in  der  kurzen  Frist  oft  niedrige  oder  negative  Free-Cashflows  aufweisen,  sollte  ein sinnvoller, mittelfristig zu erwartender Free-Cashflow verwendet werden. Sehr stabile Geschäftsmodelle mit geringen Reinvestitionsraten können unter Umständen mit großen Mengen an Fremdkapital  finanziert  sein,  ohne  dadurch  übermäßig  an  finanzieller  Stabilität  einzubüßen.  Das Beispiel der amerikanischen Fast-Food-Kette Yum! Brands verdeutlicht die ergänzende Aussagekraft des dynamischen Verschuldungsgrades in Kombination mit dem Gearing.

## Net Debt/EBITDA

Die  Kennzahl  Net  Debt/EBITDA  vergleicht  die  Nettoverschuldung  des  Unternehmens,  d.  h.  die Finanzverbindlichkeiten  abzüglich  der  liquiden  Mittel,  mit  dem  Ergebnis  vor  Zinsen,  Steuern  und Abschreibungen. Das EBITDA stellt den Betrag dar, der zur Bedienung der Zinslast in der kurzen Frist verwendet werden kann. Da das EBITDA zudem näherungsweise dem Brutto-Cashflow entspricht, kann mit dieser Kennzahl gemessen werden, wie sicher die Rückzahlung der Finanzverbindlichkeiten ist. Je stärker die Verbindlichkeiten durch das EBITDA gedeckt sind, desto größer ist die Wahrscheinlichkeit einer vollständigen Rückzahlung. Das EBITDA berechnet sich durch Addition der Abschreibungen zum operativen Ergebnis (EBIT). Das Verhältnis  von  Nettoschulden  zu EBITDA  ist inzwischen die meistverbreitete Messlatte für die Verschuldung eines Unternehmens. Allerdings weist diese Kennzahl auch  eklatante  Schwächen  auf.  Viele  Unternehmen  setzen  inzwischen  eine  angepasste  (adjusted) Version des EBITDA an, rechnen also gewisse Sonderaufwendungen heraus, wobei hier der Kreativität oft keine Grenzen gesetzt sind. Bei der Berechnung dieser Kennzahl ist also darauf zu achten, einen realistischen Wert im Zähler anzusetzen. Wichtig ist ebenfalls, wie viel Zahlungsfluss aus dem EBITDA erzielt wird, der dann tatsächlich zur Schuldentilgung verwendet werden kann. Deshalb ist es immer ratsam,  diese  Kennziffer  vor  dem  Hintergrund  des  nachhaltigen  Investitionsbedarfs  und  dem Steueraufwand des Unternehmens einzuschätzen.

## Sachinvestitionsquote

Stellen Sie sich vor, Sie besitzen ein Unternehmen, das jährlich einen Gewinn von 5 Mio. € abwirft. Um diesen Gewinn zu generieren und wettbewerbsfähig zu bleiben, müssen aber alle 2 Jahre 10 Mio. € in neue Anlagen investiert werden. Letztendlich kann dem Unternehmen also kein Geld entzogen werden, trotz jährlicher Gewinne. Die Sachinvestitionsquote beschreibt diesen Sachverhalt als Verhältnis von Sachinvestitionen zu operativem Cashflow. In der Praxis wird häufig anstatt des operativen Cashflows auch die Cash Earnings, also der Jahresüberschuss zuzüglich Abschreibungen und anderen zahlungsunwirksamen Positionen verwendet, da der operative Cashflow bei vielen Unternehmen durch Working-Capital-Veränderungen  deutlichen  Schwankungen  unterworfen  ist.  Die  Überlegungen  aus dem Eingangsbeispiel verdeutlichen, dass eine Sachinvestitionsquote von über 100 % langfristig jedes Unternehmen ruiniert. Wer über Jahre mehr Geld ausgibt, als operativ zufließt, ist über kurz oder lang auf  Kredite  angewiesen,  die  zur  Überschuldung  führen  können.  Dies  erklärt  auch  das  langfristig schwache Abschneiden von vielen kapitalintensiven Branchen wie Automobilhersteller, Luftfahrt oder Stahlerzeugung. Langfristig orientierte Investoren sind in der Regel an Unternehmen interessiert, die Jahr für Jahr hohe Gewinne auf das eingesetzte Kapital abwerfen und einen nur geringen Kapitalbedarf aufweisen oder deren Investitionen hohe Kapitalrenditen erzeugen. Ist ein Unternehmen in der Lage seinen operativen  Cashflow  zu  steigern  und  gleichzeitig  die  Sachinvestitionen  niedrig  zu  halten,  so zeugt dies oft von hohen Kapitalrenditen

## Anlagenabnutzungsgrad

Geringe Sachinvestitionsquoten sind in der Regel als Wettbewerbsvorteil oder gerade als Folge eines solchen zu werten. Jedoch können niedrige Sachinvestitionsquoten auch aufgrund eines verringerten Investitionsvolumens auftreten, was generell negativ zu beurteilen ist. Auch Unternehmen aus wenig kapitalintensiven Branchen sollten nie an den Investitionen sparen, da beispielsweise im IT-Bereich oder durch modernere  Dämmungen  der  Fabriken  Effizienzsteigerungen  möglich  sind. Lucent Microsystems  reduzierte  durch  die  Einführung  eines  Oracle  Enterprise  Systems  beispielsweise  die Durchlaufzeit  ihrer  Geschäftsprozesse  von  mehr  als  einer  Woche  auf  weniger  als  8  Stunden  und steigerte  seine  EBIT-Marge  nur  durch  eingesparte  Logistikkosten  um  einen  halben  Prozentpunkt. Colgate  Palmolive  erreichte  durch  die  Einführung  eines  SAP-Systems  gar  eine  Halbierung  der  Zeit zwischen Auftragseingang und Auslieferung. Ein findiger Manager könnte jedoch auf die Idee kommen, durch den konsequenten Verzicht auf Investitionen kurzfristig den Free-Cashflow zu erhöhen. Derartige Praktiken lassen sich mithilfe des Anlagenabnutzungsgrades überprüfen. Diese Kennzahl lässt sich als Indikator  für  das  Alter  der  Sachanlagen  anwenden.  Der  Anlagenabnutzungsgrad  sagt  nun  aus,  zu welchem Anteil das Anlagevermögen bereits abgeschrieben ist. Ein hoher Wert gibt folglich an, dass in Zukunft hohe Investitionen nötig sind, um alte Anlagen zu ersetzen. Insbesondere der Vergleich mit Branchenkonkurrenten ist hier von Interesse.

## Wachstumsquote

Eine dynamischere Kennzahl mit ähnlichem Ziel, die Wachstumsquote,  setzt die getätigten Investitionen und Abschreibungen ins Verhältnis. Für gewöhnlich ist Wachstum mit entsprechenden Investitionen verbunden. Übersteigen die Investitionen die jährlichen Abschreibungen, so befindet sich das Unternehmen meist in einer expansiven Phase. Liegt der Wert dagegen unter 100 %, ist zu prüfen, ob das Unternehmen entweder die Abschreibungsraten zu hoch ansetzt, auf Kosten seiner Substanz lebt oder geringere Investitionen gerechtfertigt sind, da die Wachstumsdynamik abgenommen hat. Ein weiterer Grund kann in technologische Veränderungen zu finden sein. Wechselt beispielsweise ein Kaufhaus komplett auf den eCommerce-Kanal, so werden die Sachinvestitionen stark abnehmen, da im eCommerce geringere Investitionen anfallen. Die Abschreibungen und Investitionen (capital expenditures, kurz CAPEX) zur Berechnung der Kennzahl für die jeweilige Periode finden sich in der Cashflowrechnung.

## Cash-Burn-Rate

Insbesondere  junge  und  schnell  wachsende  Unternehmen  weisen  einen  Kapitalbedarf  auf,  der  die operativen Cashflows oft übersteigt. Da starkes Wachstum in der Regel mit hohen Investitionen in das Umlaufvermögen  einhergeht  (z.  B.  für  ausreichende  Vorratsbestände),  würde  die  herkömmliche Bewertung auf Basis von Zahlungsströmen stets zu einem negativen Ergebnis kommen. Zwar ist eine gesunde Skepsis gegenüber jungen Unternehmen gerade in Boomphasen angebracht, jedoch sind auch in diesem Bereich interessante Investitionsideen zu finden. Die Cash-Burn-Rate zeigt an, wie lange ein Unternehmen  maximal  defizitär  wirtschaften  kann.  Bei  defizitären  Unternehmen  bietet  sich  der Vergleich von Verlust (im Betrag) und Eigenkapital an. Diese Kennzahl gibt die maximale Anzahl an verkraftbaren Verlustjahren an. Je näher dieser Wert dem Nullpunkt kommt, desto notwendiger wird eine  Kapitalerhöhung,  um  eine  Überschuldung  abzuwenden.  Weist  die  Cash-Burn-Rate  (C-B-R) beispielsweise einen Wert von 5 Jahren auf, so bedeutet dies, dass erst nach 5 konstanten Verlustjahren das Eigenkapital aufgezehrt wäre. Es ist zu beachten, dass der Investor in einem solchen Fall über eine fundierte Einschätzung verfügen sollte, wann das Unternehmen den Break-evenPunkt erreichen kann. Ist dieser beispielsweise nach 2 Jahren erreicht, so genügen die Rücklagen. Eine solche Prognose ist dabei immer unter pessimistischen Annahmen zu treffen, da bei Nichteintreffen unter Umständen ein Totalverlust droht.

## Umlauf- und Anlagenintensität

Je größer der Anteil des Umlaufvermögens an der Bilanzsumme, desto ausgeprägter ist die Flexibilität des  Unternehmens.  Da  Umlaufvermögen  per  Definition  kurzfristig  gebundenes  Kapital  darstellt, bedeutet eine hohe Umlaufintensität gleichzeitig ein großes Maß an Anpassungsfähigkeit. Insbesondere  in  schnelllebigen  Branchen  ist  Flexibilität  die  Grundvoraussetzung,  um  langfristig bestehen zu können. Weist ein Unternehmen beispielsweise eine geringe Umlaufintensität auf, so ist ein  großer  Teil  der  Vermögenswerte  im  Anlagevermögen  gebunden.  Dies  können  zum  Beispiel Fabrikgebäude und Maschinen sein. Ändert nun ein Trend wie der Elektroantrieb im Automobilsektor eine  ganze  Branche,  so  müssen  die  Anlagegüter  erneuert  werden,  was  in  der  Regel  kostspielig  ist. Gleichwohl bedeutet eine hohe Umlaufintensität nicht per se hohe Flexibilität. Gegebenenfalls kann das Unternehmen seine Vorräte nicht verkaufen oder Forderungen nicht eintreiben. In diesem Fall deutet  ein  Anschwellen  des  Umlaufvermögens  auf existenzielle  Probleme  hin.  Das  Gegenstück  zur Umlaufintensität  stellt  die  Anlagenintensität  dar.  Eine  hohe  Anlagenintensität  birgt  dabei  teilweise Risiken, da nicht schnell auf Markttrends reagiert werden kann. Ein Händler mit einer sehr geringen Anlagenintensität kann beispielsweise sehr schnell auf Trends reagieren, indem er stets die Produkte ins  Sortiment  nimmt,  die  gerade  nachgefragt  werden.  Die  Produzenten  dieser  Produkte  können dagegen  oft  nicht  flexibel  auf  Nachfrageänderungen  reagieren,  da  Maschinen  in  der  Regel  nur bestimmte Produkte herstellen können. Unternehmen mit einer hohen Anlagenintensität sollten daher stets  über  eine  hohe  Planbarkeit  verfügen,  wodurch  das  Risiko  von  neuen  Markttrends  und Nachfrageänderungen minimiert wird.

## Anlagendeckungsgrad I und II

Die 'Goldene Bilanzregel' verlangt, dass langfristiges Vermögen langfristig finanziert sein sollte, um Finanzengpässe  zu  vermeiden.  Da  neben  dem  Eigenkapital  das  langfristige  Fremdkapital  dem Unternehmen ebenfalls über mehrere Jahre zur Verfügung steht, dieses im Gegensatz zu Ersterem aber eine  Fälligkeit  aufweist,  bietet  sich  zur  Bewertung  des  Finanzierungsgrads  eine  Aufteilung  in  zwei verwandte Kennzahlen an. Die Anlagendeckung I beschreibt die prozentuale Deckung des Anlagevermögens  durch  Eigenkapital.  Da  Unternehmen  zudem  noch  langfristiges  Fremdkapital  zur Verfügung  steht,  ist  ein  Zielwert  zwischen  70  und  90  %  ausreichend.  Durch  Hinzuziehen  des langfristigen Fremdkapitals ergibt sich die Anlagendeckung zweiten Grades. Ein Wert von über 100 % sagt aus, dass neben dem Anlagevermögen auch ein Teil des Umlaufvermögens langfristig finanziert ist.  Der  Zielwert  ist  im  Bereich  von  130  %  anzusiedeln.  Insbesondere  bei  zyklischen  oder  finanziell angeschlagenen Unternehmen ist diese Kennzahl wichtig. Eine Anlagendeckung II von unter 100 % birgt die latente Gefahr von Zahlungsschwierigkeiten bei der Begleichung von kurzfristigen Verbindlichkeiten.  In  Deutschland  war  die  Hypo  Real  Estate  eines  der  prominentesten  Opfer  der Nichtbeachtung  dieser  Kennzahl.  Langfristige  Kredite  wurden  kurzfristig  finanziert,  um  aus  dem Zinsunterschied Gewinn zu ziehen - die Folgen sind bekannt.

## Goodwill-Anteil

Sechs  Jahre  nachdem  Vodafone  die  Firma  Mannesmann  für  die  Rekordsumme  von  112  Mrd. £ übernommen  hatte,  vermeldete  der  britische  Mobilfunkanbieter  im  Jahr  2006  einen  Verlust  nach Steuern  in  Höhe  von  21,8  Mrd. £.  Was  war  passiert?  Das  britische  Unternehmen  hatte  den  Wert Mannesmanns  zu  hoch  angesetzt  und  sah  sich  angesichts  der  nicht  eintretenden  Erwartungen gezwungen, den in der Bilanz ausgewiesenen Wert entsprechend anzupassen. Eine GoodwillAbschreibung in Milliardenhöhe war die Folge. Zur Erinnerung: Goodwill oder Geschäfts- und Firmenwert  ist  der  Aufpreis,  den  der  Erwerber  auf  den  Buchwert  des  Zielunternehmens  bezahlt. Unternehmen müssen jährlich einen sogenannten 'Impairment-Test' des ausgewiesenen Goodwills in der  Bilanz  durchführen.  Dieser  Werthaltigkeitstest  überprüft,  ob  die  Höhe  des  Vermögenswertes Goodwill in der Bilanz gerechtfertigt ist. Sollte dies nicht der Fall sein, erfolgt eine außerplanmäßige Abschreibung, die den Gewinn entsprechend belastet. Eine jährliche, planmäßige Abschreibung des Goodwills  wird  nach  der  geltenden  internationalen  Rechnungslegung  nicht  durchgeführt.  Goodwill stellt eine Gefahr für die Bilanzrelationen dar, da viele Unternehmen den Wert übernommener Firmen häufig zu optimistisch angesetzt haben und mitunter deutliche Abschreibungen in den Folgejahren verbuchen mussten. Oft ist dies die direkte Folge von zu hohen Kaufpreisen bei Übernahmen, welche sich  in  im  Nachhinein  durchgeführten  Impairment-Tests  als  überteuert  herausstellen.  Dennoch  ist Goodwill nicht per se zu verteufeln, da einige Unternehmen ohne Zweifel mehr als ihr bilanzielles Eigenkapital wert sind. Ein hoher Goodwill-Anteil in der Bilanz birgt die Gefahr von außerplanmäßigen Abschreibungen, die das Eigenkapital mindern. Aus diesem Grund sollte der ausgewiesene Goodwill keinen signifikanten Anteil am Eigenkapital haben. Als Faustregel kann ein Maximalverhältnis von 30 % festgehalten werden. Selbst im Fall einer Abschreibung des Goodwills sind so in der Regel weiterhin solide Bilanzkennzahlen gewährleistet. Zwar sind Abschreibungen nicht liquiditätswirksam und ziehen somit keine Auszahlungen nach sich, jedoch ist diese Art von Abschreibungen immer direkte Folge einer Überbewertung der eigenen Vermögensgegenstände, was nie positiv zu bewerten ist. Der Goodwill sollte daher im Analyseprozess einer eigenen Werthaltigkeitsprüfung unterzogen werden. Stellt sich dieser als minderwertig heraus, ist eine entsprechende Verrechnung mit dem Eigenkapital notwendig. Der genauen Bereinigung und Aufbereitung der Bilanz ist am Ende von Kapitel 8 ein eigener Abschnitt gewidmet.

## Formelsammlung

## Kennzahlen zu Ertrag und Rentabilität

Eigenkapitalrendite in % =

Jahresüberschuss

Eigenkapital

∗ 100

Gesamtkapitalrendite in % =

Jahresüberschuss + Fremdkapitalzinsen

Bilanzsumme

∗ 100

Umsatzrendite in % =

Jahresüberschuss

Umsatzerlöse

∗ 100

EBIT(DA) - Marge in % =

EBIT(DA)

Umsatzerlöse

∗ 100

Umsatzverdienstrate =

operativer Cashflow

Umsatzerlöse

Kapitalumschlag =

Umsatz

Bilanzsumme

Return on Investment (RoI) =

Betriebsgewinn

Bilanzsumme

Return on Capital Employed (ROCE) =

EBIT

Capital Employed

## Kennzahlen zur finanziellen Stabilität

Eigenkapitalquote in % =

Eigenkapital

Bilanzsumme

∗ 100

Fremdkapitalquote in % =

Fremdkapital

Bilanzsumme

∗ 100

Verschuldungsgrad in % =

Fremdkapital

Eigenkapital

∗ 100

Dynamischer Verschuldungsgrad =

Finanzverbindlichkeiten - liquide Mittel

Free - Cashflow

Gearing =

Finanzverbindlichkeiten-liquide Mittel

Eigenkapital

Sachinvestitionsquote =

Sachinvestitionen

operativer Cashflow

Cash - Burn - Rate =

Eigenkapital

Jahresfehlbetrag

Wachstumsquote =

Investitionen in Sachanlagen

Abschreibungen

Anlageintensität =

Anlagevermögen

Bilanzsumme

𝑈𝑚𝑙𝑎𝑢𝑓𝑖𝑛𝑡𝑒𝑛𝑠𝑖𝑡ä𝑡 =

𝑈𝑚𝑙𝑎𝑢𝑓𝑣𝑒𝑟𝑚ö𝑔𝑒𝑛

𝐵𝑖𝑙𝑎𝑛𝑧𝑠𝑢𝑚𝑚𝑒

Anlagedeckungsgrad 1 =

Eigenkapital

Anlagevermögen

Anlagedeckungsgrad 2 =

Eigenkapital+langfristiges Fremdkapital

Anlagevermögen

## Working Capital-Management

liquide Mittel+Wertpapiere

Liquidität 1. Grades in % =

kurzfristige Verbindlichkeiten

∗ 100

Liquidität 2. Grades in % =

liquide Mittel+Wertpapiere+Forderungen

kurzfristige Verbindlichkeiten

∗ 100

Liquidität 3. Grades in % =

Umlaufvermögen

kurzfristige Verbindlichkeiten

∗ 100

Debitorenlaufzeit =

Ø Forderungen aus Lieferungen und Leistungen

Umsatzerlöse

∗ 360

Kreditorenlaufzeit =

Ø Verbindlichkeiten aus Lieferungen und Leistungen

Materialaufwand

∗ 360

➢ Debitorenlaufzeit &lt; Kreditorenlaufzeit