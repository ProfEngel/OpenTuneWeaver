## Liquiditätsplanung und Liquiditätssicherung

Quelle:  Deutsches  Institut  für  Interne  Revision  e.V.  (Hrsg.)  (2023):  Revision  des Finanzwesens. Prüfungsleitfaden für die Revisionspraxis., Ausschnitte aus Kapitel 4

## Cash Management:

## Definition und Zielsetzung:

Je nach Größe, Branche und Struktur des Unternehmens werden die Arbeitsbereiche und somit die Begrifflichkeiten Cash Management, Liquiditätsmanagement, Finanzmanagement und Treasury unterschiedlich abgegrenzt.

Dieser Prüfungsleitfaden folgt dem Aufbau von großen und mittleren Unternehmen folgendermaßen:

Dem Finanzvorstand bzw. Bereichsleiter Finanzen untersteht der Bereich Finanzen, welcher sich in die beiden Hauptabteilungen Treasury und Controlling untergliedert. Die Hauptabteilung Treasury umfasst u.a. die Abteilungen Cash Management und Finanzplanung. Dem Cash Management sind das Liquiditätsmanagement und der Zahlungsverkehr angeschlossen. In kleinen und mittelgroßen Unternehmen können Cash Management und Finanzplanung auch in einer Abteilung zusammengefasst sein.

Hieraus leiten sich folgende Definitionen ab:

- · Das Treasury plant und steuert die Finanzströme des Unternehmens. Dies geschieht einerseits durch die zukunftsorientierte Finanzplanung und anderseits durch den zielgerichteten Einsatz von Finanzmitteln und Finanzinstrumenten, um die Finanzplanung bestmöglich umzusetzen.
- · Die Finanzplanung plant zukunftsorientiert die finanziellen Ressourcen der Unternehmung. Dies geschieht in der Regel mittels einer Kurz-, Mittel- und Langfristplanung. Die Planung berücksichtigt die durch zukünftige Zahlungsströme ausgelöste Veränderung der in der Unternehmung vorhandenen Finanzmittel.
- · Das Cash Management setzt die Finanzplanung mit den vorhandenen finanziellen Ressourcen um. Hierunter fällt die Optimierung der liquiden Mittel. Diese soll einerseits sicherstellen, dass jederzeit ausreichend Liquidität zum Ausgleich von fälligen Verbindlichkeiten im Unternehmen vorhanden ist (Liquiditätsmanagement) und andererseits kurzfristig nicht benötigte Liquidität optimal nach den Grundsätzen der Unternehmung angelegt wird (z.B. zinstragend). Je nach Ausrichtung eines

und Zielen der Unternehmung kann Cash Management national, innerhalb Währungsraumes oder über Währungsgrenzen hinweg betrieben werden.

- · Das Liquiditätsmanagement befasst sich mit der aktiven Steuerung der liquiden Mittel (in der Regel mit einem kurzfristigen Horizont). Demgegenüber ist der Ansatz des Cash Managements weiter gefasst, denn es befasst sich mit der aktiven Steuerung aller Bereiche der Unternehmung,
- · Der Zahlungsverkehr gleicht nach den Grundsätzen der Unternehmung und den Vorgaben des Liquiditätsmanagements die aufgelaufenen Verbindlichkeiten der Unternehmung aus.

Cash Management ist somit die Gesamtheit aller Aktivitäten, die direkt oder indirekt auf eine zielorientierte Gestaltung der kurzfristigen Finanzierung eines Unternehmens ausgerichtet sind. Es umfasst die Planung, Disposition und Kontrolle von Liquidität im Unternehmen.

Das Hauptziel des Cash Managements ist die Gewinnmaximierung (insofern es sich nicht um ein Non-Profit-Unternehmen handelt). Dieses Hauptziel wird durch die drei Ziele Sicherheit, Rentabilität und Flexibilität getragen, die das Cash Management folgendermaßen umsetzt:

- · Sicherheit: Sicherstellung der permanenten Zahlungsfähigkeit des Unternehmens sowie Reduzierung von Zins- und Währungsrisiken
- · Rentabilität: Maximierung der Erträge (Anlage der Finanzmittel) und Minimierung der Kosten (Kassenhaltung, Zahlungsverkehr, gebundene Mittel)
- · Flexibilität: den Geschäftsbedürfnissen folgende Struktur und Auswahl der Anlage- und Finanzkontrakte

Daraus leiten sich insbesondere die folgenden Aufgaben ab:

- • Liquiditätsplanung
- • Disposition der Finanzmittel
- • Steuerung der Zahlungsströme
- • Effiziente Gestaltung der diesbezüglichen Bankenpolitik.

Die Aufgaben betreffen u.a. die Vermeidung von Liquiditätsengpässen, die Optimierung der kurzfristigen Geldanlage und Geldaufnahme sowie die zeitnahe Ermittlung aller für die Finanzdisposition benötigen Daten. Da diese Aufgaben sehr komplex sind, wird das Cash Management in der Praxis durch elektronische Systeme unterstützt.

## 4.2 Organisation des Cash Managements:

Die Organisation des Cash Managements sollte effektiv und effizient aufgesetzt sein.

- · Liegen  für  das  Cash  Management  schriftliche  Anweisungen  vor  (z.B.  Richtlinien, Arbeitsanweisungen, Arbeitsablauf- oder Stellenbeschreibungen)?
- · Wurden diese Anweisungen kompetenzgerecht genehmigt?
- · Sind diese Anweisungen den betroffenen Mitarbeiterinnen und Mitarbeitern bekannt gemacht worden und stehen sie ihm ständig zur Verfügung?
- · Liegt  die  aktuelle  Finanzplanung  im  Cash  Management  vor  (zumindest  die  für  das Cash Management relevanten Teile)?
- · Ist  geregelt,  ob  das  Cash  Management  national,  innerhalb  eines  Währungsraumes oder über Währungsgrenzen hinweg durchgeführt werden soll?

Je nach Ausrichtung kommen Aufgaben des Cash Managements hinzu oder fallen weg (wie z.B. die Währungsabsicherung oder die Festlegung einer funktionalen Konzernwährung).

- · Ist geregelt, ob bestimmte Geschäfte (wie z.B. die Einrichtung und Fortschreibung von Kreditlinien) einer Genehmigung durch bestimmte Gremien bedürfen (z.B. Aufsichtsrat oder Beirat)?
- · Ist geregelt, ob aufgrund der Ausrichtung des Unternehmens bestimmte Geschäftsformen bevorzugt oder nicht genutzt werden können?

Hierunter können politisch, religiös oder ethisch motivierte Einschränkungen fallen, wie z.B. Einschränkungen durch (a) Embargos, (b) aufgrund von Geschäftsbeziehungen in die USA,2) (c) Zahlungsverkehrskontrollen in Indien3) oder Venezuela, (d) Geschäftsbeziehungen mit islamischen Partnern4) oder (e) beispielsweise dem Grundsatz, nicht in Agrarprodukte zu investieren.

Darüber hinaus kann es sein, dass als besonders nachhaltig angesehene Produkte zu bevorzugen sind.

- · Informiert die Richtlinie über alle zum Cash Management wesentlichen Sachverhalte? Beispielsweise:
- · Kreis der teilnehmenden Gesellschaften/Niederlassungen
- · Verfahren bei der Einbeziehung von Gesellschaften mit Anteilen Dritter
- · Zuständigkeiten
- · Verfahren der Einrichtung/Fortschreibung von Kreditlinien für teilnehmende Gesellschaften
- · Organisation für Disposition und Anlage-/Aufnahmeentscheidungen
- · Verfahren zur Führung von Fremdwährungskonten (zentral/dezentral)
- · Verfahren der Zinsberechnung
- · Berichterstattung
- · Handhabung von Zins- und Wechselkursrisiken

•

Bei Unternehmensgruppen bzw. Konzernen können zusätzlich die folgenden Punkte berücksichtigt werden:

- · Liegen  mit  den  in  das  Cash  Management  eingebundenen  Konzerngesellschaften schriftliche Vereinbarungen über die Art der Abwicklung vor und sind diese aktuell?
- · Hat das Cash Management einen ausreichenden und zeitnahen Überblick über die dezentralen Finanztransaktionen in den Konzerngesellschaften?
- · Kennt  das  Cash  Management  die  in  den  Konzerngesellschaften  vorgehaltenen Finanzmittel (z.B. sind alle lokalen Konten bekannt)?

## 4.3 Liquiditätsplanung und Disposition der Finanzmittel:

## 4.3.1 Liquiditätsplanung:

Die Liquiditätsplanung (kurzfristige Finanzplanung) ist die Grundlage des Cash Managements. Sie soll zukünftige Ein- und Auszahlungen prognostizieren und somit die zukünftige Liquiditätsentwicklung abbilden (planen). Dadurch soll erkannt werden, ob bzw. wann ein zukünftiger Liquiditätsengpass auftreten kann.

- · Besteht eine hinreichend klare Zieldefinition der angestrebten Ober- und Untergrenzen der Liquiditätsplanung? Erfolgt die Liquiditätsplanung für die unmittelbare Zukunft auf Tagesbasis?
- · Ausgangspunkt der Liquiditätsplanung ist der finale Kontostand des Vortages. Dies gilt in  der  Regel  auch,  wenn  alle  oder  einige  Konten  der  Gesellschaft  über  eine Onlineanbindung (Electronic Banking) verfügen. Wichtig ist, dass die Planungsbasis transparent ist, was durch eine einheitliche Grundlage unterstützt wird (Kontostand des Vortages).
- · Wird die Liquiditätsplanung nach Valuta- oder Buchungsdaten durchgeführt?
- · Wird der valutarische Saldo sachlich richtig ermittelt (maschinell oder manuell)?

In Deutschland wird zwischen Buchungsdatum und Valutadatum unterschieden. Im Ausland ist dies nicht unbedingt der Fall. Es können dort beide Daten identisch sein. Das Buchungsdatum  zeigt  an,  wann  die  Bank  gebucht  hat.  Das  Valutadatum  ist  für  die Zinsberechnung relevant. Eine genaue Liquiditätsplanung nutzt das Valutadatum (Wertstellungsdatum).

- · Werden ausländische Konten mit in die Planung einbezogen?
- · Erfolgt eine rollierende Planung?

Geplant werden kann auf Tages-/Wochen-/Monatsbasis (Zahlungsmittelanfangsbestand

- + Planeinzahlungen - Planauszahlungen = Zahlungsmittelendbestand).

Da hierbei die Perioden nicht miteinander verknüpft werden, sind  die  Kennzahlen  jeweils  neu  zu  ermitteln.  Die  Ausgangsbasis  der  Planungsperiode  ist hierbei naturgemäß immer aktuell.

Geplant werden kann auch gleitend (rollierend). Hierbei wird der Zahlungsmittelendbestand der Periode als Zahlungsmittelanfangsbestand der nächsten Periode eingesetzt. Es besteht das Risiko, dass sich die Ausgangsbasis der Planperiode von der Realität signifikant entfernt, da der Zahlungsmittelanfangsbestand nicht neu ermittelt, sondern aus dem Planergebnis

der Vorperiode übernommen und nicht korrigiert wird. Plan-Ist-

Vergleiche sind bei dieser Methode also unerlässlich.

## 4.3.2 Disposition der liquiden Finanzmittel:

Bei der Disposition der liquiden Finanzmittel handelt es sich um einen Kernbereich des Cash Managements. Die Disposition nimmt aufgrund der bekannten Kontenstände und der gemeldeten Zahlungsein- und -ausgänge Entscheidungen über die Anlage und Aufnahme von Finanzmitteln innerhalb zuvor definierter Grenzen (Limite) vor. Ziel ist dabei, stets alle fälligen Zahlungen termingerecht leisten zu können und den valutarischen Saldo auf den Kontokorrentkonten der Banken so gering wie möglich zu halten (i.d.R. keine Guthabenverzinsung). Die Disposition steuert den Zahlungsverkehr somit in erster Linie auf Tagesbasis.

Klassische Instrumente im Umfeld der Disposition sind:

- • Cash Pooling (vgl. Abschnitt 4.4)
- • Clearing im Konzern (vgl. Abschnitt 4.5)
- • Leading und Lagging (vgl. Abschnitt 4.3.3)
- · Verfügt die Disponentin oder der Disponent über aktuelle Daten aus der Liquiditätsplanung (tag- und betragsgenau)?
- · Erhält die Disponentin oder der Disponent aktuelle Informationen über die Kontenstände bei den Geschäftsbanken (beispielsweise per Onlineanbindung)?
- · Eine  Onlineanbindung  (Electronic  Banking)  erleichtert  es,  zeitnah  Informationen darüber zu erhalten, ob sich wesentliche geplante Zahlungsströme im Laufe des Tages realisiert haben.
- · Erhält die Disponentin oder der Disponent rechtzeitig Informationen über liquiditätswirksame Zahlungsströme (z.B. Ausfall einer wesentlichen Einzahlung) oder anderen  sich  auf  die  Liquidität  auswirkenden  Ereignissen  (z.B.  Reduzierung  von Kreditlinien)?
- · Werden wesentliche Zahlungen auf den Bankkonten valutagleich bei der Disposition berücksichtigt?
- · Bestehen unternehmensintern feste Zahlungstermine und sind Zahlungswege vorgegeben, um die Disposition zu vereinfachen?
- · Wird die Liquiditätsplanung mit den Ist-Umsätzen auf den Bankkonten abgestimmt, um Doppelerfassungen bei der Disposition zu vermeiden?
- · Werden Zahlungsströme in Fremdwährungen gesondert erfasst?
- · Werden ausländische Bankkonten mit in die Disposition einbezogen?
- · Wird der Geldmittelüberschuss bzw. -bedarf auch währungsübergreifend disponiert?

## 4.3.3 Leading and Lagging:

Das  sogenannte  Leading  and  Lagging  ist  ein  Instrument  der  Disposition  der  liquiden Finanzmittel im Konzernverbund. Eine zentrale Finanzabteilung hat die Führungsrolle inne und weist die Konzernunternehmen an, die aus dem konzerninternen Lieferungsund Leistungsverkehr resultierenden Zahlungsverpflichtungen entweder vorzeitig (Leading) oder verspätet (Lagging) in Bezug auf den ursprünglich vereinbarten Zahlungstermin auszugleichen.

Ziel dieser Technik ist es, die überschüssige Liquidität eines Konzernunternehmens zu nutzen, um  den  Liquiditätsbedarf  eines  anderen  Konzernunternehmens  kurzfristig  zu  finanzieren. Diese Technik zeigt, dass das Cash Management einen wesentlichen Beitrag zur kurzfristigen Konzernfinanzierung leisten kann.

Diese  Technik  sei  beispielhaft  folgendermaßen  dargestellt:  Konzernunternehmen  A  hat gegenüber  Konzernunternehmen  B  eine  Verbindlichkeit  in  Höhe  von  800  TEUR,  die  am 31.07.xx fällig ist. Das Konzernunternehmen A hat eine Forderung an einen Kunden in Höhe von 900 TEUR, welche am 15.08.xx fällig ist. Im Gegensatz zu Konzernunternehmen B verfügt Konzernunternehmen  A  nur  über  wenig  liquide  Mittel  (z.B.  200  TEUR).  Die  zentrale Finanzabteilung des Konzerns weist nun an, dass die Verbindlichkeit von A an B (800 TEUR) erst  nach  Eingang  der  Kundenforderung  (900  TEUR)  auszugleichen  ist  (Lagging).  Dies verhindert,  dass  Konzernunternehmen  A  seinen  Dispokredit  in  Anspruch  nehmen  muss. Insofern  es  sich  bei  beiden  Zahlungsströmen um  Fremdwährung handelt, verhindert diese Anweisung auch, dass Wechselkurse von zwei unterschiedlichen Tagen zum Tragen kommen (Minimierung des Währungsrisikos sowie der zugehörigen Transaktionskosten).

- · Besteht eine angemessen klare Zieldefinition, ob und in welchem Umfang Zahlungen verschoben werden dürfen?
- · Wurde der zentralen Finanzabteilung ein ausreichendes Durchgriffrecht eingeräumt, um Maßnahmen zum Vorziehen oder Verzögern von Zahlungen anzuordnen?
- · Hat die zentrale Finanzabteilung einen aktuellen Überblick über die Liquiditätsplanungen der einzelnen Konzerngesellschaften, um fundiert entscheiden zu können, ob Maßnahmen zum Vorziehen oder Verzögern von Zahlungen notwendig sind?
- · Ist  ausreichend  geregelt,  wie  innerhalb  des  Konzerns  mit  überfälligen  Zahlungen umgegangen wird, die auf Maßnahmen (Anweisungen) der zentralen Finanzabteilung beruhen?

Dies betrifft z.B. das Mahnwesen und ggf. die Berechnung von Verzugszinsen.

## 4.4 Cash Pooling:

Insofern das Unternehmen eine größere Anzahl von Bankkonten unterhält, erleichtert bzw. automatisiert das Cash Pooling (zentralisiertes Kassenwesen) die Disposition der Finanzmittel auf diesen Konten. Ziel des Cash Poolings ist es, Finanzmittel so auf die Konten zu verteilen, dass ein optimales Zins- und Liquiditätsergebnis erreicht wird. Das bedeutet beispielsweise die Vermeidung von Sollsalden und die Konzentration der Liquidität auf einem Hauptkonto oder dem Konto mit den höchsten Habenzinsen. Cash Pooling kann manuell oder automatisiert betrieben werden. Der Cash Pool kann Konten bezogen auf eine oder mehrere Währungen umfassen.

im Inland und Ausland eines einzigen Unternehmens oder einer Unternehmensgruppe Das Wesen des Cash Poolings ist, dass Überschuss- oder Überziehungsbeträge auf den Einzelkonten über ein Bankkonto (Hauptkonto, Konzentrationskonto) des Cash-Pool-Führers automatisch übertragen bzw. ausgeglichen werden. Dieser wird damit faktisch Bank der am Cash Pooling beteiligten Unternehmen. Auf dem Konzentrationskonto befindet sich der Netto-Liquiditätssaldo des Unternehmens oder der Unternehmensgruppe. Mit diesem kann dann gezielt nach günstigeren Marktkonditionen gesucht werden. Das Cash Pooling kann sowohl durch die Holding, ein Konzernunternehmen oder durch eine Bank als Dienstleister durchgeführt werden.

Das Cash Pooling System kann einstufig oder mehrstufig aufgebaut sein. Beim einstufigen System sind alle Poolkonten direkt mit dem Hauptkonto verbunden. Beim mehrstufigen System gibt es eine oder mehrere Zwischenstufen. Beispielsweise werden alle brasilianischen Poolkonten in einem ersten Schritt in Brasilien auf ein brasilianisches Hauptkonto gepoolt. Gleiches gilt für die nationalen Konten in Kanada und Island. In einem zweiten Schritt werden diese ausländischen Hauptkonten dann auf ein deutsches Zentralkonto gepoolt. Dies verringert z.B. die Kosten für den internationalen Geldtransfer. Bei einer rein inländischen Unternehmensgruppe kann sich das mehrstufige Verfahren an der Unternehmensstruktur ausrichten. Dies bedeutet, dass zunächst mit einem Hauptkonto auf der Ebene des jeweiligen Tochterunternehmens gepoolt wird und dann von diesen Hauptkonten auf ein Zentralkonto der Konzernmutter gepoolt wird.

Die folgenden Cash-Pool-Verfahren sind in der Praxis üblicherweise anzutreffen:

- · Zero Balancing: Am Ende des Tages wird der positive (bzw. negative) Saldo des Poolkontos durch einen Geldtransfer vom Pool- auf das Hauptkonto (bzw. vice versa) ausgeglichen. Die gesamte Netto-Liquidität befindet sich auf dem Hauptkonto. Sämtliche Poolkonten weisen einen Nullsaldo auf.
- · Target Balancing: Entspricht dem Zero-Balancing-Verfahren mit dem Unterschied, dass für das betroffene Poolkonto nicht auf einen Nullsaldo hin gepoolt wird. Es ist ein vereinbarter Zielsaldo zu erreichen, der nicht unterschritten werden darf.

In beiden Verfahren kann zusätzlich vereinbart werden, dass Überträge erst ab einem bestimmten Mindestwert übertragen werden, um (z.B. maschinell erzeugte) physische Kleinstüberträge zu vermeiden.

- · Notional Pooling: Entspricht dem Zero-Balancing-Verfahren mit dem Unterschied, dass kein Geldtransfer vorgenommen wird. Stattdessen erfolgt eine rechnerische Zusammenfassung, verbunden mit einer Zinsabrechnung für die Unternehmensgruppe. Es handelt sich um fiktives Cash Pooling und dient zur Abrechnung der (saldierten) Zinsen innerhalb einer Gruppe.
- · Settlement Pooling: Es wird ein Settlement-Korridor festgelegt (bestehend aus einem Mindest- und Maximalbetrag/Untergrenze und Obergrenze). Solange sich der Saldo des Poolkontos innerhalb des Korridors befindet, passiert nichts. Sobald der Saldo die Obergrenze überschreitet, wird der Überschuss vom Pool- auf das Hauptkonto übertragen.

Beim Unterschreiten erfolgt ein Ausgleich vom Hauptkonto auf das Poolkonto.

Diese Mechanik kann um eine Settlement-Uhrzeit ergänzt werden. In diesem Fall löst das Touchieren der Grenzen nur dann eine Überweisung aus, wenn es zur definierten Uhrzeit oder in einem definierten Zeitfenster passiert.

Ohne die Mitwirkung eines Kreditinstitutes lässt sich ein automatisiertes Cash Pooling nicht verwirklichen. Nicht jedes Kreditinstitut ist aufgrund seiner Geschäfts- und Gebührenstruktur als Cash Pooling Partner geeignet. Manchmal wird zwischen Cash Pooling und Cash Concentration unterschieden. Hierbei wird Cash Pooling dann damit charakterisiert, dass es keine Geldbewegung von einem Bankkonto auf ein anderes gibt, sondern das Kreditinstitut lediglich eine Nebenrechnung führt. Demgegenüber wird Cash Concentration damit beschrieben, dass Liquidität von einem Bankkonto auf ein anderes umgebucht wird. Diese Abgrenzung ist in diesem Prüfungsleitfaden bereits über die Abgrenzung zwischen Zero Balancing und Notional Pooling abgedeckt und wird daher nicht weiterverfolgt. Unterschiedliche englische Begriffe sind unterschiedlichen Firmenkulturen zuzuschreiben und sind von untergeordneter Bedeutung, wenn sie sachlich auf den gleichen Vorgang abzielen.

- · Liegen schriftliche Vereinbarungen mit Banken zum Cash Pooling vor?
- · Entsprechen die Unterschriftsvollmachten dem aktuellen Stand?
- · Werden die zum Cash Pooling erlassenen Regelungen eingehalten?
- · Wird die Wirtschaftlichkeit des Cash Pooling in gewissen Zeitabständen beispielsweise vor dem Hintergrund der Zinsvorteile, der Liquiditätsvorhaltung, des Verwaltungsaufwands und der Transaktionskosten untersucht?
- · Wie wird sichergestellt, dass zweckgebundene Mittel (z.B. Bargründungen, Subventionen) nicht in den allgemeinen Cash Pool einfließen?
- · Ist  die  automatische  und  taggleiche  Zusammenführung  mehrerer  Konten  bei  einer Geschäftsbank geregelt?
- · Bestehen Vereinbarungen mit den Banken, dass ungeplant auf den Konten verbleibende Salden über Nacht günstig verzinst werden (automatische Anlage/Sweep Accounts)?
- · Werden im Rahmen des Cash Pooling die Transferrestriktionen und die rechtlichen Vorschriften (z.B. Meldepflichten) der jeweiligen Länder eingehalten?

Bei Unternehmensgruppen  bzw.  Konzernen  können  zusätzlich  die folgenden Punkte berücksichtigt werden:

- · Wer führt das Cash Pooling im Konzern durch?
- · Wie und durch wen erfolgt die Gesamtkoordination der Cash-PoolingSysteme?

Denkbar sind Verfahren wie z.B. zentral durch die Holding oder durch den Cash-Pool-Führer in verschiedenen Ländern (ggf. währungsabhängig).

- · Sind Kriterien zur Teilnahme der Konzerngesellschaften am Cash Pooling festgelegt und werden diese ausreichend auf Einhaltung kontrolliert? Solche Kriterien können z.B. sein:
- · Geschäftsbereichszugehörigkeit
- · Land
- · Unternehmensgröße
- · Beteiligungsverhältnis
- · Einheitlicher Währungsbereich (z.B. Euro)

Liegen erforderliche Einverständniserklärungen und Verträge zwischen Konzerngesellschaften und Cash-Pool-Führer vor? Welche Vereinbarungen wurden mit Joint-Venture-Partnern geschlossen, um eine wirtschaftliche Benachteiligung auszuschließen? Welche Gründe liegen vor, dass Konzerngesellschaften eigene Bankverbindungen unterhalten, die nicht im Cash Pool erfasst werden und sind diese vertretbar? Sind  die  Verfahren  zur  Festlegung  der  Zinssätze  der  Mittelaufnahme  und  -anlage  für  die Konzerngesellschaften eindeutig und nachvollziehbar bestimmt? Erfolgt regelmäßig eine Saldenabstimmung der durch das Cash Pooling aufgelaufenen Forderungen und Verbindlichkeiten zwischen den beteiligten Gesellschaften? Erfolgt eine Bewertung des Ausfallrisikos durch den Netto-Gläubiger von durch das Cash Pooling aufgelaufenen Salden? Fließt das Ergebnis in das Risikomanagement der betroffenen Gesellschaft ein? Vulkan AG in 1996 ist bekannt, dass (vor dem Cash-Pool-Übertrag vorhandene)

Durch Teilnahme am Cash Pooling verschiebt sich die Liquidität auf den Konten zwischen den beteiligten Gesellschaften. Die Bonität der beteiligten Gesellschaften (und insbesondere der Konzernmutter) verändert sich hierdurch jedoch nicht. Spätestens seit dem Zusammenbruch der Bremer sichere Liquidität extrem ausfallgefährdet sein kann (bis hin zum Totalverlust).

## 4.5 Clearing im Konzern:

Für das Clearing im Konzern werden in der Regel die beiden Instrumente Matching und Netting herangezogen. Beide Instrumente dienen der Verringerung von konzerninternen Zahlungsströmen. Sie rechnen Forderungen und Verbindlichkeiten zwischen Konzerngesellschaften zu festgelegten Zeitpunkten gegeneinander auf. Transferiert wird dann lediglich der verbleibende Netto-Saldo. Durch die hierdurch vermiedene Ausführung von vielen Einzel-

überweisungen lassen sich die Transaktionskosten senken (insbesondere beim länder- und währungsübergreifenden Zahlungsverkehr). Allerdings entsteht ein gewisser Abstimmungsaufwand zwischen den Konzerngesellschaften. Entsprechend dem wirtschaftlichen Bedürfnis der Unternehmensgruppe sind in der Praxis folgende Ausprägungen anzutreffen:

- · Matching passt die Struktur von Währungen und Fristen neuer interner Forderungen und Verbindlichkeiten möglichst genau an die bereits bestehenden Strukturen mit dem Ziel an, dass nach der gegenseitigen Aufrechnung entgegengesetzter Positionen kein Saldo mehr verbleibt. Es lässt sich daher nur bei sehr wenigen internen Zahlungsströmen

einsetzen.

- · Bilaterales Netting wird zwischen zwei Gesellschaften ausgeführt. Es rechnet Forderungen und Verbindlichkeiten zu einem festgesetzten Stichtag gegeneinander auf. Es kommt beispielsweise in einer Unternehmensgruppe zur Anwendung, wenn keine weiteren Querverbindungen im Konzern bestehen (z.B. zwischen Holding und Tochtergesellschaft).
- · Multilaterales Netting berücksichtigt sämtliche Querverbindungen. Es ermöglicht, alle Verrechnungen im Konzern durchzuführen (Lieferungen zwischen Konzerngesellschaften, Gewinnausschüttungen etc.).
- · Multiples Netting bezieht ausgewählte konzernexterne Unternehmen mit dem Ziel ein, weitere Kostenvorteile durch Netting zu realisieren. Als Sonderform ist denkbar, dass nicht nur einzelne Unternehmen einbezogen werden, sondern auch Konzerne miteinander aufrechnen.
- · Netting mit Vorpooling-Kreisen fügt den vorgenannten Nettingmethoden Vorpooling-Kreise hinzu (z.B. nach Sparten, Ländern oder Teilkonzernen). Vorpooling kann jedoch den Verwaltungsaufwand erhöhen

und zu nicht zeitgerechter Aufrechnung führen.

Abbildung 3 zeigt, wie durch Netting Überweisungsvolumen und zugehörige Transaktionen reduziert werden können.

Im Beispiel sinkt das Überweisungsvolumen von 647 mit zugehörigen 12

Transaktionen (zur Zahlung anstehende Positionen) über ein Volumen von 303 mit zugehörigen 6 Transaktionen (bilaterales Netting) auf ein Volumen von 245 mit 3 zugehörigen Transaktionen (multilaterales Netting). Im letztgenannten Fall kommt hinzu, dass die Einheiten B und D keine Überweisung auszuführen brauchen. Dies kann vorteilhaft sein, wenn hier politisch motivierte Transaktionsbeschränkungen oder unwirtschaftlich hohe Transaktionskosten vorliegen sollten. Vor dem Hintergrund des notwendigen Abstimmaufwandes und der (z.B. steuerlich) notwendigen Dokumentationen dürfte in der Praxis das bilaterale Netting deutlich häufiger vorkommen als das multilaterale Netting, denn bei letzterem lässt sich die Verbindung zwischen ausgeführter Überweisung und Überweisungsgrundlage nicht ohne weiteres erkennen (bzw. herstellen). schen ausgeführter Überweisung und Überweisungsgrundlage nicht ohne weiteres erkennen (bzw. herstellen). Die Zahlung von Nettobeträgen kann auch ganz entfallen, wenn die Unternehmensgruppe über eine zentrale Finanzabteilung verfügt (z.B. in der Holding oder beim Cash-Pool-Führer). In diesem Fall kann diese zentrale Abteilung als Clearing Stelle fungieren. Die Abwicklung der Zahlungsströme erfolgt dann auf Kontokorrentbasis über (verzinsliche) Konzernverrechnungskonten (Konzernfinanzkonten). Die Zinssätze werden in diesem Fall in der Regel einheitlich für alle angeschlossenen Unternehmen getrennt nach Guthabenzins und Sollzins festgelegt. Sind die gewählten Clearing-Verfahren (Matching, bilaterales, multilaterales oder multiples Netting, mit oder ohne Vorpooling-Kreise) angemessen und hinsichtlich der vorhandenen Liefer- und Leistungsstrukturen geeignet? Sind Kriterien festgelegt, die die Teilnahme der Konzerngesellschaften

am Clearing regeln und wird die Einhaltung der Kriterien kontrolliert?

Solche Kriterien können z.B. sein:

- · Geschäftsbereichszugehörigkeit
- · Land
- · Unternehmensgröße
- · Beteiligungsverhältnis
- · Einheitlicher Währungsbereich (z.B. Euro)

Wer führt das Clearing im Konzern durch und ist die gewählte Organisationsform zweckmäßig?

Denkbar sind Verfahren wie z.B. zentral durch die Holding oder durch den

Cash-Pool-Führer in verschiedenen Ländern (ggf. währungsabhängig).

Bestehen eindeutige Regelungen, wer Auftraggeber eines Konzernverrechnungsauftrages ist (zahlungspflichtige Gesellschaft oder Belastung z.B. von Konzernumlagen durch Konzernführungsgesellschaft)?

Werden sämtliche Arten von Forderungen und Verbindlichkeiten (aus

Lieferungen und Leistungen, Zins- und Tilgungszahlungen, Gewinnausschüttungen

- u. Ä.) in das Konzern-Clearing einbezogen und werden diese

vollständig, zeitnah und wertstellungsgerecht erfasst?

Wird ein einheitliches Meldeverfahren (Formulare, Erfassungsmasken)

## verwendet?

Werden regelmäßig Saldenabstimmungen zwischen den beteiligten Unternehmen vorgenommen (z.B. durch das Einholen von Saldenbestätigungen)? Existiert eine Regelung für den Umgang mit strittigen Forderungen/ Verbindlichkeiten im Clearing?

Ist sichergestellt, dass anerkannte Verbindlichkeiten zeitnah ausgeglichen werden?

Eine stärkere Konzerngesellschaft kann geneigt sein, ihre Position auszunutzen, indem sie ihre Verbindlichkeiten gegenüber schwächeren Konzerngesellschaften zwar im Abstimmungsverfahren anerkennt, dann aber nicht oder nicht zeitnah begleicht. Wenn es hier keinen funktionierenden Kontrolloder Sanktionsmechanismus gibt, dann kann dies dazu führen, dass die schwächere Konzerngesellschaft durch den Konzern selbst in die Illiquidität getrieben wird, ohne dass dies wirtschaftlich begründet wäre. Die fundierte Analyse solcher Fälle und die Berichterstattung durch die Interne

Revision kann zu einer Verbesserung der Ausgleichsmoral innerhalb des Konzerns führen.

Erhalten die im Konzernfinanzverkehr einbezogenen Gesellschaften einen täglichen Kontenauszug (falls Vorgänge zur Buchung kommen), ergänzt um Informationen zu den jeweiligen Buchungsvorgängen?

Werden Zinsabrechnungen der konzerninternen Konten erstellt und werden die Zinsen korrekt ermittelt?

Wird bei der Durchführung des Clearings je Währung ein getrenntes Konto geführt?

Gibt es ausreichende, dokumentierte Regelungen zur Anwendung von Umrechnungskursen?

Werden im Rahmen des Clearings die Transferrestriktionen und die rechtlichen

Vorschriften der jeweiligen Länder eingehalten? Einige Länder verlangen zum Einsatz eines Netting-Systems Behörden- oder

Zentralbankgenehmigungen. Darüber hinaus sind der Grad der Konvertibilität einer Währung und die Zahlungskonditionen zu berücksichtigen. Ist eine missbräuchliche Nutzung der Konzernverrechnungskonten ausgeschlossen? Langfristige konzerninterne Kapitalzuführungen (Kapitalerhöhungen, Gesellschafterdarlehen) bedürfen einer ausdrücklichen Zustimmung durch

Gremien.

Ist

sichergestellt,

dass

Gesellschaften

ihren

eventuell

auftretenden

Rückzahlungsverpflichtungen

nachkommen?

Bei Einbeziehung von Beteiligungsgesellschaften sollten die Mitgesellschafter daher offene Beträge anteilig garantieren.

## 4.6 Kreditoren- und Debitorenmanagement:

In Abhängigkeit von Struktur und Größe des Unternehmens können auch Teile des Kreditoren- und Debitorenmanagements im Bereich des Cash Managements angesiedelt sein. Die Aufgabe des Cash Managements ist in diesem Fall, die Zahlungsströme zu optimieren, d.h. die Zahlungsfristen für Debitoren möglichst kurz zu halten und Rechnungen von Kreditoren möglichst spät zu zahlen. Weiterhin gehört das Ausnutzen von Skonti in dieses Feld. Dies geschieht mit dem Ziel, unter Beachtung von Zahlungsfristen und Skonti die unternehmensinterne Liquidität zu erhöhen.

Zur Erreichung dieses Zieles können folgende Maßnahmen herangezogen werden:

- · Im Kreditorenmanagement : Ausnutzung von Skonti, Nutzung des Eingangsdatums der Rechnung als Berechnungsbasis für die Zahlungsfrist (Eliminierung von rückdatierten Rechnungen), Festlegung eines standardisierten Zahlungslaufes (z.B. einmal wöchentlich zur Reduzierung des Verwaltungsaufwandes und der Erleichterung der Disposition), Nutzung von Scheckzahlungen (Liquidität wird aufgrund des Postlaufes und des Einlösungsverfahrens länger im Unternehmen gehalten/je nach Gebührenordnung können im Auslandszahlungsverkehr Kosten gesenkt werden), Einrichtung von Auslandskonten (außerhalb des SEPA-Raumes), Einleitung von rechtlichen Schritten (z.B. Abgabe an die Rechtsabteilung zur Klageerhebung wegen unberechtigter Abbuchung vom Firmenkonto)
- · Im Debitorenmanagement : Überwachung des Zahlungseinganges,

Festlegung von Zahlungsfristen, Festlegung der akzeptierten Zahlungsarten (z.B. Lastschrift, Überweisung, Scheck, Kreditkarte, Paypal, Bitcoin), Einleitung von rechtlichen Schritten (z.B. Abgabe an die Rechtsabteilung zur Überführung der Forderung in ein Inkassobüro oder zur Klageerhebung). Da die Einbindung des Cash Managements in das Kreditoren- und Debitorenmanagement in der Praxis sehr unterschiedlich ausgeprägt ist und in der Regel mehrere Abteilungen hierin eingebunden sind, wird dieses Thema im Rahmen dieses Abschnittes nur als Exkurs aufgeführt und nicht weiter vertieft. Eine Vertiefung dieses Themas bietet der Band 'Revision des Externen Rechnungswesens'.6) Hinsichtlich möglicher Prüfungsfragen wird zudem auf den Abschnitt zum Zahlungsverkehr verwiesen, welcher die vorangehend aufgeführten Zahlungswege ebenfalls abdeckt.

## 4.7 Anlage flüssiger Mittel:

In Abhängigkeit von Struktur und Größe des Unternehmens können auch Entscheidungsstrukturen zur Anlage flüssiger Mittel im Bereich des Cash Managements angesiedelt sein. Das Cash Management betrachtet hierbei jedoch einen eher kurz-/mittelfristigen Anlagezeithorizont. Alternativ kann die Entscheidungshoheit über Finanzmittelanlagen beispielsweise im Asset Management oder in der Finanzierungsabteilung angesiedelt sein. Verfügbare flüssige Mittel können (sofern kurzfristig nicht benötigt) mittel- und langfristig in Aktien, festverzinsliche Wertpapiere, Fonds etc. angelegt werden. Damit wären sie Bestandteil der Liquiditätsreserve.

Da die mittel-/langfristige Anlage flüssiger Mittel grundsätzlich kein originäres Thema des Cash Managements ist und in der Regel mehrere Abteilungen hierin eingebunden sind, wird dieses Thema im Rahmen dieses Prüfungsleitfadens nur als Exkurs aufgeführt und nicht weiter vertieft.

Existiert eine strategische Zielsetzung hinsichtlich Volumen, Fristigkeit und Struktur der Anlagen? Gibt es eine definierte Zuordnung von Aktivaund Passivaklassen hinsichtlich der Fristigkeit der Finanzanlagen und von Mittelaufnahmen?

Es ist eine Entscheidung der Unternehmensleitung, verfügbare Mittel aus übergeordneten unternehmerischen Gesichtspunkten oder zur Erzielung einer höheren Rentabilität anzulegen.

Ist die Anlage flüssiger Mittel in der Finanzrichtlinie geregelt? War die genehmigende Instanz hierzu legitimiert?

Ist ein maximaler Betrag vorgegeben, bis zu dem ein Erwerb je Abschluss und im Hinblick auf den Anteil am Portfolio zulässig ist?

Wurde vor der Genehmigung kontrolliert, ob bei Erwerb dieser Anlagen die  strategischen  Zielsetzungen  erfüllt  waren?    Sind  die  Anlagen  jederzeit  veräußerbar? Welche Restlaufzeiten haben die festverzinslichen Wertpapiere und ist damit ein erhöhtes Marktrisiko verbunden? Welchen Einfluss auf den Marktwert der Anlagen haben Zinserhöhungen? Wird durch eine potenzielle Marktwertänderung die Liquiditätsreserve bei u.U. notwendigem vorzeitigem Verkauf der Anlagen maßgeblich beeinträchtigt? Wird mit einem Stop Loss zur Vermeidung von Verlusten bei Kursänderungen

## agiert?

Wird die erwirtschaftete Rendite der mittel- und langfristigen Anlagen mit der Zielrendite am Kapitalmarkt verglichen? Wird die gewünschte Zusatzrendite erwirtschaftet? Gibt es hierzu eine Benchmark und wer legt diese fest?

Wird bei Anlagen in Fremdwährungen das Währungsrisiko aktiv gemanagt?

Ist die Risikoposition im Zusammenhang mit Zinspapieren definiert? Wurde die Anlage der verfügbaren flüssigen Mittel an externe Berater bzw. Banken vergeben, die - nach den Vorgaben des Unternehmens und dem gewünschten Risikoprofil - Fonds auflegen? Wurden bei Anlagen in Fonds, die von Vermögensverwaltern gemanagt werden, Ausschreibungen unter Wettbewerb vorgenommen?

Berücksichtigt die Vergütung der Vermögensverwalter eine leistungsabhängige Komponente?

Wird die erzielte Rendite gegenüber der Benchmark überwacht und werden bei negativen Abweichungen die Anlagen umgeschichtet?

Wird regelmäßig über angefallene Fonds-Verluste und -Gewinne sowie über die Stop-Loss-Aufträge berichtet?

Werden die Performance regelmäßig überwacht und die notwendigen Konsequenzen durch Umschichtung der Anlagen gezogen? Welche Konsequenzen hat die Under-Performance für den Vermögensverwalter?

Quelle:  Günther  Gebhardt,  Helmut  Mansch  (2019):  Management  und  Abbildung  von Liquidität und Liquiditätsrisiken, Kapitel 2, 3 und 4

## 2.1 Liquiditätsbegriffe:

Der Begriff termingerecht Liquidität wird in unterschiedlichen Kontexten mit unterschiedlichen Bedeutungen verwendet.1 In Bezug auf Personen bezeichnet Liquidität die Fähigkeit von natürlichen oder juristischen Personen als Schuldner, fällige Zahlungsverpflichtungen und vollständig erfüllen zu können. Zur Begleichung von Zahlungsverpflichtungen werden bei Fälligkeit Vermögenswerte benötigt, die von den Gläubigern akzeptiert werden. Lauten die Forderungen des Gläubigers auf Geldbeträge in bestimmten Währungen, so können diese durch Bereitstellung der erforderlichen Valutabeträge erfüllt werden. Soweit es sich um gesetzliche Zahlungsmittel handelt, müssen Gläubiger diese als Erfüllung akzeptieren. Verfügen Schuldner nicht über die benötigten Geldbeträge, wohl aber über andere Vermögenswerte, können diese zur Generierung von Geld genutzt werden. In diesem Kontext spricht man von der Liquidität (besser: Liquidisierbarkeit) von Vermögenswerten insbesondere durch Veräußerung an Dritte. Dies gelingt besonders leicht und schnell, wenn Vermögenswerte an Märkten aktiv gehandelt werden, wie dies zum Beispiel bei Wertpapieren oder börsengehandelten Rohstoffen der Fall ist. In diesem weiteren Kontext verwendet man den Begriff (Markt-)Liquidität für Märkte von Vermögenswerten: Auf einem Markt mit hoher Liquidität sind viele Kauf- und Verkaufsangebote zu beobachten, so dass eine einzelne Transaktion einen nur unwesentlichen Einfluss auf den Marktpreis hat. Auch für Geld- und Kapitalmärkte wird der Begriff der (Markt-) Liquidität verwendet: Liquide Geld- und Kapitalmärkte ermöglichen Emittenten von Eigenkapital- oder Fremdkapitalinstrumenten die schnelle Aufnahme von Finanzmitteln zu marktgerechten Konditionen.

Für Unternehmen ist die jederzeitige Aufrechterhaltung der Liquidität durch Bereitstellung von ausreichenden Geldmitteln zur Erfüllung von Zahlungsverpflichtungen von existentieller Bedeutung. Eine voraussichtlich dauernde Zahlungsunfähigkeit ist für natürliche und juristische Personen nicht nur der gravierenden rechtlichen und wirtschaftlichen Folgen einer Insolvenz hat die jeweils rechtzeitige Bereitstellung ausreichender Geldmittel für Unternehmensleitungen daher eine hohe Priorität.

fälligen nach deutschem Recht zentraler Insolvenzgrund (§ 17, Abs. 2 InsO). Zur Vermeidung

## 2.2 Bestandsgrößenorientierte Betrachtung der Liquiditätssicherung:

Die einfachste Form der Sicherstellung von Liquidität besteht im Vorhalten entsprechend hoher Kassenbestände und täglich verfügbarer Sichteinlagen bei Banken. Die Bereitstellung solcher Bestände an Geldmitteln (Liquidität(sbestand) im engen Sinne) löst Finanzierungskosten aus, die nicht durch die regelmäßig sehr geringen - bisweilen sogar negativen - Erträge aus Liquiditätsbeständen gedeckt werden können. Im Interesse der Rentabilität haben Unternehmensleitungen daher kein Interesse an dem Halten extensiv hoher Liquiditätsbestände. Statt Bestände an Geldmitteln zu halten, die direkt zur Erfüllung fälliger Zahlungsverpflichtungen verwendet werden können, investieren Unternehmen verfügbare Geldmittel teilweise in rentablere finanzielle Vermögenswerte, die kurzfristig ohne Wertverluste einzahlungswirksam veräußert werden können. Das Spektrum dafür geeigneter Anlagen ist breit und umfasst insbesondere Wertpapiere, die an liquiden Märkten gehandelt werden. Ein erweiterter Liquiditäts(bestands)begriff hat Eingang in die Rechnungslegungsstandards des International Accounting Standards Board (IASB) und des Financial Accounting Standards Board (FASB) für zahlungsorientierte Kapitalflussrechnungen (Cash Flow Statements) gefunden. Sowohl IAS 7 als auch ASC 230 lassen es bei der Definition des Finanzmittelfonds zu, dass dieser nicht nur aus Zahlungsmitteln im Sinne von Kassenbeständen und täglich fälligen Sichteinlagen bei Banken oder anderen Finanzinstitutionen (Cash) besteht, sondern dass er auch Zahlungsmitteläquivalente (Cash Equivalents) enthalten darf. Letztere werden definiert als kurzfristig ohne signifikante Wertänderungsrisiken in Geld transformierbare Vermögenswerte mit einer Restlaufzeit bei Zugang von weniger als drei Monaten. Nicht als Zahlungsmitteläquivalente zugelassen sind somit zum Beispiel an aktiven Märkten gehandelte Eigenkapitaltitel oder Staatsanleihen mit längeren Restlaufzeiten, die für eine Beschaffung von Geldmitteln leicht und schnell veräußert werden können.

## 2.2

## Bestandsgrößenorientierte Betrachtung

## Liquiditätssicherung:

Unternehmen als wirtschaftliche Einheiten sind häufig in Form von Konzernen organisiert, die aus einer Vielzahl von rechtlich selbständigen Gesellschaften bestehen, die ihren Sitz in unterschiedlichen Ländern auch mit unterschiedlichen Währungen haben. In solchen Konzernen reicht es nicht aus, dass die Liquiditätsbestände auf konsolidierter Basis hoch genug sind, um die konsolidierten Auszahlungsverpflichtungen abzudecken. Vielmehr muss die Sicherstellung der

der Liquidität grundsätzlich auf der Ebene aller rechtlich selbständigen Gesellschaften sowie in den jeweiligen Währungen gewährleistet sein. Dazu können grundsätzlich Bestände an Geldmitteln von Konzerngesellschaften durch konzerninterne Transaktionen kurzfristig auch über Ländergrenzen zu Konzerngesellschaften mit Liquiditätsbedarfen transferiert werden. Es ist aber zu beachten, dass dies weder überall noch unbeschränkt möglich ist. Zum einen bestehen für lokale Liquiditätsbestände zum Teil Verfügungsbeschränkungen (Restricted Cash), weil sie zum Beispiel rechtlich verpflichtend für bestimmte Investitionen, für Entsorgungs- oder Rekultivierungsmaßnahmen oder für die langfristige Fertigung von Anlagen für Kunden vorgesehen sind. In vielen Ländern ist es zum anderen üblich, dass Banken für Kreditlinien oder Kredite das Hinterlegen von Geldbeständen (Compensating Balances) verlangen, aus denen die nächsten Zahlungen zur Bedienung von Krediten geleistet werden können. Lokal frei verfügbare Geldmittel können in einem internationalen Konzern teilweise nicht grenzüberschreitend genutzt werden, weil Transferrestriktionen bestehen: Ein internationaler Konzern hat in Venezuela eine Tochtergesellschaft, die für den lokalen Verkauf Ware importiert. Die erhaltene Zahlung in lokaler Währung ist nicht frei konvertierbar und muss vor Begleichung der Importrechnungen in eine transferierbare Währung konvertiert werden. Der Kauf der notwendigen Devisen ist in der Regel nur von entsprechend zugelassenen, meist staatlichen Behörden möglich. Im Idealfall sind die importierten Waren auf einer Liste mit bevorzugten Gütern der Regierung aufgeführt (zum Beispiel Medikamente, Produkte für den Pflanzenschutz), was dann zu einem bevorzugten Kurs beim Wechsel der lokalen Währung führen sollte. In Venezuela gab und gibt es verschiedene Kurse für den Wechsel der lokalen Währung Venezolanischer Bolívar (VEF) in USD als internationale Handelswährung. Importeure von bevorzugten Produkten erhalten einen USD für Kurse zwischen 4,30 VEF und 12,00 VEF - je nach Zeitpunkt des Imports und Art des Produkts (Stand: 2013).

Voraussetzung für einen solchen Tausch durch die staatlichen Stellen ist aber das Vorhandensein entsprechender Devisen. Da sich Venezuela im Wesentlichen durch den Verkauf seiner Ölvorkommen finanziert, hat die Regierung längere Zeit unter dem niedrigen Ölpreis gelitten, so dass sie Devisen nur in geringen Mengen bereitstellen konnte. Eine Bedienung der Verbindlichkeiten aus Importrechnungen war daher für eine venezolanische Tochtergesellschaft meist nur sehr begrenzt und zeitweise überhaupt nicht möglich.

Im Graumarkt für Devisen, der von vielen Importeuren genutzt wird, deren

Produkte nicht durch die staatlichen Behörden bevorzugt werden beziehungsweise die ihr Geld schneller aus dem Land transferieren möchten, bestand die Chance, zu Kursen zwischen 200 VEF und 600 VEF zu einem USD zu tauschen (Stand: 2013). Dies schließt aber häufig die zukünftige Möglichkeit aus, zu den staatlichen Kursen zu wechseln.

Bei Konzerngesellschaften, deren Anteile auch von Minderheitsgesellschaftern gehalten werden, kann die Konzernleitung ebenfalls teilweise nicht unbeschränkt oder ohne Zustimmung der anderen Anteilseigner Geldbestände an andere Konzerngesellschaften transferieren:

In einem Mitgliedsunternehmen des Arbeitskreises haben in Indien Minderheitsaktionäre verhindert, dass verfügbare Zahlungsmittel einer indischen Gesellschaft an eine andere indische Konzerngesellschaft als Darlehen bereitgestellt werden konnten. Die Gelder mussten bei einer lokalen Bank für späteren Eigenbedarf angelegt werden, während die zweite Gesellschaft aus Europa heraus finanziert werden musste.

Grundsätzlich sind Transfers zwischen Konzerngesellschaften rechtlich verbindlich zu gestalten. Dafür stehen zum einen Kreditvereinbarungen zur Verfügung, in denen neben der Auszahlung auch Zins- und Tilgungszahlungen vereinbart werden. Damit können Geldbestände jedoch nur zeitlich befristet konzernintern verlagert werden. Solche konzerninternen Kreditverträge können zwischen allen Konzerngesellschaften abgeschlossen werden, unabhängig von direkten oder indirekten Eigenkapitalverflechtungen (wie zum Beispiel zwischen einer Gesellschaft eines US-Teilkonzerns mit einer japanischen Konzerngesellschaft).

Eine dauerhafte Verlagerung von Geldbeständen kann dagegen zum anderen durch Ausschüttungen erreicht werden, die jedoch Eigenkapitalverflechtungen voraussetzen. Allerdings erfordert dies, dass ausschüttungsfähige Ergebnisse oder Gewinnrücklagen bestehen und entsprechende Verwendungsbeschlüsse vorliegen. Damit eignen sich Ausschüttungen allenfalls ausnahmsweise zur Bewältigung von kurzfristig anstehenden Liquiditätsengpässen.

Grenzüberschreitende Ausschüttungen und Zinszahlungen lösen oft Steuerwirkungen aus, die dazu führen, dass die ausgeschütteten Geldmittel nicht in gleicher Höhe bei der empfangenden Gesellschaft ankommen. Die vom Sitzland des zahlenden Unternehmens einbehaltenen Quellensteuern auf Ausschüttungen und Zinsen werden im Sitzland des empfangenden Unternehmens zum 2.2 Bestandsgrößenorientierte Betrachtung der Liquiditätssicherung 9 Teil steuerlich berücksichtigt, indem die zufließenden Beträge entweder von der inländischen Besteuerung freigestellt werden (Freistellungsmethode) oder indem die einbehaltenen Quellensteuern auf die inländische Steuerlast ganz oder teilweise angerechnet werden (Anrechnungsmethode). Dies ist in bilateralen Doppelbesteuerungsabkommen

geregelt, die zwischen vielen Ländern bestehen:5

Schüttet eine kanadische Gesellschaft Dividenden an eine ausländische Muttergesellschaft aus, so fällt darauf eine Quellensteuer in Höhe von 5% an. In Deutschland sind erhaltene Dividenden nicht voll, sondern nur teilweise mit 5% des Ausschüttungsbetrages steuerpflichtig, was bei einem Körperschaftsteuersatz von 30% zuzüglich Solidaritätszuschlag sowie der Gewerbesteuer zu einer effektiven Steuerbelastung von ca. 1,5% führt. Liegt die Beteiligung unter 10%, so unterliegt der Ausschüttungsbetrag allerdings voll - und damit doppelt - der Körperschaftsteuer.

Die zusätzliche Steuerbelastung bei grenzüberschreitenden Ausschüttungen und Zinszahlungen hat dazu geführt, dass eine Reihe internationaler Konzerne größere Bestände an Geldmitteln bei ausländischen Konzerngesellschaften halten. 6 Ein prominentes Beispiel ist der US-Konzern Apple, der nach Angaben im Geschäftsbericht für das Jahr 2015 über mehr als 200 Milliarden USD an Zahlungsmitteln und Wertpapieren bei seinen ausländischen Konzerngesellschaften verfügt hatte. Apple hat lange Zeit nicht beabsichtigt, diese Finanzmittel in die USA zu transferieren, da dies zu einer geschätzten Steuerbelastung von etwa

## 40% führen würde.7

Daher halten eine Reihe internationaler Konzerne größere Bestände an Geldmitteln bei ausländischen Konzerngesellschaften. Dies gilt auch für andere große US-Konzerne wie beispielsweise Microsoft, die Google-Obergesellschaft Alphabet, Cisco Systems und Oracle, die nach einem Bericht von Moody´s Ende 2016 vor allem aus steuerlichen Gründen zusammen fast 600 Milliarden Dollar an Liquidität und kurzfristigen Wertpapieren in ausländischen Konzerngesellschaften hielten.8 Nachdem Ende 2017 in den USA eine große Steuerreform mit 2 Liquidität und Liquiditätssicherung

Erleichterungen für die Repatriierung verabschiedet wurde, hat Apple angekündigt, einen Großteil der Liquiditätsbestände in die USA zu transferieren.9 Weiterhin ist eine dauerhafte Verlagerung von Zahlungsmitteln durch Gestaltung der Vertragsbedingungen für konzerninterne Lieferungen und Leistungen möglich: Durch höhere oder niedrigere Verrechnungspreise kann der Anfall von Erfolgen und damit auch von Zahlungsmitteln bei liefernden und empfangenden Konzerngesellschaften gesteuert werden. Die Transferpreise für konzerninterne

Geschäfte können allerdings nicht beliebig gestaltet oder geändert werden. Es sind dabei gesellschaftsrechtliche (insbesondere Minderheitenschutzrechte) und steuerliche Vorschriften in den betreffenden Ländern zu beachten. Vor allem werden die Konditionen für grenzüberschreitende Geschäfte zunehmend intensiv von den Steuerbehörden der jeweiligen Länder beobachtet, die als missbräuchlich angesehene Gestaltungen steuerlich nicht anerkennen. Damit eignet sich auch dieser Weg kaum für die Bewältigung akuter Liquiditätsprobleme. In einem beschränkten Umfang können jedoch über die Gewährung von kürzeren oder längeren Zahlungszielen Zahlungsmittel konzernintern verlagert werden. Im internationalen Konzern kommt hinzu, dass die Konzerngesellschaften Geldbestände in den unterschiedlichen Währungen ihrer Sitzländer halten. Sollen zum Beispiel US-Dollarbestände einer amerikanischen Konzerngesellschaft genutzt werden, um einen Finanzmittelbedarf einer Gesellschaft im Euro-Raum zu decken, so löst dies Transaktionskosten aus. Diese können bei weniger gehandelten Währungen durchaus bedeutsam sein und es faktisch verhindern, dass lokal frei verfügbare Geldbestände konzernweit genutzt werden.

IAS 7 und ASC 230 sehen eine Erweiterung des Finanzmittelfonds Zahlungsmitteläquivalente

(Cash Equivalents) vor. Dies erscheint willkürlich und lässt sich konzeptionell nicht gut begründen. Wenn damit die Bestände erfasst werden sollen, die Unternehmen im Rahmen ihres Liquiditätsmanagements vorhalten, so erscheint die Beschränkung auf Schuldtitel mit einer Restlaufzeit bei Zugang von höchstens 90 Tagen wenig sinnvoll. Zur Liquiditätsvorsorge eingesetzt werden auch Schuldtitel mit längeren Restlaufzeiten wie zum Beispiel aktiv gehandelte Staatsanleihen von Ländern mit guter Bonität. Es werden von den Unternehmen dafür weiter auch Wertpapierfonds gehalten, die nicht nur Schuldtitel enthalten. Damit kann eine höhere Rentabilität erreicht werden, allerdings um den Preis höherer Wertänderungsrisiken.

Will man einen erweiterten Liquiditätsbegriff definieren, so stellt sich die Frage nach geeigneten Abgrenzungskriterien. Dies stößt schnell auf Schwierigkeiten: So können zum Beispiel Kundenforderungen im Rahmen von Factoringoder Verbriefungstransaktionen kurzfristig zur Generierung von Geldzuflüssen genutzt werden. Dies gelingt aber ebenso durch Veräußerung von marktgängigen Vorratsbeständen, Immobilien oder Finanzanlagen. Möglichkeiten zur Generierung von Geldzuflüssen bestehen weiter durch die Aufnahme von Krediten, die Ausgabe von Schuldtiteln10 oder die Emission von Eigenkapitaltiteln. 2.2 Bestandsgrößenorientierte Betrachtung der Liquiditätssicherung um

Alle derartigen Erweiterungen eines Liquiditätsbegriffes haben eines gemeinsam: daher zweckmäßig, einen engen bestandsorientierten Liquiditätsbegriff zugrunde

Die damit beschriebenen Bestände können nicht unmittelbar zur Erfüllung von Zahlungsverpflichtungen verwendet werden. Vielmehr sind zusätzliche Transaktionen mit Dritten erforderlich, um Geldzuflüsse zu generieren. Es ist zu legen, der nur Zahlungsmittel und täglich fällige Sichteinlagen bei Banken (Cash) umfasst. Abbildung 2.1 zeigt zunächst die Liquidität (im engen Sinne) und beschreibt darauf aufbauend kurzfristige Möglichkeiten zur Generierung von Liquidität, auf die in den folgenden Kapiteln eingegangen wird.

Die obigen Ausführungen gehen von einem gegebenen (Liquiditäts-)Bedarf an Geldmitteln zur Erfüllung von Zahlungsverpflichtungen aus, der aus einem vorhandenen Bestand an Geldmitteln gedeckt werden soll. Zur Sicherstellung der Liquidität ist eine erweiterte Betrachtung sinnvoll, die zum einen die Möglichkeiten einer (zusätzlichen) Generierung von Geldmitteln berücksichtigt. Zum anderen können Möglichkeiten zur Gestaltung der Auszahlungsverpflichtungen genutzt werden.

## 2.3 Stromgrößenorientierte Betrachtung der Liquiditätssicherung

Liquiditätsprobleme resultieren aus Auszahlungsverpflichtungen, die nur zum - oft kleineren - Teil bilanziell in Bestandsgrößen (das heißt Verbindlichkeiten) abgebildet werden. Der grundsätzliche Aufbau von Kapitalflussrechnungen in der Form von Cash Flow Statements erlaubt eine vollständigere Darstellung und Strukturierung von Auszahlungsverpflichtungen sowie von Einzahlungen zu deren Deckung. Cash Flow Statements für die externe Rechnungslegung werden zumeist in drei Aktivitätsbereiche gegliedert: In die Bereiche der laufenden Geschäftstätigkeit (Operating Activities), der Investitionstätigkeit (Investing Activities) und der Finanzierungstätigkeit (Financing Activities). Für interne Zwecke können feinere Gliederungen sinnvoll sein, die zum Beispiel zusätzlich nach Geschäftsbereichen unterscheiden.

Eine Strukturierung aller Ein- und Auszahlungen erlaubt die Unterscheidung von Liquiditätsrisiken, die grundsätzlich aus Abweichungen der aktuell erwarteten Ein- und Auszahlungen von den zuvor geplanten beziehungsweise erwarteten Zahlungen resultieren, die in allen Aktivitätsbereichen auftreten können. Im Bereich der laufenden Geschäftstätigkeit von besonderer Bedeutung sind die Auszahlungen für Personal und die Beschaffung von Einsatzgütern sowie für die Nutzung von Gebäuden, beweglichen Wirtschaftsgütern und Rechten im Rahmen von Miet-, Leasing- oder Lizenzvereinbarungen. Solche Auszahlungen aufgrund von vertraglichen Verpflichtungen sind zwar relativ zuverlässig prognostizierbar, aber kurzfristig oft nicht disponibel. Sofern den Auszahlungen vergleichbar zuverlässig prognostizierbare Einzahlungen von Kunden in ausreichender Höhe gegenüberstehen, sind daraus keine Liquiditätsprobleme zu erwarten. Allerdings hat es in der Vergangenheit auch für Unternehmen mit ursprünglich als stabil angesehenen Geschäftsmodellen immer wieder Überraschungen gegeben, die schnell zu Liquiditätsproblemen führten. Beispiele dafür sind die im Ausmaß unterschätzten Umsatzeinbrüche der Automobil-Konzerne in der Finanzmarktkrise 2008/2009, auf die die Unternehmen nur verzögert mit Anpassungsmaßnahmen im Bereich der Produktion (zum Beispiel Kurzarbeit) reagieren konnten. Die weiter laufenden Auszahlungsverpflichtungen führten schnell zu einem Finanzbedarf, der drohte, die verfügbaren finanziellen Reserven zu übersteigen. Bei dem Bemühen um die Beschaffung zusätzlicher Finanzmittel trat dann das Problem auf, dass Banken ihrerseits in finanzielle Schwierigkeiten geraten waren und nicht im früher gewohnten Umfang für die Bereitstellung von Liquidität zur Verfügung standen.

Wenn Geschäftsmodelle zum Beispiel aufgrund des unerwarteten Auftretens von neuen Konkurrenten oder von politischen Entscheidungen wegbrechen, können ebenfalls sehr schnell Liquiditätsprobleme auftreten, wenn die operativen Einzahlungen schneller zurückgehen als die operativen Auszahlungen.

Dies war zum Beispiel im Markt für Mobiltelefone zu beobachten, in dem der finnische Marktführer Nokia die durch den Markteintritt von Apple ausgelöste Entwicklung hin zu Smartphones nicht rechtzeitig erkannt hatte und gezwungen war, große Unternehmensteile zu verkaufen oder zu schließen. In einer ebenfalls finanziell schwierigen Lage befanden sich die großen deutschen Energieunternehmen durch die politisch überraschend und kurzfristig von der Bundesregierung dekretierte 'Energiewende' im Gefolge der Katastrophe von Fukushima: Durch den geforderten Ausstieg aus der Erzeugung von Strom in Kernkraftwerken brachen den Unternehmen die hohen und stabilen Einzahlungen weg, während gleichzeitig die Auszahlungen für die Entsorgung von Kernkraftwerken oder für den Einsatz anderer Energiequellen zeitlich vorzuziehen waren. Zugleich gerieten die Unternehmen durch sinkende Erzeugerpreise für Strom aufgrund des steigenden Angebots aus subventionierten erneuerbaren Energiequellen finanziell unter Druck.

Liquiditätsprobleme können auch schnell durch unerwartete Entwicklungen im Investitionsbereich entstehen:

Ein Beispiel dafür sind die Probleme von Thyssenkrupp mit den Investitionen in neue Stahlwerke in Brasilien und in den USA, für die die Fertigstellungstermine immer wieder erheblich überschritten wurden. Dadurch fehlten die Einzahlungen bei gleichzeitig erhöhten Auszahlungen. Verschärft wurden diese Probleme dadurch, dass die Stahlkonjunkturen in mehreren Regionen zeitgleich einbrachen. Schaeffler geriet im Herbst 2008 bei der Akquisition von Continental in erhebliche Liquiditätsprobleme. Während der noch laufenden Übernahmefrist verschärfte sich die Finanzmarktkrise im September 2008 durch den Zusammenbruch von Lehman Brothers und führte zu einem drastischen Kursrückgang der ContinentalAktie unter 20 €. Dadurch lag die Annahmequote für das rechtlich verbindliche Übernahmeangebot von zuletzt 75,00 €/Aktie mit über 90% deutlich höher als ursprünglich erwartet. Schaeffler musste die dafür erforderlichen Finanzmittel durch hohe Kredite bei Banken finanzieren, deren Bedienung in der Folge erhebliche Schwierigkeiten bereitete.

Wenn die vorhandenen Bestände an Finanzmitteln, die Einzahlungsüberschüsse aus operativer Geschäftstätigkeit und die Einzahlungen aus Desinvestitionen nicht ausreichen, um die aufgenommenen Verbindlichkeiten mit Zins- und Tilgungszahlungen termingerecht zu bedienen, entstehen unmittelbar Liquiditätsprobleme. Diese können durch Prolongation der bestehenden Verbindlichkeiten oder durch neue Kreditaufnahmen zeitweise überbrückt werden. Voraussetzung dafür ist die Bereitschaft der Kreditgeber, weiter Finanzmittel bereitzustellen. In vielen Kreditverträgen sind Klauseln (Covenants) enthalten, die es den Kreditgebern ermöglichen, bei deren Nicht-Einhaltung die Kredite fällig zu stellen. Die Weigerung von Kreditgebern, bei wirtschaftlichen Schwierigkeiten bestehende

Finanzierungen fortzuführen, hat zu großen Insolvenzfällen (zum Beispiel Kirch-Media, Schlecker) geführt. Zur Vermeidung von Liquiditätsproblemen in der sich entwickelnden globalen Finanzmarktkrise haben große deutsche Industrieund Handelsunternehmen in den Jahren 2008 und 2009 vorsorglich kurzfristig Anleihen mit vergleichsweise hohen Zinssätzen ausgegeben.

Aufgrund der Erfahrungen aus der Finanzmarktkrise haben inzwischen viele Unternehmen dem Ziel der jederzeitigen Sicherstellung der Liquidität eine deutlich höhere Aufmerksamkeit gewidmet.15 In den folgenden Abschnitten wird aufgezeigt, welche Prozesse und Maßnahmen die Unternehmen des Arbeitskreises eingerichtet beziehungsweise ergriffen haben, um Liquiditätsprobleme zu vermeiden.

## Kapitel 3

3 Grundlagen des Liquiditätsmanagements

## 3.1 Einführung:

Insbesondere seit der letzten großen Finanzmarktkrise und der nachfolgenden Wirtschaftskrise kann eine stärkere Fokussierung auf Cash sowie Cash-relevante Kennzahlen beobachtet werden. Dies ist unter anderem durch eine Instabilität des gesamtwirtschaftlichen Umfelds bedingt, die sich zum Beispiel in bestimmten Märkten und Branchen sowie aufgrund strengerer Regulierungsvorschriften für Kreditinstitute zeigt. Zusätzlich müssen sich Unternehmen mit höheren Ratinganforderungen auseinandersetzen und dies in einem entsprechend effektiven Management der Unternehmensliquidität berücksichtigen.

Unter Liquiditätsmanagement wird gemeinhin die Identifikation von Liquiditätsrisiken sowie die Steuerung und Kontrolle der Liquidität verstanden. Eine wesentliche Aufgabe ist die Aufrechterhaltung einer notwendigen Liquidität des Unternehmens, um fällige finanzielle Verpflichtungen in der jeweiligen Währung rechtzeitig begleichen zu können. Ausgehend von den Ein- und Auszahlungen aus dem operativen Geschäft ist es Ziel des Liquiditätsmanagements, im Bedarfsfall zeitgerecht entsprechende Finanzierungsmaßnahmen einzuleiten.

Als Nebenbedingungen sind hierbei einerseits die Gesamtkosten der Beschaffung der jeweiligen Liquidität (Cost of Funds) und andererseits die Rendite und die Sicherheit der Anlage der Liquidität zu beachten. Das Liquiditätsmanagement ist eine zentrale Aufgabe des Treasury. Schnittstellen des Treasury bestehen insbesondere zu den jeweiligen operativen Unternehmenseinheiten, zum Rechnungswesen und zum Controlling.

Das Liquiditätsrisiko, verstanden als Zahlungsunfähigkeitsrisiko, kann in verschiedene Zeithorizonte untergliedert werden. Im kurzfristigen Bereich - hier ist in der Regel von der Liquiditätssituation der nächsten Tage beziehungsweise Wochen auszugehen - wird im Unternehmen häufig eine detaillierte Darstellung der Ein- und Auszahlungen zur Beurteilung der Liquidität vorgenommen.

Je nach Ausgestaltung der Unternehmensprozesse sowie der unternehmensspezifischen finanziellen Situation wird die Liquidität häufig - vor

allem in Krisenzeiten - täglich überprüft. Auf diese Weise wird sichergestellt, dass Auszahlungsüberschüsse durch verfügbare Liquidität (Kassenbestände und Sichtguthaben) zeitgerecht ausgeglichen werden können.

Im Rahmen des Managements des mittel- und langfristigen Liquiditätsrisikos sind umfangreiche Analysen erforderlich. Beispielsweise muss mittels Überwachung jeweiligen

der Fälligkeitsprofile und Volumina sichergestellt werden, dass auslaufende Kreditfinanzierungen bedient werden können und etwaige Kreditvereinbarungsklauseln1 eingehalten werden.

Um die sachgerechte Überwachung und Bereitstellung der kurz-, mittel- und langfristigen Liquidität gewährleisten zu können, sind die nachfolgend dargestellten Elemente von entscheidender Bedeutung:

- · Operationalisierung des Liquiditätsbegriffs für die Liquiditätssteuerung
- · Liquiditätsplanung
- · Kennzahlen zur Liquiditätssteuerung

Diese Darstellung orientiert sich an der Praxis von Unternehmen des Arbeitskreises.

## 3.2 Operationalisierung des Liquiditätsbegriffs für die Liquiditätssteuerung:

In der Konzernbilanz werden die liquiden Mittel regelmäßig in der aggregierten Position Zahlungsmittel und Zahlungsmitteläquivalente zusammengefasst. In der internationalen Rechnungslegung werden hierunter neben Bargeld und Sichteinlagen auch alle weiteren, hochliquiden finanziellen Vermögenswerte mit einem unwesentlichen Risiko der Änderung des beizulegenden Zeitwerts und mit einer Restlaufzeit bei Zugang von maximal drei Monaten verstanden. Für eine detaillierte Liquiditätssteuerung eines Unternehmens ist jedoch die Differenzierung in der Bilanz in der Regel nicht ausreichend. Zusätzliche Informationen müssen herangezogen werden, um eine effektive und effiziente Steuerung der Liquidität zu gewährleisten. In einem ersten Schritt muss bei einem Unternehmen demnach unterschieden werden, in welcher Form und an welcher Stelle Liquidität vorgehalten wird.

Es kann durchaus sein, dass Unternehmen - beispielsweise solche, die im Einzelhandel tätig sind - einen Teil der Liquidität in Form von Barmitteln vorhalten müssen. Auch wenn Barmittel Liquidität im engeren Sinne darstellen, so können sie unter Umständen doch nicht unmittelbar zur Erfüllung von Zahlungsverpflichtungen

genutzt werden. Barmittel sind im Gegensatz zu Buchgeld nicht direkt übertragbar, sondern müssen physisch - teilweise unter erhöhten Sicherheitsvorkehrungen sowie unter Beachtung entsprechender ComplianceRegelungen - an den Erfüllungsort bewegt werden. Darüber hinaus kann bei Unternehmen auch die Situation entstehen, dass die Barmittel faktisch erst am nächsten Tag für das Unternehmen zur weiteren Disposition bereitstehen, da deren zeitnaher physischer Eingang nicht vollumfänglich geplant werden kann.

Ferner ist zwischen der Liquidität eines Konzerns und der Liquidität einer einzelnen Gesellschaft zu unterscheiden. Die Konzernbilanz stellt hierbei das Zahlenwerk einer fiktiv rechtlichen Einheit dar, die häufig über Landes- und vor der oft nicht im vollen Zugriff einer zentralen Liquiditätssteuerung steht.

allem Währungsgrenzen hinaus existiert und einen Bestand an Liquidität ausweist, Dies liegt darin begründet, dass ein Konzern aus rechtlich selbständigen Gesellschaften besteht und die Liquidität nur den jeweiligen Gesellschaften eindeutig zugeordnet ist. Jede Gesellschaft wiederum hält die Liquidität auf Bankkonten, in Depots oder - im Falle von Anlagen - bei beliebigen Kontrahenten vor. Je nach Jurisdiktion und Währung unterliegt der Transfer von Liquidität gegebenenfalls Restriktionen. Demzufolge ist eine differenzierte Darstellung der Liquidität im Konzern nicht nur nach Instrumenten und Fristigkeiten, sondern auch nach Gesellschaft und Land unerlässlich.

Gegebenenfalls ist zu berücksichtigen, ob an einer Konzerngesellschaft fremde Anteilseigner beteiligt sind, die ebenfalls Anspruch auf die liquiden Mittel erheben könnten beziehungsweise über deren Einsatz mitbestimmen können. Dies ist typischerweise bei Gemeinschaftsunternehmen (Joint Ventures) der Fall. Liegt beispielsweise kein Beherrschungsvertrag vor, ist kein unmittelbarer Zugriff auf die Vermögenswerte und demzufolge auf die liquiden Mittel der frei, im Rahmen der ihr gesetzlich oder satzungsmäßig zustehenden

Gesellschaft möglich. Allerdings steht es der Geschäftsleitung der Landesgesellschaft Rechte Darlehensverträge mit Konzerngesellschaften abzuschließen. Zahlungsmittelbestände können zudem weiteren Restriktionen unterliegen, beispielsweise wenn diese für vertraglich vereinbarte Zwecke zurückgehalten werden müssen. Dies kann bei der Bedienung kurzfristiger Verbindlichkeiten oder als Sicherungseinlage bei Termingeschäften der Fall sein. In diesem Zusammenhang spricht man in der internationalen Rechnungslegung von Restricted Cash, wobei verschiedene Ausprägungen vorliegen können. In der extremsten Form sind Zahlungsmittel eingeschränkt oder temporär nicht mehr verfügbar, wenn diese aufgrund rechtlicher Vorschriften aus einem Land, in welchem eine Konzerngesellschaft ansässig ist, nicht mehr uneingeschränkt international transferiert werden können. Derartige Einschränkungen in Bezug auf die Verfügbarkeit von Zahlungsmitteln müssen in der Liquiditätsplanung berücksichtigt werden.

Als Zwischenfazit wird festgehalten, dass für das Liquiditätsmanagement ein enger Liquiditätsbegriff der Finanzmittel (Cash), die sofort im Unternehmen für finanzielle Zahlungen verfügbar sind, zugrunde gelegt werden sollte.

Darüber hinaus ist bei der Liquiditätssteuerung eine mehrdimensionale Betrachtung erforderlich: Zum einen nach Gesellschaft, zum anderen nach Land/ Region beziehungsweise Währung. Die Bereitstellung von Liquidität erfolgt im Konzern in der Regel basierend auf den Einschätzungen des zentralen Liquidtitätsmanagements.

## 3.3 Liquiditätsplanung:

Die Liquiditätsplanung bildet die Informationsgrundlage für das Liquiditätsmanagement, um entsprechende Maßnahmen für künftige Zu- und Abflüsse von Cash einzuleiten. Dies soll unvorhergesehene Liquiditätsengpässe vermeiden und somit kurzfristige und teure Kredite zur Zwischenfinanzierung oder verspätete Zahlungen, zum Beispiel an Lieferanten, verhindern. Um dieses Ziel zu erreichen, ist zunächst der Bedarf an liquiden Mitteln über einen kurzen Zeithorizont - in der Regel wenige Tage oder Wochen - mit einem hohen Detailgrad in der Planung zu berücksichtigen. Darauf aufbauend wird häufig ein erweiterter Zeithorizont von bis zu 12 Monaten betrachtet. Unter Berücksichtigung der operativen Planung des Unternehmens werden die für diesen Zeitraum notwendigen Finanzierungsmaßnahmen durch das Treasury festgelegt und entsprechend überwacht. Demzufolge gibt eine aussagekräftige rollierende Liquiditätsplanung Aufschluss über die zu erwartende Liquidität des Unternehmens. Unter Berücksichtigung der Liquiditätsreserve4 wird deutlich, ob sich das Unternehmen im sicheren Fahrwasser bewegt oder ob größere finanzielle Risiken bestehen. Um Liquiditätsrisiken bewältigen zu können, müssen diese in einem strukturierten Prozess identifiziert werden. Basierend auf der Liquiditätsplanung können Simulationen vorgenommen werden, nicht zuletzt um die Auswirkungen von Extremereignissen - wie zum Beispiel einer erneuten Finanzmarktkrise5 auf die Liquiditätsentwicklung abzuschätzen. Zum Teil werden zur Unterstützung Simulationsmodelle ebenfalls verwendet, um das Restrisiko zu quantifizieren, welches ein Unternehmen nach den jeweiligen Sicherungsmaßnahmen akzeptiert.

Ferner muss bei global agierenden Unternehmen beachtet werden, dass die notwendige Liquidität zeitgerecht in den jeweiligen Gesellschaften des Unternehmens und in den entsprechenden Währungen bereitzustellen ist. Dies kann mittels einer mehrdimensionalen nach Gesellschaften, Ländern und Währungen differenzierenden Liquiditätsplanung erreicht werden. Dazu gehört auch, etwaige Restriktionen im Rahmen der vorhandenen Liquidität zu berücksichtigen. Zur Abschätzung der zukünftigen Zahlungsströme kann entweder eine originäre oder eine derivative Liquiditätsplanung herangezogen werden.6 Bei der originären Methode werden Zahlungsströme (zum Beispiel Umsatzeinzahlungen von Kunden beziehungsweise Auszahlungen an Lieferanten oder Mitarbeiter) geplant und so auch direkt dargestellt. Im Gegensatz dazu beginnt die derivative Methode mit einer geplanten Erfolgsgröße (zum Beispiel mit dem Jahresüberschuss). Diese wird um nicht zahlungswirksame Erträge und Aufwendungen korrigiert beziehungsweise um zahlungswirksame, aber nicht ergebniswirksame Sachverhalte ergänzt. Wird dies auch so (indirekt) dargestellt, erhält man als operativen Einzahlungsüberschuss nur eine Nettozahlungsgröße, die die einzelnen Ein- und Auszahlungen nicht erkennen lässt.

Inbesondere für kürzere Planungshorizonte (bis zu 12 Monaten) hat die originäre Methode den Vorteil, dass die Auslöser für die Zahlungsströme transparent sind. Unabhängig von der Methodik sollten Zahlungsströme aus operativer Tätigkeit sowie aus Investitions- und Finanzierungstätigkeit in diesen Teilbereichen separat erfasst werden, da diese unterschiedlichen Einflüssen ausgesetzt sind und in der Regel auch getrennt gesteuert werden.

In der Unternehmenspraxis wird für die Planung des operativen Cash Flows mehrheitlich die derivative Methode verwendet, da diese mit verhältnismäßig wenig Aufwand aus der Planbilanz und der Plan-Gewinn- und Verlustrechnung abgeleitet werden können. Im Gegensatz dazu werden der Investitions- und der Finanzierungsbereich in der Regel nach der originären Methode geplant und direkt dargestellt. Die Mittelabflüsse aus investiver Tätigkeit sind stark zukunftsorientiert, da sich hier Auszahlungen für Sachanlagen und immaterielle Vermögenswerte sowie Auszahlungen für Unternehmensakquisitionen widerspiegeln.

Die Zahlungsströme aus Finanzierungstätigkeit sind geprägt durch Aufnahme und Rückzahlung von Fremdkapital sowie seltener durch Eigenkapitalmaßnahmen. Unternehmen, die zum Beispiel jährlich eine Dividende zahlen, planen eine entsprechend hohe Liquidität für den Zahlungszeitpunkt ein. Stehen Unternehmenskäufe oder -verkäufe an, sind diese ebenfalls ein bedeutsamer Bestandteil der Liquiditätsplanung.

In der folgenden Abbildung ist die originäre Planung und direkte Darstellung des Finanzierungsbereiches eines Unternehmens beispielhaft dargestellt. Gezeigt werden die in der Zukunft fälligen finanziellen Verpflichtungen aus bestehenden Anleihen und Krediten unter Berücksichtigung der jeweiligen Währungen für einen langfristigen Planungshorizont. In diesem Beispiel erfolgt keine Differenzierung nach Gesellschaften, die Planung erfolgt für das gesamte Treasury des Konzerns. Für eine vollständigere Planung des Finanzierungsbereiches müssten auch weitere geplante Kreditaufnahmen und zugehörige Tilgungszahlungen erfasst und dargestellt werden.

Darüber hinaus ist bei der Liquiditätsplanung auch die Planungsebene von zentraler Bedeutung. Die operative Planung wird bei vielen großen Unternehmen nicht mehr auf Ebene der rechtlichen Einheiten (Legaleinheiten), sondern auf Geschäftsebene durchgeführt. Geplant werden kann beispielsweise auf der Ebene verschiedener Produktkategorien, Divisionen oder strategischer Geschäftseinheiten. Die zugrundeliegende Gesellschaftsstruktur muss nicht zwangsläufig an die Geschäftsstruktur des Unternehmens angepasst sein. So ist es nicht untypisch, dass mehrere Divisionen in einem Land in einer einzelnen Gesellschaft angesiedelt sind, aber überregional über Gesellschaftsgrenzen hinweg agieren. Für die Steuerung der Geschäftstätigkeit ist es teilweise unerheblich, in welcher Gesellschaft produziert und in welcher Gesellschaft verkauft wird, beziehungsweise wo die Ein- und Auszahlungen anfallen. Auch die konzernweite strategische Planung des Finanzierungsbedarfs wird in der Regel auf Konzernebene durchgeführt. Durch diesen top down-Ansatz ist diese Planung für die konkrete Liquiditätssteuerung des Treasury im Konzern nicht direkt verwendbar, da beispielsweise keine ausreichende Währungsdifferenzierung vorgenommen wird.

Dagegen muss die Steuerung der Liquidität immer an jener Gesellschaft ausgerichtet sein, welche die Zahlungsverpflichtung hat. Es muss kontinuierlich sichergestellt werden, dass alle Gesellschaften und Legaleinheiten eines Konzerns liquide sind und jederzeit ihren Zahlungsverpflichtungen nachkommen können. Die Liquiditätsplanung muss daher zwingend die Gesellschaftsstruktur berücksichtigen. Für größere Unternehmen mit komplexen operativen Strukturen stellt die Übersetzung der operativen, geschäftsorientierten Planung in eine gesellschaftsorientierte und währungsdifferenzierte Liquiditätsplanung eine große Herausforderung dar.

Bei einer Kopplung der Liquiditätsplanung an die operative Planung steht regelmäßig das aktuelle Geschäftsjahr im Vordergrund. Die Mittelfristplanung umfasst den Zeitraum bis zu vier Jahren. Dahinter steht oft eine rollierende Planung, bei der in regelmäßigen Abständen (zum Beispiel monatlich oder quartalsweise) die Planung für einen festen Zeitraum (beispielsweise für 12 oder 18 Monate) erstellt wird. Eine längerfristige Planung wird zum Teil für Zeiträume über die nächsten fünf Jahre und darüber hinaus erstellt und erfolgt in der Regel nur auf Jahresbasis. Ein Unternehmen des Arbeitskreises berücksichtigt beispielsweise die Laufzeiten der Treasury-Verbindlichkeiten bis zum Jahr 2047. Zur kontinuierlichen Verbesserung der Planungsqualität und zur Kontrolle der zugrunde liegenden Annahmen und des übergeordneten Planungsprozesses werden regelmäßige Plan-/Ist-Vergleiche durchgeführt. Dies ist bei vielen Unternehmen eine weitere, wesentliche Herausforderung. Häufig stehen Ist-Daten nicht in der Form der Planung oder nur bedingt in deckungsgleicher Organisationsstruktur zur Verfügung. Im Falle einer Cash Flow-Planung auf Legaleinheitsebene müsste eine Kapitalflussrechnung ebenfalls auf dieser Ebene - und nicht nur auf Divisions- oder Konzernebene - erstellt werden. Bei einer währungsdifferenzierten, originären Planung ist es meist noch schwieriger, entsprechende Auswertungen vorzunehmen. Dies liegt vor allem daran, dass gängige IT-Systeme Zahlungsströme zu Gunsten von Umsatz und Ergebnisberichten häufig nur nachrangig berücksichtigen. Wenn darüber hinaus die Gesellschaftskonten im zentralen Cash-Pool eingebunden sind und sich die einzelnen Konzerngesellschaften nicht selbst um eine angemessene Finanzierung kümmern müssen, vermindert dies die Akzeptanz für die Notwendigkeit sowohl einer präzisen Liquiditätsplanung als auch eines regelmäßigen Plan-/Ist-Abgleichs.

Zur Bewältigung der Komplexität des Liquiditätsmanagements ist der Einsatz spezialisierter Planungstools ab einer bestimmten Unternehmensgröße unverzichtbar. Eine Vielzahl von Anbietern stellt Lösungen von einfachen Standalone-Ansätzen bis zu voll integrierten IT-Systemen zur Verfügung. Die Auswahl hängt stark von den Bedürfnissen und der Komplexität des Unternehmens ab. Auch bei den Unternehmen des Arbeitskreises reicht das Spektrum von extern zugekauften Treasury-Systemen bis hin zu kundenspezifisch angepassten SAP-basierten Lösungen, die von den Unternehmen selbständig weiterentwickelt werden. Darüber hinaus gibt es Unternehmen, die vollständig auf eigens entwickelte Lösungen setzen. Kleinere und mittlere Unternehmen basieren ihre Liquiditätsplanung häufig auf einer weniger komplexen Tabellenkalkulation, beispielsweise mittels MS Excel.

Abschließendes Ziel des Planungsprozesses ist es, die erwartete Liquidität zusammen mit dem aktuellen Liquiditätsstatus zu jedem zukünftigen Zeitpunkt innerhalb des Planungshorizontes für jede einzelne Legaleinheit - aber auch für das zentrale Treasury - zu bestimmen. Somit sollte der zielgerichtete und kosteneffiziente Einsatz von Liquidität im Unternehmen regelmäßig gewährleistet sein.

## 3.4 Liquiditätskennzahlen:

In diesem Abschnitt werden die im Rahmen der Liquiditätssteuerung relevanten Kennzahlen analysiert. Von der in der Literatur vorherrschenden klassischen Systematisierung der bestandsorientierten (statischen Liquiditätsanalyse) und der stromgrößenorientierten (dynamischen Liquiditätsanalyse)9 wird in diesem Abschnitt abgewichen und eine praxisrelevante Klassifizierung eingeführt. Hierbei wird unterschieden einerseits zwischen internen Kennzahlen, die sowohl für die operative Steuerung als auch für die Treasury-Prozesse eines Unternehmens eine Rolle spielen, und andererseits zwischen externen Kennzahlen, welche insbesondere durch Analysten, Ratingunternehmen und Investoren genutzt werden.

Dabei ist zu beachten, dass die Abgrenzung der verschiedenen Kennzahlen nicht in allen Fällen trennscharf erfolgen kann. Dies ist insbesondere damit zu begründen, dass - im Falle eines hohen externen Interesses an bestimmten Kennzahlen (beispielsweise dynamischer Verschuldungsgrad) - diese vermehrt auch in der internen Unternehmenssteuerung eingesetzt werden.

## 3.4.1 Interne Kennzahlen:

Nachfolgend werden die in Unternehmen primär für interne Zwecke der operativen Liquiditätssteuerung eingesetzten Kennzahlen dargestellt. Dies kann in unterschiedlichen Unternehmensbereichen erfolgen, wie zum Beispiel im Controlling oder auch in den konzernweiten Treasury-Abteilungen.

Als eine in der Unternehmenspraxis wichtige Steuerungsgröße im Rahmen der Finanz- und Liquiditätssteuerung ist das Net Working Capital (Nettoumlaufvermögen) zu nennen. So nutzen auch alle Unternehmensvertreter des Arbeitskreises diese Steuerungsgröße im Rahmen ihrer Controlling- beziehungsweise Treasury-Prozesse.

Das Net Working Capital stellt den Saldo zwischen kurzfristigen Aktiva und kurzfristigen Verbindlichkeiten dar. Zu den wesentlichsten Treibern des Net

Working Capital zählen Forderungen, Lieferantenverbindlichkeiten und Vorräte.

In der Unternehmenspraxis besteht regelmäßig ein aktivischer Überhang, also eine Kapitalbindung, die es zu finanzieren gilt. Das Management des Net Working Capital determiniert die Mittelfreisetzung beziehungsweise -bindung und ist daher essentieller Bestandteil des Liquiditätsmanagements.

Während ein hohes positives Net Working Capital auf noch nicht realisierte Zahlungsströme hinweist, deutet umgekehrt ein niedriges oder gar negatives Net Working Capital auf hohe erhaltene Anzahlungen oder auf lange Zahlungsziele bei Verbindlichkeiten hin, die häufig auf einer besonders hohen Marktmacht des jeweiligen Unternehmens basieren. Die Optimierung des Net Working Capital durch aktive Steuerung führt somit ceteris paribus zu einer geringeren Kapitalbindung, zu reduzierten Opportunitätskosten und zu einer Erhöhung des Geschäftswertbeitrages.

Um eine dauerhafte Optimierung des Net Working Capital zu erreichen, empfiehlt es sich, zentrale und messbare Liquiditätsziele zu definieren und diese mit etablierten Kennzahlen zu überwachen. Hierzu zählen beispielsweise: Days Inventory Held (durchschnittliche Lagerbestandsdauer), definiert als Quotient des durchschnittlichen Lagerbestands zu Umsatzerlösen. Days Sales Outstanding (durchschnittliche Dauer des Zahlungseingangs bei

Forderungen), definiert als Quotient der Forderungen aus Lieferungen und Leistungen zu Umsatzerlösen.

Days Payable Outstanding (durchschnittliche Dauer bis zur Begleichung der Lieferantenverbindlichkeit), definiert als Quotient der Verbindlichkeiten aus Lieferungen und Leistungen zu Umsatzerlösen.

Eine weitere in der Unternehmenspraxis eingesetzte Kennzahl ist der Liquiditätskreislauf, der auch als Cash Conversion Cycle beziehungsweise CashtoManagements auf Basis relativer Bezugsgrößen. Die Kennzahl spielt insbesondere

Cash Cycle bekannt ist. Dieser misst die Effektivität des Working Capital bei Handels- und Industrieunternehmen (im Wesentlichen im Produktgeschäft) eine große Rolle.

Um die durchschnittliche Zeitdauer zu bestimmen, in der die Liquidität im operativen Geschäftszyklus des Unternehmens gebunden ist, werden die Umschlagsdauern des Vorratsvermögens sowie der Forderungen beziehungsweise Verbindlichkeiten aus Lieferung und Leistung verwendet. Demzufolge bestimmt sich die Länge des Liquiditätskreislaufes aus Days Inventory Held zuzüglich Days Sales Outstanding abzüglich Days Payable Outstanding. Je kürzer der Liquiditätskreislauf des Unternehmens im Branchenvergleich, desto effizienter das Net Working Capital Management. Ist das Lieferantenziel eines Unternehmens länger als die Summe aus der Umschlagsdauer der Vorräte und dem Kundenziel, so ist die Dauer des Liquiditätskreislaufes negativ. Dies resultiert in der Regel aus einem strikten Forderungsmanagement, just-in-timeLieferungen oder einer großen Verhandlungsmacht des Unternehmens gegenüber Lieferanten.

Als weitere Liquiditätskennzahl, die als Maßstab für die Mittelfreisetzung aus dem operativen Geschäft dient, ist die Cash Conversion Rate zu nennen. Diese wird als Quotient aus Free Cash Flow und Nettogewinn (beziehungsweise EBITDA) berechnet. Bei der Berechnung der Cash Conversion Rate kann - je nach Geschäftsart - eine zusätzliche Differenzierung vorgenommen werden. Einige Unternehmensvertreter des Arbeitskreises haben angegeben, dass neben der allgemeinen Cash Conversion Rate für das Gesamtgeschäft auch weiter zwischen den verschiedenen Geschäftsarten (zum Beispiel Produkt- oder Projektgeschäft) unterschieden wird, um den unterschiedlichen monetären Zyklen angemessen Rechnung zu tragen.

## 3.4.2 Externe Kennzahlen:

Im nachfolgenden Abschnitt werden ergänzend die wichtigsten Ausprägungen jener Kennzahlen dargestellt, die von unternehmensexternen Personengruppen wie zum Beispiel Investoren, Analysten und Ratingagenturen zur Liquiditätsanalyse eingesetzt werden können. Zunächst ist der dynamische Verschuldungsgrad zu nennen. Dieser drückt die Zeit aus, die ein Unternehmen braucht, um seine Schulden zurückzuzahlen; er wird als Quotient aus der Effektivverschuldung und dem operativen Cash Flow berechnet. Diese Kennzahl hat sich in empirischen Untersuchungen zur Insolvenzprognose aus Jahresabschlussdaten immer wieder als besonders erfolgreich erwiesen und wird seither regelmäßig Kreditwürdigkeitsprüfungen von Banken und von Ratingagenturen - zum Teil in

leicht abgewandelter Form - verwendet und steht auch deswegen im Fokus der Unternehmenssteuerung.

Zur Charakterisierung der kurzfristigen Liquiditätssituation des Unternehmens werden bei der klassischen bestandsorientierten Liquiditätsanalyse so genannte Liquiditätsgrade verwendet, die sich durch die unterschiedliche Fristigkeit der einbezogenen Aktiv- und Passivposten voneinander unterscheiden.

Die Liquiditätsgrade werden berechnet als Quotient aus den liquiden Mitteln (1. Grad), aus dem monetären Umlaufvermögen (2. Grad) beziehungsweise aus dem monetären Umlaufvermögen zuzüglich der Vorräte (3. Grad) einerseits und den kurzfristigen Finanzschulden andererseits.

In der Praxis der Unternehmen des Arbeitskreises spielen diese Liquiditätsgrade eine eher untergeordnete Rolle. Allerdings ist es denkbar, dass Unternehmen zur Außendarstellung die traditionellen Liquiditätsgrade berücksichtigen, sofern diese im Rahmen von externen Analysen Verwendung finden. Beispielsweise werden derartige Kennzahlen zum Teil auf Analystenkonferenzen angesprochen. Sofern die Liquiditätsgrade auf Basis von veröffentlichten Jahresabschlussinformationen ermittelt werden, ist als wesentlicher Kritikpunkt deren

Vergangenheitsorientierung zu nennen. Darüber hinaus ist auch die stichtagsbezogene Konzeption problematisch, da Änderungen in den jeweiligen Parametern, wie zum Beispiel die Fälligkeit kurzfristiger Verbindlichkeiten oder Forderungen nach dem jeweiligen Berechnungsstichtag, keinen Eingang in die bei

Methodik finden. Somit können keine Rückschlüsse auf die Liquiditätssituation von Unternehmen gezogen werden.

In der Bankenaufsicht wurde mit dem Regelwerk Basel III die Liquidity Coverage Ratio eingeführt. Diese verlangt, dass unter der Annahme eines schweren Stressszenarios die erwarteten kumulierten Auszahlungen abzüglich der erwarteten kumulierten Einzahlungen für einen Zeitraum von 30 Tagen voll durch verfügbare liquide Vermögenswerte mit hoher Qualität (High Quality Liquid Assets) gedeckt sein müssen. Von den Unternehmen des Arbeitskreises wird diese Kennzahl bislang nicht verwendet. Dies dürfte auch für andere Unternehmen außerhalb des Bankensektors gelten.

## Kennzahlen der Ratingagenturen:

Ein  Rating  beeinflusst  die  Fähigkeit  eines  Unternehmens,  sich  Kapital  zu  beschaffen. Unternehmen versuchen daher im Allgemeinen, durch aktives Liquiditätsmanagement die von Ratingunternehmen untersuchten Kennzahlen zu optimieren. Auch Unternehmen, die kein externes Rating aufweisen, unterliegen aufgrund des Bankenratings häufig vergleichbaren Anforderungen. der Beurteilungsgegenstand von Ratings auch auf Wertpapiere beziehen. Basierend

Die Rating-Einschätzung basiert sowohl auf quantitativen als auch auf qualitativen Kriterien (zum Beispiel Risikomanagementsysteme und Unternehmensstrategie). Neben der allgemeinen Zahlungsfähigkeit von Emittenten kann sich auf den von den Unternehmen zur Verfügung gestellten Informationen schätzen Ratingagenturen die Kreditwürdigkeit von Unternehmen, aber auch die von Ländern ein.

Bei kapitalmarktorientieren Unternehmen steht sehr häufig die Sicherung eines bestimmten Zielratings im Mittelpunkt. Das geht bisweilen so weit, dass Ziel untergeordnet werden. Dies gilt umso mehr für operative Maßnahmen,

Folglich ist nicht nur die Selbsteinschätzung des Unternehmens von Bedeutung: Auch die Fremdeinschätzung von Banken, Analysten und vor Hieraus können sich unter Umständen bestimmte Nebenbedingungen bei der Liquiditätssteuerung ergeben.

selbst strategische Ziele, wie die Expansion durch Unternehmenserwerbe, diesem wie die Steuerung des Umlaufvermögens. Diese wird im Hinblick auf die Auswirkung auf das Zielrating selbstverständlich ebenfalls untersucht. Ein gutes Rating im Investment Grade-Bereich bildet die Basis für eine solide Finanzierungspolitik. allem von Rating-Agenturen ist beim Liquiditätsmanagement miteinzubeziehen.

Dies gilt auch dann, wenn ein Unternehmen ausnahmsweise kurzfristig - etwa für ein bis zwei Jahre - für die Finanzierung einer strategischen Akquisition bereit ist, den Korridor eines Zielratings zu verlassen. Entweder tragen die Ratingagenturen dies mit und belassen das bisherige Rating unverändert, weil sie überzeugt sind, dass der höhere Verschuldungsgrad über künftige Cash Flows zurückgeführt wird, oder das Unternehmen positioniert sich vor dem Hintergrund einer Großakquisition im Hinblick auf ein neues Zielrating. So berichtet Zur detaillierten Beschreibung vgl. Basel Committee on Banking Supervision (2013). beispielsweise Bayer im Geschäftsbericht 2017 im Hinblick auf das aktuelle Langfrist-Rating von A- (S&amp;P Global Ratings) beziehungsweise A3 (Moody's) vor dem Hintergrund der Übernahme des Saatgutherstellers Monsanto wie folgt. Die Auswirkungen einer potenziellen Ratingverschlechterung auf die Refinanzierung sind im derzeitigen Niedrigzinsumfeld tendenziell als gering einzuschätzen.

Das langfristige Rating (long-term rating) wird von den Rating-

Agenturen durch ein kurzfristiges Rating (short-term rating) ergänzt. Dieses kurzfristige Rating bezieht sich auf Finanztitel mit einer Laufzeit von bis zu 12 Monaten. Das kurzfristige Rating ist insbesondere für Unternehmen wichtig, die sich neben einer langfristigen Kapitalmarktrefinanzierung (beispielsweise durch Anleihen) zusätzlich über kurzfristige Wertpapiere (insbesondere über Commercial Paper) am Kapitalmarkt refinanzieren. Für Unternehmen wie BASF, Bayer oder Siemens stellt diese Refinanzierungsmöglichkeit einen wichtigen Baustein im Liquiditätsmanagement dar, da so beispielsweise kurzfristige Refinanzierungen in unterschiedlichen Währungen vergleichsweise günstig vorgenommen werden können. Hier spielt das kurzfristige Unternehmensrating für den Kapitalmarktzugang im Zusammenhang mit einer derartigen Finanzierungsform eine ganz entscheidende Rolle, da - je besser dieses ausfällt - die entsprechenden Konditionen am Kapitalmarkt vorteilhafter sind.

Die Refinanzierung über kurzfristige Wertpapierprogramme stellt für kapitalmarktorientierte Unternehmen einen wesentlichen Vorteil gegenüber mittelständischen Unternehmen dar.13 Allerdings muss beachtet werden, dass die Investorennachfrage für kurzfristige Wertpapiere bei einer Ratingverschlechterung schnell abnehmen oder sogar komplett wegbrechen kann. Dies verwehrt den Unternehmen im schlimmsten Fall den Kapitalmarktzugang zu dieser Refinanzierungsform.

Nachfolgend wird beispielhaft die Ratingtabelle von Moody's dargestellt, im Rahmen derer man die Abstufungen der kurz- und langfristigen Ratingklassen Sieht. Aus der obigen Ratingtabelle wird ersichtlich, dass ein Abrutschen beim langfristigen Rating nicht zwingend Konsequenzen im Kurzfristbereich nach sich ziehen muss. Insgesamt lässt sich bei den Unternehmen des Arbeitskreises jedoch eine verstärkte Beobachtung des eigenen kurz- und langfristigen Kreditratings feststellen. Es ist regelmäßig zu prüfen, welches Rating auf Dauer anzustreben oder (noch) zu tolerieren ist.

Die allgemeine Analyse der Ratingagenturen im Rahmen von Emittentenratings bezieht sich im Wesentlichen auf folgende drei Risiken: Unternehmens-,

Branchen- und Länderrisiko. Um eine umfassende Ratingeinschätzung vornehmen zu können, bedienen sich Ratingunternehmen unter anderem der Liquiditätsanalyse, um die entsprechende Bonitätssituation - als ein Element des Unternehmensrisikos - einschätzen zu können. Der umfassende Einsatz der Liquiditätsanalyse  im  Rahmen von Ratingeinschätzungen ist insbesondere  auf die erhöhte Volatilität der Fremdkapitalmärkte zurückzuführen, welche sich unter anderem in Volatilitäten der Credit Spreads sowie in unterschiedlichen Marktzugangs- und Beleihungsstandards niederschlägt. In einem unsicheren makroökonmischen Umfeld zeigt sich bei vielen Unternehmen darüber hinaus die Tendenz zu erhöhten Liquiditätsreserven.15

Ratingunternehmen analysieren im Wesentlichen die Quellen der Liquidität beziehungsweise die kurzfristigen Liquiditätszuflüsse (Liquidity Sources)

und die kurzfristigen Liquiditätsabflüsse (Liquidity Uses) eines Unternehmens.

Dabei wird die Differenz zwischen Liquiditätszu- und -abflüssen sowie in weiterer Folge der Quotient der beiden Größen ermittelt. Diese Berechnungen basieren jeweils auf den von den Unternehmen publizierten Informationen. Eingang in die Ratingbeurteilung finden zum Teil auch zusätzliche Informationen, welche die Agenturen in Rating-Gesprächen ergänzend zu den publizierten Informationen von den Unternehmen erhalten.16

In Anlehnung an das Vorgehen der Ratingagentur S&amp;P werden folgende Ratingkennzahlen berechnet, welche in die Gesamtbewertung des Ratings Eingang finden:

Ratingkennzahl 1 = Funds Flow from Operations (FFO) / Net Debt

Ratingkennzahl 2 = (Industrial) Net Debt / EBITDA

Ratingkennzahl 3 = Free Cash Flow / EBITDA

Kennzahlen als Bestandteil von Kreditvereinbarungsklauseln

Kennzahlen - wie im vorherigen Abschnitten beschrieben - dienen einerseits der eigenen Unternehmenssteuerung oder der externen Unternehmensbeurteilung, sie können andererseits aber durchaus auch zu einer verpflichtenden Vorgabe werden. Dies ist immer dann der Fall, wenn zum Beispiel ein Kreditgeber eine solche Kennzahl als Bestandteil eines Covenant (Kreditvereinbarungsklausel)

in die Kreditdokumentation aufnimmt und die Einhaltung bestimmter Größen fordert. Wird aufgrund schwacher operativer Geschäftsentwicklung oder besonders hoher Investitionen die Vorgabe der Kennzahl nicht mehr erreicht, kann der Kreditgeber auf eine sofortige Rückzahlung des Kredits bestehen. Hierbei ist es unerheblich, ob es sich dabei um ein Bankdarlehen oder ein Kapitalmarktinstrument, wie zum Beispiel eine Anleihe, handelt. Häufig führt die vorzeitige Fälligstellung von Krediten zu erheblichen Finanzierungsschwierigkeiten und im Extremfall zur Insolvenz des Unternehmens. Allerdings muss bei der Kündigung von Kreditverträgen die Konsequenz nicht zwingend eine sofortige Fälligstellung der Kredite sein: Kreditgeber können auch darauf abzielen, mit den Kreditnehmern in Nachverhandlungen bezüglich einer Refinanzierung einzutreten,

da eine im Extremfall eintretende Insolvenz von kreditnehmenden Unternehmen auch für  den  Kreditgeber  ein  entsprechendes  Risiko  darstellt.  Aus  Sicht  der  Kreditnehmer sollten idealerweise Kreditverträge oder Kapitalmarktinstrumente ohne Covenants abgeschlossen werden. Dies ist aber in der

Regel nur möglich, wenn das kreditaufnehmende Unternehmen in einer starken Verhandlungsposition ist und/oder entsprechende Finanzierungsalternativen hat. Je höher der Finanzierungsbedarf und je schwächer die Kreditwürdigkeit des Unternehmens ist, desto größer wird die Wahrscheinlichkeit, dass die Kreditgeber auf Covenants bestehen. Wenn dies der Fall ist, muss die Einhaltung der vereinbarten Covenants vom Unternehmen sichergestellt werden. Dazu muss das Management eine laufende Überwachung der relevanten Kennzahlen und der Entwicklung des jeweiligen Spielraums (Headroom) etablieren, um rechtzeitig einer etwaigen Nichteinhaltung entgegensteuern zu können. Nur so können sich Kreditnehmer vor einer überraschenden Fälligstellung von Krediten schützen.

## Kapitel 4 Liquiditätssteuerung:

## 4.1 Einführung:

Basierend auf den bisherigen Ausführungen thematisiert dieser Abschnitt die Steuerung der Liquidität. Es muss sichergestellt werden, dass ausreichend Liquidität am richtigen Ort, zur richtigen Zeit und in der richtigen Währung zur Verfügung steht. Das Treasury eines Industriekonzerns trägt in der Regel die Verantwortung, die Liquidität des Unternehmens zentral zu bündeln, anzulegen und dem Liquiditätsbedarf entsprechend den Geschäftseinheiten beziehungsweise Gesellschaften zur Verfügung zu stellen.

Im Treasury eines größeren Unternehmens werden hierfür zentrale Verrechnungsplattformen eingesetzt. Hierbei handelt es sich in der Regel um Inhouse Banking-Strukturen, welche die Zahlungsströme innerhalb des Konzerns zusammenfassen. Häufig wird der externe Zahlungsverkehr durch eine unternehmensinterne Einheit vorgenommen, die für alle Konzerngesellschaften sämtliche Ein- beziehungsweise Auszahlungen zentral bündelt, verwaltet und durchführt. Die Zusammenfassung derartiger Prozesse ist unter dem Stichwort Payment Factory bekannt. Darüber hinaus geht der Trend bei vielen Unternehmen im Rahmen von Digitalisierungsinitiativen zusätzlich in Richtung einer Collection Factory, was im Umkehrschluss die Bündelung der Forderungseingänge in einer unternehmensinternen

Einheit bedeutet. Des Weiteren hat sich in den letzten Jahren eine engere Verzahnung des zentralen Controllings und des Treasury als sinnvoll erwiesen; so wurden etwaige Differenzen und Doppelarbeiten zwischen der originären Liquiditätsplanung (über das Treasury) und der derivativen Liquiditätsplanung (über das Controlling) aufgehoben.

Darüber hinaus fungiert das Treasury als 'lender of last resort', um Tochtergesellschaften, die in einen ungeplanten Liquiditätsengpass geraten, kurzfristig zu refinanzieren. Aus diesem Grund ist es wichtig, dass ein Teil der Konzernliquidität unmittelbar und uneingeschränkt dem Treasury zur Verfügung steht. Dies bedeutet, dass die Liquidität idealerweise bereits bei einer zentralen Gesellschaft liegt, diese nicht längerfristig investiert oder gebunden ist und somit jederzeit genutzt werden kann. Diese Liquidität wird im Folgenden als TreasuryLiquidität bezeichnet.

Es ist davon auszugehen, dass ein wirtschaftlich operierendes Unternehmen auf lange Sicht mehr Liquidität generiert als verbraucht. Somit stellt sich unter anderem auch die Frage, wie mit dieser zusätzlichen Liquidität umgegangen werden soll. Im Gegensatz dazu muss bei größeren Investitionsvorhaben oder unregelmäßigen und saisonalen Zahlungsströmen zeitweise zusätzliche Liquidität beschafft werden.

## 4.2 Interne Liquiditätssteuerung:

Zunächst geht es um die optimale Steuerung der Liquidität innerhalb des Unternehmens. Grundsätzlich sollte nicht benötigte Liquidität aus Effizienzgesichtspunkten an möglichst wenigen Punkten konzentriert werden, um von dort aus die Liquidität bedarfsgerecht an jenen Punkten bereitzustellen, an denen sie planmäßig als nächstes benötigt wird. In diesem Abschnitt wird zwischen drei grundsätzlichen Verfahren differenziert, die sich dazu eignen, Liquidität von einem

Punkt der Organisation rechtsverbindlich an eine andere Stelle zu übertragen. Als erstes wird das Cash-Pooling betrachtet. Dabei handelt es sich um ein Verfahren, das Liquidität sehr zeitnah und zentral konzentriert. Längerfristig, oder dann, wenn aufgrund der lokalen Gesetzgebung ein Cash-Pooling nicht zulässig ist, besteht die Möglichkeit, Liquidität in Form von internen Geldanlagen beziehungsweise Darlehen von einer Gesellschaft des Konzerns an eine andere zu übertragen. Soll schließlich die Liquidität dauerhaft transferiert werden, sind auch Eigenkapitalmaßnahmen wie Dividendenzahlungen beziehungsweise Eigenkapitaleinzahlungen und -rückführungen denkbar. Für die Liquiditätssteuerung, insbesondere in Bezug auf Auslandsgesellschaften, sind daher die Kapitalstrukturen der jeweiligen Tochtergesellschaften von wesentlicher Bedeutung.

## 4.2.1 Cash-Pooling:

Unter Cash-Pooling versteht man ein weitgehend automatisiertes Verfahren zur Aggregation von Liquidität auf wenigen zentralen Konten, die auf automatisierten Darlehensvereinbarungen zwischen dem Treasury und den beteiligten internen Gesellschaften basieren. Realisiert wird Cash-Pooling durch Vereinbarungen mit den kontoführenden Banken, die jegliche Liquidität der eingebundenen Konten auf ein zentrales Konto übertragen. Besteht eine Unterdeckung auf einem Konto, so wird dies durch Übertragung der notwendigen Liquidität von dem Haupt- auf das Unterkonto gleichfalls behoben. Auf diese Weise werden alle Konten im Cash-Pool automatisch auf ein zentrales Konto gepoolt. Diese Konstruktionen können mehrstufig sein, Landesgrenzen überschreiten und in einigen Fällen auch verschiedene Währungsräume umfassen. Häufig werden allerdings Cash-Pools nach Währung differenziert, um die Zahlungsströme pro Währung getrennt zu steuern. Die bereitgestellte beziehungsweise genutzte Liquidität wird typischerweise zu marktüblichen Konditionen verzinst, denn Transaktionen im Konzernverbund müssen einem Fremdvergleich (arm's length principle) standhalten, um insbesondere steuerlichen Anforderungen gerecht zu werden. Cash-Pool-Strukturen sind nicht abhängig von der Gesellschaftsstruktur einer Unternehmensgruppe und können auch zwischen zwei Gesellschaften, die nicht in einem Mutter-Tochter-Verhältnis stehen, aufgebaut werden. Um den Liquiditätsbedarf eines Unternehmens optimal und effizient zu steuern, sind viele Konzerne dazu übergegangen, die externen Bankkonten insgesamt zu reduzieren. Unternehmensintern werden Verrechnungskonten verwendet, welche eine Reduktion des Cash-Pooling zur Folge haben.

Es kann sein, dass aus regulatorischen Gründen auf eine physische Übertragung der Liquidität verzichtet wird, die Bank aber den Kontoinhaber so stellt, als wäre die Liquidität auf einem zentralen Konto. Diese Konstruktion wird als Notional-Pooling bezeichnet, soll aber im Rahmen dieser Ausarbeitung keine Rolle spielen, da eine Zentralisierung der Liquidität hier nicht erfolgt. Damit das Treasury in der Lage ist, die Liquidität eines Cash-Pools sinnvoll zu nutzen, müssen sämtliche Zahlungsströme auf allen angeschlossenen Bankkonten geplant werden. Nur so ist es möglich, die am Ende des Tages verfügbare Liquidität auf einem zentralen Konto zu bestimmen und zielgerecht zu nutzen. Werden Cash-Pools in verschiedenen Währungen geführt, gibt es unterschiedliche Strategien, wie mit der zentral verfügbaren Liquidität weiter verfahren wird. Sind die Zu- und Abflüsse der Liquidität durch die jeweiligen CashPools relativ ausgeglichen, so können die Salden der jeweiligen Währung für zukünftige Bedarfe auf den Konten verbleiben. Sammelt sich allerdings längerfristig Liquidität in einzelnen Währungen an, kann es zweckmäßig sein, diese in eine andere Währung zu konvertieren, in der gegebenenfalls Bedarf besteht. Gerade wenn Cash-Pools in einer Vielzahl von Währungen geführt werden, empfiehlt es sich, alle Salden in eine oder zumindest in wenige Währungen zu konvertieren, damit diese wirtschaftlich sinnvoll angelegt werden können. Durch Cash-Pooling kann ein wesentlicher Teil der verfügbaren Liquidität auf wenige Konten konzentriert und optimal gesteuert werden. Es eignet sich aber nicht in jedem Fall zur Bereitstellung von Liquidität am richtigen Ort zur richtigen Zeit. Zum einen gibt es rechtliche und möglicherweise auch steuerliche Restriktionen, da Cash-Pooling nur unter Auflagen zulässig beziehungsweise nicht in allen Ländern erlaubt ist. Unzulässig ist Cash-Pooling beispielsweise nach deutschem Recht, wenn dadurch Eigenkapitaleinlagen wieder an die Kapitalgeber zurückfließen. Bei länderübergreifenden Aktivitäten kann Cash-Pooling gegebenenfalls zu Steuerzahlungen führen. Liegen derartige Einschränkungen vor, kann Liquidität auch in Form von explizit vereinbarten Darlehen bereitgestellt werden, die im nächsten Abschnitt diskutiert werden.

## 4.2.2 Interne Darlehen:

In Fällen, in denen Cash-Pooling mit automatisierten Darlehensvereinbarungen nicht möglich oder nicht sinnvoll ist, müssen andere Formen der Liquiditätsbeschaffung herangezogen werden. Eine Option stellen anlassbezogene, explizit zu vereinbarende interne Darlehen dar. Im Gegensatz zum Cash-Pooling, bei dem meist täglich die gesamte verfügbare Liquidität konzentriert wird, ist ein internes Darlehen ein Instrument mit klaren Attributen wie Darlehensbetrag, Währung,

Verzinsung, Tilgungsplan oder Fälligkeit. Durch diese geregelten Konditionen ergeben sich mehrere Vorteile für den Darlehensgeber, aber auch für den Darlehensnehmer. Zunächst besteht vollständige Klarheit über die verfügbare Liquidität beider Parteien. Es gibt einen Tilgungsplan (zum Beispiel Annuitätendarlehen) beziehungsweise ein Fälligkeitsdatum (zum Beispiel endfälliges Darlehen). Solche Darlehen werden häufig präzise auf die Bedürfnisse des Darlehensnehmers zugeschnitten, zum Beispiel für eine geplante Investition. Die Zinskonditionen des Darlehens orientieren sich dabei an den gegebenen Marktkonditionen und dem Risikoprofil des Darlehensnehmers. Sollten beide Parteien in unterschiedlichen Währungsräumen beheimatet sein, ist eine individuelle Währungssicherung aufgrund der eindeutigen Darlehensstruktur möglich. Interne Darlehen können auch in Verbindung mit Cash-Pooling zum Einsatz kommen, um zum Beispiel Sockelbeträge, die langfristig im Cash-Pool bereitgestellt oder benötigt werden, auf eine individuelle längerfristige Basis zu stellen. Grundsätzlich unterliegen interne Darlehen im Hinblick auf Änderungen von Konditionen wie beispielsweise Terminierung oder Rückzahlung den gleichen Anforderungen wie externe Vereinbarungen.

Interne Darlehen sind, wie auch Cash-Pools, von der Gesellschaftsstruktur einer Unternehmensgruppe unabhängig. Ein Darlehen kann nicht nur zwischen Mutter- und Tochterunternehmen, sondern prinzipiell zwischen jeglichen Gesellschaften eines Konzernverbundes vergeben werden. Um unnötige Komplexität zu vermeiden, werden Darlehen typischerweise zwischen beliebigen Gesellschaften und einem oder mehreren Treasury-Zentren des Konzerns vergeben.

So ist sichergestellt, dass kein Geflecht aus bilateralen Darlehensvereinbarungen zwischen einer Vielzahl von Gesellschaften entsteht. Die zentrale Gesellschaft kann hierbei die Obergesellschaft des Konzerns oder eine Treasury-Gesellschaft sein.

Wie auch beim Cash-Pooling ist eine marktgerechte Verzinsung der Darlehen Voraussetzung, um insbesondere die Anforderungen der Steuerbehörden in Bezug auf den Fremdvergleichsgrundsatz zu erfüllen. Hierbei spielen sowohl die Parameter des Darlehens (Laufzeit, Betrag und Währung) als auch die aktuellen, risikoadäquaten Zinskonditionen eine entscheidende Rolle. Je höher das Risiko eines Ausfalls des Schuldners ist, desto höher wird der durch den Gläubiger zu fordernde Zinssatz sein.

## 4.2.3 Interne Dividenden und andere Eigenkapitalmaßnahmen:

Sollte der Finanzierungsbedarf längerfristig sein oder steht dauerhaft Überschussliquidität in einer Gesellschaft zur Verfügung, sind auch Eigenkapitalmaßnahmen in Betracht zu ziehen. Entsteht Überschussliquidität und bestehen erwirtschaftete Gewinne, kann die Gesellschaft eine Dividende an ihre Muttergesellschaft(en) ausschütten.

Verändert sich das Geschäftsmodell der Gesellschaft durch Expansion oder Wegfall von Aufgaben, kann dies durch eine Eigenkapitalerhöhung beziehungsweise -herabsetzung begleitet werden, um die Höhe des Eigenkapitals an die veränderten Bedingungen anzupassen.

Sowohl bei Dividenden als auch bei einer Eigenkapitalerhöhung oder -herabsetzung erfolgt dies stets über die Anteilseigner. Bei größeren Konzernen kann dies eine lange Kette von Gesellschaften sein, bevor die Zahlungsmittel tatsächlich bei der Obergesellschaft ankommen. Alle Kapitalmaßnahmen sind in der Regel von den Gremien der Gesellschaft formal zu beschließen. Lokale Regularien, wie zum Beispiel eine Thin Capitalization Rule3 zur Vermeidung der Unterkapitalisierung von Gesellschaften, spielen hierbei eine entscheidende Rolle. Eigenkapitalmaßnahmen sind immer langfristig zu betrachten und stellen somit nur bedingt ein brauchbares Instrument für die Liquiditätssteuerung dar.

## 4.3 Externe Anlage von Liquidität:

Im Rahmen der Liquiditätssteuerung ist es Aufgabe des Treasury eines Konzerns, die Anlage von liquiden Mitteln im Rahmen einer etwaigen Überschussliquidität zu prüfen. Demzufolge werden Liquiditätsüberschüsse über das Treasury extern angelegt. Die Verwendung von Überschussliquidität für operative Tätigkeiten sowie damit im Zusammenhang stehende Investitionen wird hier nicht betrachtet.

Die externe Anlage von Liquidität erfolgt in einem dynamischen Prozess, der externe Umfeldbedingungen und unternehmensinterne Präferenzen in Einklang bringt. Dabei sind die Präferenzen zwischen einzelnen Unternehmen nicht deckungsgleich, und sie können sich auch im Laufe eines Jahres ändern. Bei der externen Anlage von Liquidität sind insbesondere die folgenden drei Dimensionen zu beachten, die zueinander in Konkurrenz stehen können:

Rendite:

Prinzipiell gilt der Grundsatz der Gewinnmaximierung auch bei der Anlage von liquiden Mitteln im Rahmen der Liquiditätssteuerung, wobei höhere Renditen regelmäßig mit höheren Risiken oder längeren Bindungsfristen verbunden sind.

Verfügbarkeit:

Je höher die Verfügbarkeit von Liquidität ist, desto größer sind die unternehmerischen Freiheitsgrade. Eine singuläre Optimierung dieser Dimension würde primär zu einer kurzfristigen Anlage, zum Beispiel in Tagegeldern, führen. Bei zunehmender Internationalisierung muss die Verfügbarkeit von Liquidität je Währungsraum in geeigneter Weise sichergestellt werden. Risiko:

Unternehmerisches Handeln zielt stets auf den Schutz der Vermögenswerte ab. Hierbei korreliert das Risiko negativ mit der Rendite einer Investition; demzufolge muss bei der Anlage von Liquidität stets auch das entsprechende Risiko in Betracht gezogen werden. Insbesondere ist in diesem Zusammenhang das Kontrahentenrisiko zu berücksichtigen.

Die Gewichtung dieser drei Aspekte muss unternehmensindividuell entschieden werden, wobei auch veränderte Umfeldbedingungen zu beachten sind. So hat während der Finanzmarktkrise die Bedeutung der Themen Verfügbarkeit und Kontrahentenrisiko zugenommen. Dies hat zur Folge, dass die Kreditwürdigkeit der Banken, bei denen Anlagen vorgenommen werden, heute intensiver geprüft Repurchase Operations (Repos) eingesetzt. Es wird von der

wird. Häufiger wird eine Besicherung der Geldanlagen durch Anlageformen wie zum Beispiel Annahme ausgegangen, dass Investoren ceteris paribus für eine längere Kapitalbereitstellung und ein höheres Ausfallrisiko jeweils Zuschläge bei der Rendite erwarten.

Grundsätzlich stehen Unternehmen für die Anlage von Liquidität diverse Alternativen zur Verfügung. Diese sind vor dem Hintergrund der zum Teil miteinander in Konflikt stehenden Dimensionen unterschiedlich einzuordnen. In diesem Abschnitt steht die kurzfristige Steuerung mit Laufzeiten von bis zu einem Jahr im Fokus.

Eine sehr traditionelle Form ist die Anlage in Tages- und Termingeldern bei Banken. Große Konzerne nutzen daneben auch Commercial Paper-Programme anderer Unternehmen. Commercial Paper-Programme umfassen Laufzeiten bis zu einem Jahr und sind oftmals in unterschiedlichen Währungen handelbar. Im Kurzfrist-Bereich bieten viele Unternehmen Anlagemöglichkeiten mit gutem Rating, wobei das Kurzfrist-Rating weit weniger differenziert ist als das Langfrist-Rating. Daneben gibt es noch eine Vielzahl weiterer Anlageformen, wie beispielsweise Geldmarktfonds, Repos, Staats- und Unternehmensanleihen sowie Aktien. Das Risiko hängt hierbei jeweils vom Schuldner/Emittenten und der konkreten Ausgestaltung der Konditionen (zum Beispiel Laufzeit) ab. Grundsätzlich gilt, je länger die Laufzeit, desto höher das Risiko und desto geringer die Verfügbarkeit.

Insbesondere in Zeiten von Negativzinsen kann es durchaus attraktiv sein, Liquidität in Form von Bargeld zu halten. Darüber hinaus hat die Entwicklung der Bankenregulierung dazu geführt, dass Banken auch durchaus Liquidität auf den Bankkonten wünschen und die Konditionen besser sein können als bei Tagesgeldern.

## 4.4 Beschaffung von Liquidität:

In den nachfolgenden Ausführungen wird die Beschaffung von Liquidität erläutert. Die Struktur des Abschnitts orientiert sich am Aufbau der Kapitalflussrechnung und gliedert sich in operative, investive und finanzielle Maßnahmen.

## 4.4.1 Operative Maßnahmen:

Das Working Capital Management ist eine effektive und vergleichsweise kostengünstige Methode, die interne Finanzierungskraft im Unternehmen zu erhöhen und demzufolge gebundene Liquidität freizusetzen. Während börsennotierte, diversifizierte Konzerne durch entsprechend etablierte Prozesse regelmäßig ein gut gemanagtes Working Capital und somit eine vergleichsweise niedrige Kapitalbindung haben, gibt es hier in kleineren und mittleren Unternehmen häufig einen entsprechenden Aufholbedarf.

Zu den effektivsten Maßnahmen im Working Capital Management zählen die Optimierung von Logistik und Lagerhaltung (Supply Chain Management), das Management von Forderungen (Order-to-Cash) und das Management von Verbindlichkeiten (Purchase-to-Pay). Nach Analyse und Definition der debitorischen und kreditorischen Prozessketten sowie der Lagerhaltung sollten ebenso damit in Zusammenhang stehende Themen aufgegriffen werden, wie zum Beispiel Verhandlungen mit Lieferanten über verlängerte Zahlungsziele und bessere Konditionen, Bündelung von Einkaufsvolumina sowie Optimierung des Forderungsbestands.

Beim Working Capital Management steht demzufolge die Beschleunigung von Zahlungsflüssen bei gleichzeitiger Minimierung der Kapitalbindung im und jener des operativen Unternehmensergebnisses gefunden werden. Als Beispiel für diesen Konflikt können Anzahlungen genannt werden:

Vordergrund. Dennoch muss eine Balance zwischen der Optimierung der Zahlungsströme Einerseits geht der frühere Zahlungseingang oftmals mit einem entsprechenden

Margenverzicht einher. Auf der anderen Seite erhöhen länger gewährte Zahlungsziele das Bonitätsrisiko und den eigenen Finanzierungsbedarf.

## 4.4.2 Desinvestitionen:

Im Rahmen der Liquiditätssteuerung ist es naheliegend, bestimmte Cash-Bedarfe durch Abgabe von Vermögenswerten zu decken. Dies umfasst insbesondere kurzfristige Geldanlagen, wie Termingelder, die bei Fälligkeit nicht prolongiert werden, bis hin zu kurz- oder langfristigen Wertpapieren, die veräußerbar sind. Bewusst ausgeklammert werden hier die Veräußerung von operativ benötigten Vermögenswerten sowie Sale and Lease Back-Modelle.

Im Rahmen der längerfristigen Liquiditätsplanung werden auch Bilanzpositionen analysiert, die regelmäßig nicht im direkten Zugriff des Treasury stehen. Hierzu gehören etwa Unternehmensbeteiligungen oder anderes Betriebsvermögen, das für operative Zwecke nicht zwingend notwendig ist. Neben dem Verkauf von solchen Vermögenswerten kann gegebenenfalls auch das Verschieben beziehungsweise das Zurückhalten von ursprünglich geplanten Investitionen eine Option sein, möglicherweise allerdings mit operativen Nachteilen.

## 4.4.3 Finanzielle Maßnahmen:

Kreditlinien und Darlehen im Bankenmarkt

In der Regel beschaffen sich Unternehmen zusätzliche Liquidität durch Fremdfinanzierung.

Traditionell ist eine Fremdfinanzierung durch eine Hausbank oder allgemeiner durch den Bankenmarkt verbreitet. Zugesagte Kreditlinien und eingeräumte Kredite erfordern bei der Bank eine Eigenkapitalunterlegung nach den aufsichtsrechtlichen Bestimmungen. Da Eigenkapital bei Banken eine knappe Ressource ist, wird die Kreditgewährung zu einem knappen Gut. Die Kosten für eine zugesagte Kreditlinie und für eine gegebenenfalls anschließende Finanzierung orientieren sich an den Eckdaten des Darlehens (zum Beispiel Laufzeit und Volumen), am aktuellen Zinsniveau und an der Kreditwürdigkeit des Unternehmens. Je schlechter die Bonität des Unternehmens ist, desto teurer ist die Finanzierung. Außerdem steigt die Wahrscheinlichkeit, dass die Bank zusätzliche Bedingungen in den Vertrag einbringt, die in Krisenphasen des Unternehmens dazu führen können, dass das Darlehen vor Vertragsablauf zurückgeführt werden muss.

Neben der einfachen Finanzierung durch Banken gibt es noch weitere Möglichkeiten der Liquiditätsbeschaffung. Für Unternehmen stehen beispielsweise für bestimmte, projektbezogene Investitionen Fördermittel in Form von vergünstigten

Darlehen (zum Beispiel über die Kreditanstalt für Wiederaufbau oder die Europäische Investitionsbank) zur Verfügung. Des Weiteren kann es bei größeren Finanzierungen sinnvoll sein, diese auf mehrere Banken in Form einer Syndizierung zu verteilen. Zu den Nutzern dieses Instruments gehört auch die Deutsche Post DHL. Sie weist in ihrem Geschäftsbericht für das Jahr 2017 darauf hin, dass als Liquiditätsreserve eine mehrjährige syndizierte Kreditlinie in Höhe von 2 Milliarden Euro vereinbart wurde. Wesentliche Bankpartner stellen diese Linie bereit:

'Der Konzern deckt seinen Finanzierungsbedarf langfristig durch Eigenkapital und Fremdkapital. Dadurch werden sowohl die finanzielle Stabilität als auch eine hinreichende Flexibilität sichergestellt. Unsere wichtigste Finanzierungsquelle ist grundsätzlich der Mittelzufluss aus laufender Geschäftstätigkeit. Darüber hinaus sichert uns die syndizierte Kreditlinie mit einem Gesamtvolumen von 2 MRD € günstige Marktkonditionen und bildet eine langfristig sichere Liquiditätsreserve mit einer Laufzeit bis zum Jahr 2020. Die syndizierte Kreditlinie enthält keine weiter gehenden Zusagen, was die Finanzkennziffern des Konzerns betrifft.

Angesichts unserer soliden Liquidität wurde sie im Berichtsjahr nicht beansprucht.' Regelmäßig wird erwartet, dass sich Banken, zu denen ein Unternehmen intensive Beziehungen unterhält, an syndizierten Kreditlinien beteiligen. Bei der Auswahl der Banken sollte auf ein gutes Langfrist-Rating geachtet werden. Es sollte hinreichend sicher sein, dass die Banken während der Laufzeit der Kreditlinie solvent bleiben und bei Bedarf ihre eingegangenen Verpflichtungen honorieren. Eine Abhängigkeit von einigen wenigen Banken oder Bankengruppen sollte vermieden werden.

Der Anteil, zu dem sich Banken an einem syndizierten Kredit beteiligen, ist häufig unterschiedlich. Dies reflektiert einerseits die Begrenzung des Kreditexposures der Banken. Andererseits ist die Höhe auch Ausdruck der gesamten Geschäftsbeziehung zwischen dem Unternehmen und der Bank. Bei der Deutsche Post DHL erfolgt darüber hinaus eine Diversifikation, so dass die Gruppe der Bankpartner auf eine breite Basis gestellt ist. Dies wird im Geschäftsbericht 2017 wie folgt formuliert:

'Bei unserer Bankenpolitik achten wir darauf, das zu vergebende Geschäftsvolumen breit zu streuen und mit den Kreditinstituten langfristige Geschäftsbeziehungen zu unterhalten. Den Fremdmittelbedarf decken wir außer über die Kreditlinien auch über andere unabhängige Finanzierungsquellen wie Anleihen und operatives Leasing. Die Fremdmittel werden weitgehend zentral aufgenommen, um

Größen- und Spezialisierungsvorteile zu nutzen und so die Fremdkapitalkosten zu minimieren.'

Für eine mit Banken vereinbarte langfristige Kreditzusage sind regelmäßig Provisionen zu entrichten, die in der Regel für die Laufzeit fest sind und sich an der Bonität des Unternehmens orientieren. Aus den Konditionen lassen sich für das Unternehmen Rückschlüsse auf das eigene Standing und die Bonitätseinstufung durch die Vertragspartner ziehen. Aus Sicht des Unternehmens handelt es sich bei einer Provision um eine Art Versicherungsprämie, um gegen Liquiditätsengpässe geschützt zu sein. Der Zinssatz für eine mögliche Inanspruchnahme orientiert sich an einem Referenzzinssatz (zum Beispiel LIBOR, EURIBOR) zuzüglich eines bonitätsabhängigen Aufschlags.

Der Umfang eines syndizierten Kredits bestimmt einerseits die Anzahl der teilnehmenden Banken. Andererseits erwarten diese Banken trotz der Provision häufig weiteres Bankgeschäft, so dass die Kundenbeziehung für die Banken rentabel ist. Insofern sollte das Bankenkonsortium - zwischen der vom Schuldner gewünschten Diversifikation einerseits und der von den Banken erwünschten

Teilhabe an den gesamten Bankprovisionen (Share of Wallet) andererseits - ausbalanciert sein.

Die Kosten für Kreditlinien sind abzuwägen gegenüber den Kosten der entsprechenden Liquiditätshaltung. Dazu gehört die Differenz zwischen dem Zinssatz der Kreditaufnahme (oder einem internen Opportunitätskostensatz) und dem kurzfristigen Anlagezins der Barreserve. In der derzeitigen Niedrigzinsphase kann sogar eine direkte Liquiditätshaltung in Form von Bargeld vorteilhaft sein, die dann aber physische Lagerkosten (Cost of Carry) verursacht. Damit ein Unternehmen unbeschränkt Zugriff auf zugesagte Kreditlinien hat, dürfen keine Restriktionen, wie zum Beispiel in Form einer Material Adverse Change-Klausel (MAC Clause) oder in Form von weiteren Kreditvereinbarungsklauseln, akzeptiert werden. Die Material Adverse Change-Klausel ist eine vertragliche Regelung und beinhaltet, dass die Banken den zugesagten Kredit nicht gewähren, wenn sich die Vermögensverhältnisse des Darlehensnehmers wesentlich geändert haben. In die gleiche Richtung zielt die Vereinbarung, bestimmte Finanzkennzahlen während der Laufzeit der Kreditzusage einzuhalten (Covenants). Diese können sich zum Beispiel auf die Eigenkapitalquote, den Verschuldungsgrad oder den Cash Flow beziehen. Material Adverse EffectKlauseln (MAE Clauses) können die Gewährung eines Kredites dann einschränken, wenn sich die allgemeinen wirtschaftlichen Verhältnisse verschlechtern. Darunter könnten eine Finanzmarktkrise oder auch Turbulenzen am Geld- und

## Kapitalmarkt fallen.

Von vertraglich fest zugesagten und häufig langfristig vereinbarten Kreditlinien (unwiderrufliche Kreditzusagen) sind solche zu unterscheiden, die von Banken gewährt, aber jederzeit kündbar sind (widerrufliche Kreditzusagen). Solche Kreditlinien haben häufig eine Laufzeit von weniger als einem Jahr und dienen eher der Finanzierung der laufenden Geschäftstätigkeit. Als Liquiditätsreserve sind sie nicht geeignet.

## Aufnahme von Liquidität am Kapitalmarkt

Als Alternative zur klassischen Bankenfinanzierung steht vor allem größeren Unternehmen die direkte Finanzierung am Kapitalmarkt offen. Die Eintrittshürden für eine direkte Kapitalmarktfinanzierung sind um einiges höher als für eine klassische Finanzierung über Banken. Dafür ist die Kapitalmarktfinanzierung in der Regel günstiger. Eine externe Beurteilung der Kreditwürdigkeit des Unternehmens ist zwar nicht zwingend, wird aber sehr häufig vorgenommen und ist für größere Volumina kaum zu vermeiden. In der Regel wird diese durch eine oder mehrere Ratingagenturen durchgeführt, und das Ergebnis wird in Form eines Ratings festgestellt. Für viele institutionelle Investoren stellt ein Investment Grade-Rating eine Mindestanforderung für eine Investition dar. Zu entsprechend höheren Kosten ist eine Finanzierung aber auch mit einem SubInvestment Grade-Rating möglich.10

Des Weiteren wird vor einer Emission regelmäßig eine Dokumentation inklusive Prospekt erstellt, die als Entscheidungsgrundlage für potenzielle Investoren dient. Die Dokumentation kann entweder für eine spezielle Finanzierungsmaßnahme oder für einen zeitlich begrenzten Finanzierungsrahmen erstellt werden, unter dem mehrere Transaktionen getätigt werden können (zum Beispiel Commercial Paper,  Medium  Term  Notes).  Im  einfachsten  Fall  kann  hieraus  ein  Private  Placement entstehen, bei dem

eine Anleihe direkt für bestimmte Investoren begeben wird. Im komplexeren Fall wird typischerweise mit Hilfe eines Bankenkonsortiums ein Public Placement durchgeführt, zum Beispiel für Eurobonds. Die Banken unterstützen hierbei sowohl die Preisfindung, die Platzierung und die technische Abwicklung der Ausgabe und erhalten hierfür eine entsprechende Provision. Häufig flankiert das Unternehmen diesen Vorgang mit Roadshows, um Investoren von der Vorteilhaftigkeit der Finanzierung zu überzeugen. Zeichner sind zumeist institutionelle Investoren wie Versicherungen oder Pensionsfonds. Mit kleinerer Stückelung (zum Beispiel EUR 1.000) können aber auch Privatinvestoren adressiert werden. In der Finanzmarkt- und Wirtschaftskrise hat sich das Schuldscheindarlehen als Instrument zur langfristigen Finanzierung bewährt. Die Kapitalaufnahme erfolgt dabei direkt über die Platzierung bei institutionellen Investoren, insbesondere Versicherungen.

## Eigenkapitalmaßnahmen

Als Alternative zur Fremdkapitalfinanzierung können auch Eigenkapitalmaßnahmen genutzt werden, um Mittelbedarfe zu decken. Das Spektrum ist hier sehr weit. Es beginnt mit der klassischen Finanzierung durch die bestehenden oder durch neu aufzunehmende Eigentümer bei nicht börsennotierten Unternehmen. Bei börsennotierten Unternehmen sind die Gestaltungsvarianten vielfältig; sie umfassen neben der klassischen Kapitalerhöhung durch Ausgabe junger Aktien die Wiederausgabe von eigenen Aktien sowie eine Vielzahl von Varianten mit Options- oder Wandelkomponenten, die von Umwandlungsrechten bis zur Pflichtumwandlung reichen.

Eigenkapitalmaßnahmen erfordern in der Regel einen größeren zeitlichen Vorlauf. Bei Kapitalgesellschaften setzen sie entsprechende Beschlüsse der Gesellschafterversammlung voraus. Derartige Maßnahmen sind demzufolge nicht Teil der Liquiditätssteuerung im engeren Sinn, sondern Bestandteil strategischer Überlegungen zur angestrebten Kapitalstruktur des Unternehmens.

## Quelle: Clemens Jäger, Thomas Heupel (2020): Management Basics. Grundlagen der Betriebswirtschaftslehre - dargestellt im Unternehmenslebenszyklus, Kapitel 12

- 12.1 Cash-Management
- 12.1.1 Die Begriffe Cash und Cash-Management
- 12.1.1.1 Cash

Primäre liquide Zahlungsmittel werden als Cash bezeichnet. Eine zentrale Aufgabe des Cash-Managements ist die Disposition von liquiden Mitteln (vgl. Heesen 2014, S. 28). Hierzu gehören Bargeld und Sichtguthaben. Diese können sofort flüssiggemacht werden. Die Sekundärliquidität, in Form nicht ausgenutzter Kreditmöglichkeiten und Zahlungsäquivalente ('Near Money Assets' = kurzfristig liquidierbare Finanzanlagen) können  kurzfristig  zu  flüssigen  Mitteln  führen.  Termingelder  können  nach  Ablauf  einer festgelegten Laufzeit in flüssige Mittel umgewandelt werden. Dies gilt auch für Termingelder, bei denen eine Kündigungszeit vereinbart wurde. Ein Geldmarktpapier ist eine kurzfristige Schuldverschreibung mit einer Laufzeit von in der Regel bis zu einem Jahr. In Deutschland zählen dazu auch Staatspapiere wie Schatzwechsel, Schuldverschreibungen von Banken (Einlagezertifikate) und Unternehmen (Commercial

Paper). Wertpapiere, z. B. Aktien, die kurzfristig verkauft werden können, zählen ebenfalls zu den kurzfristig liquidierbaren Finanzanlagen.

Cash als solches beinhaltet im Rahmen des Cash-Managements allerdings nicht nur zuvor genannte Bestandsgrößen, sondern auch Bewegungsgrößen in Form von Zahlungsströmen.

Dabei werden die entsprechenden Zahlungshöhen und die Zahlungszeitpunkte Berücksichtigt.

## 12.1.1.2 Cash-Management:

Das Cash- bzw. Liquidationsmanagement kann als unternehmensweites Finanzmanagement bezeichnet werden, das jederzeit die optimale Menge an Liquidität im Unternehmen bereitstellt. Es wird eingesetzt, um Finanzierungskosten und -risiken zu verringern (vgl. Korts 2005, S. 3) und ist eng verknüpft mit dem Bereich 'Treasury'. Das ist der Teil des Unternehmens, der sich mit der Disposition und Anlage von bestehenden und zufließenden finanziellen Mitteln befasst, also vorwiegend der Innenund Außenfinanzierung des Unternehmens (vgl. Heesen 2014, S. 27). des Unternehmens, unter Berücksichtigung der Effizienz des Liquiditätsmanagements,

Cash-Management steht im betriebswirtschaftlichen Sinne für alle Maßnahmen der kurzfristigen Finanzdisposition im Unternehmen. Es hat zur Aufgabe, die Liquidität sicherzustellen. Eine aktive, zielorientierte Steuerung der Liquidität ist notwendig, um Zahlungsausfälle und Zinsverluste zu vermeiden.

## 12.1.2 Aufgaben und Ziele des Cash-Managements:

Das Cash-Management, auch kurzfristiges Liquiditätsmanagement, ist ein Instrument des Finanzmanagements eines Unternehmens auf dispositiver Ebene und repräsentiert eine Grundfunktion der betrieblichen Finanzwirtschaft (vgl. Busse 2003, S. 37 ff. 3). Das Cash-Management steuert die täglichen unternehmerischen Gelddispositionen. Mit einem Planungshorizont von wenigen Tagen bis zu mehreren Jahren wird versucht, die zukünftige Liquiditätslage des Unternehmens zu prognostizieren. Hierfür werden Informationen

über ein- und ausgehende Zahlungsströme benötigt. Cash-Management ist das Steuern des richtigen Betrages, in der richtigen Währung, zum richtigen Zeitpunkt, auf das richtige Konto zur Erzielung der optimalen Erträge und somit die zielorientierte Gestaltung des kurzfristigen Finanzpotenzials eines Unternehmens. Cash-Management steht somit im weitesten Sinne für die Liquiditätssteuerung und Liquiditätssicherung sowie die kurzfristige Finanzmitteldisposition, also die Verwaltung und Steuerung aller

Ein- und Auszahlungen.

## 12.1.2.1 Aufgaben des Cash-Managements:

Um die zentralen Anforderungen der Liquidität und der Rentabilität des Unternehmens zu erfüllen, müssen im Rahmen der Disposition von liquiden Mitteln Defizite gedeckt und Überschüsse rentabel angelegt werden. Überschüssige flüssige Mittel werden abhängig von Fristenkongruenz und Verfügbarkeit für zinsbringende Anlageentscheidungen genutzt. Fristenkongruenz bedeutet, dass die Laufzeit der Finanzierung mit der Investitionslaufzeit identisch sein soll. Beispiel: Ein Fahrzeug mit einer Nutzungszeit von fünf Jahren soll über fünf Jahre finanziert werden. Sollte das Darlehen über zwei Jahre komplett bezahlt werden, so wäre ein hoher Liquiditätsabgang in dieser Zeit vorhanden. Vermögen wird aufgebaut. Wird der Kredit mit einer Laufzeit länger als fünf Jahre getilgt, so wäre der Wert des Vermögens nach fünf Jahren gleich null. Der Kredit würde aber noch laufen. Es muss sichergestellt sein, dass die liquiden Mittel in dem Anlagezeitraum verfügbar sind und die anlagepolitischen Maßnahmen nicht die Zahlungsfähigkeit des Unternehmens gefährden. Dem Unternehmen muss es weiterhin möglich sein, auf nicht prognostizierbare Liquiditätsschwankungen zu reagieren (vgl. Bodemer und Disch 2014, S. 72).

Das Cash-Management hat die Aufgabe, unter Liquiditäts-, Risikound Rentabilitätsgesichtspunkten eine optimale Planung der Finanzmittel zu erreichen. Dabei muss das Cash-Management die Ein- und Auszahlungsströme überwachen. Eine Koordinierung der Zahlungsströme muss erfolgen. Das Aufgabengebiet umfasst sämtliche Maßnahmen zur Sicherung der uneingeschränkten Zahlungsfähigkeit und der Liquiditätsoptimierung. Dabei sollen die Zahlungsbestandskosten und die Kosten der Zahlungsströme eines Unternehmens minimiert werden.

Zum Jahresabschluss kann die Liquidität stark beeinflusst werden. Soll eine hohe Liquidität in der Bilanz dargestellt werden, so können zu erwartende Einzahlungen vorgezogen werden. Es kann z. B. der Kunde aufgefordert werden, offene Rechnungen schneller zu begleichen, damit die Liquidität ersten Grades verbessert wird. Häufig ist dies mit einem aktiven Forderungsmanagement verbunden. Um eine Verbesserung der Liquidität zu erhalten, können auch kürzere Zahlungsziele mit dem Kunden und längere Zahlungsziele mit dem Lieferanten vereinbart werden.

Um eine bessere Liquidität zum Jahresende zu erreichen, können weitere Maßnahmen getroffen werden. Rechnungen, die an Lieferanten gezahlt werden müssen, werden erst zu Beginn des nächsten Geschäftsjahres beglichen. Durch diese Maßnahme erhöht sich die Liquidität zum Bilanzstichtag. Rückstellungen, die erst in folgenden Geschäftsjahren zu Auszahlungen führen, werden gebildet. Dadurch wird der Aufwand dem alten Jahr zugeordnet, die Auszahlung aber erst in den nächsten Jahren. Eine weitere Möglichkeit der Liquiditätsverbesserung besteht in der passiven Rechnungsabgrenzung. Hier werden Erträge, die dem nächsten Geschäftsjahr zugeordnet werden müssen, im alten Jahr vom Schuldner bezahlt. Ein Beispiel: Der Mieter zahlt an uns (Vermieter) die Januarmiete 2002 bereits im Dezember 2001. Zum Jahresende sind es für uns Schulden. Der Zahlungsverkehr ist aber bereits erfolgt. Daraus ergibt sich eine Liquiditätsverbesserung. Die Bilanz wird durch die zuvor genannte Maßnahme im Rahmen der Liquidität ersten Grades verbessert. Um die Liquiditätskennzahlen zu ermitteln, gibt es verschiedene Formeln.

Die Liquidität ersten Grades ergibt sich aus:

(Liquide Mittel / kurzfristige Verbindlichkeiten) x 100

Um liquide zu sein, müssten die flüssigen Mittel ausreichen, die kurzfristigen Verbindlichkeiten zu tilgen.

Die Liquidität zweiten Grades wird wie folgt berechnet: (Liquide Mittel + kurzfristige Forderungen / kurzfristige Verbindlichkeiten) x 100 Bei der Liquiditätsberechnung wird der Zeitpunkt der Bezahlung nicht berücksichtigt. Die kurzfristigen Forderungen werden aber zeitnah fällig. Die kurzfristigen Verbindlichkeiten ebenfalls. Deshalb wird eine Liquidität von 100 % als erstrebenswert angesehen. Unter Liquidität dritten Grades versteht man: (Liquide Mittel + kurzfristige Forderungen + Vorräte / kurzfristige Verbindlichkeiten) x 100

Die Vorräte können durch einen Verkauf zu flüssigen Mitteln umgewandelt werden.

Dies ist gerade bei Handelsunternehmen gegeben.

Hohe liquide Mittel bedeuten eine geringe Rentabilität. Unnötige Zahlungsmittelüberschüsse sollen vermieden werden. Eine Verzinsung der liquiden Mittel leistet einen Beitrag zur Rentabilitätssteigerung, indem überschüssige liquide Mittel angelegt werden. Hierzu zählen z. B. die kurzfristige Anlage in Tagesgeld oder Festgeld.

## 12.1.2.2 Ziele des Cash-Managements:

Ziel ist es, diese Zahlungsströme auf den Zahlungsverkehrskonten transparent zu machen. Die Ziele und Aufgaben des Cash-Managements lassen sich aus den übergeordneten finanzwirtschaftlichen Zielen Liquidität, Rentabilität und Sicherheit ableiten.

Dabei wird der Zeithorizont berücksichtigt. Die Planung kann täglich erfolgen, wenn die Zahlungstermine feststehen.

Feste Termine können besser berücksichtigt werden. Mieten, Versicherungen, Steuervorauszahlungen,

Löhne, Gehälter und Lastschriften sind als regelmäßige Auszahlungen einfach zu planen. Probleme treten häufig bei Steuernachzahlungen, z. B. nach Betriebsprüfungen, auf. Diese müssen häufig durch liquide Mittel oder Kreditaufnahme finanziert werden.

Cash-Management ist vor allem bei Unternehmen mit Niederlassungen oder bei international tätigen Unternehmen notwendig. Bei internationalen Unternehmen erfolgt ein Ausgleich von Zahlungsströmen in unterschiedlichen Währungen. Ziel des CashManagements ist es dabei, die auftretenden Risiken und die anfallenden Kosten zu minimieren. Somit wird eine optimale Ausnutzung liquider Mittel durch das Cash-Management ermöglicht. Bankbezogene Kosten werden reduziert und es erfolgt eine Verminderung der Währungsrisiken. Außerdem wird eine höhere Transparenz und Flexibilität erreicht, die eine einheitliche Finanzführung ermöglichen.

Auf der anderen Seite entstehen die Kosten der zentralen Abteilungen. Sie überwachen und verwalten die liquiden Mittel. Es entsteht die Gefahr, dass ein zu hoher Fokus auf kurzfristige Gewinnerzielung gelegt wird. Cash-Management dient somit auch als wichtiges Instrument des Bilanzstrukturmanagements.

## 12.1.2.3 Einflussfaktoren auf das Cash-Management:

Das Cash-Management wird von vielen Faktoren beeinflusst. Dabei ist zwischen internen und externen Faktoren zu unterscheiden.

· Beispiele für interne Einflussfaktoren sind die Kundenstruktur, die Lieferantenstruktur, die Wettbewerbsstruktur, die Unternehmensgröße, die Unternehmensstruktur und finanzwirtschaftliche Grundsätze des Unternehmens. Abhängig von der Marktmacht können Unternehmen Einfluss auf das Zahlungsverhalten der Kunden und Lieferanten nehmen. Dies geschieht durch kurze Zahlungsziele mit den Kunden und lange Zahlungsziele mit den Lieferanten. Abhängig von der Unternehmensgröße können große Unternehmen durch die Marktmacht bessere Konditionen für sich aushandeln, als kleine Unternehmen. Dabei spielt die Zahlungsmoral der Kunden eine erhebliche Rolle. Werden Rechnungen von Kunden zu spät gezahlt, so fehlt Liquidität. Durch die vorzeitigen eigenen Auszahlungen, z. B. Gehälter, Mieten und Eingangsrechnungen, besteht die Gefahr der Insolvenz durch eine drohende Zahlungsunfähigkeit. Dieses Problem entsteht häufig, wenn nur ein oder wenige Kunden vorhanden sind, die Zahlungsziele vorgeben. Geht ein Kunde in Insolvenz, so droht oft den Zulieferern ebenfalls die Insolvenz, da sich sofort eine Zahlungsunfähigkeit ergeben kann. Hat der Kunde eine erhebliche Marktmacht, so kann er die

Zahlungsziele vorgeben. Durch die langen Zahlungsziele mit dem Kunden erhöht sich das betriebsnotwendige Vermögen, da z. B. Waren vorfinanziert werden müssen. Dadurch entsteht ein vorzeitiger Liquiditätsabgang. Häufig erfolgt auch eine Orientierung der Zahlungsziele an den Wettbewerbern. In der Tourismusbranche und der Möbelindustrie ist es üblich, dass der Kunde Anzahlungen tätigt. Einen entscheidenden Einfluss hat auch die Unternehmensstruktur. Bei einer zentralen Struktur können die Liquiditätsreserven geringer gehalten werden, als bei einer dezentralen Struktur. Das Cash-Management ist dann wesentlich einfacher. Liegt eine dezentrale Unternehmensstruktur vor, z. B. bei Niederlassungen, so muss in der Summe eine höhere Liquidität vorhanden sein. Besonders ausgeprägt ist dies bei Unternehmen, die täglich einen hohen Kassenzugang oder -abgang haben. Großunternehmen müssen über ein komplexes Cash-Management verfügen. Ein weiterer Einfluss besteht im Rahmen der Finanzierungsgrundsätze des Unternehmens. Hierzu zählt z. B. die Art der Finanzierung. Manche Unternehmen werden nur durch Eigenkapital finanziert. Die Abhängigkeit von Kreditgebern wird somit minimiert. Ein Wachstum ist aber nur begrenzt möglich. Liegt der Fokus des Unternehmens auf einer hohen Rentabilität, umso schwieriger wird das Cash-Management, da die überflüssigen Mittel verzinst angelegt werden müssen.

- · Externe Einflussfaktoren sind die Zinshöhe und Zinsschwankungen, die Steuergesetzgebung und Bankensysteme sowie Schwankungen der Wechselkurse. Die

Geschäftsvorgänge in der heutigen Wirtschaft sind zunehmend Zinsänderungs- und Währungsrisiken ausgesetzt. Bei der Anlage finanzieller Mittel und bei der Finanzierung von Investitionen bedroht das Risiko der Zinsänderung stark die Finanzplanung des Unternehmens. Veränderungen der variablen Zinssätze können erhöhte Kosten und folglich eine schlechtere Rentabilität für das Unternehmen bedeuten. Probleme bereiten auch fällige Darlehen, die mit einem höheren Zinssatz nachfinanziert werden müssen. Geldanlagen sind besonders durch sinkende Zinsen bedroht, da dies zu Ertragseinbußen für das Unternehmen führt. Tritt das Unternehmen als Kreditnehmer auf, führen steigende Zinsen zu erhöhten Kosten.

Allgemein bedeutet der Wechselkurs den Preis einer Währung ausgedrückt mithilfe einer anderen Währung. Diese Wechselkursschwankungen haben verschiedene Ursachen. Zu diesen gehören die unterschiedlichen Entwicklungen von Produktivität und Preisniveau in den verschiedenen Staaten. Dadurch, dass diese Einflussfaktoren sich auf die Handelsströme der einzelnen Länder auswirken, verändern sie gleichzeitig auch die Handelsund Leistungsbilanzen.

Eine weitere Ursache wird in den Wechselkursen gesehen. Ein Großteil des Devisenhandels entsteht aus kurzfristigen Geschäften zwischen Banken und Finanzhäusern. Als weiteren Einflussfaktor gibt es die Zentralbanken, welche durch geplantes Handeln auch auf die Entwicklung des Wechselkurses einwirken können. Es gibt keine genau definierten Vorgaben, die einem Unternehmen bei der Entscheidung über die Höhe der verfügbaren liquiden Mittel helfen. Eines der Probleme dabei ist, dass Manager die zukünftigen Risiken  im  Voraus  beurteilen  müssen.  Je  weiter  der  Zeitraum  des  Risikos  ist,  umso problematischer

wird die Risikoeinschätzung. Je mehr das Unternehmen über liquide Mittel verfügt, desto einfacher können Rechnungen termingerecht beglichen werden. Auf der anderen Seite wird mehr Gewinn erzielt, desto mehr Geld das Unternehmen investiert oder innerhalb des Unternehmens arbeiten lässt. Sollten nicht genug liquide Mittel vorhanden sein, ist es dem Unternehmen nicht möglich, den Vorteil von Rabatten oder Skontoabzug zu nutzen. Außerdem kann aufgrund von zu späten Zahlungen die Zusammenarbeit mit den Lieferanten gefährdet werden. Aus diesem Grund muss das Management eine Balance zwischen Liquidität und Rentabilität schaffen (vgl. Samuels 1991, S. 534).

Prognostizierte Überschüsse sind daher gewinnbringend anzulegen und kurzfristige Kapitalanlagen zu optimieren. Erkennbare Finanzdefizite sind entweder durch Auflösung von Liquiditätsreserven zu verhindern oder durch die Inanspruchnahme zinsgünstiger Kredite fristenkongruent zu finanzieren.

Unter das Rentabilitätsziel fallen zudem die Maximierung von Investitionserlösen sowie die Minimierung von Finanzierungskosten und der Steuerlast. Bei einer internationalen Geschäftstätigkeit erweitert sich das Aufgabengebiet des Cash-Managements auf die Risikominimierung aller angelegten und aufgenommenen Gelder (Währungs- und Kursrisiken) sowie auf die Beschleunigung der Zahlungsabwicklung.

Neben der vorausschauenden Planung zählt auch die aktive Gestaltung eines störungsfreien Zahlungsverkehrs zu den Aufgaben des Cash-Managements. Zielführend wirken die Beschleunigung von Einzahlungen (proaktives Forderungsmanagement/Zahlungsvereinbarungen)

und die Verzögerung von Auszahlungen (Ausnutzung von Zahlungszielen).

Ein Einfluss des Cash-Managements liegt auch bei Kapitalverkehrsregelungen oder vor. Es erfolgen Eingrenzungen der Kapitalverkehrsfreiheit durch EinAusfuhrbeschränkungen

von Zahlungsmitteln, Gesellschaftsanteilen oder auch der Aufnahme von Fremdwährungsschulden. Einen Einfluss hat zudem auch das Bankensystem. Gerade bei Konzernen ist es unerlässlich, dass international tätige Banken als Partner vorhanden sind, um das Cash-Management mitzusteuern. Zu beachten bleibt schließlich auch die Auswahl und Pflege der Bankenbeziehungen, deren Partizipation ebenfalls von Bedeutung für die effiziente Gestaltung des Cash-Managements ist. Grundlegende Voraussetzung für den Einsatz des Cash-Managements ist die laufende Bereitstellung von aktuellen Informationen zur Liquiditätslage inklusive Zahlungsbewegungen, Kreditpositionen

und Kontoständen sowie einer Liquiditätsprognose.

## 12.1.3 Cashflow:

Für ein erfolgreiches Cash-Management ist die Messung des Cashflows erforderlich. Der Cashflow gibt damit die Möglichkeit, die dynamische Liquidität zu messen. Er wird auch als partielle Bruttokapitalflussrechnung bezeichnet.

## 12.1.3.1 Berechnung des Cashflows:

Man berechnet beim Cashflow den aus den Umsatzerlösen entstandenen Einzahlungsüberschuss einer Geschäftsperiode. Die Gewinn- und Verlustrechnung stellt die Rentabilität des Unternehmens dar, während die Cashflow-Rechnung eine Aussage über

die Liquidität des Unternehmens trifft. Es sind laufende Kontrollen für beide Instrumente nötig. Jahresüberschuss und Cashflow sind jeweils wertmäßige Ertragsgrößen.

Liquiditätswirksame Vorgänge können aber auch ohne entsprechende Erfolgskomponenten stattfinden, z. B. durch Kreditaufnahme oder Kredittilgung, oder den Kauf von Anlagevermögen.

Der Cashflow gewinnt an Bedeutung, da der ausgewiesene Gewinn in dem Jahresabschluss nichts anderes ist als der tatsächliche Jahresgewinn, der nach Zuweisung der offenen Rücklagen und der Rückstellungen sowie der Bildung stiller und verdeckter Reserven zur Verteilung an die Aktionäre übrig geblieben ist. Abschreibungen, Bildung von Wertberichtigungen und Rückstellungen, oder deren Auflösung, beeinflussen ganz wesentlich den ausgewiesenen Gewinn, der durch finanzpolitische und steuerrechtliche Dispositionen aller Art weiter korrigiert wird.

## 12.1.3.2 Abgrenzung des Cashflows:

Es gibt unterschiedliche Möglichkeiten, den Cashflow abzugrenzen.

Der betriebliche Cashflow entsteht aus der Innenfinanzierung des Unternehmens und ist ein Indikator für die Finanzkraft des Unternehmens. Es werden nur Einzahlungen und Auszahlungen aus der betrieblichen Tätigkeit berücksichtigt. Der Cashflow wird wie folgt berechnet:

Jahresüberschuss (Ergebnis nach Steuern)

- + Aufwendungen, die nicht zu Auszahlungen geführt haben
- - Erträge, die nicht zu Einzahlungen geführt haben
- = Cashflow

In der Praxis wird aber häufig eine einfachere Form verwendet:

Jahresüberschuss

- + Abschreibungen
- + Veränderung Rückstellungen
- = Cashflow

Der totale Cashflow berücksichtigt zusätzlich die Transaktionen auf dem Geld- und Kapitalmarkt. Für die finanzielle Führung des Unternehmens ist dieser Cashflow primär interessant. Im Falle des Cashflows als Kennziffer werden dem Bilanzgewinn die Positionen hinzurechnet, die den Gewinn beeinflusst haben, die flüssigen Mittel aber nicht. Der Cashflow wirkt sich jedoch noch auf weitere Kennzahlen aus. Darunter fallen der dynamische Verschuldungsgrad (Effektivverschuldung/Cashflow), die Entschuldungsdauer (FK/Cashflow), der dynamische Liquiditätsgrad (Cashflow/kurzfristiges FK) sowie der Innenfinanzierungsgrad von Investitionen (Cashflow/Netto-Anlageinvestitionen).

## 12.1.4 Cash-Management-Systeme:

Als Cash-Management-Systeme (CMS) bezeichnet man EDV-gestützte Formen der Kommunikation zwischen Banken und ihren Geschäftskunden, mit denen Daten zur Steuerung der täglichen Kassendisposition von Unternehmen ausgetauscht werden. Diese Dienstleistung wird von Banken angeboten und richtet sich insbesondere an große, umsatzstarke Unternehmen, die über liquide Mittel in unterschiedlichen Währungen verfügen. Wenn die im Unternehmen vorhandene Liquidität ermittelt werden soll, stellt sich das Problem, dass Informationen über aktuelle und in der Zukunft zu erwartende Ein- und Auszahlungen sowie Bestände von Kasse und Bank kurzfristig beschafft werden müssen. Dies ist ein sehr komplexes Vorgehen, das mit großem Aufwand verbunden ist. Zum einen  müssen  Informationen  aus  der  Bilanz,  zum  anderen  aus  dem  Forderungs-  und Verbindlichkeitsmanagement herangezogen werden. Die Sammlung von Informationen aus

dem Forderungs- und Verbindlichkeitsmanagement ist ebenfalls sehr aufwendig. In kleinen Unternehmen ist dies begrenzt möglich und machbar. Fast unmöglich hingegen ist dies in großen, international tätigen Unternehmen. Die Summen der Forderungen und Verbindlichkeiten ändern sich regelmäßig. Diese Zahlen zu verfolgen ist nur schwer und mit großem Aufwand möglich. Aus diesem Grund werden zur Erstellung des Liquiditätsplans und zur Berechnung der aktuellen Liquidität die Zahlen mit Berücksichtigung von Erfahrungswerten, Marktveränderungen und Trends geschätzt.

Vor allem für Unternehmen, die über räumlich weit verteilte Niederlassungen verfügen, kann dieses Problem - unmittelbar auf relevante Informationen zugreifen und Korrekturmaßnahmen sofort durchführen zu können - auftreten. Daher ist es für große und international tätige Unternehmen wichtig, Zahlungsströme zentral zu überwachen und zu verwalten. Zu weiteren Schwierigkeiten der Organisation kann es kommen, wenn Unternehmen eine Vielzahl von Konten bei unterschiedlichen Kreditunternehmen unterhalten, da die Übersicht verloren geht.

Aus diesem Grund ist die Entwicklung von Cash-Management-Systemen für die Unternehmen von großer Bedeutung. In der Regel werden diese Systeme von Kreditinstituten angeboten und enthalten den folgenden Leistungsumfang: Informationsbeschaffung, Informationsverarbeitung und Transaktionsmöglichkeiten.

Die Cash-Management-Systeme werden durch die zentrale Finanzabteilung, die an ein Kommunikations- und Rechnernetz angeschlossen ist, gesteuert. Durch dieses Netz wird eine Übersicht der Zahlungsströme und -bestände ermöglicht. Die Informationen werden von den Systembeteiligten und den Kreditinstituten, bei denen Konten unterhalten werden, eingegeben. Basierend auf diesen Informationen treffen die Finanzmanager des Unternehmens ihre Entscheidungen (vgl. Walz 2004, S. 222 ff.).

Durch verschiedene Konzepte des Cash-Managements können auch Ziele des Liquiditätsmanagements erreicht werden. Unternehmen müssen bei der Wahl der Cash-Management-Modelle die Vor- und Nachteile der jeweiligen Möglichkeit abwägen.

Eine  Möglichkeit  des  Cash-Managements  ist  die  Verrechnung  von  Forderungen  und Verbindlichkeiten.

Dadurch werden die Ein- und Auszahlungen minimiert.

## 12.1.4.1 Netting:

'Die zunehmende Globalisierung der Finanzmärkte und die damit einhergehende Vernetzung gegenseitiger Verbindlichkeiten im Bankengeschäft lässt aufgrund der enormen Beträge Befürchtungen bezüglich Insolvenzen und der Gefährdung des gesamten Bankensystems aufkommen' (Müller-Möhl 1999, S. 226).

Als ein mögliches Modell zur Risikominimierung wurde das Netting eingeführt. Es soll z. B. durch Netting-Vereinbarungen das Kreditrisiko gemindert werden. Derartige Abkommen sind für Unternehmen ebenso bedeutsam wie Rahmenverträge. Diese stellen eine Besonderheit der Beschaffung dar, da sie für eine bestimmte vertraglich festgelegte Zeit Kauf- und Verkaufsbedingungen festlegen. Durch diese Verträge können für das Unternehmen günstigere Konditionen, z. B. hohe Mengenrabatte, erreicht werden. Netting kann man mit dem Begriff 'Aufrechnung' übersetzen. Das Netting ermöglicht die Verrechnung von Forderungen und Verbindlichkeiten von verschiedenen Vertragspartnern

untereinander. Wenn ein Unternehmen aus unterschiedlichen Aufträgen ausstehende Forderungen und Verbindlichkeiten hat, werden diese mithilfe des Matchings aufgerechnet, sodass nur noch die Differenz in Form einer Forderung oder einer Verbindlichkeit beim Clearing überwiesen werden muss.

Dadurch wird das Transfervolumen minimiert. Es werden nur Restbeträge überwiesen. Im Rahmen des Nettings beschreibt das 'Matching' die Aufrechnung. Die beteiligten Unternehmen verrechnen Forderungen und Verbindlichkeiten, die zweifelsfrei gegenseitig aufrechnungsfähig und fällig sind.

Durch die Verrechnung sinkt das Risiko, dass im Rahmen der Insolvenz ein Ausfall der Forderungen eintritt. Innerhalb des Nettings gibt es verschiedene rechtswirksame Vereinbarungen. Die gängigste Methode ist das Netting by Close-out. Bei dieser Methode werden, kurz bevor die Insolvenz eintritt, die gegenseitigen Ansprüche nach dem Marktwert verrechnet und die Insolvenzmasse besteht nur noch aus dem Nettosaldo. Der Marktwert orientiert sich an dem Preis, der sich durch den Handel mit dem bestimmten Gut ergibt. Dieser Wert kann sich täglich verändern, je nachdem um was für ein Gut es sich handelt. Entscheidend ist immer der aktuelle Wert zum Zeitpunkt der Transaktion, also direkt bevor die Verrechnung stattfinden soll.

Der Vorteil dieser Methode liegt darin, dass Banken durch das geringe Adressausfallrisiko eine Verringerung der Eigenkapitalbelastung hervorrufen.

Nach der Feststellung des Differenzbetrages erfolgt das Clearing. Der Differenzbetrag zwischen den verrechneten Forderungen und Verbindlichkeiten wird überwiesen.

Als  Hilfe  für  das  Netting-Verfahren  gibt  es  Netting  Center,  die  die  Koordination  der Verrechnungsprozesse

übernehmen. Die Verrechnungen der gegenseitigen Forderungen und Verbindlichkeiten der Unternehmen können aber auch ohne Netting Center durchgeführt werden. Verrechnen nur zwei Unternehmen, so handelt es sich um ein bilaterales Netting. Sind mehr als zwei Unternehmen betroffen, so liegt ein multilaterales Netting vor. Netting kann national oder international durchgeführt werden. Beim internationalen Netting müssen die unterschiedlichen Währungen berücksichtigt werden. Für Unternehmen, die im Import und Export tätig sind, sollte das Ziel sein, die Kontrahierungswährung an die der Lieferanten anzupassen.

Der Vorteil dieser Strategie liegt in ihrer neutralisierenden Wirkung auf das Ergebnis. Risiken aber auch Chancen werden, ohne Transaktionskosten zu verursachen, neutralisiert (vgl. Ertl 2004, S. 175).

Vorteile des Nettings sind sowohl Kosteneinsparungen der Bankprovision, Bankgebühren als auch Devisenkonvertierungskosten für die Währungsumrechnung. Außerdem verfügt man über einen genaueren Überblick über Volumen, Zeitpunkte und

Währungen der Zahlungen. Durch ein integriertes Netting Center erfolgt eine vereinfachte Verwaltung der Forderungen und Verbindlichkeiten und deren Prüfung. Die Planung der kurzfristigen Finanzmittel kann dadurch erheblich verbessert werden. Das Transaktionsrisiko wird durch das Netting eingeschränkt. Aufgrund der geringeren Anzahl der Transaktionen fallen die Aufwendungen geringer aus.

Die Aufgabe des Nettings ist es, aufkommende Währungsrisiken und den Verwaltungsaufwand, der durch die Verrechnung von Forderungen und Verbindlichkeiten entsteht, zu minimieren.

Am Meldetermin werden die aktuellen Forderungen und Verbindlichkeiten an das Netting Center gemeldet. Anschließend werden die Nettopositionen ermittelt und der Wechselkurs festgelegt. Die beteiligten Gesellschaften erhalten am Information Date die Höhe der Salden, die zum Zahlungszeitpunkt überwiesen werden. Am Transaction Date erfolgen die Überweisungen. Innerhalb des Konzerns erfolgt der Ausgleich der Forderungen und der Verbindlichkeiten am Settlement Date.

Bei dieser Vorgehensweise wird vor dem Begleichen von Verbindlichkeiten bzw. dem Verrechnen von Forderungen ein Gesamtsaldo gebildet. Demnach besteht am Ende nur noch ein deutlich geringerer Betrag an Verbindlichkeiten oder Forderungen im Vergleich zu den ursprünglichen Ansprüchen. Es wird ausschließlich der Restbetrag transferiert. Dies führt  dann  zu  den  zuvor  genannten  Einsparungen  bei  den  Transaktions-  und

Verwaltungskosten.

Ein weiterer Vorteil besteht darin, dass bei Wechselkursschwankungen weniger Geld übertragen werden muss.

## Beispiel

Autozulieferer A hat an seinen Kunden B eine Forderung in Höhe von 100.000 EUR. Der Kunde B hat an den Autozulieferer A eine Forderung in Höhe vom 120.000 EUR. Beim Netting verrechnet A die Forderungen in Höhe von 100.000 EUR und überweist den Nettosaldo in Höhe von 20.000 EUR.

## 12.1.4.2 Pooling:

Pooling stellt eine Dienstleistung eines zentralen Finanzmanagements innerhalb eines Konzerns dar, die einen konzerninternen Liquiditätsausgleich zur Erhaltung der Zahlungsfähigkeit begünstigt. Es ist eine Möglichkeit der internen Konzernfinanzierung (vgl. Große Vorholt und Binson 2007, S. 324). Bei einem zentral geführten Pool-Konto, oftmals 'Master-Account' genannt, werden positive sowie negative Salden des Verfahrens mit einbezogen und die Unterkonten valutarisch abgeglichen (vgl. Jetter 1988, S. 42 f.) (siehe hierzu auch Abb. 12.4).

Cash-Pooling ermöglicht die Konzernfinanzierung unabhängig von Kapitalgebern und wird von einer Vielzahl von Kreditinstituten mit entsprechenden Kontoführungsmodellen unterstützt.

Bei diesem Verfahren wird die Liquidität des Unternehmens auf einem gemeinsamen Konto zusammengefasst, welches über die Muttergesellschaft des Konzerns geführt wird. Im Rahmen des Cash-Pools werden zuerst die aktuellen Buchsalden erfasst. Anschließend wird der Wert des valutarischen Saldos ermittelt. Es erfolgt der Abgleich im Rahmen des Cash-Pools der Ist- und Planumsätze, um die Liquiditätsplanung zu aktualisieren. Am Schluss erfolgt der Kontenausgleich. Überflüssige Mittel können verzinst angelegt werden.

Die Tochtergesellschaften zahlen in der Regel täglich die Salden ihrer Konten auf das gemeinsame Konto, den sogenannten Cash-Pool, ein. Dadurch werden die Konten der Tochtergesellschaften auf null gesetzt und der Cash-Pool bildet einen einheitlichen Saldo für den gesamten Konzern.

Der Cash-Pool fungiert als internes Kreditinstitut, durch das die Tochtergesellschaften für ihre Einzahlungen Zinsen erhalten und auf der anderen Seite Kredite mit einem geringen Zinssatz als bei einer vergleichbaren Bank bekommen. Der Zinssatz, den der Cash-Pool anbietet, muss dennoch dem Drittvergleich standhalten und dementsprechend im Bereich der Zinssätze von externen Kreditinstituten liegen. Durch dieses Instrument kann das Unternehmen zahlreiche Vorteile erzielen.

Die Optimierung des Zinsergebnisses kann durch die Vermeidung von gleichzeitigen Sollund Habensalden erreicht werden. Dies ermöglicht dem Unternehmen große Zinseinsparungen, die extern gezahlt werden müssten. Intern gezahlte Zinsen verbleiben im Konzern und sind auf Konzernebene gewinnneutral.

Außerdem wird es den Tochtergesellschaften erleichtert interne Kredite aufzunehmen, da die Möglichkeit besteht, höhere Kreditsummen unabhängig vom Rating und ohne Zweckbindung vom Mutterkonzern zu erhalten. Die Muttergesellschaft kann durch das bessere Rating zinsgünstige Kredite bei Banken aufnehmen. Sie verfügt in der Regel über Vermögensposten, die als Sicherheiten verwendet werden können.

Das Pooling bietet, durch die zentrale Kompetenz, intern eine sehr hohe Transparenz. Auf der anderen Seite verhindert es dadurch eine geringe externe Transparenz. Die Daten gegenüber Kreditgebern müssen nicht unbedingt veröffentlicht werden.

Eine weitere Möglichkeit besteht in der Beschleunigung oder Verzögerung der Zahlungen innerhalb des Konzerns. Hier werden Zahlungen vor dem ursprünglichen Zahlungstermin getätigt. Es liegt Leading vor. Zahlungen können auch nach dem ursprünglichen Termin erfolgen. Dabei handelt es sich um Lagging. Ein Ziel von

Leading und Lagging ist der schnellstmögliche Transfer von Liquidität vom Ort des Zuschusses zum Ort des Bedarfs. Konzerninterne Währungskostenminimierung entsteht ebenfalls durch die optimale Terminierung der Zahlungsvorgänge in Fremdwährung. Der Cash-Pool eines Unternehmens wird am letzten Tag des Geschäftsjahres aufgelöst und am ersten Tag des nächsten Geschäftsjahres neu gegründet. Die Tochtergesellschaften, die einen Kredit bei dem Cash-Pool aufgenommen haben, nehmen einen kurzfristigen Kredit bei Banken auf, um in der Lage zu sein, die Schulden beim CashPool zu begleichen. Die anderen Beteiligten des Cash-Pools erhalten ihre Einzahlungen zurück.

Dies bietet den Vorteil, dass der Cash-Pool in der Bilanz nicht verrechnet werden muss und somit ein großer Aufwand vermieden wird. Wechselkursschwankungen können durch eine feste Konzernwährung minimiert werden.

Trotz der im Vorangegangenen beschriebenen wirtschaftlichen Vorteile bringt das Pooling auch Risiken in rechtlicher Hinsicht mit sich. Die Gefahren für Mutter- und Tochtergesellschaften bestehen in den Haftungs- und Strafbarkeitsrisiken. Die regelmäßigen Einzahlungen der Tochtergesellschaften in den Cash-Pool können sich im Hinblick auf die Richtlinien der Kapitalbeschaffung und der Kapitalerhaltung als kritisch erweisen. Für die Muttergesellschaft kann das Risiko entstehen, dass der Cash-Pool als Eigenkapitalersatz angesehen wird. Sollen an dem Pooling neben dem Euro auch andere Währungen beteiligt werden, so gibt es zwei Verfahren. Entweder erhält jede Währung ein eigenes Zentralkonto und das Pooling wird unabhängig voneinander durchgeführt (sogenanntes 'Single-Currency-Pooling'), oder es erfolgt eine fiktive Umrechnung verschiedener Währungen in eine Basiswährung (sogenanntes 'Cross-Currency-Pooling'). Dabei ermittelt man die Salden pro Währung, rechnet sie anschließend in eine Basiswährung um und der summierte Saldo ist letztlich ausschlaggebend für die

## Zinserrechnung

(vgl. Pentz und Sollanek 2005, S. 81).

Eine Sonderform des Cash-Poolings ist das 'fiktive Cash-Pooling'. Hierbei erfolgt die Verrechnung der Salden nur theoretisch. Hier findet kein tatsächlicher Geldtransfer auf ein Zentralkonto statt. Die Salden der Unterkonten und somit die Vermögen der Tochtergesellschaften bleiben unberührt und werden allein rechnerisch auf ein fiktives Zentralkonto zusammengeführt. Auf Basis des von der Inhouse-Bank ermittelten valutarischen Gesamtsaldos wird der Zinssatz ermittelt. Daraus ergibt sich die Möglichkeit der günstigen Verzinsung; in der Praxis erfolgen keine Zahlungsströme und die Konzentration der Liquidität im Cash-Pool findet nicht statt. Das fiktive Pooling wird angewandt, wenn ausländische Tochtergesellschaften daran beteiligt werden sollen und es nicht möglich ist, physisches Pooling durchzuführen. Dies ist denkbar, sofern die Genehmigungen zum Zahlungstransfer nicht gegeben sind, oder die Kosten für die Genehmigung den Nutzen des Poolings übersteigen würden (vgl. Pentz und Sollanek 2005, S. 83). Cash Concentration wird eingesetzt, um einen regelmäßigen Ablauf von Ein- und Auszahlungen zu gewährleisten. Dabei ist das Ziel, die Konten der Tochtergesellschaften innerhalb eines Wertrahmens zu halten. Dies geschieht, indem die Salden an ein Konto der Muttergesellschaft übertragen werden.

Innerhalb dieses Systems werden verschiedene Hierarchien gebildet, die mindestens zwei Stufen enthalten müssen. Die Fälligkeit der einzelnen Konten der Tochtergesellschaften wird vor jeder geplanten Verrechnung ermittelt. Man spricht vom sogenannten Sweeping,  wenn  sich  das  Unterkonto  im  Haben  befindet  und  seinen  Saldo  an  das übergeordnete

Konto überträgt. Weist das Unterkonto hingegen einen Soll-Saldo auf, so erhält es den erforderlichen Betrag zum Ausgleich von dem nächsthöheren Konto und man spricht von Topping (vgl. Korts 2005, S. 6).

Die Voraussetzung für ein funktionierendes Cash-Concentration-System ist, dass die Konten der Tochtergesellschaften einem Rahmenvertrag unterliegen.

Der Ablauf wird durch die Bestimmung der Kontenhierarchie definiert. Somit wird festgelegt, welche Konten Cash in den Cash-Pool einzahlen müssen und welche Cash aus dem Pool beziehen können. Der interne Finanzausgleich kann sehr schnell erfolgen, da keine Prüfung der Kreditfähigkeit notwendig ist. Dadurch besteht auch keine Abhängigkeit von externen Geldgebern. Durch einen Cash-Pool besteht auch die Möglichkeit, den Gewinn zu verschieben. Durch die Verbuchung des Zinsaufwandes kann in einem Land mit einer hohen Steuerbelastung der Gewinn gesenkt werden und der Erlös wird versteuert in einem Land mit einer geringen Steuerlast. Die Mitarbeiter des Cash-Pools verfügen über Fachkompetenzen, da es sich um Personen mit Fachkenntnissen der Branche handelt. Dadurch entsteht im Mutterunternehmen ein zentrales Kompetenzcenter. Ein Nachteil kann aber für die Tochtergesellschaften darin bestehen, dass eine größere Kontrolle durch die Muttergesellschaft erfolgt.

## 12.1.5 Cash-Verwaltung:

## 12.1.5.1 Treasury:

Der Treasurer ist eine Position des Finanzvorstands, der die Steuerung der Zahlungsvorgänge, wie die tägliche Finanzdisposition und das Kontrollieren der Liquiditätsreserven, als Aufgabe hat. Er vertritt die finanziellen Funktionen des Unternehmens nach außen.

Der  Bereich  Treasury  setzt  sich  aus  den  Komponenten  Cash-Management,  TreasuryManagement,

Darlehensverwaltung und Marktrisiko-Management zusammen. Aufbauend auf den aktuellen Liquiditäts- sowie Risikoanalysen trifft der Treasurer, unter Berücksichtigung der Konditionen an den Geld- und Kapitalmärkten, die Entscheidung über die künftigen Finanzanlagen bzw. -aufnahmen des Unternehmens und konkretisiert diese als Finanzgeschäfte im Treasury-Management. Ziel des Treasury-Managements ist es, die Verwaltung von Finanzgeschäften und -beständen vom Handel über die Abwicklung bis zur Überleitung in die Finanzbuchhaltung zu unterstützen.

## 12.1.5.2 Cash-Management-System:

Die Zielsetzung des Systems ist der optimale Liquiditätsausgleich durch kostengünstige Sicherung der Zahlungsfähigkeit zu jedem Zeitpunkt des Planungszeitraums.

Voraussetzung für die Anwendung des CMS ist, dass alle Konten ausschließlich von der dienstleistenden Bank unterhalten werden, alle Kreditinstitute, bei denen die Konten geführt werden, die Daten in das fremde Netz einspeisen, oder eine internationale Unternehmung mehrere CMS gleichzeitig benutzt. Die Kosten für die Anwendung des Systems sind die Abschreibung oder Leasingraten für Terminal und Software und die Nutzungsgebühren für das Übertragungsnetz. Die Kosten sind relativ hoch und man muss vor der Einführung prüfen, ob sich das System rentieren kann.

Wichtig bei den Cash-Management-Systemen ist die Datensicherheit. Es darf kein Dritter Zugang zu den Kontoinformationen haben oder in der Lage sein, Transaktionen durchzuführen.

Importe und Exporte können einen erheblichen Einfluss auf die Liquidität nehmen.

Bilanzansätze in Fremdwährung werden umgerechnet.

Quelle: Liquiditätsplanung (2023): Das Steuerungstool für zukunftssicheres unternehmerisches Handeln - ein Praxisleitfaden, Gesamtes Werk mit Ausschluss von Case Studies und Darstellungen

## Generelle Einordnung der Liquiditätsplanung:

Die Liquiditätsplanung zeichnet sich durch eine einzigartige Charakteristik aus, da sie im Rahmen der finanzwirtschaftlichen Landkarte eine besondere Rolle spielt. Sie ist keine Planungsrechnung,  die  sich  in  die  bekannten  wirtschaftswissenschaftlichen  Planungsrechnungen einordnen  lässt  und  zwingt  den  Ersteller  dazu,  eine  ganz  eigene,  spezielle  Sichtweise  auf  das wirtschaftliche Geschehen im Unternehmen einzunehmen. Im Kern gilt die alte Kaufmannsregel: 'Nur was man im Geldbeutel hat, kann man auch ausgeben'. Cash ist die harte Wahrheit der Liquiditätsplanung.

## Definition der Liquiditätsplanung:

Der  Liquiditätsplan  ist  die  Abbildung  sämtlicher  zu  erwartender  Einzahlungen  und  Auszahlungen innerhalb einer festgelegten Planungsperiode und gehört zur kurz- bis mittelfristigen Finanzplanung. Der Planungshorizont erstreckt sich von einem Tag bis zu zwölf

Monaten, sodass noch abschätzbare Eintrittswahrscheinlichkeiten aus den Planungsdaten ableitbar sind.

Aufgabe des Liquiditätsplans ist es, alle Einzahlungen und Auszahlungen zeitgerecht einzuordnen und mögliche Liquiditätsrisiken frühzeitig aufzudecken. Der Liquiditätsplan ist ein typisches Beispiel für eine rollierende Planung, bei der die Pläne fortlaufend aktualisiert und angepasst werden müssen. Die übergeordnete Zielsetzung ist, die jederzeitige Zahlungsfähigkeit sicherzustellen  bzw.  zu  überwachen.  Oder  auch  anschaulich  formuliert:  Wieviel  Geld  steht  dem Unternehmen in 3 Tagen, 3 Wochen, 3 Monaten, an einem bestimmten Tag zur Verfügung und reicht dieses, um die finanziellen Verpflichtungen zu erfüllen?

## Abgrenzung zu den finanzwirtschaftlichen Planungen:

Grundsätzlich ist es wichtig, die Liquiditätsplanung zu anderen Planungsrechnungen bzw.

Begrifflichkeiten  abzugrenzen,  damit  die  Grundlagen,  die  Vorgehensweise  und  die  Zielstellung  der

Liquiditätsplanung eindeutig beschreibbar sind.

Die Kapitalfussrechnung (KFR), eine Nebenrechnung der Finanzbuchhaltung, leitet über eine indirekte Methode durch eine Rückrechnung der ausgabenrelevanten Erlöse und

Aufwände mit der Verknüpfung der Veränderungssalden der Bilanz, die KFR her. Die

KFR  (oder  auch  Cash-Flow-Statement  genannt)  wird  in  der  Regel  eher  in  der  Nachbetrachtung verwendet und ist bei großen Unternehmen Bestandteil des Jahres- bzw. Konzernabschlusses.

Allerdings  bieten  moderne  Enterprise-Ressource-Planning  (ERP)  Systeme  die  Möglichkeit,  beim Vorliegen einer im ERP integrierten Planung, mittels eines rechnerischen monatlichen Abschlusses eine KFR für die kommenden Planmonate zur erstellen. Diese kann auf Monatsbasis eine Grundlage zur Indikation eines grundsätzlichen finanziellen Handlungsbedarfs bilden, stellt aber aufgrund der indirekten Methode und der fehlenden Terminierungsparameter von Ein- und Auszahlungen keine Liquiditätsplanung im definierten Sinne dar.

Die Finanzplanung oder Cash-Flow-Planung stellt, aufgrund der operativen Planung als Datenbasis, eine Planungsrechnung dar, die deutlich spezifscher als die KFR die Finanzierungsanforderungen induziert. Die folgende Gegenüberstellung verdeutlicht die bestehenden Unterschiede zwischen einer Finanzplanung und der Liquiditätsplanung.

Ziel der Ermittlung: Verfügbare liquide Mittel

Gegenüberstellung: Ein- und Auszahlungen

Objekt der Planung: Konten

Häufigkeit der Erstellung: Einmal, dann rollierend

Betrachteter Zeitraum: Tag, Woche, Monat

Terminierung: Zahlungstermin

Betrachtung von Netto oder Brutto: Brutto

Steuern: Alle Arten von Steuern (insbesondere Umsatzsteuer)

Noch  deutlicher  wird  der  Unterscheid  bei  der  Betrachtung  der  Datenbasis  beider  Planungen.  Die Finanzplanung verwendet die operative Planung für das Jahr (Budget), während die Liquiditätsplanung Bankkonten, Finanzbuchhaltung, operative Planung, operatives Management und Prognoseverfahren kombiniert.

## Bedeutung der Liquiditätsplanung:

Die Liquiditätsplanung erscheint immer wieder als eine Planung, die vom Unternehmensmanagement stiefmütterlich behandelt wird -Renditeplanungen stehen oftmals im Vordergrund, da der Unternehmenserfolg gleichlautend mit einem Managementerfolg gesehen wird. Dabei gilt 'Liquidität vor  Rentabilität'  als  wichtigster  kaufmännischer  Grundsatz,  da  die  Sicherung  der  Liquidität  die vordringlichste Aufgabe des Managements ist.

Eine ausreichende Liquidität ist zum einen eine gesetzlich maßgebliche Anforderung und wird zum anderen durch Gesellschafter bzw. Anteilseigner und Kreditgeber (Finanziers) gefordert.

## Gesetzliche Anforderungen:

Für  jede  Unternehmensform  gilt  die  grundsätzliche  Anforderung  an  den/die  Geschäftsleiter,  die Liquidität  und  damit  den  Fortbestand  des  Unternehmens  zu  sichern,  sowie  die  Befriedigung  aller ausstehenden Verbindlichkeiten (Gläubigerschutz) zu gewährleisten.

Auf Seiten des Einzelunternehmens bzw. der Personengesellschaften sind die gesetzlichen Regelungen nicht  explizit  definiert  worden,  da  die  persönliche  Haftung  der  Geschäftsleiter  den  Gläubigern ausreichend Sicherheit geben sollte. Für den Unternehmer an sich ist die persönliche Haftung ein essenzielles Risiko, was ihm Antrieb genug sein sollte, die Liquidität immer und zu jedem Zeitpunkt sicher zu stellen und mit Hilfe einer Liquiditätsplanung zu überwachen.

Für Kapitalgesellschaften hat der Gesetzgeber die Auflagen mannigfaltig definiert und zum  1.  Januar  2021  mit  dem  'Gesetz  über  den  Stabilisierungs-  und  Restrukturierungsrahmen  für Unternehmen' kurz StaRUG nochmals verschärft.  In §  1  ist  die  Pflicht  für  Unternehmensleiter  zur Krisenfrüherkennung und Krisenmanagement neu installiert worden.

Diese Pflicht gilt immer, auch wenn das Unternehmen kein Sanierungsfall ist. Sie trifft alle Geschäftsleiter von Kapitalgesellschaften (z. B. den Vorstand einer AG und den Geschäftsführer einer GmbH) und kapitalistischer Personengesellschaften (z. B. den Geschäftsführer des Komplementärs bei einer GmbH &amp; Co. KG). Die Geschäftsleiter haben danach fortlaufend alle Entwicklungen zu überwachen, welche den Fortbestand des Unternehmens gefährden können.  Erkennen  sie  solche  kritischen  Entwicklungen,  haben  sie  geeignete  Gegenmaßnahmen  zu ergreifen und ihren Überwachungsorganen, z. B. bei der GmbH

der Gesellschafterversammlung, unverzüglich Bericht zu erstatten. Die Pflicht zu Krisenfrüherkennung und  Krisenmanagement  gilt  zusätzlich  zu  den  sonstigen  Pflichten  der  Geschäftsleiter.  Die  Idee  des Gesetzgebers ist es, dass durch die neu im Gesetz installierte

Pflicht zur Krisenfrüherkennung und zum Krisenmanagement Insolvenzen vermieden werden können.

In einer wirtschaftlichen Krise, insbesondere einer 'Liquiditätskrise', sieht sich der

Geschäftsleiter einer Kapitalgesellschaft mit dem schwerwiegenden Problem konfrontiert, dass  die  ihm  zur  Verfügung  stehenden  liquiden  Mittel  möglicherweise  nicht  mehr  zur  Begleichung laufender Verbindlichkeiten ausreichen. Im Falle dieser drohenden Insolvenz wandeln sich die Regelungen von einem 'sollte' in ein 'muss', d. h. der Geschäftsleiter

muss eine Liquiditätsvorausschau aufstellen und damit nachweisen, dass keine Zahlungsunfähigkeit vorliegt und eine überwiegend wahrscheinliche positive Fortführungsprognose gegeben ist.

Tut er das im Falle einer eintretenden Zahlungsunfähigkeit nicht und das Unternehmen muss Insolvenz anmelden, so ist er persönlich, aufgrund des Tatbestandes einer dann vorliegenden Insolvenzverschleppung, zum einen für die entstandenen Schäden haftbar und zum anderen kann er sich gemäß § 266a Strafgesetzbuch (StGB) strafbar machen, wenn er Beiträge nicht an die zuständigen Sozialversicherungsträger abführt. Allein deshalb muss der

Geschäftsleiter immer versuchen, zumindest diese Beiträge zu zahlen. Ansonsten droht ihm zusätzlich die Gefahr, dass er diese Beiträge persönlich zahlen muss, denn die zuständige Krankenkasse kann den Geschäftsleiter persönlich in Anspruch nehmen und ihm gegenüber eine Schadensersatzforderung geltend machen (§ 266a StGB i. V. m. § 823 Abs. 2 BGB).

Ähnliches gilt im Hinblick auf die fälligen Steuerverpfichtungen. Dabei droht ganz besonders bei der

Nichtzahlung von Lohnsteuern, jedoch auch bei der Nichtzahlung von Umsatz-, Körperschafts- oder Gewerbesteuern, die persönliche Haftung des Geschäftsleiters (§§ 34, 69 Abgabenordnung AO).

Sollte eine Insolvenz angemeldet werden müssen, so ist die Liquiditätsplanung (oder auch von den Gerichten häufig Finanzplanung genannt), das zentrale Element der unternehmerischen Steuerung durch den Sachwalter oder den Insolvenzverwalter. Wenn auf Basis des Insolvenzplanes die korrespondierende Liquiditäts- bzw. Finanzplanung für die kommenden 3 Monate positiv ausfällt, kann das Verfahren eingestellt werden.

## Anforderungen der Finanziers:

Sowohl Eigen-, als auch Fremdkapitalgeber, haben ein nachdrückliches Interesse an der Sicherstellung der Zahlungsfähigkeit der finanzierten Kapitalgesellschaft. Deshalb ist die Geschäftsleitung immer verpflichtet, darüber kontinuierlich zu berichten und mit Hilfe eines Risiko- und Frühwarnsystems mögliche Gefahren frühzeitig zu kommunizieren, um entsprechende Kapitalmaßnahmen einzuleiten. Einen Umstand, den auch der Gesetzgeber entsprechend vorgegeben und die Geschäftsleitung dazu gesetzlich verpflichtet hat. Es obliegt damit der Geschäftsleitung eine Liquiditätsplanung als permanentes

Steuerungs- und Überwachungssystem zu installieren.

## Bausteine der Liquiditätsplanung:

Der Liquiditätsplan verknüpft die kurzfristigen finanzwirtschaftlichen Planungsrechnungen,  die Finanzbuchhaltung, das operative Management  sowie  mathematische  Prognoseverfahren zur Ableitung von zeitlichen Eintrittswahrscheinlichkeiten der Zahlungsströme.

- 1. Finanzwirtschaftliche Ist-Abrechnung bedeutet Finanzbuchhaltung:

Erlös-/Aufwandskonten, Bilanzkonten, Kreditoren-Management, Debitoren-Management

- 2. Finanzwirtschaftliche Planungsrechnung bedeutet Operative-Planung: GuV-Planung, Investitionsplanung, Finanzplanung, Bilanzplanung
- 3. Unternehmensmanagement bedeutet Operatives Management: Planungen, Terminierungen, Konditionen und Verträge
- 4. Mathematische Methoden bedeutet Prognoseverfahren Zeitreihen, Eintrittswahrscheinlichkeiten

Die  Darstellung  macht  deutlich,  dass  die  Liquiditätsplanung  als  eine  wesentliche  Grundlage  die operative Planung nutzt, darüber hinaus aber auch die gebuchten Ist-Werte, die Inputs des operativen Managements und mathematische Methoden verwendet.

## Finanzbuchhaltung:

Mit der Abbildung der vorgefallenen Geschäftsvorfälle in der Finanzbuchhaltung wird die Grundlage geschaffen, die historischen Daten wirtschaftlich strukturiert aufzubereiten und damit die  Grundlage  für  die  Ermittlung  des tatsächlichen wirtschaftlichen Erfolgs zu schaffen. Alle finanzwirtschaftlichen  Zusammenhänge  sind  dokumentiert  und  können  als  Ausgangspunkt  für  die Ableitung von zukünftigen Geschäftsvorfällen genutzt werden. Wichtig ist dabei, dass der tatsächliche Anfall der Einnahmen und Ausgaben terminiert vorliegt und aus der Debitorenund Kreditorenbuchhaltung zukünftige (meist eher kurzfristige) Zahlungsverpflichtungen abgeleitet werden können.  An  dieser  Stelle  ist  zu  bedenken,  dass  es  sich  aber  immer  nur  um  bereits  dokumentierte zukünftige  Ein-  und  Auszahlungen  handelt,  denn  ohne  Beleg  erfolgt  keine  Dokumentation.  Des Weiteren können aus den hinterlegten Zahlungsbedingungen (sowohl debitorisch als auch kreditorisch),  die  kurzfristigen  anstehenden  Ein-  und  Auszahlungsverpfichtungen  termingerecht abgeleitet  werden.  Systemisch  erstellte  Zahlungsläufe  sind  für  die  kommenden  2  bis  3  Wochen hilfreich, spiegeln aber nicht die zeitlich weiter vorausschauenden anfallenden Ein- und Auszahlungen wider.

Als Aufsetzpunkt einer Liquiditätsplanung sind die Bilanzkonten von entscheidender Bedeutung. Wichtigste Größe ist der Aufsetzpunkt der Liquiditätsplanung mit dem aktuellen Stand der liquiden Mittel. Das Anlage- und Umlaufvermögen und die Passivseite, mit den unternehmerischen Verbindlichkeiten, sind für die Wandlungsprognosen dieser Bestandsgrößen in Ein- und Auszahlungen maßgebliche Grundlagen.

## Operative Planung:

Die operative Planung mit dem Jahresplan/Budget bildet die betriebswirtschaftliche Grundlage für die Abbildung der erwarteten wirtschaftlichen Entwicklung des Unternehmens auf

Monatsbasis. Für die Entwicklung des Budgets sind, unter der Führung des Finanzverantwortlichen, die Erwartungen  und  Zielsetzungen  aller  Organisationseinheiten  zusammengeflossen  und  mit  der Geschäftsführung kalibriert worden. Nach der Verabschiedung des Budgets durch die verantwortlichen Gremien, bildet es den Handlungsrahmen der kommenden 12 Monate ab.

Der Schwerpunkt dieser Planung liegt häufig auf der Gewinn- und Verlustrechnung (GuV-Planung) mit den Umsatz- und Kostenabschätzungen für das kommende Geschäftsjahr, da diese den wirtschaftlichen Erfolg des Unternehmens repräsentiert. Daneben hat der Investitionsplan einen ebenso hohen Stellenwert, da darüber die Weiterentwicklung der Unternehmensinfrastruktur determiniert wird. Die geplanten Investitionen spielen eine zentrale Rolle für die Finanzplanung, da es sich in der Regel um signifikante Auszahlungsbeträge handelt, die unabhängig vom operativen Geschäftsverlauf zeitlich unstet anfallen.

Als nächsten planerischen finanzwirtschaftlichen Baustein gibt die Finanzplanung Auskunft über die Quelle(n) der Finanzierung. Das heißt auf Basis der integrierten Cashflow-Planung wird deutlich, ob und  wann  Finanzierungsbedarf  besteht  bzw.  Finanzierungsrückführungen  in  den  entsprechenden Monaten möglich sind. Abschließend leitet sich die Bilanzplanung aus den anderen Planungselementen ab und bildet den Abschluss der operativen finanzwirtschaftlichen Planung. Inwieweit diese auf monatlicher Basis erstellt, wird hängt von den Vorgaben des Managements bzw. der Anteilseigner oder finanzierenden Banken ab, und dem ggf. verwendeten Planungssystem, das eine Planbilanz automatisiert erstellen kann.

## Operatives Management:

Das  operative  Management  verfügt  über  entscheidendes  Wissen  bezüglich  der  kommenden finanziellen Verpflichtungen bzw. eingehenden Finanzströme.

Der Vertrieb hat relativ konkretes Wissen über die zukünftig zu erwartenden Umsätze mit den Kunden oder am Point of Sales (POS). Insbesondere monatliche Verschiebungen oder Veränderungen der Planzahlen sollten bekannt und abschätzbar sein. Dasselbe gilt für vereinbarte Veränderungen von Konditionen, Zahlungsbedingungen oder Preisen.

Aus dem Einkauf und der Logistik lassen sich die Zahlungsverpflichtungen für die kommenden  Monate,  aufgrund  der  bestellten  und  geplanten  An-  und  Auslieferungen,  gesichert ableiten. Im Zusammenspiel mit den Zahlungskonditionen ergibt sich daraus für die kommenden 3-4 Wochen ein sehr konkretes Bild für die Liquiditätsplanung.

Der Bereich der Produktion verfügt über eine vorausschauende Mengenplanung der kommenden Monate, was damit den Verbrauch/Einkauf von Herstellungsmaterialen bestimmt, sowie den Einsatz von personellen Ressourcen.

Ausgehend von der Investitionsplanung, führen die operativ Projektverantwortlichen in der Regel eine rollierende Planung über den Realisierungsfortschritt durch, woraus sich die entstehenden Fälligkeiten von korrespondierenden Zahlungsverpflichtungen ableiten lassen.

## Prognoseverfahren:

Auch wenn sich aus den drei bereits beschriebenen Bausteinen der Liquiditätsplanung bereits konkrete und gute abgeschätzte Zahlungsströme ableiten lassen, verbessert die Anwendung

Zusammenfassend handelt es sich bei den anzuwendenden mathematischen Verfahren Eintrittszeitpunkten.

von mathematischen Prognoseverfahren die Abschätzung des Eintrittes von Ein- und Auszahlungen nachhaltig. Insbesondere bei Unternehmen mit stetig wiederkehrenden Geschäftsvorfällen lässt sich mit Hilfe dieser Verfahren die zukünftige Eintrittswahrscheinlichkeit von Zahlungsströmen, dem Zeitpunkt und der Höhe nach, nachhaltig verbessern. Beispielhaft sein an dieser Stelle die Ableitung der Umsatzkurve für ein Consumer Goods Unternehmen genannt. Unter der Bedingung von einem konstanten Netz an Vertriebspunkten, können aus den tatsächlichen Umsätzen der letzten Jahre Umsatzkurven abgeleitet werden, die die Grundlage für die Herleitung der Einzahlungen aus Verkäufen bilden. Noch genauer wird diese Prognose, wenn die historischen Einzahlungen die Grundlage der Verteilungskurve bilden, da diese für die Liquiditätsplanung auf Tages- oder Wochenbasis valider ist. in  der  Regel  um  Verfahren zur Ableitung einer zeitlichen Verteilungskurve oder der Herleitung von

## Liquiditätsplanung:

Nach  der  Einordnung  der  Liquiditätsplanung  in  das  planerische  Umfeld  und  die  grundsätzliche Verwendung  von  Datenquellen,  gilt  es  im  nächsten  Schritt eine Liquiditätsplanung inhaltlich aufzubauen und mit Daten zu füllen.

## Grundsätze einer Liquiditätsplanung:

## Sichtweise als Wallet-Planung:

Die alles entscheidende Sichtweise der Liquiditätsplanung ist das Verständnis, dass die

Liquiditätsplanung als Abbild des Wallet eines Unternehmens zu sehen ist. Es zählt in allen Dimensionen immer nur die Fragestellung: 'Wann und in welcher Höhe werden aktuelle oder erwartete zukünftige Geschäftsvorfälle monetär wirksam?'.

Am Ende muss die Liquiditätsplanung immer zu einem permanenten positiven Cashbestand führen, da ansonsten der Tatbestand der Zahlungsunfähigkeit greifen würde.

## Verwendung von Brutto-Werten:

Im Gegensatz zu allen anderen Planungsrechnungen muss die Liquiditätsplanung, da ihr Ziel eine Abbildung der zukünftigen Zahlungsströme - also der Ein- und Auszahlungen ist, immer auf Bruttowerten basieren. Daraus ergibt sich zwangsläufig die Notwendigkeit, eine Berechnung und Abschätzung der zu zahlenden oder zu erhaltenden Umsatzsteuer vorzunehmen (siehe dazu Abschn. 6.3.1).

## Kalendarischer Fokus statt Monatssichtweise:

Einer  der  wichtigsten  Grundsätze  ist  die  kalendarische  Sichtweise  auf  alle  Geschäftsvorfälle,  was bedeutet, dass alle Ein- und Auszahlungen auf Basis eines Kalendertages zu planen sind. Nur dann ist es möglich, sowohl eine Sicht nach Kalenderwochen als auch nach

Monaten zu generieren. Versuche nur auf Wochenbasis zu planen sind zum Scheitern verurteilt, da dann  zum  Monatsultimo,  aufgrund  der  Wochensicht  ohne  Tagesdatum,  kein  Liquiditätsbestand ermittelt werden kann, was aber eine unbedingte Anforderung an eine Liquiditätsplanung ist. Es muss der Kanon Tag - Woche - Monat mit den jeweiligen Cashbeständen zum Stichtag sichtbar sein.

Des Weiteren gilt die Maxime, jeden Tag zahlungsfähig zu sein. Konkret heißt dies, dass auf Monatsbasis und auf Wochenbasis die Liquidität positiv sein kann, aber an einem konkreten Tag können Zahlungen aufgrund von fehlenden finanziellen Mitteln nicht ausgeführt werden -  dann  wäre  eine  Zahlungsunfähigkeit  gegeben.  Aus  der  Sicht  des  Liquiditätsmanagements  ist  es notwendig  auf  Tagesbasis  zu  agieren,  da  im  Falle  eines  Liquiditätsengpasses  'auf  Sicht  gefahren' werden muss. Das heißt, die Zahlläufe jeden Tages

müssen gegen die Liquidität gespiegelt und eine mögliche Verschiebung von Zahlungen auf die nächsten Kalendertage geprüft werden. Dies gilt insbesondere, wenn wertmäßig große Einzahlungen ausstehen und nur auf Basis deren Monetarisierung offene Zahlungen geleistet werden können.

## Rollierende Flussrechnung statt Zeitpunktbetrachtung:

Die Liquiditätsplanung ist ihrem Wesen nach eine permanente und rollierende Aufgabe, um die tägliche Zahlungsfähigkeit sicher zu stellen. Deshalb muss mindestens einmal in der Kalenderwoche eine Aktualisierung der vergangenen Tage erfolgen und eine Planung für die kommenden Tage vorgenommen werden. Bei einer stringent strukturierten Liquiditätsplanung sind die erwarteten Ein- und Auszahlungen auf Basis der Liquiditätsplanungen bereits der Höhe und dem  Zeitpunkt  nach  planerisch  determiniert.  Die  Aktualisierung  konkretisiert  dann  lediglich  und ergänzt diese um unvorhersehbare Zahlungsverpflichtungen. Abschließend sollte auch eine Aktualisierung  der  mittelfristigen  Erwartungen  (2  bis  4  Wochen)  erfolgen,  um  den  Ausblick  für  die kommenden  3  Monate  möglichst  genau  zu  prognostizieren.  Nur  so  können  Zahlungsengpässe frühzeitig erkannt werden und entsprechende Maßnahmen ergriffen werden.

## Grundsätzliche Struktur einer Liquiditätsplanung:

Die Liquiditätsplanung ist eine Methode der direkten Ermittlung einer Mittelflussrechnung und folgt in ihrem grundsätzlichen Aufbau der KFR bzw. Cashflow-Rechnung.

Daraus  ergibt  sich  die  folgende  Grundstruktur,  die  sich  aus  den  verschiedenen  Cashflows  bzw. Zahlungsströmen zusammensetzt.

## Grundsätzliche Struktur einer Liquiditätsplanung:

Der Cashflow aus operativer Tätigkeit stellt die operativen Einnahmen und Ausgaben gegenüber, im Wesentlichen im Schema einer GuV. Der investive Cashflow spiegelt die Investitionstätigkeiten wider, der steuerliche Cashflow Verpflichtungen gegenüber dem Finanzamt und der Cashflow aus Finanzierungen die Finanzierungsplanung.

Die im Folgenden dargestellten Cashflows können als erste Blaupause für den Aufbau einer Liquiditätsplanung genutzt werden, um diese dann unternehmensspezifsch anzupassen. Die  jeweiligen  Cashflows  müssen  je  nach  Branche  und  Sektor,  in  dem  ein  Unternehmen  tätig  ist, differenziert werden (siehe dazu Kap. 5). Dabei ist es wichtig, die jeweiligen

Cashflows  genau  zu  definieren,  um  die  Zuordnungen  der  Zahlungsströme  eindeutig  vornehmen  zu können.

Der operative Cashflow stellt die operativen Einnahmen und Ausgaben gegenüber, im Wesentlichen im Schema einer Gewinnund Verlustrechnung (GuV) oder auch einer betriebswirtschaftlichen Auswertung (BWA).

Operativer  Cashflow=Operative  Einzahlungen  (Umsatz,  Sonstige  Erlöse)-Operative  Auszahlungen (Ware/Material, Personal, Lager/Logistik, Raum, IT/Kommunikation, Versicherung/Beiträge, Beratung, Verwaltung, Sonstiges, Reise/Kfz)

Der  operative  Cashflow  ist  das  Herzstück  der  Liquiditätsplanung,  da  durch  die  unternehmerische Tätigkeit die wesentliche Wertschöpfung und damit Liquidität geschaffen wird.

Die dargestellten Elemente sind weder ausschließlich noch als zwingend anzusehen, sondern spiegeln eine  Standardstruktur  wider.  Bei  dem  Aufbau  einer  Liquiditätsplanung  ist  darauf  zu  achten,  nur Elemente zu definieren, die auch eine entsprechende Wertigkeit im Sinne ihres monetären Umfanges auf die Liquidität haben. Es gilt also: da zusammenfassen, wo möglich, und da zu detaillieren, wo nötig. Bis auf die Kfz-Steuer (als Teil der Kfz-Kosten) sollten alle steuerlichen und finanzierungsrelevanten Zahlungskategorie außen vor Bleiben -

es ist nicht das Ziel eine GuV oder BWA nachzubilden.

Beim investiven Cashflow liegt der Schwerpunkt auf den Auszahlungen, die die Investitionen nach sich ziehen.

Investiver Cashflow=Auszahlung für Investitionen (Investitionen Software, Investitionen Sachanlagen)Einzahlung aus De-Investition (Verkauf von Anlagegütern)

Die möglichst der Höhe und dem Zeitpunkt nach akkurate Berücksichtigung der Investitionsauszahlungen ist zwingend notwendig, da es sich in der Regel um  signifikante Größenordnungen handelt, die einen nachhaltigen Effekt auf die Liquidität haben. Für  den  steuerlichen  Cashflow  ist  keine  weitere  Detaillierung  nötig,  da  die  beiden  dargestellten Kategorien 'Umsatzsteuer' und 'Gewerbe-/Ertragssteuern' eineindeutig in ihrer Definition sind. Der wichtigsten Punkt bei der Modellierung dieses Cashflows ist die Beachtung der vorgegebenen Zeitpunkte der Fälligkeit der Zahlungen. Diese sind nicht veränderbar  und  die  Liquidität  immer  muss  ausreichen,  um  diese  Zahlungen  zeitrecht  leisten  zu können.

Damit zum letzten Element der Cashflow-Struktur, der Cashflow-Finanzierung. Hier werden alle Geschäftsvorfälle subsummiert, die eine externe Zuführung oder einen Abfluss an externe Finanzierungsgeber darstellen.

Cashflow Finanzierung= Zuführungen (Eigenkapital, Kredite/Darlehen, Förderungen)-

Aus-/Rückzahlungen (Entnahmen/Ausschüttungen, Zinsen, Tilgung, Rückzahlung Förderungen)

Im Gegensatz zu GuV oder BWA sind die Zinsen dieser Kategorie zugeordnet, da sie in einem  unmittelbaren  Zusammenhang  mit  der  Finanzierung  stehen  und  nicht  durch  die  operative Tätigkeit  induziert  sind,  sondern  auf  den  jeweiligen  Ständen  der  externen  Finanzierungsquellen basieren. Förderungen haben einen eigenen Charakter und müssen im Rahmen der Liquiditätsplanung jeweils gesondert betrachtet und geplant werden. Dazu sind die Bedingungen und Regelungen der Förderung mit dem operativen Management abzustimmen und zu integrieren.

Zusammenfassend lässt sich die Liquiditätsplanung als Flussrechnung damit wie folgt darstellen:

Liquiditätsplanung:

Anfangsbestand liquide Mittel

- +/-Operative Zahlungsströme
- +/-Investive Zahlungsströme
- +/-Steuerliche Zahlungsströme
- +/-Finanzierungsströme
- =Endbestand liquide Mittel

## Branchenspezifische Strukturierung und Aufbau:

Die bis hierher erfolgte Einordnung und Strukturierung der Liquiditätsplanung hat die Grundlagen und Grundsätze geklärt und definiert, verbleibt aber damit zwangsläufig auf einen generalistischen Niveau. Für die Entwicklung einer Liquiditätsplanung in der Praxis ist es wichtig, die Frage nach dem Planungsvorgehen zu beantworten.

Und  an  dieser  Stelle  ist  es  unabdingbar,  die  Anwendungsmethodik  weiter  zu  spezifizieren,  da signifikante Unterschiede zwischen den Sektoren und Branchen beim operativen Cashflow bestehen. Ein reiner Einzelhändler hat im Vergleich zu einem produzierenden

Unternehmen deutlich andere Liquiditätscharakteristiken. Während der Einzelhändler z. B. relativ unmittelbar die Einnahmenseite herleiten kann, muss der Produzent deutlich mehr Aufwand betreiben und andere Planungsgrundlagen nutzen, um die Einnahmenseite zu prognostizieren.

Im ersten Schritt erfolgt deshalb die Definition von Sektoren und Branchen, nach denen im zweiten Schritt die einzelnen Elemente der Liquiditätsplanung des operativen Cashflows mit den Planungsgrundlagen und Methodiken verknüpft werden.

Der Planer kann nach der Sektor-Branche Kategorisierung seines Unternehmens, die entsprechenden Liquiditätsmerkmale identifizieren und analysieren. Im nächsten Schritt erfolgt durch die weitere Klassifizierung der Liquiditätsbausteine in Bezug auf die jeweilig relevanten Planungselemente eine vertiefende Darstellung, in welcher Mechanik die operativen Einnahmen und Ausgaben geplant werden sollten.

Durch diese systematische Struktur ersteht für den Planer ein Baukasten, durch den er sich zügig zu seinen relevanten Planungselementen und deren Planungsmechanik navigieren kann.

## Sektoren- und Branchenstruktur:

In Anlehnung an die volkswirtschaftliche Definition von Wirtschaftssektoren erfolgt eine Einteilung der Unternehmen in folgende 3 Bereiche:

- • Handel
- • Produktion
- • Dienstleistung

Im Folgenden werden diese Sektoren definiert und in einzelne Branchen spezifiziert.

## Handel:

Für die Liquiditätsplanung ist der Sektor Handel definiert als funktioneller Handel, d. h. die zugeordneten Branchen setzen Güter, die sie von anderen Marktteilnehmern beschaffen und i.  d. R. nicht selbst be- oder verarbeiten (Handelswaren; Manipulationen wie

- z.  B.  Sortieren, Mischen, Abpacken gelten dabei nicht als Be- oder Verarbeitung), an Dritte ab.

Daraus abgeleitet sind für die Liquiditätsplanung folgende Elemente von besonderer Bedeutung:

- • Einnahmen als Monetarisierung des Absatzes
- • Beschaffungsausgaben zum Erwerb der Handelsware
- • Strukturkosten der Absatzorganisation

Diese grundsätzlichen Feststellungen gelten für alle Branchen in diesem Sektor, die aber jeweils differenzierte Liquiditätsmerkmale aufweisen.

Insbesondere  für  die  Einnahmenseite  erfolgt  eine  Strukturierung  des  Handels  in  unterschiedliche Branchen.

Beim Einzelhandel handelt es sich um den klassischen Verkauf der Ware in Verkaufsräumen an den Endkunden. Durch die nahezu unmittelbare Monetarisierung sind die Einnahmen umgehend verfügbar und fließen werkstägig. Ein zu beachtender Zeitversatz entsteht durch die Abwicklung der Kartenzahlungen, die über einen Payment Provider

(Zahlungsabwickler) erst nach 2 bis 3  Tagen dem Unternehmen tatsächlich zufließen. Demgegenüber  bilden die Warenbeschaffungskosten, die Verkaufsstruktur (Mieten, Personal,

Werbung) und Lager-/Logistik die wesentlichen Ausgabenströme ab.

Im eCommerce - dem Verkauf der Ware über einen digitalen Shop an den Endkunden - verzögert sich die Monetarisierung der Einnahmen durch Zielkäufe und durch die

Abwicklung von Kartenzahlungen über einen Payment Provider, während die Ausgaben für die Verkaufsstruktur, bis auf die Werbeaufwendungen, durch die Aufwendungen für den Shopbetrieb ersetzt werden. Lager- und Logistik bekommen durch den Absatzprozess der Versendung einen deutlich höheren Anteil an den Ausgaben.

Demgegenüber hat der Großhandel - der Verkauf der Ware in großen Mengen an Geschäftskunden

(B2B) - grundsätzlich andere Mechanismen. Die Einnahmenseite wandelt sich  zum  nahezu  kompletten  Zielkauf  und  auf  der  Ausgabenseite  dominieren  die  Ausgaben  für

Warenbeschaffung und Lager-/Logistik. Zu einem gewissen Teil führen auch die Verkaufsstrukturen zu entsprechenden Ausgaben.

Wichtig  ist  bei  dieser  Betrachtungsweise,  welchen  Einfluss  am  Ende  die  Absatzprozesse  auf  die Liquidität haben. Der Einzelhandel erzielt nahezu direkt die korrespondierenden Einnahmen, während der Großhandel durch das vereinbarte Zahlungsziel erst im

Zeitversatz den Absatz monetarisieren kann.

Die Warenbeschaffung ist die entscheidende Stellgröße im Rahmen der Liquiditätsplanung im Handel. Es sei nochmals darauf hingewiesen, dass es sich um die Fälligkeit der tatsächlichen Wareneinkäufe handelt, nicht um den betriebswirtschaftlichen Wareneinsatz.

Das Warenlager im Handel ist die wesentliche Größe für die Kapital- und damit auch die Liquiditätsbindung.

Die Verkaufsstruktur folgt i. d. R. bestehenden Verträgen mit bekannten Fälligkeiten und Volumina, während Lager-/Logistikausgaben Volumen getrieben sind und meistens nach vereinbarten Abrechnungsrhythmen fällig werden.

## Produktion:

Unter dem Sektor Produktion sind alle Unternehmen subsummiert, die eine Weiterverarbeitung von Rohstoffen  und  Grundgütern  zu  einem  handelbaren  Gut  vornehmen.  Der  Sektor  umfasst  das produzierende Gewerbe einer Volkswirtschaft und es wird deshalb auch häufig  das  Synonym  'industrieller  Sektor'  verwendet.  Zu  diesem  Sektor  zählen  das  verarbeitende Gewerbe, die Industrie, das Handwerk, die Energiewirtschaft, die Energie- und

Wasserversorgung. Das Baugewerbe wird zunehmend auch diesem Sektor zugerechnet, aus Sicht der Liquiditätsplanung erfolgt allerdings eine Klassifizierung zum Dienstleistungssektor. Durch den Produktionsprozess mittels des Einsatzes von Investitionsgütern,

ist der Sektor Produktion material- und kapitalintensiv.

Eine Aufteilung in Branchen ist in diesem Sektor aus Sicht der Liquiditätsplanung, aufgrund des Charakters der Güter (Vorleistungs-, Investitions-, Gebrauchs- und Verbrauchsgüter) nicht notwendig, sondern es erfolgt vielmehr eine Differenzierung nach der

Absatzseite des Sektors:

- • Absatz direkt an den Endkunden (B2C)
- ·  Absatz  an  einen  Geschäftskunden  (B2B)  -  Absatzmittler  (Großhandel)  oder  weiterverarbeitendes Unternehmen

Beim Endkunden gelten die bereits unter den Branchen Einzelhandel und eCommerce

(siehe oben) dargestellten Liquiditätsmechaniken. Die Endkundeneinnahmen per Rechnung unterliegen  einer  schnelleren  Wandung  in  Cash,  während  die  Seite  der  Geschäftskunden  durch Rechnungen auf Ziel sich mit einem Zeitversatz verschieben.

An dieser Stelle muss erwähnt werden, dass in der B2B Branche das Thema des Klumpenrisikos, also eine  geringe  Anzahl  an  Kunden  mit  hohem  Umsatzanteil,  aus  Liquiditätssicht  eines  besonderen Augenmerks  bedarf.  Besonders  deutlich  wird  dies  am  Beispiel  eines  Automobilzulieferers,  der  nur einen Fahrzeugproduzenten als Kunden hat. Die

Liquidität hängt dann zu 100 % an diesem einen Kunden, dessen wirtschaftlicher Performance und Zahlungsmoral.

Der Rohstoff-/Materialeinkauf - nicht der Verbrauch - ist die wesentliche treibende

Kraft  der  Ausgaben.  Es  ist  die  Aufgabe  der  Liquiditätsplanung,  diesen  möglichst  zeitgenau  zu terminierten und zu planen. Grundlage dafür ist zum einen die Produktionsplanung

des  operativen  Managements,  zum  anderen  die  Lagerbestände  an  Roh-/Hilfs-  und  Betriebsstoffen sowie  Halbfertigwaren  aus  der  Finanzbuchhaltung.  Ergänzt  wird  die  Prognose  um  den  Stand  der Lieferantenverbindlichkeiten.

Ebenso wichtig sind die bezogenen Leistungen (Strom, Gas, Wasser etc.), die neben den Materialkosten einen wesentlichen Kostenfaktor darstellen können. Aufgrund der verbrauchsorientierten  Abrechnung  ist  die  Produktionsplanung  entscheidend  für  die  Prognose  der fälligen Ausgaben.

## Dienstleistung:

In der volkswirtschaftlichen Gesamtrechnung zählen zum Dienstleistungssektor die Wirtschaftsbereiche Handel, Gastgewerbe und Verkehr, Finanzierung, Vermietung und Unternehmensdienstleister sowie öffentliche und private Dienstleister. Dienstleistung ist eine Tätigkeit, die ein Unternehmen gegen Entgelt für andere ausübt. Im Gegensatz zu den Sektoren Handel und Produktion, handelt es sich bei einer Dienstleistung um ein immaterielles Gut, das allerdings zur Erstellung eines materiellen Gutes führen kann (z. B. Gebäude, Software). Aus Sicht der Liquiditätsplanung erfolgt eine Aufteilung des Sektors Dienstleistung anhand des Charakters der zu erbringenden Leistung:

- • Erbringung einer reinen Dienstleistung
- • Erstellung eines Gewerkes durch die Erbringung einer Dienstleitung

Diese  Differenzierung  hat  einen  nachhaltigen  Einfluss  auf  die  Planung  der  Einnahmenseite,  da  die Zahlungszeitpunkte sich deutlich zu unterscheiden.

Bei der reinen Leistungserbringung erfolgt eine Abrechnung der Leistung monatlich i. d. R. auf Basis der zeitlichen Inanspruchnahme der genutzten Dienstleistung mit einer vereinbarten Fälligkeit.

Wird demgegenüber ein Gewerk erstellt, sind die Zahlungszeitpunkte abhängig von dem erzielten  Fortschritt  der  Erstellung  des  Gewerkes.  Dabei  handelt  es  sich  bis  zur  Fertigstellung  um Abschlagszahlungen mit einer abschließenden Abschlussrechnung. Für die Liquiditätsplanung ist damit die Projektplanung des operativen Managements eine der wesentlichen

Datenquellen  für  die  Prognose  der  Einnahmen.  Klassisches  Beispiel  ist  die  Softwareerstellung,  die Meilensteinen folgt und entsprechend der Erreichung zu Rechnungsstellungen und damit in Folge zu Einnahmen führt.

Auf  der  Ausgabenseite  dominieren  naturgemäß  die  Ausgaben  für  Personal,  die  basierend  auf  den bestehenden Anstellungsverträgen und möglichen Zusatzvereinbarungen zu prognostizieren sind. Wichtig ist in diesem Zusammenhang, dass jegliche personelle Ressource gemeint ist, d. h. auch extern beschaffte Personalressourcen. der entsprechenden Gegenstände oder aber zu einer monatlichen Nutzungsgebühr. Somit bedarf es neben  der  Aufwandsplanung  auch  die  Nutzung  der  Investitionsplanung  als  Planungsgrundlage.  Im operativen  Cashflow  sind  allerdings  nur  die  Nutzungsentgelte  für  fremde  technische  Hilfsmittel  zu

Der Einsatz technischer Hilfsmittel (z. B. Computer, Maschinen etc.) führt zum Erwerb betrachten.

Für Handwerk und Bauunternehmungen ist die Ausgabengröße Material von großer Bedeutung, da diese in Vorleistung einzukaufen sind. Deshalb muss für diese Kategorie eine dezidierte Planung erfolgen. Liquiditätsgetrieben sollten, aufgrund der großen Belastung für das ausführende Unternehmen, Vorauszahlungen auf den Auftrag oder das Material mit dem Kunden vereinbart werden.

## Liquiditätsplanung der Cashflows:

Im Folgenden wird die Liquiditätsplanung der einzelnen Cashflows generell oder differenziert nach

Branchen detailliert beschrieben. Der Fokus liegt dabei auf den wesentlichen Elementen der jeweiligen Cashflows - weitere Spezifizierungen können nötig sein, sind aber von der jeweiligen Unternehmenssituation abhängig. Zum Beispiel die Definition einer gesonderten Ausgabenkategorie für Zahlungen an einen Lieferanten, der gleichzeitig auch Gesellschafter des Unternehmens ist.

## Branchenbezogene Planung des operativen Cashflows:

Nach der Zuordnung des zu planenden Unternehmens in die Branche und den Sektor, erfolgt eine Analyse der Elemente der operativen Einnahmen- und Ausgabenseiten im Zusammenspiel mit den Bausteinen der Liquiditätsplanung.

Für jede der Kategorien werden diese gegen die Planungselemente gemappt und es erfolgt eine Beschreibung des planerischen Zusammenspiels zur Ermittlung der zukünftigen Zahlungsströme.

Aus Vereinfachungsgründen werden die Bausteine wie folgt abgekürzt:

- • Finanzbuchhaltung=FIBU
- • Operative Planung=OPLA
- • Operatives Management=OPMT
- • Prognoseverfahren=PRVR

Für  jeden  dieser  Bausteine  wird  im  Mapping  die  jeweilige  Basisgröße  der  Planung  benannt  und beschrieben, aber auch das Zusammenspiel dieser, um eine valide Planung aufzustellen.

Zusätzlich wird, nach der Fristigkeit des jeweiligen Planungsgegenstandes, ausgehend vom Planungsdatum differenziert in:

- • Aktuell=kommende 4 Wochen
- • Kurzfristig=5. bis 13. Woche
- • Mittelfristig=ab der 14. Woche

Für wie viele Wochen die Planung erstellt werden soll hängt von den Vorgaben ab. Generell hat sich ein Planungszeitraum über mindestens 6 Monate bewährt, aber noch besser ist  eine  Liquiditätsplanung  für  ein  Kalender-  oder  Geschäftsjahr.  Dabei  verlieren  allerdings  die Planwerte des 2. Halbjahres deutlich an Planungssicherheit, sowohl der Höhe nach als auch nach zeitliche Eintrittswahrscheinlichkeit. Für die rollierende Planung ist es  demgegenüber  von  Vorteil,  einen  längeren  Zeitraum  zu  wählen,  um  diesen  dann  kontinuierlich fortzuschreiben und das Modell nicht mehrfach weiter kalendarisch ausbauen zu müssen.

## Operativer Cashflow-Handel:

Differenziert nach den Branchen des Sektors Handel erfolgt im Folgenden die beschriebene Darstellung des Mappings und der Planungsvorgehensweise.

Im ersten Schritt erfolgt die Ermittlung der operativen Einzahlungen aus dem Umsatz getrennt nach den definierten Branchen.

## Einzahlungen Handel:

Grundsätzlich  gilt  für  die  Einnahmenplanung,  dass  geplante  Netto-Umsätze  in  einen  Bruttoumsatz, mittels des anzulegenden Mehrwertsteuersatzes, gewandelt werden.

## Einzelhandel:

Auf der Einnahmenseite entfällt im Einzelhandel die Differenzierung der Fristigkeit, da der Umsatz sich nahezu direkt in Einnahmen wandelt.

Bei  der  Planung  der  Einnahmen  im  Einzelhandel  ist  die  Tagesverteilung  der  Einnahmen  die entscheidende Größe. Es muss demzufolge das Ziel sein, die Monatsplanung des

Umsatzes der OPLA in eine tagesbezogene Einnahmenplanung umzuwandeln. Nachfolgend wird auf Basis der historischen Daten der Tagesverteilung aus der Buchhaltung, mit Hilfe der PRVR, eine generelle Tagesverteilung der Einnahmen ermittelt. Dabei ist unbedingt zu beachten, dass Wochenende und Feiertage korrekt berücksichtigt werden, d. h. die entsprechende kalendarische Verschiebung vom Altjahr zum Planjahr erfolgt. Im nächsten Schritt ist über das OPMT zu ermitteln, in welchem Verhältnis die möglichen Zahlarten der Kunden (Bar, EC-Karte, Kreditkarte etc.) geplant und dementsprechend die Bruttoumsätze aufzuteilen sind.

Abschließend muss für die Cash-Einnahmen der kalendarische Versatz zwischen getätigtem

Kasseneinnahmen und Wertstellung auf dem Bankkonto ermittelt werden. In der Regel  handelt  es  sich  um  einen  Versatz  von1  bis  2  Tagen.  Nicht  zu  vergessen  ist  die  zeitliche Verschiebung der Wertstellung durch das Wochenende, d. h. die Cash-Einnahmen des Samstages (und eines möglicherweise Verkaufssonntages) werden frühstens am folgenden

Montag summarisch wirksam.

Für  die  Kartenzahlungen  ist  der  Auskehrrythmus  des  Payment  Providers  (Bank,  Zahlungsabwickler) anhand der vertraglichen Regelungen und der geübten Praxis zu ermitteln und entsprechend zu berücksichtigten.

Insgesamt bildet sich damit eine Tageseinnahme auf dem Bankkonto, die sich aus

Cash-Einnahmen der Vortage und Auskehrbeträgen der Payment Provider zusammensetzt. Summiert man die nach dem jeweiligen Monat, so ist im Vergleich zu OPLA eine signifikante Abweichung festzustellen, die zwangsläufig aufgrund der unterschiedlichen zeitlichen Zuordnung entsteht und nicht zu einer Verunsicherung des Planers führen sollte.

## eCommerce:

Beim eCommerce ist eine Differenzierung der Fristigkeit in aktuell und kurz-/mittelfristig vornehmen. Die Erwartung der kommenden 4 Wochen (aktuell) ist aufgrund der Ableitung aus der Vergangenheit und der aktuellen Bestellentwicklung konkret zu ermitteln.

Demgegenüber sind die kommenden Monate abhängig von der OPLA zu determinieren.

Die kurzfristigen Einnahmen determinieren sich zum einen aus den offenen Posten der Endkunden aufgrund der Bestellungen der letzten 2 bis 4 Wochen (unter der Annahme einer Fälligkeit von 30 Tagen) und aus der konkreten OPLA für den anstehenden Monat. den Fälligkeiten der Endkunden OP können daraus die erwarteten Einzahlungen der kommenden 4 Wochen abgeleitet werden. Im nächsten Schritt ist für die zu erwartenden Einnahmen über das OPMT

Zur Ableitung der Einnahmen aus den Endkunden OP (offenen Posten) sind mit Hilfe der historischen Daten aus der FIBU und der PRVR eine zeitliche Conversion Ratio der offenen Posten, sowie eine Ausfallquote auf Kundenforderungen zu ermitteln. Im Zusammenspiel mit und unter Anwendung der PRVR zu ermitteln, in welchem Verhältnis die Zahlarten der Kunden geplant sind. Dementsprechend sind die geplanten Bruttoumsätze aufzuteilen. Für die ermittelten Rechnungskäufe werden die oben beschriebenen Conversion

Rate  und  Ausfallquoten  angewendet,  während  für  die  Käufe  über  Zahlungsabwickler  (Payment Provider, Kreditkartenanbieter, Bank) der Auskehrrythmus dieser Abwicklers anhand der vertraglichen Regelungen und der geübten Praxis angelegt werden muss. Sollte mit einem Payment Provider ein gesicherter Rechnungskauf und die Abtretung der Forderung vereinbart sein, so entfällt die Anwendung der Ausfallquote. Allerdings ist darauf zu achten, dass die entsprechende Gebühr bzw. der einbehaltene Umsatzanteil des Payment Providers zu einer Umsatz- und damit Einnahmenminderung führt.

Im Falle der Nutzung von Online-Marktplätzen gilt ebenso, deren Auskehrrythmus auf

Basis der vertraglichen Vereinbarungen und den sofortigen Einbehalten der Gebühr zu berücksichtigen. Mit Blick auf die kurz- und mittelfristige Planung ist die OPLA die Ausgangsgröße für die Einnahmenplanung. Auf dieser Basis ist unter Anwendung der PRVR zu ermitteln, in welchem  Verhältnis  die  Zahlarten  der  Kunden  geplant  und  dementsprechend  die  Bruttoumsätze aufzuteilen sind. Für die weitere Herleitung gelten die oben dargestellten Planungsmechaniken für den zu erwartenden Einnahmenanteil aus zukünftigen Bestellungen.

## Großhandel:

Auch  beim  Großhandel  ist  eine  Differenzierung  der  Fristigkeit  in  aktuell  und  kurz-/mittelfristig vornehmen. Die Erwartung der kommenden 4 Wochen (aktuell) ist aufgrund der Ableitung aus der Vergangenheit und des aktuellen Auftragseinganges konkret zu ermitteln.

Demgegenüber sind die kommenden Monate abhängig von der OPLA zu determinieren.

Ausgehend von den offenen Posten der Kreditoren sind mit Hilfe der historischen Daten aus der FIBU und der PRVR eine zeitliche Conversion Ratio der offenen Posten, sowie eine Ausfallquote dieser zu ermitteln. Über die Fälligkeitskaskade lassen sich dann die erwarteten Einzahlungen ableiten.

Der Abgleich mit der OPLA für den entsprechenden Monat zeigt den noch erwarteten

Umsatz für diese Periode. Dieser wird dann ebenfalls über die dargestellte Umwandlungssystematik in aktuelle Einnahmen der kommenden 4 Wochen gewandelt.

Für die Kurz-/Mittelfristplanung ist wieder die OPLA der Ausgangspunkt, der mit dem OPMT auf mögliche Anpassung der Vertriebsplanung oder die Umsetzung von vertrieblichen, nicht geplante Verkauftaktionen, abzugleichen ist. Zusätzlich müssen erwartete

Änderungen in der Zahlungskonditionen mit den Kunden abgefragt werden, um diese entsprechend zu berücksichtigen.

In einem weiteren Schritt werden die operativen Einzahlungserlöse aus sonstigen Erlösen ermittelt. Eine Aufteilung nach Branchen ist dabei nicht von Nöten, der der Charakter der sonstigen Erlöse dem Grunde nach in allen Branchen ähnlich ist. Wichtig ist dabei,

dass es sich aus Sicht der Liquiditätsplanung um sonstige betriebliche Erlöse handelt, also Einnahmen, die dem betrieblichen Geschehen zuzuschreiben sind.

Es verbleiben als sonstige operative Einzahlungserlöse somit Erlöse, die regelmäßig und kontinuierlich dem Unternehmen zufließen. Diese gilt es aus den Konten er Finanzbuchhaltung herauszufiltern. Beispiele dafür sind: Mieteinnahmen durch Vermietung von

Grundstück- oder Gebäudeteilen, Erhalt von Vergütungspauschalen für Dienstleistungen,

Einnahmen aus bereits abgeschriebenen oder wertberichtigten Forderungen oder Versicherungsentschädigung.

Andere sonstige Erlöse, wie z. B. Gewinne aus der Veräußerung Gegenständen des Anlagevermögens fallen unter die jeweilige Cashflow-Kategorie, also im Beispiel unter den investiven Cashflow.

Alle reinen finanzbuchhalterischen sonstigen Erlöse, wie

- • Auflösung von Rücklagen
- • Auflösung oder Herabsetzung von Rückstellungen
- • Herabsetzung von Verbindlichkeiten
- • Währungsumrechnungen

sind für die Liquiditätsplanung irrelevant, da sie monetär nicht wirksam sind.

## Auszahlungen Handel:

Nach der Ermittlung der operativen Einzahlungen des Handels, erfolgt im zweiten Schritt Ermittlung der operativen Auszahlungen getrennt nach den definierten Branchen.

Allen Handelsbranchen gleich ist dabei die Thematik der Auszahlungen für die Warenbeschaffung und die Ausgaben für Ware bilden die wesentliche Größe. Von daher gilt die im Folgenden dargestellt Systematik für alle Branchen gleichlautend.

## Änderung Zahlungskonditionen Lieferanten

Die  aktuellen  Auszahlungen  für  Ware  lassen  sich  nahezu  unmittelbar  aus  den  offenen  Posten  der Warenlieferanten ableiten. Ausgehend von den Fälligkeiten können diese auf dem Zeitstrahl geclustert werden und bilden die wesentliche Grundlage der kommenden 2 Wochen. Für die Ausgabenplanung der folgenden Wochen (kurzfristig) sollten über das OPLA der  geplante  monatliche  Beschaffungswert  verprobt  werden  und  mit  dem  Anlieferungsmonitor abgeglichen werden. Der Anlieferungsmonitor, der im Einkauf erstellt werden sollte, gibt Auskunft über die Terminierung der erwarteten Lieferungen und damit der zu erwarteten Fälligkeiten aufgrund der erfolgten Anlieferung. Die PRVR kann dabei mit einer Ableitung einer Prognose aufgrund des bisherigen Anlieferungsverhaltens unterstützen. In Ausnahmesituationen, wie zum Beispiel der Störung von Lieferketten, sind die

Ergebnisse nur bedingt belastbar.

Bei  der  Ableitung  der  mittelfristigen  Ausgaben  für  Ware  ist  ein  ganzes  Bündel  an  Datenquellen notwendig. Zum einen die vorhandenen Lagerstände laut FIBU, ergänzt um die erwarteten Lieferungen als Ausgangspunkt, die dann ergänzt werden müssen um die Monatsplanung der OPLA und am besten noch verifiziert werden durch die aktuelle Abverkaufsplanung aus dem OPMT. Zusätzlich gilt es hier, die geplanten Einnahmen aus dem Verkauf der Ware (siehe oben) über die PRVR mit der historischen Wareneinsatzquote zu verproben. In der Handelsbranche ist dieser  Zusammenhang  immer  dann  zu  beachten,  wenn  die  aktuellen  Verkaufsmengen  nicht  der Planung  entsprechen.  Ansonsten  wird  in  der  Ausgabenprognose  im  Falle  eines  verminderten Abverkaufes zu viel oder zu wenig Ware planerisch beschafft. Deshalb ist immer eine Verprobung mit den, den Einzahlungen zu Grunde liegenden Umsätzen, vorzunehmen.

Aus diesem Grund muss auch die Abstimmung mit dem OPMT bezüglich vertrieblichen Sonderaktionen erfolgen, denn diese führen zwangsläufig zu einem deutlich höheren Warenabfuss als in der Planung vorgesehen.  Die  PRVR  kann  zum  Teil  unterstützen,  wenn  sich  aus  historischen  Aktionen  die entsprechenden Abverkaufseffekte ableiten lassen.

Generell  ist  mit  dem  OPMT  zu  überprüfen,  ob  sich  möglicherweise  die  Zahlungskonditionen  der Lieferanten geändert haben oder ändern werden, denn diese sind dann zwangsläufg entsprechend in der Terminierung der Warenzahlungen zu berücksichtigen. Einzelhandel

Im  Bereich  des  Einzelhandels  dominieren  zwei  Ausgabenkategorien:  die  Vertriebsstrukturausgaben (VKS) und die Ausgaben für Logistik und Versand. Dabei ist sind die VKS von deutlich höherer Bedeutung im Vergleich zu den Logistik- und Lagerkosten.

Bei der VKS setzen sich zusammen aus den Ausgaben für Miete und Personal - die beiden wesentlichen Ausgabenkategorien und auch Erfolgskriterien im Einzelhandel. Bei den Mietverträgen ist die Ausgabenplanung bezogen auf die Nettokaltmiete relativ eindeutig, die die bestehenden Mietverträge diese Kategorie der Höhe nach, dem Fälligkeitsdatum und der Entwicklung der Nettokaltmiete an sich (Staffelmiete) determinieren. Allerdings können die Expansion bzw. der Abbau der Verkaufsstellen (POS) diese entsprechend der Anzahl nach verändern. Deshalb ist mit dem OPMT immer auch eine Abstimmung für entsprechenden

Veränderungen vorzunehmen.

Bei den Mietnebenkosten (MNK) gilt im Grundsatz die beschriebene Logik wie bei den Nettokaltmieten, allerdings ist dieses Ausgabenelement inzwischen aufgrund der Volatilität der Energiekosten  zu  einem  variablen  Ausgabenfaktor  geworden  -  Abschlagszahlungen  verändern  sich permanent und Abschlussrechnungen können einige  Überraschungen  bergen.  Abschätzung  zu  den MNK sind deshalb schwierig, können aber möglicherweise mit Hilfe der PRVR aus volkswirtschaftlichen Daten validiert werden.

## eCommerce:

Beim eCommerce sind folgende 3 Ausgabenkategorien von Bedeutung:

- • Kosten für den Betrieb des WebShop, d. h. alle technischen und inhaltlichen (Content)

bezogenen Leistungen, um den Webshop 365/24 h erreichbar zu halten

- · Kosten für Online-Werbung/Marketing und zusätzlich alle Mailing-Aktionen von der Planung bis zum Versand
- • Lager- und Logistikkosten für die Ware, hierbei insbesondere die Verpackungs- und Versandkosten

Bei der Planung der Ausgaben für den Shopbetrieb ist insbesondere auf die Variabilität des Volumens zu achten, denn oftmals liegen volumenabhängige Kostenfunktionen vor, die entsprechend zu berücksichtigen sind und aus der OPLA abgeleitet werden müssen. Eine Abstimmung mit dem OPMT gibt Auskunft darüber, ob Funktionsanpassungen geplant sind (z. B. neue Zahlarten) und sind damit wichtig für die Berücksichtigung aller Zahlarten und auch entscheidende Hinweise für die Investitionsplanung. Gerade das Online-Werbe-/Marketing-Budget ist zwar oftmals in Summe für ein Jahr

in  der  OPLA geplant, die genaue Einsteuerung und damit der kalendarische Anfall unterliegen aber meistens den aktuellen Entwicklung im Abverkauf und der Wettbewerbssituation. Deshalb muss bei der Planung dieser Ausgabenkategorie zwingend die Abstimmung mit dem OPMT und seinen Planungen erfolgen. An dieser Stelle können auch mit Hilfe der PRVR die effektivsten Einsatzzeitpunkt des Marketingbudgets ermittelt werden. Die Lagerplanung unterliegen in großem Maße der Volumenentwicklung und dem damit notwendigen Räumlichkeiten. Aus diesem Grund muss eine Abstimmung mit der OPLA und dem OPMT erfolgen, um mögliche Verschiebungen zu antizipieren. Hier kann oftmals  mittels  der  PRVR  abgeleitet  werden,  wie  sich  die  Lagerfächenanforderungen  verändern werden. Wichtig ist es, bei der Lagerkosten nicht nur die Kosten der Fläche und Infrastruktur  zu  analysieren,  sondern  auch  im  Falle  von  variablen  externen  Mitarbeiterkapazitäten, diese zu planen und in der Liquiditätsplanung zu berücksichtigen. Bei eCommerce als Versandhandel sind die Logistikosten zwangsläufig ein wesentlicher Ausgabenfaktor, der allerdings aufgrund der Variabilität des Volumens in Kombination mit einem Stückpreis relativ gut zu prognostizieren ist. Auf Basis, der bereits für die anderen Ausgabenarten ermittelten Volumenplanung, können die Logistikkosten abgeleitet werden. Änderungen könnten dabei lediglich durch Preisänderungen (Preiserhöhung oder Volumenabhängigkeit) induziert werden.

## Großhandel:

Ausgehend vom Geschäftsmodell des Großhandels, sind die Lager- und Logistikkosten (nach dem Wareneinkauf), die entscheidende Ausgabenkategorie. Zur Abwicklung der Aufträge sind daneben noch die Personalkosten (alle Funktionen) von Bedeutung.

Unter der Kategorie VKS Personal sind alle notwendigen Einsatzressourcen zur Auftragsabwicklung zu fassen, d. h. vom Verkauf bis hin zur Auslieferung an den Kunden.

Damit sind auch die meistens fest angestellten Mitarbeiter im Lager und der Logistik dieser Kategorie zuzuordnen. Es kann i. d. R. davon ausgegangen werden, dass die Grundkapazität für die Abwicklung durch eigene Mitarbeiter abgedeckt wird und Kapazitätsspitzen extern dazu gekauft werden, die dann auch in die Lager-/Logistik-Kategorie fallen.

Wie beim eCommerce unterliegen Lager-/Logistik der Volumenplanung und es gelten die bereits ausgeführten Ableitungsregelungen des eCommerce. Der wesentliche Unterschied liegt in der Logistik, da dort andere Dienstleister genutzt werden. Statt B2C Paketdienste sind hier Anbieter der Kontaktlogistik im Einsatz, die die deutlich größeren Auslieferungsmengen pro Auftrag zum Kunden transportieren. Damit gelten andere Preisregularien, die mit dem OPMT verifiziert werden sollten.

## Operativer Cashflow Produktion:

Im Sektor Produktion gilt aufgrund der Definition, dass es sich um Unternehmen handelt, die  aktiv  ein  handelbares  Produkt  herstellen.  Somit  wird  die  Ausgabenseite  von  den  wesentlichen Einsatzfaktoren der Herstellung dominiert.

Auf der Einnahmenseite gibt es per Definition zum einen die Unternehmen, die vertikal integriert an den Endkunden verkaufen und zum anderen diejenigen, die ausschließlich andere Gewerbekunden beliefern, meist in Form der Zulieferung von Vorprodukten oder auch der Großhandel (siehe oben).

## Einzahlungen Produktion:

Für die folgenden Einnahmen-Mechanismen ist ein Verkauf der produzierten Produkte per Bestellung als Regelfall unterstellt worden.

Endkunde (B2C)

Bei den Einnahmen aus dem Verkauf an Endkunden (B2C) gelten grundsätzlich ähnliche Regeln wir Handel (siehe oben) und sollten dementsprechend auch angewendet werden, wenn der Verkauf über eine Einzelhandelsfäche oder einen eCommerce Kanal erfolgt.

Basierend auf den offenen Posten der Kreditoren sind mit Hilfe der historischen Daten aus der FIBU und der PRVR eine zeitliche Conversion Ratio der offenen Posten, sowie eine Ausfallquote der offenen Posten zu ermitteln. Über eine kalendarische Fälligkeitskaskade lassen sich dann die erwarteten Einzahlungen für die kommenden Tage ableiten. Dabei ist der zeitliche Verzug der Kontogutschrift durch den Payment Provider zu berücksichtigen. Der Abgleich mit der OPLA für den entsprechenden Monat zeigt den noch erwarteten Umsatz für diese Periode. Diese wird dann ebenfalls über die dargestellte Umwandlungssystematik in aktuelle Einnahmen der kommenden 4 Wochen gewandelt.

Für die Kurz-/Mittelfristplanung ist wieder die OPLA der Ausgangspunkt, der mit dem OPMT auf mögliche Anpassung der Vertriebsplanung oder die Umsetzung von vertrieblichen, nicht geplante Vertriebsaktionen, abzugleichen ist.

Geschäftskunde (B2B)

Der B2B Verkauf erfolgt grundsätzlich auf der Basis einer Rechnungsstellung gefolgt von der Auslieferung und der Zahlung.

Damit sind die kreditorischen Offenen Posten (OP) der Ausgangspunkt der Prognose der kommenden Tage. In Kombination mit der erwarteten Ausfallquote und der zeitlichen Conversion Ratio (PRVR basiert) lässt sich der Einnahmenfluss in kalendarische Zahlungen überführen. Kurz- und mittelfristig bildet die OPLA mit ihrer Produktionsplanung die Plattform der Prognose.  Das  OPMT  sollte  zusätzlich  Auskunft  darüber  geben,  ob  die  zu  Grunde  liegende Absatzplanung noch valide ist, sowie über mögliche Änderungen der Konditionen oder auch über vertriebliche Sonderaktionen.

## Auszahlungen Produktion:

Bei  den  Auszahlungen  erfolgt  eine  Differenzierung  in  die  wesentlichen  Ausgabekategorien  bei  der Produktion.

Rohstoff-/Material

Unter dieser Kategorie sind alle Ausgaben für Zukäufe von Rohstoffen und Material subsummiert.

Die aktuellen Auszahlungen lassen sich ausgehend von den Debitoren-OPs aus der FIBU planungssicher über die Fälligkeit ableiten. Änderungen ergeben sich nur, wenn aktiv eine Zahlung aus dem Zahlungslauf verschoben wird, die dann allerdings umgehend auf den neuen Zieltermin gesetzt werden muss.

Bei der kurzfristigen Sichtweise wird die Basis der Herleitung deutlich breiter. Neben den Debitoren-OPs nach Fälligkeitsdatum als ein Baustein, ist die Produktionsplanung ein weiteres zentrales Element. In Kombination mit den vorhandenen Lagerbeständen lässt sich der

Verbrauch an Rohstoffen und Material ableiten, der dann mit dem Stand der aktuellen Bestellungen im Sinne der Anlieferung (aus dem OPMT) zu verifizieren ist. Gegebenenfalls kann die PRVR mit einer Anlieferungsprognose an diese Stelle hilfreich sein. Aus diesen beiden Datenpunkten können dann die kommenden kurzfristigen Ausgaben prognostiziert werden.

Einen noch höheren Stellenwert bekommt die Produktionsplanung bei der mittelfristigen

Planung, da sie in Kombination mit der Monatsplanung aus der OPLA die zukünftige Produktionsmenge determiniert. Hier müssen dann die FIBU basierten Bestände an Materialien, sowie an Fertig- und Halbfertigprodukten in der Prognose mitberücksichtigt werden. Daneben gilt es, mit dem Vertrieb des OPMT abzustimmen, ob noch mit Sondereffekten in der Absatzplanung zu rechnen ist, die die geplante Produktionsmenge nochmals verändern würden.

Am besten erfolgt die integrierte Herleitung der mittelfristigen Produktionsmenge gemeinsam mit dem Produktionsmanagement (als Teil des OPMT), um so eine sichere Prognose zu erstellen. Auf Basis dieser kann dann in Kombination mit der historischen

Output-Materialeinsatzquote  der  PRVR  die  zu  beschaffende  Menge  an  Rohstoffen/Materialien abgeleitet werden. Im Endeffekt handelt es sich um ein komplettes Update der Produktionsplanung.

Abschließend sollte noch eine Abstimmung mit dem Einkauf im Hinblick auf die zeitliche Terminierung der Bestellungen, der Lieferungen und Fälligkeit der Ausgaben erfolgen.

## Bezogene Leistungen:

Bei den bezogenen Leistungen handelt es sich um Leistungen, die von Dritten zur Verfügung gestellt  werden  und  kontinuierlich  im  Produktionsprozess  verbraucht  werden  und  nur  bedingt lagerfähig sind. Beispiele dafür sind z. B. Strom, Gas und Wasser. Insbesondere bei energieintensiven Produktionen, wie z.  B. der Metallerstellung oder der Herstellung von chemischen Fasern, spielen diese Ausgaben eine signifkante Rolle bei den Ausgaben.

Im  Kern  folgt  die  Planung  dieser  Ausgaben  den  Ausführungen  bei  der  Rohstoff-/Materialplanung bezogen auf alle Fristigkeiten.

Die  Produktionsplanung  muss  auch  für  diese  Ausgabenprognose  der  bezogenen  Leistungen  einmal komplett aktualisiert werden, um dann auf Basis der historischen Output-Verbrauchsquoten der PRVR die notwendigen Einkaufsmengen kalendarisch zu bestimmen.

Wichtig ist dabei zu beachten, dass die Verbrauchsabrechnung und damit auch die

Rechnungstellung und Fälligkeiten sehr kontinuierlich erfolgen. Die Lieferanten diese

Leistungen sind bestrebt, das Obligo auf ihrer Seite nicht zu hoch werden zu lassen. Möglicherweise sind auch Abschlagszahlungen vereinbart, die in den Konditionen der Lieferanten (FIBU oder OPLA) abgebildet sind und deren Aktualität zu prüfen ist. Die

Auszahlungen setzen sich dann zusammen aus der Abschlagszahlung des aktuellen Monats und dem Mehr-/Minderverbrauch des Vormonats.

Als eine Besonderheit bei den bezogenen Leistungen kann es zusätzlich sein, dass Vorauszahlungen geleistet werden müssen, weshalb zu prüfen ist, ob diese bereits gezahlt wurden oder ob eine Erhöhung der Vorauszahlung erfolgen könnte (OPLA).

## Personal

Als Personalausgaben sind alle Ausgaben gemeint, die im Zusammenhang mit der zur Verfügungstellung von Personalressourcen anfallen. Damit fällt ausdrücklich jegliches Fremdpersonal, auf  welcher  vertraglichen  Basis  auch  immer  (ANÜ,  freie  Mitarbeiter,  Auftragsarbeiten),  in  diese Ausgabenkategorie.

In eine Fristigkeit ist bei der Personalausgaben nicht zu differenzieren, da diese zeitlich fix auf einen bestimmten Termin im Monat terminiert sind.

Zwangsläufig ist wieder die aktualisierte Produktionsplanung die Basis für die Planung der Personalausgaben. Über die Funktion des Personaleinsatzquote (aus der PRVR) ergibt sich die notwendige Kapazität. Nach Abzug des Eigenpersonals verbleibt der Teil, der durch Fremdpersonal abzudecken ist.

Für das Eigenpersonal sind die vertraglichen Regelungen (Individualvertrag, Haustarif, Tarifvertrag)  die  Basis  der  Ermittlung  der  zu  erwartenden  Personalausgaben  (Lohn/Gehalt,  Sozial/Rentenversicherung, Lohnsteuer). Hier sollte in Zusammenarbeit mit der Personalabteilung (als Teil des OPMT) ein Berechnungsmodus für eine Prognose erarbeitet werden.

Beim Fremdpersonal gelten die jeweiligen Vergütungsregelungen als Ausgangspunkt, die  kombiniert  mit  der  Inanspruchnahme,  die  zu  erwartenden  Ausgaben  herleitbar  machen. Grundsätzlich gelten für die kalendarische Terminierung dieser Ausgaben die normalen Mechanismen des Fremdeinkaufes (Rechnung, Debitoren-OP, Zahlungslauf).

## Operativer Cashflow Dienstleistung:

Im Sektor Dienstleistung ist der operative Cashflow der Sache auf den ersten Blick relativ problemlos zu ermitteln, aber aufgrund der Unsicherheit der Einnahmen mit besonderer Vorsicht zu planen. Die Projektplanungen sind der Schlüssel zur Liquiditätsprognose und damit Kernelement für die folgende Darstellung der Einnahmen- und Ausgabenplanung.

## Einnahmen Dienstleistung:

Die Einnahmen der Branche Leistung und Gewerke bestehen aus den Zeitabrechnungen und der Weiterberechnung von Einsatzfaktoren (Material und technische Hilfsmittel). Leistung

Die  Leistungsabrechnung  basiert  auf  der  verursachungsgerechten  Erfassung  und  Zurechnung  der eingesetzten Leistungseinheiten.

Die aktuellen Einzahlungen basieren auf den kreditorischen OP zur Prognose der kommenden Tage. In Kombination mit der erwarteten Ausfallquote und der zeitlichen Conversion Ratio (PRVR basiert) lässt sich der Einnahmenfluss in kalendarische Zahlungen überführen. Über die OPLA ist zu prüfen, ob noch nicht abgerechnete Leistungen, die über den vereinbarten Auftrag hinaus gehen, noch offen sind und damit umgehend nachverrechnet werden müssen.

Für die zukünftigen kalendarischen Einnahmen ist die Projektplanung der OPLA von entscheidender Bedeutung. Dabei muss davon ausgegangen werden, dass es im Dienstleistungsunternehmen ein funktional umfassendes System zur Projektplanung gibt, sodass die erbrachten Leistungen  verursachungsgerecht und  damit  projektund  kundenbezogen  erfasst, zugeordnet und abgerechnet werden.

Für die Prognose der Einnahmen erfolgt ein Update der Projektplanung mit dem OPMT, insbesondere zum Stand und geplanten Fortschritt innerhalb der einzelnen Projekte. Auf dieser Basis können die kommenden Leistungsabrechnungen antizipiert werden und dann über  die  Mechanismen  der  Rechnungsstellung,  Fälligkeit  und  Zahlungsterminierung  kalendarisch eingeordnet werden.

Ein immer wieder wichtiges Element der Einnahmenplanung sind die erbrachten Sonderleistungen, die gegebenenfalls außerhalb des definierten Projektauftrages liegen. Es ist unbedingt notwendig, diese mit dem OPMT zu prüfen und die Rechnungsstellung und damit auch eine Einnahmengenerierung zu initiieren.

## Gewerke:

Auch die Leistungsabrechnung basiert auf der verursachungsgerechten Erfassung und Zurechnung der eingesetzten Leistungseinheiten, ist aber auf der Einnahmenseite abhängt von den vereinbarten Fortschrittszahlungen oder dem Fertigstellungszeitpunkt mit einer Gesamt- oder Abschlusszahlung.

Die aktuellen Einzahlungen basieren auf den kreditorischen OP zur Prognose der kommenden Tage. In Kombination mit der erwarteten Ausfallquote und der zeitlichen Conversion Ratio (PRVR basiert) lässt sich der Einnahmenfluss in kalendarische Zahlungen überführen.

Im Bereich der Kurz- und Mittelfristplanung liegt das Augenmerk auf den vereinbarten Zahlungsbedingungen der jeweiligen Projekte (Gewerke). In der Regel bestehen die Zahlungen aus Abschlagszahlungen  (möglicherweise  abhängig  von  der  Erreichung  von  Milestones)  und  einer Abschlussrechnung nach Fertigstellung des Gewerkes.

Von daher ist die Projektplanung bzw. der Status des Projektfortschrittes das wichtigste Element der mittelfristigen Einnahmenplanung. Gemeinsam mit dem OPMT muss kontinuierlich ein Abgleich  der  Planung  der  OPLA  erfolgen  und  entsprechend  eine  Nachsteuerung  bei  zeitlichen Veränderungen erfolgen.

Nachdem die Projektplanung aktualisiert worden ist und die Projektfortschritte determiniert sind, muss die Umwandlung in zu erwartenden Rechnungsstellungen erfolgen. Dabei müssen die vereinbarten Konditionen (FIBU) mit den Projektfortschritten gematched und die Rechnungsvolumina ermittelt werden. Auf dieser Basis kann dann die Ableitung der Fristigkeit und Einnahmengenerierung kalendarisch bestimmt werden.

Auch bei den Gewerken ist die Abrechnung von Sonderleistungen immer ein kritischer Punkt, der durch den Liquiditätsplaner gemeinsam mit dem OPMT permanent gemonitort werden muss.

## Weiterbelastung

Wie bereits erwähnt sind, bei entsprechenden Gewerken (wie z. B. Bau oder Werkzeugbau) die Weiterbelastungen von Material und technischen Hilfsmitteln ein wesentlicher Teil der Einnahmen.  Dabei  ist  zu  beachten,  dass  auch  eigene  technische  Hilfsmittel  in  dieser  Kategorie berücksichtigt werden sollten. Hierzu sollte in den vertraglichen Regelungen (aus der FIBU) des jeweiligen Auftrages eine entsprechende Regelung bzw. ein Abrechnungswert hinterlegt sein.

Wesentlicher Ausgangspunkt für diese Abrechnung ist die projektbezogene Kostenrechnung der FIBU. Sie bildet die Basis für die Weiterbelastung und in ihr sollten alle abrechnungsrelevanten Mechanismen (wie z. B. Verrechnungssätze, Margen, Zuschläge) hinterlegt sein. Gemeinsam mit dem OPMT ist auf Basis der Ist-Daten eine Prognose in Abstimmung mit der aktualisierten Projektplanung über das Volumen der Rechnungsstellung für Materialien und technischen Hilfsmittel mittels einer Verbrauchsplanung durchzuführen. Für die Planung zukünftiger Projekte kann die PRVR auf Basis historischer Einsatzquoten die Grundlage für diese Abrechnungsgröße liefern.

Für  die  kalendarische  Terminierung  der  Rechnungsstellung  und  damit  der  Einnahmengenerierung gelten die oben genannten Regeln für die Leistungs- bzw. Gewerkabrechnungen.

## Auszahlungen Dienstleistung:

Die Ausgaben der Branche Leistung und Gewerke bestehen dem Charakter nach aus den Personalausgaben  und  gegebenenfalls  den  weiteren  Einsatzfaktoren  (Material  und  technische Hilfsmittel).

## Personal

Als Personalausgaben sind alle Ausgaben definiert, die im Zusammenhang mit der zur

Bereitstellung von Personalressourcen anfallen. Damit fällt ausdrücklich jegliches Fremdpersonal, auf welcher  vertraglichen Basis auch  immer  (ANÜ,  freie Mitarbeiter, Auftragsarbeiten), in diese Ausgabenkategorie.

Änderung Zahlungskonditionen Personaldienstleister

In eine Fristigkeit ist bei der Personalausgaben nicht zu differenzieren, da diese zeitlich fix auf einen bestimmten Termin im Monat terminiert sind.

Die aktualisierte Projektplanung ist die Basis für die Planung der Personalausgaben.

Über die Funktion des Personaleinsatzquote (ermittelt mit Hilfe der PRVR) ergibt sich die notwendige Kapazität. Nach Abzug des Eigenpersonals verbleibt der Teil, der durch Fremdpersonal abzudecken ist.

Für das Eigenpersonal sind die vertraglichen Regelungen (Individualvertrag, Haustarif, Tarifvertrag)  die  Basis  der  Ermittlung  der  zu  erwartenden  Personalausgaben  (Lohn/Gehalt,  Sozial/Rentenversicherung, Lohnsteuer). Aufgrund der festen vertraglichen Vereinbarungen sind daneben lediglich  mögliche  Bonuszahlungen  für  eine  erfolgreiche  Projektabwicklung  zu  berücksichtigen.  Die Personalausgaben sind zeitlich terminiert und damit auch kalendarisch eindeutig festzulegen.

Beim Fremdpersonal gelten die jeweiligen Vergütungsregelungen als Ausgangspunkt, die  kombiniert  mit  der  Inanspruchnahme,  die  zu  erwartenden  Ausgaben  herleitbar  machen. Grundsätzlich gelten für die kalendarische Terminierung dieser Ausgaben die normalen Mechanismen des Fremdeinkaufes (Rechnung, Debitoren-OP, Zahlungslauf).

## Material:

Für alle Branchenunternehmen, bei denen neben dem Personaleinsatz auch Materialien für die Leistungserbringung notwendig sind, müssen diese projektbezogen geplant werden.

Die aktuellen Auszahlungen für Materialien basieren auf den debitorischen OP zur Prognose der kommenden Tage. In Kombination mit der geplanten Zahlungsläufen lässt sich der Ausgabenfluss in kalendarische Zahlungen überführen.

Kurzfristig muss der Debitoren OP Basiswert, um die erwarteten Anlieferungen des OPMT und damit Rechnungsstellungen erweitert werden. Zusätzlich bildet der geplante Beschaffungswert der OPLA die Leitplanken für die Prognose.

Bei der Mittelfristplanung müssen die Bestände an Materialien (aus der FIBU) mitberücksichtigt werden und sind mit der Bestellplanung (aus der OPLA) zu kombinieren.

Auch bei den Materialien ist die Projektplanung mit dem Fortschrittsstatus und der Fortschrittsplanung der Ankerpunkt für die Prognose der Beschaffungsvolumina, die dann mit den Beständen und den ausstehenden Anlieferungen die neu zu beschaffenden Materialen ermittelbar macht. Auf Basis der Bestellerfahrungen des OPMT und der zeitlich geplanten Projektfortschritte können die Beschaffungsvolumina auf eine Zeitschiene gebracht werden. Damit ist die kalendarische Zuordnung der Materialausgaben der Höhe und dem Zeitpunkt nach determiniert.

## Technische Hilfsmittel

Als technische Hilfsmittel (THM) sind aus Sicht der Ausgabenplanung nur jene zu betrachten, die als Fremdleistung eingekauft werden. Im Falle des Einsatzes von eigenen THM sind diese, im Falle einer Neu- oder Zusatzbeschaffung, im Rahmen der Investitionsplanung zu planen und diese Beschaffungsausgaben sind dann relevant für die Liquiditätsplanung.

Die aktuellen Auszahlungen basieren auf den debitorischen OP zur Prognose der kommenden Tage. In Kombination mit der geplanten Zahlungsläufen lässt sich der Ausgabenfluss in kalendarische Zahlungen überführen.

Für die Kurzfristplanung sind die Einsatzplanung (aus der OPLA) und der aktuelle Einsatzmonitor (aus dem OPMT) die entscheidenden Planungsparameter. In dieser Kombination kann die Nutzung der THM, und damit die folgende Abrechnung der Verleiher, antizipiert werden.

Aus mittelfristiger Sicht ist die Projektplanung mit dem korrespondierenden Einsatzplan der THM die Plattform für die Auszahlungsprognose. Die Projekte mit der Einsatzplanung der kommenden Wochen und Monate geben Aufschluss über den Bedarf und die Deckung durch eigene THM bzw. Fremdmittel. Auf dieser Basis können die erwarteten Nutzungszeiten und damit Nutzungsentgelte abgeleitet werden und es gelten für die kalendarische Terminierung dieser Ausgaben die normalen Mechanismen des Fremdeinkaufes (Rechnung,

Debitoren-OP, Zahlungslauf).

## Branchenunabhängige Auszahlungen:

Neben  den  genannten  Ausgabekategorien  in  der  branchenspezifischen  Herleitung  der  Ausgaben, verbleiben noch die folgenden operativen Ausgaben:

- • Reise/Kfz
- • IT/Kommunikation
- • Versicherung/Beiträge
- • Beratung
- • Verwaltung

## • Sonstiges

Für alle diese Ausgaben gilt ein gleichartiges Vorgehen. Die FIBU mit den historischen Ist-Daten und die OPLA bilden die Basis für die Prognose. Die bestehenden Verträge sollten in Kombination mit dem OPMT über erwartete Einzelbeauftragungen die Grundlage bilden. Wichtig für den Liquiditätsplanung ist der zeitliche Anfall der Ausgaben, die in einer OPLA Kostenplanung in der Regel aus betriebswirtschaftlichen Gründen mit nahezu gleichen Monatswerten geplant sind. Hier gilt es diese so weit als möglich in eine ausgabengerechte kalendarische Planung zu bringen. Ausgangspunkt dafür sind die historischen FIBU-Daten als Zeitreihe, die aufzeigen wann der tatsächliche Ausgabezeitpunkt ist. Beispielhaft seien hier die Versicherungsbeiträge genannt, die entweder einmal jährlich oder quartalsweise anfallen und so die Liquidität überproportional beanspruchen werden.

## Planung des investiven Cashflows:

Der investive Cashflow basiert grundsätzlich auf dem Investitionsplan des Unternehmens, der allerdings für die Liquiditätsplanung von der betriebswirtschaftlichen Jahres-/Monatsplanung in eine Zeitpunktplanung umgewandelt werden muss. Aktivierungszeitpunkte und Abschreibungsregeln spielen in der Liquiditätsplanung keine Rolle, einzig und allein der Auszahlungszeitpunkt von Teil- oder Gesamtrechnungen ist entscheidend. Deshalb muss bei allen Investitionen das Thema Zahlungskonditionen durch den Liquiditätsplaner mit dem OPMT geklärt werden.

Auch beim investiven Cashflow ist eine Betrachtungsweise getrennt nach den Sektoren sinnvoll, da die zu berücksichtigenden investiven Elemente sich deutlich unterscheiden.

## Investitionen Handel:

Der Handelssektor ist investiv geprägt vom Auf- und Ausbau der Verkaufspunkte und der Logistik.

Im Einzelhandel ist die Expansions- bzw. Umbauplanung der Point of Sales (POS) aus der OPLA und der OPMT die Kerngröße der Investitionen. Dazu sind bei der Liquiditätsplanung die folgenden kalendarischen Pläne wichtig für die Herleitung der Auszahlungszeitpunkte:

- • POS Roll-Out
- • POS Umbau/Erneuerung
- • Ladenbaukonzept nach finanziellem Umfang und Finanzierung

Zur POS-Erneuerung gehören auch alle möglicherweise geplanten technischen Erneuerungen wie z. B.

neue Kassensysteme, neue LAN Anbindung, Payment Provider Endgeräte. Beim eCommerce stellt der funktionale Entwicklungsplan für den Shop (OPLA und OPMT) die entscheidende Grundlage dar, denn diese führt zu entsprechenden Software- und Hardwareinvestitionen. Hier ist die Absprache mit dem OPMT außerordentlich wichtig, da gerade der zeitliche Anfall in Abhängigkeit vom Fortschritt der Realisierungsprojekte in der Realität oft nicht mit dem Plan übereinstimmt. An zweiter Stelle beim eCommerce sind die Investitionen in die logistische Abwicklung der Bestellungen von hoher Relevanz, da sowohl Software- als auch Lagerinvestitionen in der Regel einen erheblichen Umfang haben. Zusätzlich sollten die  mit  der  Implementierung  einhergehenden Berateraufwendungen in die Planung aufgenommen werden.  Wie  bei  den  Shop  Investitionen  muss  auch  für  diese  Auszahlungskategorie  eine  enge Abstimmung mit dem OPMT zur Terminierung erfolgen. Beim  Großhandel  liegt  der  Fokus  auf  den  Investitionen  für  die  Logistik  zur  Auslieferung  an  die Einzelhandelspartner.  Grundsätzlich  gelten  dieselben  Regeln  wie  bei  den  Logistikinvestitionen  im eCommerce. Wichtig an dieser Stelle nochmals der Hinweis, dass Logistikinvestitionen immer auch die korrespondierenden Softund Hardwareinvestitionen inkludieren.

## Investitionen Produktion:

Der Produktionssektor ist geprägt von Investitionen in die Anlagen des Unternehmens. Deshalb sind Anlagenspiegel, Investitions- und Produktionsplanung die wesentlichen Grundlagen der Ausgabenplanung.

Der Anlagenspiegel gibt die aktuelle technische Infrastruktur wieder und bildet die Grundlage für die Planung. In Kombination mit der Investitionsplanung wird deutlich wo und wann Investitionen getätigt werden und in Absprache mit der OPMT sollten auch die Zahlungsbedingungen abgestimmt werden.

Der Produktionsplan des OPLA bildet eine Prüfgröße für die Liquiditätsplaner im Sinne der  Verprobung von Produktionsmengen und infrastruktureller Kapazität. Deshalb sollte immer ein intensiver Austausch mit dem OPMT dazu erfolgen. Gerade mögliche expansive Planung des Vertriebs gegenüber der Ursprungsplanung müssen sich in einer angepassten

Investitionsplanung wiederfinden.

Um sich unvorhergesehenen finanziellen Belastungen zu vermeiden, muss der Liquiditätsplaner auch die Nutzungsdauer der Anlagen kritisch überprüfen und mit dem Investitionsplan verproben. Nichts wäre bei einer angespannten Liquiditätslage schlimmer als die plötzliche Notwendigkeit einer ungeplanten Ersatzinvestition.

## Investitionen Dienstleistung:

Beim Dienstleistungssektor hat der investive Cashflow in der Regel eine geringe Relevanz, da das Geschäftsmodell auf der Erbringung von Leistung des Human Capitals liegt.

Trotzdem  sind  die  technischen  Hilfsmittel  durchaus  von  Bedeutung  für  die  Liquiditätsplanung, insbesondere im Baugewerbe und im Handwerk.

Planerisch folgen die Investitionen in die technischen Hilfsmittel dem Vorgehen bei den Investitionen im Sektor Produktion, wenn auch meistens mit geringerem finanziellem Ausmaß. Allerdings ist beim Einsatz von Fremd- und Eigenanlagen das Zusammenspiel gesondert zu betrachten (siehe dazu: Ausgaben - Technische Hilfsmittel - Dienstleistung).

## Planung des steuerlichen Cashflow:

Der steuerliche Cashflow ist dem Grunde unkompliziert, in der Wirkung auf die Liquidität hingegen äußerst wichtig, da erhebliche Zahlungen fest und nicht verschiebbar zu einem bestimmten Zeitpunkt fällig sind. Zu diesen muss dann die notwendige Liquidität gegeben sein, um nicht in einen steuerlichen Verzug zu geraten.

## Umsatzsteuer:

Aus der Praxis hat sich bewährt, die Umsatzsteuer, im Sinne der zu leistenden Vorauszahlung, auf Basis der Liquiditätsplanung in einem einfachen Verfahren im Liquiditätsmodell direkt zu ermitteln.

Die jeweils einem Monat zugehörigen Ein- und Auszahlungen aller Cashflows sind nach ihrer umsatzsteuerlichen Relevanz zu clustern und gegeneinander aufzurechnen. Aufgrund der Bruttobetrachtung der Liquiditätsplanung ist die Herleitung unproblematisch, allerdings ist bei innereuropäischen Einzahlungen die in der Regel bestehende Vorsteuerbefreiung von Waren- und Dienstleistungen zu beachten. In Abhängigkeit von der Vorauszahlungsterminen ist dann der sich ergebende Saldo entsprechend für den 10. jedes Monats einzuplanen.

## Gewerbesteuer/Ertragssteuer:

Bei der überwiegenden Anzahl an Unternehmen besteht von Seiten der Finanzbehörden eine Gewerbesteuervorauszahlungsplicht, determiniert über den entsprechenden Bescheid des Vorjahres, der der FIBU vorliegt. Diese Vorauszahlungen sind damit zum angegebenen

Zeitpunkt in der Liquiditätsplanung zu berücksichtigen.

Für die erwartete Gewerbesteuerzahlung des abgelaufenen Geschäftsjahres lässt sich aus  der  OPLA  auf  Basis  der  Ergebniserwartung  und  des  geltenden  Gewerbesteuerhebesatzes  eine Abschätzung ableiten und nach Aufrechnung mit den Vorauszahlungen ermitteln und zum erwarteten Stichtag nach Feststellung des Jahresabschlusses einplanen. Da diese finale Auszahlung nachschüssig erfolgt, kann bei einer Planung für die kommenden 12  Monate die Gewerbesteuererwartung auf Basis des Jahresabschlusses des Vorjahres (FIBU) angewendet werden.

Dem Grunde nach folgt die Planung der Ertragssteuer der der Gewerbesteuer, sodass die gleichen Mechanismen anzuwenden sind.

## Planung des Cashflows Finanzierung:

Der  finanzielle  Cashflow  ist  grundsätzlich  aus  Liquiditätssicht  gut  planbar,  da  alle  Elemente  der Zuführungen  und  Aus-/Rückzahlungen  durch  entsprechende  vertragliche  Vereinbarungen  unterlegt sind.

## Finanzielle Zuführungen:

Die finanziellen Zuführungen erhöhen die Liquiditätsbasis und setzen sich aus folgenden Formen zusammen und sind jeweils durch entsprechende Unterlagen der FIBU zeitlich zu terminieren.

- • Eigenkapitalerhöhungen - Gesellschafterbeschlüsse
- • Aufnahme neuer Kredite/Darlehen - Kredit-/Darlehensverträge
- • Erhalt von Förderungen - Förderbescheide

Wichtig ist dabei, aus den zugrundeliegenden Verträgen abzuleiten, wann und in welcher Höhe die Mittel dem Unternehmen zufließen und damit in der Liquiditätsplanung entsprechend positiv wirken.

Wenn  die  Liquiditätsplanung  einen  negativen  Liquiditätssaldo  ausweißt,  muss  von  Seiten  der Liquiditätsplanung eine Imitierung einer Zuführung an finanziellen Mittel erfolgen - mit zeitlichem und der Höhe nach abgeleiteten Volumen.

## Finanzielle Aus-/Rückzahlungen:

Wie bei den finanziellen Zuführungen sind auch die Aus-/Rückzahlungen durch vertragliche Grundlagen terminiert.

- • Entnahmen/Ausschüttungen - Gesellschafterbeschlüsse
- • Zinsen &amp; Tilgung - Kredit-/Darlehensverträge
- • Rückzahlung von Förderungen - Förderbescheide

Alle diese Elemente sind eindeutig dem Zeitpunkt und der Höhe nach determiniert. Eine Rückführung von finanziellen Mitteln kann nur erfolgen, wenn die Liquidität dies auch zulässt. Ansonsten muss aus Sicht der Liquiditätsplanung eine Prolongation oder Aussetzung der Rückführung initiiert werden.

## Zusammenfassende Darstellung:

Unter  Berücksichtigung  der  dargestellten  Detaillierungen  der  Planung  der  einzelnen  Cashflows  der Liquiditätsplanung ergibt sich die im Folgenden dargestellte zusammenfassend generalistische Grundstruktur. Diese muss durch den Planer entsprechend der Branchen und  Sektorenzuordnung  des  Unternehmens  und  möglicher  Sonderthemen  (z.  B.  außerordentliche Lagerverkäufe als Einnahmenkategorie oder ein spezifischer Lieferantenausweis bei den Auszahlungen) angepasst werden.

## Liquiditätsmodell:

Im Folgenden erfolgt eine Darstellung des Aufbaues, der Strukturierung und Steuerung eines Liquiditätsmodells aus der Praxis.

## Modellapplikation:

Oftmals  herrscht die  Meinung  in  Unternehmen,  dass  das  ERP-System  die  Liquiditätsplanung automatisiert übernehmen kann. Die gemachten Ausführungen zum inhaltlichen Zusammenspiel der verschiedenen Grundlagen für eine Liquiditätsplanung (FIBU, OPLA,

OPMT und PRVR) haben deutlich gemacht, dass diese Annahme für eine fundierte und belastbare Liquiditätsplanung nicht gilt, sondern erst aus der intellektuellen Verknüpfung

der  verschiedenen  Planungselementen  und  der  Interaktion  mit  dem  Management  eine  solche entstehen  kann.  Deshalb  ist  der  Aufbau  eine  Liquiditätsplanung  auf  Basis  eines  eigenen  Tools notwendig, in dem alle Planungen und Erkenntnisse zusammenfließen.

Best Practise dafür ist heutzutage Microsoft Excel, das über eine entsprechende Verbreitung verfügt und dessen Anwendung in den Finanzbereichen der Unternehmen geübte

Praxis ist.

Daneben ist zu erwähnen, dass auch andere Tools (wie zum Beispiel Lucanet, Agicap, tidely, Commitly) einsetzbar sind, die bereits die Grundstruktur einer Liquiditätsplanung enthalten und den Unternehmensanforderungen entsprechend zu konfigurieren sind.

## Modellstruktur:

Wie bereits erwähnt basiert eine belastbare Liquiditätsplanung immer auf einer Tagesbasis, da nur so die Anforderung der Sicherung einer ausreichenden Unternehmensliquidität zu jedem Zeitpunkt innerhalb der kommenden Wochen und Monate gesichert werden kann.

Die Tagesplanung wird in ihren Werten gespeist aus den zugrundliegenden Daten, um die das Planungstool, in Abhängigkeit von der Wichtigkeit der jeweiligen Planungsgröße, erweitert wird.

Die Zusammenführung der Liquidität nach Kalenderwochen und Monaten, sowie grafische Darstellungen, basieren alle auf der Tagesplanung und enthalten in sich selbst keine eigenen Berechnungen.

Die  im  Anhang  dargestellt  Case  Study  visualisiert  diese  Struktur  und  macht  den  Zusammenhang zwischen den Planungselementen nochmals deutlich.

## Kalendarischer Allokationsalgorithmus:

Das entscheidende Ziel bei der Liquiditätsplanung ist die Einnahmen und Ausgaben auf den relevanten Fälligkeitstag zu allokieren. Aus diesem Grund muss im ersten Schritt die kalendarische Strukturierung erfolgen.

Dazu ist der zu planende Zeitraum (i. d. R. sind 12 Monate zu empfehlen) als Kalender im Modell zu hinterlegen.

Aus dem Kalender werden folgende Steuerungsfelder generiert:

- • Umsetzung numerische Tagesangabe (Tag)
- • Zuordnung zur Kalenderwoche (KW)
- • Zuordnung zum Jahr (Jahr)
- • Monat als numerischer Wert (Mo)
- • Kombination Jahr und KW (JahrKW)
- • Kombination Monat und Jahr (JahrMo)

Die Kombination mit dem Kalenderjahr ist eigentlich nur bei einer jahresübergreifenden Planung notwendig, sollte aber grundsätzlich genutzt werden, um die Zukunftsfähigkeit des Modells sicherzustellen.

Diese Struktur bildet umgesetzt in die Vertikale die Steuerungsleiste für die Tagesplanung. Dabei sollten die Wochenendtage unbedingt bestehen bleiben, da bei der Steuerung der Fälligkeitstage (z. B. Umsatzsteuer am 10. eines Monats), diese vorhanden sein müssen, um die Zahlung auf die kommende Woche zu steuern. Da aber an Wochenenden keine Zahlungen  kontowirksam  erfolgen,  ist  eine  weitere  Steuerungszeile  hinzuzufügen  -  Zahltag.  Diese Kennung induziert, das an diesen beiden Tagen nicht gezahlt wird, aber am darauffolgenden Montag die Zahlung zu leisten ist. Die jeweilige 1 verhindert eine Zahlung an diesem Tag, die 2 führt zur Nachholung der Zahlung am folgenden Montag. Über die Zeile KW lassen sich alle Zahlungen der Kalenderwoche summieren, über die

Zeile Monat gleichlautend die Zahlungen im Monat.

## Tagessteuerung:

Die kalendarische Steuerungsleiste bildet auch die Grundlage für die Einsteuerung von Einnahmen und Ausgaben auf vordefinierte Tage.

Bei der Einnahmenplanung z. B. auf Grundlage einer abgeleiteten Tagesverteilung oder der Debitorenauswertung, bei den Ausgaben durch vertraglich fixierte Zahltage (z. B. Mietzahlungen) oder auch im Unternehmen festgelegten Tagen für den Zahlungslauf. Im folgenden Beispiel sind die Steuerungselemente die Auszahlungen für Versand und Miete dargestellt.

Bei der Miete ist vertraglich der 2. eines Monats als Zahltag festgeschrieben werden, an dem der Gesamtbetrag fällig ist.

Am Beispiel ist zu sehen, dass eine Aufteilung der Auszahlungen für den Versand, die als Wert aus der Auszahlungsplanung gezogen werden (hier EUR 162k pro Monat), erfolgt und dass diese Zahlung auf den Montag der folgenden Woche verschoben wird. Deshalb sind für alle Ein- und Auszahlungen 2 Zeilen zu modellieren - eine für die Verteilung entsprechend des festgelegten Algorithmus und eine für die Steuerung auf den Zahltag. Die Miete wird auf den 2. des Monats gesetzt und wird an diesem Tag dann auch zahlungswirksam, da es sich um einen Banktag handelt.

## Ermittlung der Basisgrößen für Ein- und Auszahlungen:

Für die Einsteuerung in die Tagesplanung müssen alle relevanten Ein- und Auszahlungsgrößen auf eine Tagesbasis allokiert werden.

Beispielhaft werden im Folgenden die Einnahmen eines Einzelhändlers und die eines

Produzenten dargestellt.

## Einzelhandel

Aus der FIBU erfolgt die Erhebung der historischen Einzahlungen der Filialen des Einzelhändlers, wobei zu beachten ist, dass es zu einer Verschiebung der Wochentage kommt.

Deshalb werden in einem ersten Schritt die historischen Werte wochentags genau dem neuen Planungskalender zugeordnet und daraus die Verteilung im Monat pro Wochentag abgeleitet. Der Planer muss zusätzlich darauf achten, wie und wann sich die Feiertage verschieben haben und entsprechende händische Anpassungen vornehmen und die Einnahmen verschieben. Diese Verteilung, die für alle Tage des Jahres vorzunehmen ist, bildet dann die Grundlage für die Tagesplanung.

Der Basiswert der Einzahlungen pro Monat leitet sich aus der OPLA ab. Aus dieser werden die Monatsumsätze dann in Bruttoeinzahlungen des Monats umgewandelt. Es obliegt dem Planer zu entscheiden, ob der geplante Umsatz auch tatsächlich den zu erwartenden Einzahlungen des Monats entspricht, oder ob noch eine Verschiebung von z. B. einer

Woche vorgenommen werden muss, da die geplanten Umsätze erst mit einem Verzug von diesem Zeitraum zahlungswirksam werden (siehe zur inhaltlichen Planung die Kapitel Einnahmen Operativer Cashflow).

## Produktion:

Auf Basis der Debitoren OP werden die Einzahlungen nach Fälligkeiten auf die Tagesleiste transferiert und es wird die erste Grundlage für die Einnahmenprognose geschaffen.

Im nächsten Schritt erfolgt der Abgleich der Monatssumme mit dem erwarteten Umsatz der OPLA. Es ist davon auszugehen, dass über die ersten 2 Planwochen hinaus die Debitorenwert nicht ausreichen, den Umsatz zu unterlegen. Deshalb muss der Planer zum einen die vorhandene Bestellliste auswerten und zum anderen im Abgleich mit der OPLA Erwartung den offenen Betrag händisch dazu planen. Für die Monate t + 3 gelten die OPLA-Werte als Grundlage und sind nach der Wandlung in Bruttoumsätze auf die Kalenderwochen auf Basis zu verteilen.

Auf der Ausgabenseite ist insbesondere die Herleitung der Beschaffungskosten auf Tagesbasis eine der schwierigsten Aufgaben. Deshalb im Folgenden dazu ein Beispiel aus dem Einzelhandelsbereich.

## Wareneinkauf:

Die OPLA ist in der Regel nach dem Umsatzkostenverfahren ermittelt worden, wodurch sie  zwar  den  Verbrauch  verursachungsgerecht  darstellt,  aber  nur  sehr  bedingt  den  Wareneinkauf reflektiert.

Aus diesem Grund muss die Planung der Beschaffungskosten auf Basis

- • der Warenlieferanten kreditorischen OPs
- • des Bestellobligo und Anlieferungsmonitor

erfolgen. Für die Umsetzung der Warenlieferanten OPs können die dargestellten Mechanismen zu den

Einnahmen im Produktionsbereich angewendet werden, d. h. Überführung der Fälligkeiten auf die Tagesleiste.

Ausgehend vom Bestellobligo in Kombination mit dem Anlieferungsmonitor können die Fälligkeiten abgeleitet werden.

Die Parameter Anlieferung und Fälligkeit hängen jeweils von den Zahlungsvereinbarungen mit dem Lieferanten und der festgelegten Lieferlogistik ab.

Für  die  Planung  über  den  kurzfristigen  Zeitraum  hinaus  hat  es  sich  bewährt,  die  historische Wareneinkaufsquote auf die geplanten Einzahlungen (nicht Umsätze) anzuwenden.

## Rollierende Planung:

Eine reine Planung der Liquidität ist hilfreich, um mögliche Engpässe zu erkennen und Gegenmaßnahmen einzuleiten. Dies stellt aber nur eine Seite der finanziellen Sichtweise dar, denn  erst mit  einem  permanenten  Update  der Planung durch Ist-Werte entfaltet die Liquiditätsplanung ihre volle Wirkung. Bekanntermaßen entwickelt sich die Realität immer anders als eine Planung, wodurch entsprechende Unwuchten in der Liquiditätsprognose entstehen können - zum Guten wie zum Schlechten.

Der Liquiditätsplaner muss daher mindestens einmal wöchentlich oder im Falle einer risikobehafteten Situation sogar täglich, ein Update der Planung mit den Ist-Werten durchführen. Im Falle eine Liquiditätsplanung im Rahmen eines Insolvenzverfahrenes ist dies keine Option, sondern ein Muss.

Auf Basis der Kontoauszüge und der Daten aus der FIBU erfolgt eine Übertragung der Daten in das Liquiditätsmodell für den abgelaufenen Tag oder die abgelaufene Woche. Danach kommt die  entscheidende  Aufgabe  für  den  Liquiditätsplaner:  Anpassung  der  Prognose  in  die  Zukunft.  Das heißt, der Planer muss die erwarteten, aber nicht realisierten Einund Auszahlungen neu bewerten und auf der Zeitleiste entsprechend seiner Erwartung, und am besten in Absprache mit dem OPMT, neu terminieren.

Beispiel: Erwarteter Wareneinkauf von EUR 235 am 3. des Monats hat im tatsächlichen

Zahllauf am 3. nur mit EUR 201k stattgefunden. Das Delta von EUR 34k ist damit offen und zu klären. Entweder wurde eine Zahlung verschoben oder die finale Rechnung liegt unter der erwarteten Auszahlungsverpfichtung. Der Planer muss diesen Umstand klären und entscheiden, ob dieser Betrag an einem der kommenden Tage gezahlt werden muss oder die Reduktion nachhaltig und damit nicht weiter zu berücksichtigen ist. Zusätzlich ist die Frage zu klären, ob der dann geringere Wareneinsatz nicht zu Mindereinnahmen führen könnte. Auf der Einzahlungsseite muss der Planer mit der FIBU und dem OPMT abstimmen, ob  die  erwarteten  Umsätze  und  damit  Einzahlungen  so  erfolgen  werden.  Es  macht  keinen  Sinn, Planwerte einfach fortzuschrieben mit dem Wissen, dass in den letzten 2-4 Wochen die  Einzahlungen  immer  unter  der  Prognose  gelegen  haben.  Es  muss  dann  eine  entsprechende Anpassung des erwarteten Monats- oder Wochenwertes vorgenommen werden. Des Weiteren muss zu diesem Zeitpunkt eine Abstimmung mit dem OPMT über den kommenden  Zahllauf  erfolgen,  um  diesen  dann  entsprechend  einzuplanen  und  liquiditätswirksam auszuweisen.

Diese Vorgehensweise gilt für alle Positionen der Liquiditätsplanung und führt im Ergebnis zu einem komplett neuen Forecast für die kommenden Tage oder Wochen.

Aus der praktischen Erfahrung heraus haben besondere folgende Vorfälle einen nachhaltigen Einfluss auf die Liquiditätsplanung:

- · bei einem Produktionsunternehmen kommt ein ungeplanter Großauftrag, das Working Capital steigt aufgrund der Einkaufsnotwendigkeiten deutlich an und muss vorfinanziert werden
- ·  ein  Debitor  mit  erheblichen  finanziellen  Volumen  kommt  in  wirtschaftliche  Schwierigkeiten  und benötigt eine Prolongation seiner Fälligkeiten oder im schlimmsten Falle entsteht ein zeitlicher längerer Ausfall der Einzahlungen
- · aufgrund der wirtschaftlich schwierigen Lage des Unternehmens verlangen die Lieferanten Vorkasse statt Zahlungsziele

Eine  Liquiditätsplanung  ist  damit  immer  eine  sich  ständig  ändernde  Prognose,  die  wochen-  oder tagesaktuell Aufschluss über den Liquiditätsstatus des Unternehmens gibt und als Steuerungstool für ein zukunftssicheres unternehmerisches Handeln unabdingbar ist.