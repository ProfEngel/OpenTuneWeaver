## Budgetierung in einem produzierenden Unternehmen

## Grundlagen:

Wie plant das Controlling?

Planen in vier Schritten

Gleichgültig, welcher Bereich im Unternehmen geplant werden soll, die Aufgabe wird in immer gleiche Schritte gegliedert. Je nach individueller Vorgehensweise und Anforderung an das Planungsergebnis werden die einzelnen Schritte unterschiedlich gewichtet. Das Controlling bestimmt in erheblichem Umfang die Bedeutung der einzelnen Bestandteile des Planungsprozesses und unterstützt die Tätigkeiten der Planer.

## Schritt 1: Konditionen festlegen

Sie können die Planwerte nur dann realistisch festlegen, wenn Ihnen die Bedingungen des zu planenden Bereichs bekannt sind. Das Ergebnis wird von einer Vielzahl von Faktoren bestimmt, die Einfluss haben auf die Entwicklung in Ihrem Bereich, in angrenzenden Bereichen und auf wichtige Gebiete, die das Gesamtunternehmen betreffen.

[TIPP: VERÄNDERUNGEN GIBT ES IMMER In vielen Unternehmen wird die Planung durchgeführt, ohne Bedingungen ausdrücklich festzulegen. Diese Vorgehensweise unterstellt, dass sich nichts verändert. Da dies aber nie der Fall ist, leiden die Planungsergebnisse immer unter einem mehr oder weniger großen Mangel an Realitätsnähe. Wenn Sie besondere Ziele außerhalb der bisher erreichten Ergebnisse in die Planung einfließen lassen sollen, müssen Sie dazu selbstverständlich außergewöhnliche Maßnahmen durchführen. Wenn Sie z.B. Ihre Lieferzeiten halbieren wollen, müssen Sie Ihre Fertigungssteuerung ausbauen oder Ihr Lager vergrößern. Diese und weitere Maßnahmen müssen geplant werden. Nur so erhalten Sie aussagefähige Voraussagen.]

Die für die Planung wichtigen Bedingungen sind sehr vielfältig und unterschiedlich wahrscheinlich. Die Wahrscheinlichkeit, mit der eine Bedingung eintritt, hängt von Ihrer Möglichkeit ab, diese Bedingungen zu beeinflussen. Interne Maßgaben können Sie relativ gut beeinflussen. Diese haben daher eine hohe Eintrittswahrscheinlichkeit. Externe Konditionen sind meist nur in geringem Umfang von Ihnen oder von anderen Stellen Ihres Unternehmens zu beeinflussen. Daher schwanken die Wahrscheinlichkeiten für die externen Konditionen erheblich. In der Regel betreffen die Bedingungen primär einen Bereich und haben dann über die Abhängigkeit der einzelnen Pläne untereinander Einfluss auf die übrigen Bereiche. Einige Beispiele sollen dies verdeutlichen.

Das Controlling ermittelt über seine Informationsquellen die externen Bedingungen. Auch dabei ist es auf die Zusammenarbeit mit den Fachabteilungen angewiesen, da diese einen wesentlich besseren Zugang zu den Informationsquellen haben. Die internen Bedingungen leiten sich aus den Unternehmenszielen ab oder aus Teilplänen und anderen internen Entwicklungen.

Je nachdem, wie intensiv die Bedingungen berücksichtigt werden, entstehen für Ihre Planung gegenläufige Auswirkungen:

- -Je mehr Konditionen, interne Abhängigkeiten oder externe Faktoren Sie bei Ihrer Planung berücksichtigen, desto besser wird das Ergebnis Ihrer Vorhersage.
- -Jede Abhängigkeit muss ermittelt werden. Jeder zusätzliche Parameter erhöht die Komplexität der Planung. Dadurch steigt mit der Anzahl der berücksichtigten Bedingungen der Aufwand, den Sie für die Planung treiben müssen.

Es liegt in der Natur der wirtschaftlichen Zusammenhänge, dass es Rückkopplungen einzelner Bedingungen auf die eigenen Voraussetzungen gibt. In einer Exceltabelle würde sich in einem solchen Fall ein Zirkelbezug ergeben. Ein einfaches Beispiel dafür ist der Verkaufspreis eines Produkts, der Einfluss auf die Verkaufsmenge hat. Von dieser benötigten Menge wiederum hängt der Einkaufspreis ab, der in der Regel mit steigenden Einkaufsmengen sinkt.

Solche Rückkopplungen sind nicht lösbar. Die Abteilungen warten gegenseitig auf die Abgabe der einzelnen Planwerte, um selber planen zu können. Hier liegt die Aufgabe des Controllers darin, mit sinnvollen Annahmen den Kreis zu unterbrechen und bestimmte Werte, z.B. die Veränderung der Verkaufsmengen, vorzugeben.

Mithilfe des Controllings müssen Sie einen Weg finden, der mit einem vertretbaren Aufwand ein akzeptables Ergebnis liefert. Der Controller ergänzt Ihr Fachwissen über die Abhängigkeit von Parametern mit seinem Wissen über die Gesamtzusammenhänge. Gemeinsam können Sie einen praktikablen Kompromiss erzielen.

## Schritt 2: Vergangenheit betrachten

Die Planung soll die traditionelle Sichtweise, die mit statischen Informationen aus Bilanzen und Gewinn- und Verlustrechnungen arbeitet, ablösen und durch eine vorausschauende, dynamische Unternehmenssteuerung ersetzen. Trotzdem spielt die Vergangenheit eine Rolle in der Unternehmensplanung. Die Vergangenheitswerte bilden das Fundament, auf dem bei der Schätzung der zukünftigen Werte aufgebaut wird. In der Regel wird der Vorjahreswert um eine geschätzte Veränderung korrigiert und als neuer Planwert übernommen. Dies ist eine praktikable und wirtschaftliche Vorgehensweise. Darüber hinaus werden viele kleine Werte ohne Korrektur in das neue System übernommen, da eine diferenzierte Betrachtung kaum ökonomisch ist.

Ihr Controlling liefert die Statistiken, denen Sie die Vergangenheitswerte als Grundlage für die aktuelle Planung entnehmen. Die bekannten Bedingungen für das abgelaufene Jahr werden berücksichtigt und relativieren die Zahlen. In vielen Fällen können Sie aus dem Verhalten in der Vergangenheit auf die zu erwartenden Zahlen in der Zukunft schließen. Wenn Sie das Erstellen einer Vorhersage für absolut unmöglich halten, bilden die Statistikwerte der abgelaufenen Zeiträume noch die Alternative mit dem besten Bezug zur Realität.

[TIPP: VORSICHT BEI NOCH NICHT ABGESCHLOSSENEN PLANUNGSPERIODEN Meist werden Sie die Planung für das kommende Jahr bereits im Oktober, spätestens aber im November des laufenden Jahres durchführen. Zu diesem Zeitpunkt ist das letzte Planjahr noch nicht abgeschlossen. Bei Planungen im Oktober können Sie demnach maximal auf Istwerte für ein Dreivierteljahr zurückgreifen. Die letzten drei Monate der Planung müssen aus Planwerten ergänzt werden. Damit Sie in dieser Situation wirklich realistische Zahlen für das nächste Jahr planen, müssen die Werte der Monate Oktober bis Dezember vor der Verwendung kritisch geprüft werden. Unter Umständen ist für den Zweck der neuen Planung eine Anpassung notwendig.]

Ergänzt werden die Vergangenheitswerte um Daten, die sich nicht sofort aus den abgelaufenen Perioden ergeben. Dabei handelt es sich um neue Entwicklungen, die berücksichtigt werden müssen. Die Unternehmensleitung gibt z.B. vor, einen neuen Vertriebsweg zu nutzen und über das Internet zu verkaufen. Oder es werden bisher zugekaufte Bauteile selbst gefertigt. In solchen Fällen muss eine neue Planungsbasis aufgebaut werden.

## Schritt 3: Erfahrungen nutzen

Nachdem die Bedingungen Ihrer Tätigkeit für das kommende Jahr festgelegt und die bisherigen Werte und neue Vorgaben bekannt sind, werden die Planzahlen für die nächste Planperiode ermittelt. Dies geschieht auf zwei Wegen:

Zum einen können Sie aus den vergangenen Werten und den Bedingungen Abhängigkeiten ermitteln und beschreiben. Im günstigsten Fall kann dies mathematisch beschrieben werden, meist ist jedoch eine weniger genau definierte Abhängigkeit zu erkennen.

(Beispiel: Eine einfache mathematische Abhängigkeit

Die Nachfrage eines Ersatzteils für ein in der Vergangenheit vertriebenes Produkt ist abhängig von den im Markt befindlichen Maschinen und deren Alter. Der Absatz kann also anhand einer mathematischen Formel, die aus den Erfahrungen der letzten Jahre ermittelt wurde, berechnet werden.

Absatz Periode t = Anzahl Maschinen in Periode × Durchschnittsalter × 0,4 Für t = 2022 und 10.000 im Markt befindliche Maschinen mit einem Durchschnittsalter von drei Jahren ergibt sich folgende Rechnung:

Absatz in Periode 2022 = 10.000 × 3 × 0,4 = 12.000 Stück

Die Idee, die Abhängigkeit der Ersatzteilmenge von den Parametern »Anzahl der im Markt befindlichen Maschinen« und »Durchschnittsalter dieser Maschinen« zu suchen, kam aus der Fachabteilung. Der Controller entwickelte dann aus den Zahlen die mathematische Formel. Profitiert haben beide Parteien. Die Planung für die Fachabteilung ist einfacher und der Controller erhält einen realistischen Planwert.)

Liegen keine durch Formeln beschreibbaren Abhängigkeiten vor, werden die Planwerte von der Erfahrung der verantwortlichen Mitarbeiter bestimmt. Diese legen aufgrund ihrer Kenntnisse die Zahlen fest, die sie für das nächste Jahr verantworten können. Dafür muss, wie auch bei für das Unternehmen neuen Situationen, die Erfahrung durch externe Informationen ergänzt werden. Controller und Fachmann besorgen sich die notwendigen Daten aus externen Quellen wie Veröfentlichungen, Planungen des Staates, Schätzungen der Wirtschafsweisen usw.

## Schritt 4: Ergebnis prüfen

Das Controlling prüf die so entstandenen Planwerte auf Plausibilität. Zu ambitionierte Pläne müssen ebenso zur Realität gebracht werden wie Pläne, die unterhalb vorgegebener Margen bleiben. Wenn z.B. alle Außendienstmitarbeiter eine Steigerung des Umsatzes um mehr als zehn Prozent für möglich halten, dann benötigen Sie gute Gründe für Ihren eigenen Plan, der unter dieser Grenze bleibt. Das Unternehmensergebnis der Planung ergibt sich aus der Addition aller Pläne der einzelnen Bereiche. Wenn das Planungsergebnis des gesamten Unternehmens nicht mit dem Ziel der Geschäftsführung übereinstimmt, muss der dritte Schritt mit veränderten Bedingungen wiederholt werden, bis eine Übereinstimmung erreicht wird. Selbstverständlich können Unternehmensleitung und Controller von Ihnen nur dann eine Plananpassung verlangen, wenn Ihnen auch die Mittel zur Veränderung der

Bedingungen gegeben werden. So müssen Ihnen für eine Produktionsausweitung entweder neue Mitarbeiter genehmigt werden oder die Mittel für Investitionen in Rationalisierungsmaßnahmen. Erweisen sich die Vorgaben als nicht erfüllbar, muss die Unternehmensleitung eine Entscheidung über die Veränderung des Unternehmensziels treffen oder zusätzliche Bedingungen schaffen, die eine Zielerreichung ermöglichen.

[…]

## Was ist das Budget?

Der Unternehmer hat viele Pläne im Kopf, die verantwortlichen Manager wollen ihre Bereiche weiterentwickeln. Mit einem unternehmensweiten Planungssystem bringt der Controller diese Pläne in Übereinstimmung miteinander. Gleichzeitig achtet er darauf, dass die Pläne vollständig sind und einem gemeinsamen Ziel folgen. Das verhindert aber nicht, dass die einzelnen Pläne hinsichtlich ihres Detaillierungsgrads unterschiedlich sind und ihre Zuordnung zu vorhandenen Strukturen oft nicht passt. Im nächsten Schritt sorgt der Controller dafür, dass aus den vielen Einzelplänen ein einziger Plan wird, der auch realistisch umgesetzt werden kann und dessen Entwicklung kontrolliert wird. Dieses Budget ist also das Werkzeug für die Umsetzung der Pläne in eine reale Vorgabe. Diese Umsetzung wiederum schafft die Voraussetzungen für die Planerfüllung auf allen Unternehmensebenen.

## Das Budget aufstellen

Wenn Sie die Planung abgeschlossen und die Ziele für das kommende Jahr festgelegt haben, ruhen Sie sich selbstverständlich nicht bis zum nächsten Jahr aus. Sie beginnen damit, Ihre Pläne umzusetzen. Der Controller tut auch seine Arbeit und bereitet die auf die Planung folgende Überwachung der Entwicklungen vor. Er stellt die Budgets auf.

- -Die Gesamtpläne für Kosten und Leistungen müssen in praktikable Einzelpläne überführt werden.
- -Die Kostenarten und unterschiedlichen Leistungsgrößen müssen entsprechend den monatlichen Kostenstellenabrechnungen aufgebaut werden.
- -Die Planzahlen müssen für die monatliche Überwachung vorbereitet werden.

Das Ergebnis dieser Controllingaufgaben ist das Budget. Ihr Budget enthält alle für Ihren Verantwortungsbereich vorgesehenen Planzahlen. Das Jahresbudget ist für die schnelle Überwachung in monatliche Budgets aufgeteilt worden. Die Kostenblöcke im Budget entsprechen den Kostenarten Ihrer Kostenstellenabrechnung. Sie enthalten jetzt auch die Kosten, die Ihrer Abteilung aus anderen Bereichen des Unternehmens zugeteilt wurden.

Innerhalb des Budgets sind Sie niemandem direkt verantwortlich, solange Sie mit Ihren Handlungen dazu beitragen, die geplanten Ziele zu erreichen. Eingeschränkt werden Sie nur durch Bedingungen, die in den Budgetverhandlungen bekannt waren. So kann z.B. ein Führungshandbuch existieren, das den Umgang mit Mitarbeitern und die Politik der Einstellungen und Entlassungen bestimmt. Oder das Unternehmen ist nach ISO 900X zertifiziert und verfügt über ein Qualitätshandbuch. Solche grundsätzlichen Vorschriften müssen Sie selbstverständlich in Ihrer täglichen Arbeit berücksichtigen. Daneben gibt es weitere Bedingungen, die während der Budgetgespräche ausdrücklich mit Ihnen vereinbart worden sind. Diese können quantitative Inhalte haben (z.B. die Erhöhung der durchschnittlichen Auftragswerke von 850 auf 950Euro) oder qualitative Vorgaben machen (z.B. die Kundenzufriedenheit zu steigern). Solche qualitativen Nebenbedingungen können

Ihren Spielraum innerhalb des Budgets stark einschränken, darum müssen Sie sie unbedingt gleichzeitig mit den Planwerten vereinbaren.

(Beispiel: Nebenbedingungen ins Budget

Für die IT-Abteilung können qualitative Nebenbedingungen vereinbart werden, die sich mit der Leistung der dort beschäftigen Mitarbeiter beschäftigen. Beispiele dafür können sein:

- · Die Anwender sind im Umgang mit den Office-Programmen auszubilden.
- · Die Bearbeitung jeder Fehlermeldung muss innerhalb einer Stunde nach der Meldung beginnen.
- · Für Zeiten außerhalb der normalen Arbeitszeiten und am Wochenende ist ein Notdienst einzurichten.
- · Die Verfügbarkeit der Informationstechnik muss wirtschaftlich gewährleistet werden.

Beispiele für oft nicht ausdrücklich angesprochene Nebenbedingungen oder Unterziele, die dennoch erfüllt werden müssen, sind:

- · Arbeitsspitzen werden mit Aushilfskräften abgedeckt, Überstunden müssen abgefeiert werden.
- · Externe Kräfte werden nur nach Absprache mit der Unternehmensleitung eingesetzt.
- · Jede Beschaffung, gleich welcher Produkte, Geräte oder Materialien, erfolgt durch den Einkauf.

)

Der Controller wird, wenn er seine Aufgabe gut macht, die Nebenbedingungen, die einen wichtigen Einfluss auf das Ergebnis Ihrer Stelle haben, ausdrücklich mit Ihnen gemeinsam festlegen. Auch diese Vereinbarungen müssen regelmäßig überprüf werden.

[…]

## Checkliste Budgetaufstellung

Bei der Aufstellung des Budgets müssen viele Punkte beachtet werden. Damit Sie keinen vergessen, folgt jetzt eine Checkliste mit den wichtigsten Parametern, die in den Budgetgesprächen berücksichtigt werden müssen. Die ausführliche Beschreibung der einzelnen Punkte ist notwendig, um der Komplexität der Budgetierung zu entsprechen.

CHECKLISTE: VOM JAHRESPLAN ZUM BUDGET Parameter Beschreibung erl.

- · Jahresplanung: Die Jahresplanung liegt vor, ist mit den anderen Unternehmensbereichen abgestimmt und genehmigt.
- · Monatswerte ermitteln: Die Monatswerte wurden aus den Jahreswerten mit sinnvollen Formeln ermittelt. Das gilt für alle Kosten- und Leistungsarten.
- · Monatswerte-Entwicklung sinnvoll: Der Verlauf der Monatswerte ist sinnvoll. Geplante Veränderungen zum Vorjahr sind sinnvoll auf die einzelnen Monate verteilt.
- · Monatswerte summieren: Die Summe der Monatswerte ergibt den Jahreswert. Das gilt für alle geplanten Kosten- und Leistungsarten.
- · Monatswerte prüfen: Jeder Monatswert für sich liegt innerhalb der möglichen Grenzen. Es werden in keinem Monat vorhandene Kapazitäten (Menschen, Maschinen, Logistik etc.) überschritten.
- · Monatswerte abstimmen: Jeder Monatswert ist mit den vor- und nachgelagerten Unternehmensbereichen abgestimmt und führt dort nicht zu Problemen.
- · Detailierung ausreichend: Die Aufteilung in Kostenarten und unterschiedliche Leistungen muss ausreichend sein, um Entwicklungen zu erkennen.
- · Detaillierung nicht zu hoch:  Die Aufteilung in Kostenarten und unterschiedliche Leistungen darf nicht zu komplex sein. Es lohnt nicht, Kostenarten mit geringem Einfluss separat zu planen oder jede einzelne Schraube im Verkauf zu budgetieren. Investitionen Die Auswirkungen von zusätzlichen
- · Investitionen: oder vom Abbau von Kapazitäten wurden zeitlich passend eingeplant. So wurden z.B. zusätzliche Mengen erst ab der geplanten Realisierung der Investition ins Budget übernommen.
- · Mitarbeiter: Veränderungen in der Mitarbeiterzahl wurden zeitlich passend budgetiert. Einarbeitungszeiten für neue Mitarbeiter oder Resturlaub für abgebaute Stellen wurden berücksichtigt.
- · Sonstige Kapazitätsveränderung: Andere Kapazitätsveränderungen wurden zeitlich passend eingeplant. So kann eine Ausweitung von Produktionslosgrößen erst dann erfolgen, wenn die notwendige Lagerkapazität aufgebaut wurde.
- · Investitionen: Die Kosten und Leistungen der geplanten Investitionen sind vollständig im Budget enthalten.
- · Mitarbeiter: Die Kosten und Leistungen der geplanten Mitarbeiter sind vollständig im Budget enthalten.
- · Umlagen: Die Leistungen aus Umlagekostenstellen (z.B. Informationstechnologie) sind korrekt geplant und als Kosten im Budget enthalten.
- · Nebenbedingungen: Die Nebenbedingungen zu den Budgetzahlen sind abgestimmt und festgehalten. Sie bilden die Umwelt des budgetierten Bereichs vollständig ab.
- · Verantwortungsbereich: Das Budget deckt sich mit dem Verantwortungsbereich des Planenden.
- · Einfluss: Die budgetierten Parameter können auch tatsächlich beeinflusst werden. Ist das nicht der Fall, werden sie fest vorgegeben und müssen entsprechend gekennzeichnet werden.
- · Vergleichsmöglichkeit: Die budgetierten Parameter können sowohl inhaltlich als auch zeitlich im Ist ohne großen Aufwand ermittelt werden. Nur so ist ein sinnvoller Vergleich der Planwerte mit den Istwerten möglich.

Einige der in der Checkliste enthaltenen Punkte lassen auf einen großen Aufwand schließen. So muss z.B. sichergestellt werden, dass die im Vertrieb geplanten monatlichen Verkaufsmengen auch tatsächlich produziert werden können. Der Aufwand für diese Prüfung ist bei Hunderten Produkten sehr hoch. In der Praxis kann jedoch sehr schnell eingeschätzt werden, ob solche Bedingungen erfüllt sind oder nicht. Die Erfahrung des Fachmanns und die Systematik des Controllers schaffen hier gemeinsam praktikable Lösungen.

[…]

## Zielvereinbarungen

Am Ende des Budgetgesprächs sind Ziele vereinbart, an denen Sie als der verantwortliche Stelleninhaber gemessen werden. Sie werden in den kommenden Monaten alles tun, um diese Ziele zu erreichen. Der Controller wird genau dies überwachen und eingreifen, sobald Probleme erkennbar sind. Auf der anderen Seite gibt das Budget Ihnen einen gewissen Freiraum. Solange Sie sich auf dem vereinbarten Weg befinden, das vereinbarte Ziel verfolgen und die Nebenbedingungen einhalten, können Sie in Ihrem Verantwortungsbereich allein entscheiden.

Leistungsziele : In den Leistungszielen werden die Leistungen der Abteilung oder der Kostenstelle festgehalten. Dabei ist es gleichgültig, ob es sich um Umsatz, Produktionszahlen, durchgeführte Arbeiten oder Qualitätsmerkmale handelt.

Kostenziele : Kostenziele sind immer abhängig von den Leistungszielen. Sie legen ein einzuhalten des Kostenniveau bei gegebener Leistung fest. Üblich sind, wenn es technisch möglich ist, auch Funktionen, die die Kostenhöhe von der erbrachten Leistung abhängig machen.

(Beispiel: Personalkosten in Abhängigkeit von der Produktion: In einer Fertigungsabteilung wird mithilfe von Automaten ein Produkt hergestellt. Zum Betrieb der Automaten werden Hilfskräfte nach Bedarf beschäftigt. Die Bezahlung erfolgt leistungsbezogen pro Stück. Außerdem sind noch fest angestellte Mitarbeiter für die Pflege der Maschinen und für die Logistik vorhanden. Die Personalkosten für die Aushilfskräfte sind variabel, die der angestellten Mitarbeiter zumindest kurzfristig fix. Dadurch ergibt sich folgende Abhängigkeit der Personalkosten von den produzierten Stückzahlen:

Personalkosten (Euro/Monat) = fixe Personalkosten (Euro/Monat) + variable Personalkosten (Euro/Stück) × Produktionsmenge (Stück/Monat)

Personalkosten = 7.500Euro/Monat + 1,50Euro/Stück × X Stück

Die Zielvereinbarung hinsichtlich der Personalkosten enthält in diesem Beispiel die genannte Formel. Es kann auch eine Tabelle angegeben werden, in der für realistische Stückzahlen ein Wert für die Personalkosten vorgegeben wird:

10.000 Stück = 22.500Euro

11.000 Stück = 24.000Euro

12.000 Stück = 25.500Euro

Eine solche Tabelle ist zwar nicht so genau wie eine Formel, vereinfacht aber das Verständnis und die laufende Kontrolle erheblich.)

Kostenziele werden für jede Kostenart, die einen bestimmenden Einfluss auf das Ergebnis der Stelle hat, vereinbart. Ein Tausch zwischen den Kostenarten (z.B. Personalkosten gegen IT-Kosten) ist in der Regel nicht möglich, da auf Grundlage der Summen der einzelnen Kostenarten weitere Pläne entwickelt wurden.

Kostenziele können nur für die direkten Kosten einer Stelle vereinbart werden, nicht aber für die indirekten. Indirekte Kosten entstehen in anderen Kostenstellen und werden durch Umlagen auf die Endkostenstellen verteilt. Typische Fälle sind Kosten für Gebäude, Verwaltung oder Personalwesen. Der jeweilige Kostenstellenverantwortliche, dessen Kosten verteilt werden, kann die absolute Höhe beeinflussen. Die empfangende Kostenstelle verantwortet lediglich den Verbrauch der Leistung.

(Beispiel: IT-Kosten im Vertrieb: Der Plan-Ist-Vergleich für die erste Hälfe des Jahres weist für den Vertrieb IT-Kosten in Höhe von 119.900Euro auf. Geplant waren lediglich 100.000Euro. Um die Ursache für diese Kostensteigerung zu ermitteln, ist eine detaillierte Betrachtung notwendig. Die IT-Kosten werden anhand der Anwenderzahl auf die einzelnen

Unternehmensbereiche verteilt. Geplant waren zehn Anwender im Vertrieb, die mit jeweils 10.000Euro IT-Kosten in die Kostenplanung eingegangen sind. Im Ist sind elf Anwender im Vertrieb vorhanden, die mit jeweils 10.900Euro bewertet werden. Damit trägt der Vertrieb die Verantwortung für 10.000Euro Mehrkosten (ein ungeplanter Anwender mit 10.000Euro Plankosten). Die Informationstechnologie muss den Rest 9.900Euro verantworten (elf Anwender mit Mehrkosten von 900Euro pro Anwender).)

## Nebenziele

Eine wichtige Rolle in den Zielvereinbarungen eines Budgets spielen die Nebenziele. Sie legen die Bedingungen fest, unter denen die Leistungs- und Kostenziele erreicht werden. So kann z.B. die Höhe der Personalkosten einer Abteilung abhängig sein von der Verfügbarkeit von IT-Leistungen. Wird der Einsatz von Computern ermöglicht, sinken die Personalkosten auf das geplante Niveau. Diese Bedingung ist festzuhalten. Nicht immer können Nebenziele in Zahlen ausgedrückt werden. Dann handelt es sich um qualitative Ziele, die meist nur schwer in den Budgetierungen festgehalten werden können. Auch die Beobachtung durch den Controller fällt schwer. So könnte sich ein Nebenziel mit der Betreuung der Anwender in der Entwicklungsabteilung durch die IT-Abteilung beschäfigen. Das Nebenziel für den Abteilungsleiter IT könnte sein, die Betreuung der CAD-Nutzer zu verbessern. Das wiederum kann eine Bedingung sein, unter der in der Entwicklungsabteilung bestimmte Ziele erreicht werden sollen. An dieser Stelle muss eine Quantifizierung erfolgen, die bereits bei der Zielfestlegung vereinbart werden muss.

## Zielformulierung

Der Controller ist dank seiner Ausbildung in der Lage, ein Ziel so zu formulieren, dass es praktikabel ist. Selbstverständlich achtet er darauf, dass das Ziel realistisch erreicht werden kann. Ansonsten wäre die gesamte Vereinbarung sinnlos. Außerdem muss er in der Zielformulierung einige Forderungen an praktikable Ziele beachten:

- · Ein Ziel muss allgemeingültig messbar sein. Die Vereinbarung muss festlegen, in welchen Einheiten das Ziel gemessen werden soll und ab wann es als erreicht gilt. Subjektive Zielerreichungsgrade müssen durch Bewertung (z.B. durch Befragung) messbar gemacht werden.
- · Ein Ziel muss einen Zeitbezug haben. Es wird vereinbart, welche Messzahl zu welchem Zeitpunkt erreicht sein muss. Sie können auch Zwischenstufen vereinbaren.
- · Die Zusammenhänge zwischen den Parametern, die verändert werden können, müssen bekannt sein. Die verantwortlichen Personen müssen in der Lage sein, diese Parameter zu beeinflussen.

(Beispiel: Ziele aus der Praxis:

- · Der Umsatz im Bereich Vertrieb Nord wird bis zum Ende des Planungsjahres um zehn Prozent steigen. Die Umsatzsteigerung wird kontinuierlich erfolgen.
- · Das Marketing wird im Planungsjahr drei Messen gestalten und dort insgesamt 1.000 Kontakte mit potenziellen Neukunden erzielen. Die Verteilung der Kontakte auf die drei Messen erfolgt gleichmäßig.
- · Die Entwicklungsabteilung wird im Planungsjahr die Zeit für die Entwicklung eines neuen Produkts von sechs auf vier Monate verkürzen. Dadurch wird erreicht, dass bis zum 31. Dezember des Jahres sieben neue Produkte produktionsreif sind.
- · Die Produktionsabteilung stellt vom 1. Januar bis zum 31. Dezember 518.000 Einheiten des Produkts A oder 412.000 Einheiten des Produkts B her. Eine eventuelle andere Zusammensetzung der Zahlen wird anteilig bewertet.
- · Der Einkauf senkt die Materialpreise innerhalb der nächsten zwölf Monate um durchschnittlich fünf Prozent, bezogen auf das Niveau vom 31. Dezember des laufenden Jahres.

Hier auch einige Ziele, die den Anforderungen nicht entsprechen und daher nicht für die Budgetierung geeignet sind:

- · Der Umsatz wird gesteigert. (Zeitbezug fehlt, keine überprüfbare Größe.)
- · Die Buchhaltung ergreif Maßnahmen, um den Umsatz im kommenden Jahr um 20 Prozent zu steigern. (Umsatz ist nicht von der Buchhaltung zu beeinflussen.)
- · Die IT-Abteilung steigert die Nutzung der digitalen Anwendungen um 20 Prozent. (Wie soll das gemessen werden? Die Informationstechnologie hat keinen Einfluss auf die Nutzung, die wird in der Fachabteilung entschieden.)

)

## Vom Stellenziel zum Unternehmensziel (oder umgekehrt)

Maßgebend für alle Aktivitäten im Unternehmen ist das Unternehmensziel, das von der Geschäfsführung festgelegt wird. Es kann Märkte, Produkte, Mitarbeiter, Kapitalgeber oder andere Parameter betrefen, enthält jedoch immer auch eine Erlöskomponente. Das Controlling sorgt mit seiner Arbeit dafür, dass alle Stellen- also die einzelnen Mitarbeiter, Gruppen und Abteilungen im Unternehmen - so gesteuert werden, dass das Unternehmensziel erreicht wird. Im Rahmen der Budgetierung werden für diese beteiligten Mitarbeiter, Gruppen und Abteilungen Stellenziele auf den unterschiedlichen Ebenen vereinbart, die in ihrem Ergebnis den von der Führung gewünschten Erfolg bringen müssen. Verantwortlich für die Planung und die Zielerreichung einer solchen Stelle, die meist mit der Kostenstelle identisch ist, sind Sie als Stellenleiter.

Die Zusammenhänge werden Ihnen und den anderen verantwortlichen Kostenstellenleitern nicht immer ersichtlich sein. So kann es durchaus sinnvoll sein, den Umsatz in einem Teilgebiet zurückzufahren, um das Gesamtziel einer Ausweitung des Marktanteils zu erreichen. Es kann durchaus sinnvoll sein, das Ziel für Ihren Verantwortungsbereich unterhalb des Möglichen anzusetzen, um damit das Unternehmensziel zu erreichen. Die Bildung der untergeordneten Ziele kann auf unterschiedliche Art geschehen:

- · Die einfachste Methode ist die mathematische Verteilung quantitativer Ziele. So kann ein angestrebter Gesamtumsatz entsprechend der bisherigen Verteilung aus der Vergangenheit auf die unterschiedlichen Vertriebsgebiete verteilt werden.
- · Bessere Ergebnisse verspricht eine Verteilung, die neben der Vergangenheit zumindest zu erwartende Veränderungen und spezielle Potenziale berücksichtigt.
- · Qualitative Ziele müssen durch individuell geplante Maßnahmen unterstützt werden. Soll z.B. laut Unternehmensziel der Shareholder Value gestärkt werden, sind unterschiedlichste Teilziele im gesamten Unternehmen notwendig.

## Fehlende Kenntnis der Gesamtzusammenhänge

Da Sie als einzelner verantwortlicher Stellenleiter die übergeordneten Unternehmensziele nicht unbedingt kennen oder die Zusammenhänge zwischen den Zielen aus Ihrer Arbeit heraus nicht ableiten können, sind Sie auf den Controller angewiesen. Dieser wird im Budgetgespräch versuchen, die Vereinbarungen so zu gestalten, dass sie den Ansprüchen der Geschäftsführung genügen.

(Beispiel: Eine einfache Zielabhängigkeit:

Unternehmensziel: In Deutschland soll 2023 der Umsatz auf Euro-Basis ein gleiches Wachstum erreichen wie der Markt, im Ausland erfolgt eine Konzentration der Aktivitäten auf die Euro-Länder mit einem mindestens 20-prozentigen Wachstum, die Umsätze in Osteuropa werden nur noch bei sichergestellter Bezahlung durchgeführt und sollen auf 50 Prozent des bisherigen Niveaus sinken.

Vertriebsbereich Inland: Der Umsatz steigt in 2023 entsprechend den Marktprognosen um mindestens acht Prozent.

Vertrieb Inland Nord: Der Umsatz wird in 2023 um mindestens zehn Prozent gesteigert.

Vertrieb Inland Süd: Der Umsatz wird in 2023 um mindestens zwölf Prozent gesteigert.

Vertrieb Inland Ost: Der Umsatz wird in 2023 auf dem Vorjahresniveau gehalten.

Vertriebsbereich Ausland: Der Umsatz wird in 2023 auf dem Vorjahresniveau gehalten, wobei der Umsatz in Osteuropa auf 50 Prozent des Vorjahreswerts sinkt und gleichzeitig die Sicherheit der Forderungseingänge garantiert wird. In den Euro-Ländern wird eine Steigerung von mindestens 20 Prozent gegenüber dem Vorjahr erreicht.

Vertrieb Osteuropa: Es werden sichere Finanzierungswege entwickelt, über die in 2023 allein der Umsatz erwirtschaftet wird. Dabei sinkt er nicht unter 50 Prozent des Vorjahreswerts.

Vertrieb EU: Der Umsatz mit den Euro-Ländern wird in 2023 um 20 Prozent gegenüber dem Vorjahr gesteigert.)

Die einzelnen Stellenziele werden aus dem jeweils übergeordneten Ziel abgeleitet. Die Ergebnisse aller Stellenziele zusammengenommen müssen das gewünschte Unternehmensziel ergeben. Dies prüft das Controlling im Rahmen der Budgetierung. Ist das nicht zu erreichen, muss das Unternehmensziel angepasst werden. Die Praxis zeigt jedoch, dass es in aller Regel Maßnahmen gibt, die zur Zielerreichung ergrifen werden können. Dies erhöht jedoch den Aufwand des Controllings.

## Zusammenhang sicherstellen

Die Aufgabe des Controllers, den Zusammenhang zwischen den Unternehmenszielen und den Stellenzielen aus dem Budget herzustellen, ist sehr anspruchsvoll. Nicht immer ist der Zusammenhang als einfache Addition der Teilziele darzustellen.

- · In einzelnen Abteilungen entwickeln sich gleiche Sachverhalte relativ zueinander mit Unterschieden. Der Umsatz in einzelnen Vertriebsgebieten muss unterschiedlich stark gesteigert werden, um jeweils die gleiche Ertragsverbesserung zu erreichen. Das liegt an unterschiedlichen Margen in den Vertriebsbereichen.
- · Unternehmensziele haben andere Dimensionen als die Teilziele. So hat das Unternehmensziel »Senkung der Fremdverschuldung« Auswirkungen auf Lagerbestände, Bestellgrößen und Zahlungskonditionen. In den betroffenen Abteilungen ist kein direkter Bezug zur Fremdverschuldung gegeben.
- · Die Leistungen der Einzelbudgets können selbst bei gleicher Einheit nicht sinnvoll addiert werden. Wenn der Fertigungsbereich 1 die Maschinen herstellt und der Fertigungsbereich 2 die Ersatzteile, macht die Addition von Stückzahlen wenig Sinn.

Ohne eine ausgleichende Stelle ist es nicht möglich, aus den einzelnen Teilzielen das Unternehmensziel zu errechnen oder aus dem Unternehmensziel die einzelnen Teilziele korrekt abzuleiten. Diese Aufgabe erfüllt der Controller.

## Planung und Budgetierung im Controlling: Warum ist Planung notwendig?

- · Tempo, Komplexität und Veränderungsdynamik haben sich wesentlich erhöht und führen gleichzeitig zu steigender Unsicherheit bei Unternehmungsentscheidungen.
- · Verknappung der Ressourcen erfordert ein Umdenken.
- · Ungeheure Konzentrationstendenzen.
- · Veränderte Nachfragemacht der Abnehmer. Niemand kann es sich noch leisten, Entscheidungen ungeplant, spontan, d. h. 'aus dem Bauch heraus' zu treffen. Die Begriffe 'Planen' und 'Planung' werden unterschiedlich definiert:
- · 'Planung ist ein in die Zukunft gerichtetes, systematisches Denken und Festlegen von Maßnahmen'.
- · 'Planung - eine besondere Art zielstrebigen menschlichen Handelns' (Kosiol).

Allgemein kann man Planung als 'ein systematisches, zukunftsbezogenes Durchdenken und Festlegen von Zielen, Maßnahmen, Mitteln und Wegen zur künftigen Zielerreichung' auffassen.

Planung ist der Entwurf einer Ordnung, nach der sich das betriebliche Geschehen in der Zukunft vollziehen soll (Gutenberg).

Unabhängig von allen Definitionen gilt, dass systematischer Leistungserstellungsprozess eine systematische Planung erfordert.

Planen ist ein systematischer Prozess, bei dem künftige Ziele, Pläne, die zu ihrer Erreichung notwendigen Maßnahmen und der dafür erforderliche Mitteleinsatz festgelegt und aufeinander abgestimmt werden. Planung will die Zukunft aktiv gestalten. Planung muss von der Unternehmensführung bewusst und aktiv wahrgenommen werden. Sie ist Pflichtaufgabe und die Verantwortung dafür ist nicht delegierbar!

Planung ist nicht Wahrsagen sondern das analytische Abwägen von Notwendigkeiten mit Möglichkeiten zur Erreichung der Zielvorstellungen. Pläne sind Ziele, die erreicht werden sollen, erweitert um Vorgaben, wie die Erfüllung zu bewerkstelligen ist. Auch die beste Planung kann nicht verhindern, dass Abweichungen auftreten. Aber die Planung zeigt auf, dass Abweichungen auftreten werden bzw. aufgetreten sind! Bei der Planung werden zukünftige Entwicklungen bereits berücksichtigt, soweit sie bei der Planerstellung bereits zu erkennen sind. Planung sorgt dafür, dass heute Maßnahmen ergriffen werden, die nicht nur morgen, sondern auch zukünftig die Existenzsicherung ermöglichen, d.h., es sind heute systematisch zukünftige Chancen und Risiken zu erkennen und zu beachten, Erfolgspotentiale für die Zukunft aufzubauen.

Planung ist aber nicht gleichbedeutend mit 'Vorhersage der Zukunft'. Die Vorschau hat nur untergeordnete Bedeutung; die Vorgabe und Steuerungsfunktion überwiegt. Mit der Planung soll 'zukünftiges Tathandeln' vorweggenommen werden. Bei jeder Planung müssen Annahmen getroffen werden auf der Basis vorhandener Informationen und Wissens, die das wann, was, wie, wer, wo beantworten sollen.

Allerdings ist es eine Illusion zu glauben: Die Planungsphilosophie sagt, Ergebnis ist der Zielerfüllungsversuch. Plan = Ist = unzulässige Fiktion.

Sinn und Zweck der Planung können mit den Begriffen Partizipation, Kommunikation, Koordination und Terminisierung umschrieben werden:

- -Partizipation: Mitarbeit aller Verantwortungsträger bei der Aufstellung der gemeinsamen Pläne als Basis für künftige Aktivitäten
- -Kommunikation: Planung ist ein formeller Weg der gegenseitigen Information um Planansätze zu generieren
- -Koordination: Planung zeigt, wo und warum Koordination und Aktivitäten nötig sind, um eine positive Zusammenarbeit sicherzustellen.
- -Terminisierung: Pläne zeigen, welche Aktivitäten zu welchem Zeitpunkt erforderlich sind.

Der Rahmen, in dem sich die Planung des Controllers bewegt, ist eindeutig vorgegeben durch die Zielsetzung des Unternehmens.

Planung ist ein fortwährender Prozess, der die Weiterentwicklung des Unternehmens und seine Anpassung an veränderte Umweltbedingungen sicherstellen sollten.

Das Ergebnis der Planung sind nicht Feststellungen und Rechtfertigungen, sondern die Beseitigung der Ursachen. Deshalb müssen die eingehenden Werte der Planung zielorientiert, kompetent, kooperativ, systematisch, kreativ, innovativ, zukunftsorientiert, marktorientiert, vollständig, verbindlich, kontrollierbar, realisierbar, angemessen und vor allem wirtschaftlich sein.

Die Planungsfunktion des Controllings besteht im Wesentlichen aus folgenden Einzelaufgaben:

- ■ Beratende Mitwirkung bei der Aufstellung der Unternehmensziele
- ■ Aufstellen eines zielorientierten Gesamtplanes
- ■ Koordination und Leitung der Planungsarbeiten, Beratung der Kostenstellen, Abstimmung und Koordination des Gesamtplanes mit den Teil und Einzelplänen, Aufstellen von Kostenplänen.

Die Planungstätigkeit des Controllers beinhaltet auch die Entwicklung und den Einsatz geeigneter Medien, Systeme und Instrumente, um den Verantwortungsbereichen die Vorgabegrößen verständlich und aussagefähig zur Verfügung zu stellen.

Bei der Planung muss der Controller folgende Aufgaben übernehmen:

- 1. Entwickeln mit Einsatz geeigneter Systeme, Instrumente
- 2. Bekanntgabe der Ziele für die Verantwortungsbereiche
- 3. Erstellen von Planungsrichtlinien/Erarbeitung eines Planungshandbuches
- 4. Budgetierung und Bestimmung der Kostenverantwortlichen
- 5. Erarbeitung und Überprüfung von Planungsrichtlinien
- 6. Durchführung von Soll-Ist-Vergleichen
- 7. Erarbeitung von Abweichungsanalysen

Sind für die einzelnen Verantwortungsbereiche die Leistungsziele definiert, müssen die Kostenvorgaben erarbeitet werden. Die konkrete Vorgabe von Leistungszielen und dadurch notwendigen Kosten für die einzelnen Bereiche erfolgt durch die Budgetierung. Mit den Kostenvorgaben erhält jeder Verantwortungsträger Steuerungs und Zielgrößen, die eingehalten werden müssen, es sei denn, Planungsgrößen und/ oder Ausgangsprämissen haben sich grundlegend verändert.

Durch die Budgetierung wird die Verantwortung für die Zielerreichung den einzelnen Bereichen/Abteilungen und Kostenstellen übertragen. Deshalb muss für alle Verantwortungsbereiche des Unternehmens über ein individuelles Budget definiert werden. Die Zusammenfassung dieser Budgets gemäß der hierarchischen Gliederung des Unternehmens führt dann zum Gesamtbudget. Die Budgetierung folgt damit der organisatorischen Verantwortungsstruktur des Unternehmens und das Gesamtbudget regeneriert sich aus den Bereichen und Kostenstellenbudgets.

Der Planungsprozess erfolgt in folgender Reihenfolge:

- 1. Unternehmensanalyse, Marktanalyse [&amp;] Umweltanalyse
- 2. Festlegung der Unternehmenszielsetzung
- 3. Planung
- 4. Koordination der Realisierung
- 5. Abweichungsanalyse
- 6. Rückkopplung (von der Abweichungsanalyse zu Unternehmensanalyse, Marktanalyse [&amp;] Umweltanalyse)

Das zentrale Problem bei jeder Planung sind die folgenden Fragen:

- a) Wer plant und trägt hierfür die Verantwortung?
- b) Wie wird geplant?
- c) Was wird geplant?

Zu a): Neben dem Controller und seinen Mitarbeitern grundsätzlich immer diejenigen, die letztlich die Verantwortung dafür tragen, dass die Pläne später erfüllt werden. Die Betrachtung dieses Grundsatzes erleichtert die Kostensteuerung, denn die verantwortlichen Bereichsleiter, Abteilungsleiter, Kostenstellenleiter kennen ihr Fachgebiet und die tatsächlichen Möglichkeiten. Sie sind mit den zu lösenden Problemen meist besser vertraut; ihr Urteil bildet die sachliche Basis, die allein allerdings nicht ausreicht. Hinzukommen muss der höhere Informationsgrad des Controllers und sein hoffentlich höherer Objektivitätsgrad. Besonders die Objektivität ist bei den Kostenstelleninhabern nicht immer gegeben. Planvorgaben dürfen deshalb nie allein von Kostenstelleninhabern festgelegt werden! Das würde in den meisten Fällen nur den Kostenstellen und Eigeninteressen zugutekommen, nicht aber den übergeordneten Unternehmenszielen. Andererseits darf die Planungsvorgabe von Planwerten nicht ohne Mitarbeit und Zustimmung des Kostenstelleninhabers erfolgen. Verantwortung kann nur übernommen werden, wenn man über den Grad der zu übernehmenden Verantwortung informiert wird und wenn man nach der direkten Auseinandersetzung mit dem Controller auch bereit ist, Verantwortung zu tragen. Eine Planvorgabe, von der der Kostenstelleninhaber genau weiß, dass sie objektiv unerreichbar ist, kann auch durch sofortige Korrekturmaßnahmen bei den ersten Abweichungen durch den Controller nicht mehr eingehalten werden. Es gilt bei der Ermittlung und Vorgabe von Plankosten, die Informationen der 'Planenden' (in diesem Fall der Controller) und die Informationen der 'Geplanten' (die Kostenstellenleiter) gemeinsam zu erund verarbeiten. Die Motivationswirkung dieses Grundsatzes ist ein nicht zu unterschätzender Faktor im Planungsprozess.

Zu b): Hier wird die Frage angeschnitten, nach welcher Methode geplant wird und welcher Genauigkeitsgrad angestrebt wird. Welche geeigneten Kennziffern und

Bewertungsmaßstäbe gibt es? Wie detailliert muss die Planung sein, welche Art der Planungsdarstellung ist erforderlich? Dabei kommt es sehr stark auf die jeweilige Struktur des Unternehmens an, es gibt hierzu keine allgemein gültigen Richtlinien. Bei der Frage nach dem wie gilt es für den Controller, die entsprechenden Planungshilfen und Planungsformulare zu entwickeln, die Methoden zu erklären und konkret mitzuarbeiten. Zu

- c): Die Frage, was als Planwert überhaupt eingehen soll, ist die eigentliche Kernfrage. Es ist ein großer Unterschied, ob man nur Kosten in ihrer Gesamtheit plant und vorgibt, oder ob man die Kosten detailliert bis zur kleinsten Kostenstelle erfasst und in den Soll-Ist-Vergleich mit aufnimmt. Es gilt hier, sorgfältig die Kosten für den Planungsprozess mit dem späteren Erkenntniswert des Soll-Ist-Vergleichs abzuwägen. Es würde dem ökonomischen Prinzip widersprechen, wenn man z.B. für die Planung der Bleistifte in der Kostenstelle 'Allgemeine Verwaltung' eine langwierige Kostenanalyse durchführen würde. Für die Kostensteuerung des Unternehmens durch Soll-Ist-Vergleiche dürfte es ziemlich belanglos sein, ob hier die Planung auf € 100,- oder € 50,- genau ist.

[…]

## Die Koordination der Planung

Die Koordination der Planung ist eine der Hauptschwierigkeiten in der Planung. Diese Koordination kann grundsätzlich von 'unten nach oben' ('bottom up') und von 'oben nach unten' ('top down') erfolgen.

Beide Verfahren haben ihre Vor- und Nachteile:

## Top down Planung:

- -Vorteile: Ganzheitliche Zielformulierung wird versucht, durchzusetzen. Alle Führungsebenen werden an diesem Ziel gemessen. Information über Gesamtziele
- -Nachteile Zielvorgabe für alle Ebenen nur schwer definierbar. Gefahr, dass man nur solche Pläne aufstellt, die leicht verwirklicht werden. (Niedriges Anspruchsniveau) Gefahr zu hoher Planungsvorgaben

## Bottom up Planung:

- -Vorteile: Teilpläne stehen im Mittelpunkt, die schrittweise verdichtet werden, um so einen Gesamtplan zu generieren. Mehr Motivation für die einzelnen Ebenen.
- -Nachteile: Evtl. niedriges Gesamtzielniveau (Nivellierungsgefahr!) Zusammenfassung von Teilplänen eventuell nicht zielführend. Man baut Planreserven auf.

[…]

VUCA ist ein Akronym für die englischen Begriffe Volatility, Uncertainty, Complexity und Ambiguity. Der Begriff weist darauf hin, dass die Veränderungen insgesamt vier Kategorien zuzuordnen sind, deren Beherrschung jeweils unterschiedliche Maßnahmen erfordert.

## Die vier VUCA-Kategorien:

## 1. Komplexität:

- o Eigenschaften: Es gibt viele miteinander verbundene Teile und Variablen. Einige Informationen sind verfügbar oder können vorhergesagt werden, aber das Volumen oder die Art können zu komplex sein, um verarbeitet zu werden.
- o Beispiel: Sie machen Geschäfte in vielen Ländern, alle mit einzigartigen regulatorischen Umgebungen, Zöllen und kulturellen Werten.
- o Ansatz: Restrukturierung, Einbringung oder Entwicklung von Spezialisten und Aufbau von Ressourcen, die der Komplexität gerecht werden.

## 2. Volatilität:

- o Eigenschaften: Die Herausforderung ist unerwartet oder instabil und kann von unbekannter Dauer sein, aber sie ist nicht unbedingt schwer zu verstehen; Wissen dazu ist oft verfügbar.
- o Beispiel: Die Preise schwanken, wenn eine Naturkatastrophe einen Lieferanten handlungsunfähig macht.
- o Ansatz: Kalkulieren Sie einen Leerstand mit ein und schaffen Sie Ressourcen zur Vorbereitung - z.B. durch Aufbau von Lagerbeständen oder durch übermäßige Beschaffung. Diese Schritte sind typischerweise teuer; Ihre Investition sollte dem Risiko entsprechen.

## 3. Mehrdeutigkeit

- o Eigenschaften: Kausale Beziehungen sind völlig unklar. Es gibt keine Präzedenzfälle. Sie stehen vor 'unbekannten Unbekannten'.
- o Beispiel: Sie beschließen, in unreife oder aufstrebende Märkte zu ziehen oder Produkte außerhalb Ihrer Kernkompetenzen einzuführen.
- o Ansatz: Experiment. Um Ursache und Wirkung zu verstehen, müssen Hypothesen generiert und getestet werden. Gestalten Sie Ihre Experimente so, dass die gewonnenen Erkenntnisse breit angewendet werden können.

## 4. Unsicherheit:

- o Eigenschaften: Trotz fehlender anderer Informationen sind die grundlegenden Ursachen und Wirkungen des Ereignisses bekannt. Veränderung ist möglich, aber nicht gegeben.
- o Beispiel: Die Produkteinführung eines Wettbewerbers macht die Zukunft des Geschäftsmodells und des Marktes unsicher.
- o Ansatz: Investieren Sie in Informationen: Sammeln Sie, interpretieren Sie und teilen Sie Informationen. Das funktioniert am besten in Verbindung mit strukturellen Änderungen, wie z. B. mit zusätzlichen Netzwerken zur Informationsanalyse, die die anhaltende Unsicherheit reduzieren können.

[…]

Der Sachverhalt 'Hierarchiedynamik' bestimmt, wie die einzelnen Planungsorgane sachlich und zeitlich zusammenwirken. Die Entwicklungsfolge von Plänen kann bezogen auf die Organisationsstruktur folgende Formen annehmen:

- i. Retrograde Planung : Die Planung erfolgt in der Organisationshierarchie von 'oben' nach 'unten' (Top-down-Ansatz); d. h. die Führungsspitze des Unternehmens legt die obersten Ziele als Rahmenplan fest, die weiteren Führungsebenen konkretisieren diese Schrittweise in detailliertere Teilpläne:
- a. Prinzip der Gesamtplanung: Die Planung erfolgt in der Organisation von 'oben" nach 'unten".
- b. Realisationsvoraussetzungen: Werden nur teilweise erfüllt, da nur ein Mittelrahmen bekannt.
- c. Planungsmotivation: Vorgabecharakter beeinträchtigt
- d. Koordinationsmöglichkeiten: Koordinationserfordernisse häufig nicht erkennbar.

[…]

- e. Kommunikationserfordernisse: Beträchtliche Informationsprobleme der Führungsebene. Notwendigkeit von Rückkopplungen.
- f. Arbeits- und Zeitaufwand: Rückkopplungen sind arbeits- und zeitaufwendig.
- g. Fazit: Einseitiger Ansatz: was müssen wir tun?
- h. Gefahren der Suboptimierung. Der vertikalen Interdependenz kann nur durch weitgehende Zentralisation der Planung Rechnung getragen werden.
- ii. Progressive Planung : Die Planung beginnt bei den unteren Ebenen der Organisationen und wird schrittweise in der Organisation nach 'oben' geführt (Bottom-up-Ansatz). Die Gesamtziele und -pläne sind somit das Endergebnis der Planung.
- a. Prinzip der Gesamtplanung: Die Planung erfolgt in der Organisation von 'unten" nach 'oben" (Anti-these zur retrograden Planung).
- b. Realisationsvoraussetzungen: Besser als bei der retrograden Planung, da Pläne von Realisierern entwickelt.
- c. Planungsmotivation: Schlecht erfüllt. Negativkoordination, Fortschreibung alter Ziele
- d. Koordinationsmöglichkeiten: Horizontale Koordination nicht gegeben.
- e. Kommunikationserfordernisse: Rückläufe auch hier erforderlich.
- f. Arbeits- und Zeitaufwand: Rückläufe sind arbeits- und zeitaufwendig.
- g. Fazit: Einseitiger Ansatz: was können wir tun? Auch hier Gefahren der Suboptimierung. Horizontale Koordination erforderlich.
- iii. Gegenstromverfahren : Diese Vorgehensweise kombiniert die retrograde mit der progressiven Planung. Zunächst werden vorläufige Oberziele durch die oberste Führungsebene gesetzt und aus ihnen durch die untergeordneten Ebenen deduktiv Unterziele und Teilpläne zwecks Prüfung der Realisationsmöglichkeiten abgeleitet. Dann setzt der Rücklauf von 'unten' nach 'oben' ein, der die Pläne der unteren Ebenen schrittweise koordiniert und zusammenfasst. Der Prozess schließt ab mit der endgültigen Festlegung der Ziele und Pläne durch die oberste Führungsebene. Der Anstoß kann im Prinzip auch von 'unten' erfolgen.
- a. Prinzip der Gesamtplanung: Ein retrograder Vorlauf und ein progressiver Rücklauf vereinigen Elemente der vorgenannten Verfahren.
- b. Realisationsvoraussetzungen: Sehr gute Realisationsvoraussetzungen, da Planung und Realisationsmöglichkeiten durchgehend abgestimmt.
- c. Planungsmotivation: Sehr gut gegeben, da das Abstimmungsverfahren planungsmotivierend wirkt.
- d. Koordinationsmöglichkeiten: Vertikale und horizontale Koordination vorgesehen.
- e. Kommunikationserfordernisse: Kommunikationserfordernisse größer als bei progressiver und retrograder Planung.
- f. Arbeits- und Zeitaufwand: Arbeits- und zeitaufwendiger als retrograde und progressive Planung.
- g. Fazit: Kein einseitiger Denkansatz. Risiken der Suboptimierung werden vermieden. Der vertikalen Interdependenz der Planung wird Rechnung getragen.

In der Praxis eines Controllers nehmen Budgets einen zentralen Platz ein. In amerikanischen Unternehmen wird 'Controllership' häufig mit 'Budgeting' gleichgesetzt.

## […]

Die Budgetierung wird häufig als das Instrument der Planung angesehen, mit dem am zeitlichen Ende des Planungsprozesses die erstellten Pläne in quantitative, vor allem wertmäßige Größen transformiert werden.

## […]

Ein Budget ist für uns ein formalzielorientierter, in wertmäßigen Größen formulierter Plan, der einer Entscheidungseinheit für eine bestimmte Zeitperiode mit einem bestimmten Verbindlichkeitsgrad vorgegeben wird. Budgets gibt es somit auf allen Planungsstufen und für alle Planungsfristigkeiten.

Wesentlich ist, dass nach unserer Auffassung - die mit der Praxis übereinstimmt - Budgets und Aktionspläne auf allen Planungsstufen existieren. Auf diesen Stufen müssen sach- und formalzielorientierte Pläne aufeinander abgestimmt werden. Das Gewicht und der Detaillierungsgrad der Budgets nehmen von der Strategiestufe zur operativen Stufe zu.

Die Ergebniszielorientierung des Controllings kann ohne Budgets nicht realisiert werden!

Budgets können anhand zahlreicher Merkmale differenziert werden. Unmittelbar aus unserer Definition ergeben sich folgende Möglichkeiten:

- · Merkmal Entscheidungseinheit:
- o horizontale Differenzierung nach Funktionen, Prozessen, Produkten, Regionen oder Projekten,
- o vertikale Differenzierung nach Ebenen der Unternehmenshierarchie.
- · Merkmal Geltungsdauer, z. B.:
- o Monatsbudget,
- o Quartalsbudget,
- o Jahresbudget,
- o Mehrjahresbudget.
- · Merkmal Wertdimension, z. B.:
- o Ausgabenbudget,
- o Kostenbudget,
- o Deckungsbeitragsbudget,
- o Umsatzbudget.
- · Merkmal Verbindlichkeitsgrad, z. B.:
- o Budget mit Vorgabe einer absolut starren Ober- bzw. Untergrenze ('Etat'),
- o Budget mit Vorgabe einer Orientierungsgröße.

Die Unterscheidung 'starres' bzw. 'flexibles' Budget betrifft die Frage, inwieweit Budgets für einen oder für mehrere Beschäftigungsgrade vorgegeben werden. Starre Budgets werden ausschließlich für eine bestimmte Beschäftigung festgelegt, flexible Budgets differenzieren die Vorgaben für eine Bandbreite möglicher Beschäftigungshöhen.

In der Praxis werden unter Budgets manchmal ausschließlich die eher kurzfristigen und mit einem starken Verbindlichkeitsgrad ausgestatteten formalzielorientierten Pläne verstanden ('Jahresbudget'). Wir wollen diese Einschränkung nicht mit vollziehen, weil wir der Auffassung sind, dass formalzielorientierte Pläne auf allen Planungsstufen von wesentlicher

Bedeutung für die Lenkung des Unternehmens sind, auch wenn ihr Verbindlichkeits- bzw. Detaillierungsgrad bei langfristig-strategischen Plänen abnehmen mag.

[…]

## Das Budgetierungssystem

Unter Budgetierung wollen wir den gesamten Budgetierungsprozess verstehen, d. h. insbesondere Aufstellung, Verabschiedung, Kontrolle sowie Abweichungsanalyse. Das Budgetierungssystem ist jenes Subsystem des PK-Systems, dem die formalzielorientierte Planung und Kontrolle zugeordnet werden kann. Hinsichtlich der Subsysteme des Budgetierungssystems differenzieren wir analog zu unseren früheren Ausführungen. Wir unterscheiden:

- · funktionale Sicht:
- o Budgets (Budgetsystem)
- o Budgetierungsaktivitäten
- · institutionale Sicht:
- o Budgetierungsorgane
- o Budgetierungsprozesse
- · instrumentale Sicht:
- o 'ideelle' Budgetierungsinstrumente
- o reale (technische) Budgetierungsinstrumente

Alle Ausführungen, die wir bereits zur Koordination von Planung und Kontrolle gemacht haben, gelten auch für die Budgetierung. Wir wollen im Folgenden die wichtigsten spezifischen Aspekte der Koordination des Budgetierungssystems ansprechen. An erster Stelle steht die Frage, wie die Schnittstelle, zwischen der sachziel- und der formalzielorientierten Planung gestaltet wird:

- -Erstens geht es um die Enge der Systembeziehungen und
- -zweitens ist die hierarchische Beziehung zwischen den beiden Planungssubsystemen von Bedeutung.

Die Enge der Systembeziehungen betrifft funktional und organisatorisch die Frage, wie stark zwischen sachziel- und formalzielorientierten Planungen differenziert wird. Empirische Untersuchungen (vgl. Horváth et al. 1985; Posselt 1986; Dambrowski 1986) zeigen, dass die Kopplung der beiden Teilsysteme durchweg recht hoch ist. Viele sachziel- und formalzielorientierte Planungsaufgaben sind z. B. im Zuständigkeitsbereich der gleichen Personen; der Budgetierungsprozess wird häufig stark in den Prozess der Gesamtplanung eingebunden und inhaltlich gibt es zwischen Budgets und Aktionsplänen häufig Überschneidungen. Hinsichtlich des hierarchischen Beziehungszusammenhangs zwischen Budgetierung und Aktionsplanung lassen sich zwei Grundtypen unterscheiden:

- -Die Aktionspläne gehen den Budgets voraus und determinieren diese vollständig und
- -Budgets gehen den Aktionsplänen voraus und bestimmen wesentlich die Inhalte der Aktionspläne.

In der Realität dominieren Mischformen, die sogar in den verschiedenen Teilbereichen des PK-Systems variieren können.

Budgetierung ist Erfolgsplanung. Sie kann erfolgen:

- -retrograd, d. h. die einzelnen Pläne werden aus einer vorgegebenen Erfolgsgröße abgeleitet, oder
- -progressiv, d. h. der Erfolg ergibt sich als Restgröße aus den einzelnen Teilplänen.

Das Budgetsystem ist die geordnete Gesamtheit aufeinander abgestimmter Budgets. Die Vorgaben in den einzelnen Budgets können die Dimension aller erfolgs- und finanzorientierten Grundgrößen des Rechnungswesens haben. Die Verdichtung der einzelnen Budgets erfolgt in drei Richtungen:

- -Budgetierte Erfolgsrechnung,
- -Budget der Finanzmittel und
- -budgetierte Bilanz.

[…]

## Aufgaben, Organisation und Instrumente der Budgetierung

Der Budgetierungsprozess ist in der Regel in den Gesamtprozess der Planung eingebettet. So bilden langfristige Zielpläne zunächst den Rahmen für Investitionsbudgets und die Investitionsplanungen verschiedener Planungseinheiten. Nach deren Verabschiedung und der Fixierung der langfristigen Zielplanung erfolgt die detaillierte operative Planung über ca. drei Monate hinweg. Ergebnisse sind schließlich die operative Planung und die daraus abgeleitete Finanzplanung/Budgetierung.

Im Budgetierungsprozess nimmt die Abstimmung der Zahlen der einzelnen Teilbudgets einen wesentlichen zeitlichen Anteil ('Knetphase') ein. Hier muss die Controllerin als Koordinatorin mitwirken. Weitere wesentliche Arbeitsschritte aus der Sicht des Controllings sind auf die Kontrollphase konzentriert. Hier sind die Gestaltung und die laufende Überwachung des Soll-Ist-Vergleichs sowie die Abweichungsanalyse gemeint. Die Dokumentation der Zahlen erfolgt im Rahmen der Budgetberichterstattung. In der Regel erfolgt bei der Jahresbudgetierung ein monatlicher Soll-Ist-Vergleich sowie die Hochrechnung (Forecasting) der zu erwartenden Jahreszahlen bzw. teilweise auch über das Jahresende hinweg Erwartungswerte im Sinne einer rollierenden Planung z. B. über 5 Quartale in die Zukunft.

In der Abweichungsanalyse interessiert nicht nur die punktuelle Soll-Ist-Abweichung eines Teilbudgets, sondern auch die Beeinträchtigung des Gesamterfolges durch diese Abweichung. Darüber hinaus wird nach Abweichungsursachen und nach Korrekturvorschlägen gefragt.

Während des Budgetjahres erfolgen in der Regel Budgetanpassungen, wenn sich wesentliche Prämissen für die Budgetvorgabe verändert haben. Sogenannte Erwartungsrechnungen signalisieren die Auswirkungen solcher Prämissenveränderungen. Man wird natürlich aus wirtschaftlichen Gründen abwägen, wann die Prämissenveränderungen so erheblich sind, dass eine kostenverursachende Budgetanpassungsprozedur erforderlich wird. Bei der Abweichungsanalyse der Budgetvorgaben interessiert nicht nur die Einzelabweichung. Wesentlich ist das Gewicht einer Abweichung, d. h. ihre 'Ergebniswertigkeit'.

Die (ideellen) Budgetierungsinstrumente sind in erster Linie der Informationsversorgung zuzurechnen. Es handelt sich um Verfahren aus dem Bereich des Rechnungswesens, insbesondere der Kosten- und Leistungsrechnung.

Budgets sollen - wie alle Pläne - verhaltensbeeinflussend wirken. Damit Budgets ihre Steuerungswirkung realisieren können, sind einige verhaltensbezogene Gestaltungsempfehlungen einzuhalten:

- -Budgets müssen sich auf klar umrissene Verantwortlichkeiten beziehen,
- -Budgetvorgaben müssen messbar sein,
- -Budgetvorgaben müssen seitens der Budgetverantwortlichen beeinflussbar sein,
- -Budgetvorgaben müssen herausfordernd, aber erreichbar sein,
- -Budgetvorgaben müssen einen Handlungsspielraum ('budgetary slack') enthalten und
- -Budgetverantwortliche sind am Budgetierungsprozess zu beteiligen.

Die Praxis zeigt, dass durch die Budgetierung häufig auch dysfunktionale Wirkungen entstehen. Die Beteiligten versuchen, das Budget 'auszutricksen'. Ein typisches Fehlverhalten ist das 'Budget wasting': Budgetierte Mittel werden verschwendet. Der Grund liegt darin, dass Neubewilligungen häufig von der Ausschöpfung früherer Bewilligungen abhängig gemacht werden oder dass der Erfolg der Mittelverwendung nicht bestimmbar ist. Die Änderung dieser Einstellung kann im Prinzip nur durch Nachweis oder Glaubhaftmachung des Erfolgs beim Mitteleinsatz erreicht werden. Eine andere Dysfunktionalität wird dadurch geschaffen, dass zu niedrige oder zu hohe Vorgaben unzulässige Spielräume ('slack') erlauben.

Neben den dysfunktionalen Wirkungen schränken insbesondere aktuelle Entwicklungen des Wettbewerbsumfeldes Effektivität und Effizienz der Budgetierung nachhaltig ein.

## Beyond Budgeting und Better Budgeting

## Weiterentwicklungen der klassischen Budgetierung

Die Budgetierung ist in den meisten Unternehmen der jährlichen Ergebnis- und Finanzplanung gleichzusetzen, die detailliert und umfassend die operativen Planungsinhalte monetär abbildet.

Mintzberg kritisierte bereits, dass Budgetierung die Planung auf ein 'Numbers Game' reduziere. Zudem sind im heutigen VUCA-Kontext Strategieflexibilität und Kundenorientierung wichtig, um in der veränderten Wettbewerbslandschaft zu bestehen. Klassische Budgets versagen jedoch bei der Abbildung dieser neuen Erfolgsfaktoren und verhindern eine notwendige Anpassung des Steuerungssystems in mehrfacher Hinsicht:

- · Zeitlich und inhaltlich fixierte Strategien und (Jahres-) Budgets können nicht schnell und flexibel neuen Umweltbedingungen angepasst werden,
- · Budgets haben in der Regel keine Verbindung zur Strategie,
- · administrativ gehandhabte 'command and control'-Budgets hemmen die Kreativität der Mitarbeiter und fördern dysfunktionale Verhaltensweisen,
- · Innovationen verlangen Investitionen. Budgets wirken mit ihrer kurzfristigen und risikoscheuen Sichtweise kreativen Innovationen entgegen,
- · periodenbezogene Kostenziele in Budgets verhindern kontinuierliche, an marktbezogenen Benchmarks orientierte Verbesserungsprozesse,
- · Budgets liefern keine Messgrößen zur Steuerung 'weicher' kritischer Erfolgsfaktoren, wie z. B. Kundenzufriedenheit und
- · Budgets fokussieren kurzfristige Erfolgsziele und nicht langfristige Wertsteigerung.

Trotz der genannten Kritik an der Budgetierung bleibt eine ergebniszielorientierte Koordination (und damit die Funktion der Budgets) unverzichtbar zur Unternehmenssteuerung. Zwei grundlegende Optionen stehen zur Verfügung:

- a. Verbesserung funktionaler und institutionaler Aspekte der bisherigen Budgetierung (' Better Budgeting ') oder
- b. Verzicht auf die herkömmliche Budgetierung und Wahrnehmung der erforderlichen Funktionen durch andere Instrumente (' Beyond Budgeting ').

Better Budgeting will das bestehende Budgetierungssystem durch die Fokussierung der Planungsinhalte (funktionaler Aspekt) und durch die Verkürzung des Budgetierungsprozesses (institutionaler Aspekt) optimieren. Der funktionale Aspekt umschließt insbesondere:

- · Konzentration auf erfolgskritische Prozesse und damit Reduzierung der erforderlichen Budgets und finanziellen Vorgabegrößen,
- · marktorientierte Ziele und Vorgaben anstelle von Budgetierung auf Basis der Fortschreibung,
- · schnelle Vorschauinformationen anstatt detaillierter budgetbasierter Prognoserechnungen,
- · Verlassen des Kalenderjahres und z. B. Übergang zur Meilensteinbudgetierung und
- · Reduzierung von Frequenz und Anzahl der Budgetkontrollen und damit Fokussierung des Reporting.

Hinsichtlich der organisatorischen Gestaltung soll der Budgetierungsprozess flexibilisiert und verkürzt werden, indem

- · die Top-down-Komponente der Aufbauorganisation gestärkt wird, um den Arbeitsund Zeitaufwand zu reduzieren,
- · der Budgetvereinbarungs- und -verabschiedungsprozess vereinfacht und
- · die operative Planung dezentralisiert wird.

Durch diese Maßnahmen lassen sich sowohl aktuellere Daten in die Planung mit einbeziehen, als auch die Planungszeiträume auf bis zu drei Monate reduzieren.

## […]

Der Beyond Budgeting-Ansatz verzichtet vollkommen auf Budgets. Traditionell von der Budgetierung übernommene Funktionen müssen daher durch andere Instrumente realisiert werden. Die Anwendung moderner Instrumente des Empowerments und des strategischen Managements, wie die Balanced Scorecard, vermeidet die Nachteile der Budgetierung und verwirklicht gleichzeitig einen effektiveren und effizienteren Steuerungsansatz: Dieser neue Steuerungsansatz unterstützt die Verknüpfung der operativen Planung mit der Unternehmensstrategie und fördert kontinuierliche Prozesse der Strategieentwicklung. Die Delegation von Ressourcenverantwortung wirkt motivierend und verbessert zugleich die Planungsqualität durch 'größere Nähe zum Geschäft'.

Im praktischen Einsatz hat sich das Konzept laut mehreren Veröffentlichungen jedoch nicht bewährt. Von einer Verbreitung und praktischen Anwendungen ist kaum et- was bekannt. Ferner gerieten einige Prämissen von Beyond Budgeting in starke Kritik. Obwohl das Konzept selbst nicht in der Praxis verankert und etabliert ist, hat es wichtige Anstöße für die Weiterentwicklung von Budgetierungsystemen gegeben:

- · Orientierung am Markt und Wettbewerb,
- · Konzentration auf Führung (Führungsprozesse und Führungsverhalten) statt auf (Führungs-)Instrumente sowie
- · Aufmerksamkeit auf wenig bekannte, aber relevante Instrumente (relative Ziele, rollierende Planung und Hochrechnung, bedarfsorientierte Ressourcensteuerung).

Aufbauend auf den verschiedenen Konzepten der Budgetierung (Better Budgeting und Beyond Budgeting) wurde in der Literatur auch immer wieder das Konzept des Advanced Budgeting erwähnt. Dieses zielt 'auf eine abnehmende Bedeutung von Budgets auf mittlere Frist bei kurzfristiger Steigerung der Planungsqualität und Verringerung des Budgetierungsaufwandes' ab.

Ein neues und stark durch die Praxis geprägtes Modell ist der Ansatz der ' Modernen Budgetierung ', der in den vergangenen Jahren durch den Internationalen Controller Verein e. V. (ICV) und Experten aus Wissenschaft, Praxis und Beratung entwickelt wurde. Da die Budgetierung den Kern der unternehmerischen Formalzielplanung darstellt, liegt ein großes Augenmerk der Controllerin und des Controllers - als oberster Planungsmanager - auf den Koordinationsaktivitäten im Rahmen der Budgetierung. Eine spezielle Herausforderung ist die Abstimmung der sachzielorientierten, operativen Planung mit der mehr formalzielorientierten Budgetierung.

Das neuentwickelte Modell gibt zwar auch prozessuale Hinweise, fokussiert im Kern jedoch auf Empfehlungen bezüglich Gestaltung und sogenannten Fundamenten. Diese

Empfehlungen beziehen sich stark auf funktionale und instrumentelle Aspekte der Budgetierung.

'Die Gestaltungsempfehlungen umfassen drei Empfehlungen für die Gestaltung der Planungsprozesse und Planungsebenen sowie die Auswahl der Planungsinstrumente:

- · Einfach: Schlanke Abläufe, die sich nur auf steuerungsrelevante Inhalte beschränken, nur nutzenbringende Instrumente und Methoden einsetzen, nur wenige Eingangsgrößen, optimale Detaillierung finden, manchmal genügt auch 'top-down'.
- · Flexibel: Bereitschaft für Änderungen, Sensitivitäten und Szenarien, auch relative Ziele aufgrund von Benchmarks, (rollierende) Forecasts, flexibles und kontrolliertes Umschichten von Ressourcen.
- · Integriert: Strategie, Planung, Reporting und Forecasts müssen verknüpft sein. Konkrete, aber wenige voneinander ableitbare Vorgaben, Budget und Anreizsysteme lose koppeln, nicht nur kurzfristige Ziele.

Ebenso werden drei Empfehlungen zur Festlegung der wichtigsten Fundamente gegeben:

- 1. Organisation abbilden: Konkrete, eindeutige Ziele, Orientierung am Gesamtziel, Organisation muss kurze und schnelle Entscheidungswege finden.
- 2. Wertschöpfung abbilden: Verständnis der eigenen Wertschöpfungskette. Ziele, Engpässe und Restriktionen determinieren die Planung.
- 3. Absichten klar machen und kommunizieren: Ziele und Absichten klar verständlich machen, den Kern des Plans kommunizieren und leistungsebenengerecht transformieren, Umsetzungsverantwortung mitteilen, durch Prämissen und Top-down Vorgaben Planungsschleifen verhindern'.

## […]

Die bisherigen Konzepte der Budgetierung im Vergleich:

## Better Budgeting:

- · Ziel: Optimierung einzelner Bereiche der Planung
- · Absicht: Beibehaltung der Budgetierung

•

Ergebnis: Verbesserung von punktuellen Schwachpunkten der Planung,

Effizienzsteigerung/Aufwandssenkung

- · Planung: Vereinfachung und Konzentration auf erfolgskritische Prozesse; verstärkte Berücksichtigung strategischer Inhalte in der operativen Planung
- · Motivation: Stärkerer Fokus auf marktorientierte Zielsetzung
- · Koordination: Vorwiegend Koordination über Pläne

## Advanced Budgeting:

- · Ziel: Optimierung des gesamten Planungssystems
- · Absicht: Zurückdrängung der Bedeutung von Budgets
- · Ergebnis: Erhöhung der Planungsqualität und Verringerung des Budgetierungsaufwands
- · Planung: Vereinfachung und Konzentration auf erfolgskritische Prozesse; verstärkteBerücksichtigung nicht-monetärer Größen; Einsatz neuer Instrumente (BSC, Benchmarking), integrierte operative und strategische Planung
- · Motivation: Stärkerer Fokus auf marktorientierte Zielsetzung
- · Koordination: Vorwiegend Koordination über Pläne

## Beyond Budgeting:

- · Ziel: Veränderung des gesamten Managementsystems
- · Absicht: Abschaffung von Budgets als fixierte Leistungsverträge
- · Ergebnis: Bessere Unternehmenssteuerung durch Rückbesinnung auf mitarbeiterorientierte/partizipative Führungskonzepte
- · Planung: Rollierende, auf monetäre und nicht-monetäre Kerngrößen fokussierende Planung; integrierte operative und strategische Planung; Dezentralisierung der Planung
- · Motivation: Selbstadjustierende Zielsetzung relativ zu internen/externen Vergleichsobjekten
- · Koordination: Dezentrale marktähnliche Koordination; Unterstützung durch zentrale Stellen

Ein interessanter neuer Ansatz, bei dem bewusst der Verzicht auf eine Budgetierung gefordert wird. Das Beyond Budgeting geht davon aus, dass budgetbasierte Planungsprozesse eher negativ sind und lehnt deshalb die traditionelle Budgetierung ab und zielt auf die Dezentralisierung der Verantwortungs und Entscheidungsfindung, um so den gesamten Steuerungsprozess in der Unternehmung zu verbessern. Es bedeutet nicht unkontrolliertes Vorgehen, sondern es werden andere Mittel eingesetzt, die Leistungsanreize geben und eine flexiblere Planung ermöglichen.

Im Mittelpunkt stehen die Prinzipien der adaptiven Prozesse und der Dezentralisierung. Damit wird das als veraltet empfundene Prinzip der fixen Zielvorgaben vermieden, welches in Unternehmen häufig dazu führt, dass man zwar versucht diese Ziele zu erreichen, aber keine Anreize bestehen sie zu überschreiten. Beyond Budgeting führt hingegen zur automatischen Anpassung der Ziele an die möglichen Chancen. Vor allem die Dezentralisierung soll die Eigenverantwortung stärken und die 'zentrale Planungsbürokratie' überwinden. Es wird der starre am Kalender orientierte Planungszyklus aufgelöst und mit rollierender Planung (rolling forecast) gearbeitet.

Beyond Budgeting baut auf folgende Prinzipien auf:

- 1. Self Governance: Starre bürokratische Regeln werden durch eindeutige Werte und Grenzen ersetzt.
- 2. Leistungsverantwortung: Von Mitarbeitern wird Eigenverantwortung gefordert.
- 3. Empowerment: Kundennähe wird bei den Entscheidungen gefordert.
- 4. Struktur: Es entsteht ein Netzwerk.
- 5. Koordination: Gestalten der internen Prozesse, so dass sie effizienter ineinander übergreifen.
- 6. Führung: Änderung des Führungsstils durch Coaching.
- 7. Zieldefinition: Nicht vage Zielvorstellungen, sondern konkrete Ziele auf der Grundlage des Benchmarkings und von Wettbewerbsanalysen. Außerdem werden noch folgende Prinzipien gefordert: Strategieprozesse, Antizipationssystem, Ressourcennutzung, Messen, Kontrollen, Motivation und Vergütung.

Beyond Budgeting: Unter dem Schlagwort 'Beyond Budgeting' wird ein Planungs- und Steuerungsmodell verstanden, das zum Ziel hat, Budgets zu ersetzen (vgl. z. B. Schäffer und Zyder 2003). Damit soll eine flexiblere, weniger arbeitsaufwändige und marktgerechte Unternehmenssteuerung erfolgen. Anstelle von klassischen Budgets wird stark auf Delegation von Entscheidungen an dezentrale Bereiche sowie empowerment, Netzwerkorganisation und marktnahe Koordination gesetzt. Beyond Budgeting nutzt daher andere Koordinationsinstrumente als die Budgetierung. Dies kann in bestimmten Unternehmenssituationen nützlich sein, in anderen wiederum nicht. Beispielsweise ist eine starre und detaillierte Budgetierung bei steigender Unsicherheit auf den Märkten weniger hilfreich als eine flexible Budgetierung auf Basis rollierender Forecasts. Ein apodiktisches Urteil, dass die Budgetierung überkommen sei, ist damit aber nicht zu stützen.

## Partizipationsvarianten im Agency-Modell

Bevor geprüft werden kann, welche Partizipationsvariante angesichts der second bestLösung sinnvoll ist, muss zunächst eine Interpretation der weiter oben allgemein dargestellten Budgetierungsvarianten im Kontext des Agency-Modells erfolgen. Dazu werden folgende Interpretationen verwendet:

- · Top down-Budgetierung . Die Größen des Budgetsystems werden ohne Partizipation des Managers alleine von der Zentrale festgelegt. Der Manager hat also keinerlei Einfluss auf die Bestimmung der Budgetgrößen, die ihm von der Zentrale einfach 'diktiert' werden.
- · Bottom up-Budgetierung . Die Zentrale erwartet vom Manager eine Berichterstattung über die tatsächlich vorliegende Kostensituation. Diese Berichte werden von der Zentrale nicht weiter überprüft, sondern quasi 'unbesehen' übernommen. Dieses System gibt dem Manager den dominanten Einfluss auf die konkrete Budgetfestlegung.
- · Budgetierung im Gegenstromverfahren. Der Manager legt zwar auch hier einen Bericht zur Kostensituation vor. Dieser Bericht wird aber nicht 'unbesehen' übernommen, sondern von der Zentrale gemäß dem eigenen Informationsstand und den eigenen Zielvorstellungen in Kostenniveaus transformiert

## Traditionelle Budgetierung

Ein Budget ist für uns ein formalzielorientierter, in wertmäßigen Größen formulierter Plan, der einer Entscheidungseinheit  für  eine  bestimmte  Zeitperiode  mit  einem  bestimmten  Verbindlichkeitsgrad vorgegeben  wird.  Die  Formalzielorientierung  grenzt  die  Budgetierung  von  der  sachzielorientierten Planung ab. Die sachzielorientierte Planung ist an Aktivitäten orientiert. Zielobjekte sind beispielsweise bestimmte Absatzoder Produktionszahlen. Die formalzielorientierte Planung ist auf die finanzwirtschaftlichen Auswirkungen, wie bestimmte Liquiditäts- oder Rentabilitätsziele, gerichtet.

Budgetierung umfasst 'den gesamten Prozess der Erstellung, Vorgabe, Kontrolle und Anpassung von Budgets.

Zur weiteren Differenzierung der Planung folgen drei grundsätzliche Merkmale. Den Zeithorizont der Planung, den Charakter und den Zentralisationsgrad der Planentstehung. Diese Charakteristika können auf die Budgetierung übertragen werden.

Bezüglich der Zeithorizont der Budgetierung hat die Budgetierung hat meist einen Planungshorizont von  einem  Jahr  und  wird  für  jedes  Geschäftsjahr  neu  erstellt.  Von  diesem  in  der  Praxis  weit verbreiteten  Planungshorizont  kann  es  jedoch  auch  Abweichungen  geben.  Neben  Mehrjahres-, Quartalsund  Monatsbudgets  sind  insbesondere  für Projekte spezielle  periodenunabhängige Periodenbudgets verbreitet

Dem  folgt  der  Charakter  der  Budgetentstehung.  Für  die  Budgeterstellung  besteht  prinzipiell  die Möglichkeit, entweder stark auf Erfahrungen der Vergangenheit zu bauen oder die Planansätze jeweils neu zu ermitteln. Die Fortschreibung von Vergangenheitswerten - 'Ex-post-Planung" oder 'Ex-postplus-Planung" genannt - ist relativ einfach, da diese Form der Budgetgenerierung auf das Budget der Vorperiode zurückgreift und lediglich geringfügige Änderungen  und Anpassungen  vornimmt. Problematisch wird diese

Form  der  Budgetierung,  wenn  Änderungen  in  Strukturen  und  Ausprägungen  zunehmen,  die  eine umfangreiche Anpassung der Budgets beziehungsweise deren grundlegende Neuplanung erforderlich machen.

Bei einer grundlegenden Neuplanung bilden produkt- und marktbezogene Absatz- und Umsatzpläne die Ausgangsbasis. Darauf aufbauend werden anhand von analytisch zu erstellenden Produktionsfunktionen,  Arbeitsganglisten,  Stücklisten  und  ähnliches  detaillierte  Budgets  für  die einzelnen Bereiche des Unternehmens erstellt. Diese Vorgehensweise verursacht jedoch erhebliche Planungs- und Koordinationskosten.

Als dritter Grund folgt der Zentralisationsgrad der Budgetentstehung. Da das budgetierungsrelevante Wissen  im  Unternehmen  verteilt  ist,  sind  häufig  mehrere  Stellen  in  den  Budgetierungsprozess involviert. In Abhängigkeit davon, wie das Wissen im Unternehmen verteilt ist, sind unterschiedliche Grundformen der Planungsmitwirkung möglich. Dabei ist es das Ziel, die verschiedenen

Verantwortungs- und Informationsebenen der Hierarchie so zu gestalten und zu verknüpfen, dass jede Ebene den besten Beitrag zum Planungsprozess leistet.

Verfügt die Unternehmensspitze über ein hohes Maß an budgetierungsrelevantem Wissen, prägt diese den Budgetierungsprozess, indem sie den Rahmen und die Ziele festlegt. Untergeordneten Ebenen bleibt die Aufgabe, diese Vorgaben zu präzisieren und zu konkretisieren. Diese zentralisierte Form der Budgetentstehung nennt man 'retrograde Budgetierung" oder 'Top-down-Budgetierung".

Verfügen dagegen die dezentralen Bereiche über einen Wissensvorsprung, kommt der Unternehmensspitze  die  Rolle  eines  Koordinators  dezentral  gebildeten  Willens  zu.  Aufgabe  der dezentralen Bereiche ist die Budgeterstellung für ihren Bereich. Die Teilbudgets werden schrittweise aggregiert,  bis  schließlich  das  Gesamtbudget  resultiert.  Man  spricht  von  einer  'progressiven Budgetierung"  beziehungsweise  vom  'Bottom-up-Ansatz".  Ist  das  Budgetierungsrelevante  Wissen schließlich über das gesamte Unternehmen verteilt, leisten sowohl Unternehmensspitze als auch die dezentralen  Bereiche  ihren  jeweiligen  Beitrag  zur  Budgeterstellung.  Die  Unternehmensspitze  gibt Leitlinien  und  zentrale  Ziele  vor,  die  dezentralen  Einheiten  bringen  ihr  Detailwissen  und  ihre Vorstellungen ein. In einem 'Gegenstromverfahren" kommt es zum Abgleich und zur Integration der Sichtweisen, bis das endgültige Budget durch die Unternehmensspitze verabschiedet wird.

Die Budgetierung soll grundsätzlich vier Aufgaben erfüllen: einen Leistungsmaßstab vorgeben, Ziele für die nächste Geschäftsperiode festlegen, betriebliche Teilbereiche aufeinander abstimmen und die finanzielle  Entwicklung  prognostizieren  helfen.  Was  ist  der  wesentliche  Vorteil  von  Budgets?  Das Budget erlaubt den Mitarbeitern größere Entscheidungs- und Handlungsspielräume. Es weist nur einen Geldbetrag aus und bestimmt nicht, was damit genau getan werden soll. Damit sollen die Mitarbeiter auch  stärker  motiviert  sein  und  rascher  reagieren  können.  Weiterhin  reduziert  sich  für  die Unternehmensleitung  der  Planungsaufwand,  da  nicht  mehr  jedes  Detail  und  jede  Maßnahme  zu planen ist. Es lassen sich unterschiedliche Budgetarten benennen. Beim traditionellen Budgetsystem wird eine Mengenplanung vorausgesetzt und benötigt. Ohne Planung der Absatzmengen, kombiniert mit den Absatzpreisen, ergibt sich kein Umsatzbudget, Entsprechendes gilt für das Produktionsbudget wie auch für jedes Budget.

Der Ablauf der Budgetaufstellung besteht im Wesentlichen aus sechs Phasen. Die erste Phase ist eine Entwicklung von Budgetrichtlinien. Denn in die Budgetaufstellung gehen eine Reihe von Informationen ein, wie z.B. Vorgaben aus der strategischen Planung und der langfristig operativen Planung, weitere budgetrelevante Faktoren wie die Änderung des Produktionsprogramms und Erkenntnisse aus der Abweichungsanalyse des letzten Budgets. Weiterhin wird das Management Ziele und Restriktionen vorgeben. So könnten Einsparungsziele genannt sein oder Begrenzungen der Finanzmittel, Absatzmengen, Produktionsmengen oder ähnliches.

Die  zweite  Phase ist  das  Aufstellen  der  Teilbudgets.  Jeder  Budgetverantwortliche  wird  für  seinen Verantwortungsbereich auf der Basis der Budgetvorgaben sowie einer Mengen- und Wertplanung ein erstes Budget aufstellen.

Die dritte Phase ist die Budgetabstimmung und Budgetverhandlung. Bei der Budgetaufstellung muss der Budgetverantwortliche seine Pl ä ne meist unternehmensintern noch abstimmen. So hat er auch interne Leistungsverflechtungen mengen- und wertm ä ßig zu ber ü cksichtigen. Auch werden mit ü berund untergeordneten F ü hrungsebenen Abstimmungsgespr ä che zu f ü hren sein.

Die vierte Phase ist die Budgetpr ü fung und Budgetkonsolidierung. Das zentrale Controlling wird die eingehenden Budgets auf ihre inhaltliche und formale Richtigkeit pr ü fen. Inhaltlich meint hier nicht so sehr,  ob  die  Planinhalte  selbst  korrekt  sind,  sondern  ob  sie  korrekt  gerechnet,  nachvollziehbar begr ü ndet und mit anderen Pl ä nen abgestimmt sind. Formal pr ü ft der Controller die Einhaltung der Richtlinien  zur  Darstellung  und  Gliederung  der  Budgets.  Nach  dieser  Pr ü fung  und  gegebenenfalls Anpassung  sind  die  Budgetpl ä ne  zu  einem  Gesamtbudget  zu  konsolidieren: Ä hnlich  wie  in  der Konzernkonsolidierung des Konzernrechnungswesens m ü ssen interne Lieferund Leistungsbeziehungen so eliminiert werden, dass am Ende ein Gesamtbudget ohne Mehrfachz ä hlungen entsteht. Dieser Schritt des Budgetprozesses f ü hrt meist zu mehreren Budgetierungsl ä ufen mit den F ü hrungskr ä ften und Controllern im Unternehmen.

Die fünfte Phase ist die Genehmigung und Vorgabe. Sind alle Abstimmungen zwischen F ü hrungskr ä ften derselben Ebene sowie zwischen allen Hierarchieebenen einschließlich des obersten Managements erfolgreich abgeschlossen, erh ä lt die Unternehmensleitung die Budgets zur Genehmigung. Damit erhalten alle Budgetverantwortlichen ihre Zielvorgabe und ihren Kompetenzrahmen f ü r die Folgeperiode.

Die  sechste  Phase ist  die  Kontrolle  und  Abweichungsanalyse:  Die  Budgetkontrolle  pr ü ft  sowohl w ä hrend der Budgetperiode als auch nach Ablauf der Periode die Zielerreichung. Eine Zielverfehlung ist zun ä chst nur ein Symptom f ü r ein m ö gliches Problem, und so müssen in der Abweichungsanalyse die Ursachen für Budgetabweichungen herausgearbeitet werden ebenso wie die Verantwortlichen für Abweichungen und mögliche Gegenmaßnahmen.

Der regelmäßige, oft jährliche Budgetprozess ist in vielen Unternehmen sehr aufwendig und bis ins letzte Detail durchstrukturiert. Die einzelnen Schritte werden in einem Budget- und Planungskalender detailliert  festgehalten.  Damit  erleichtert  man  sich  komplexe  Planungen  in  großen  Unternehmen, handelt sich dafür jedoch auch eine geringe Flexibilität ein, wenn sich Märkte rasch entwickeln oder die Organisation verändert wird.

Die traditionelle Budgetierung ist stark am Rechnungswesen orientiert und erfordert somit von den Beteiligten ein umfassendes Verständnis für die bilanziellen Zusammenhänge und Buchhaltung. Als Ausgangslage  verwendet  die  traditionelle  Budgetierung  meist  die  produkt-  und  marktbezogenen Absatz-  und  Umsatzpläne.  Die  Basis  für  die  Daten  kommt  aus  der  Marktforschung  und  aus  den Vergangenheitswerten,  damit  bilden  sie  den  Grundstein  für  die  Bestimmung  der  Pläne  für  die Produktion  bzw.  Leistungserstellung.  Anschließend  leiten  sich  aus  den  Produktionsplänen  die Beschaffungspläne  ab.  Für  die  Beschaffungspläne  steht  bei  den  Unternehmen  oft  eine  analytische Datenbasis zu Verfügung, wie Stücklisten für die Produkte.

Die  Planungsbasis  für  die  administrativen  und  dispositiven  Leistungen  in  Absatz,  Produktion  und Beschaffung ist oft deutlich ungenauer zu ermitteln. Für diese Kosten werden häufig Vergangenheitswerte  verwendet,  worin  aber  zugleich  ein  Problem  liegt,  da  die  Vergangenheit  für zukunftsorientierte  Pläne  nur  eingeschränkt  aussagekräftig  ist.  Vor  allem  bei  der  inkrementellen Budgetierung  bzw.  Budgetfortschreibung  wächst  das  Volumen  des  Budgets  jährlich  und  es  wird lediglich über die Budgeterhöhung verhandelt, aber nicht das bisherige Budget in Frage gestellt. Somit wird hierbei auch nicht die Möglichkeit schrumpfender Budgets in Betracht gezogen, was angesichts der heutigen volatilen Entwicklungen auf vielen Märkten jedoch notwendig erscheint.

Es  findet  sich  in  der  traditionellen  Budgetierung  oft  die  Vereinbarung  von  Zielen  sowie  auch Belohnungen und Mittel zur Erreichung von diesen vereinbarten Zielen zwischen dem Management und den Mitarbeitern. Damit soll die Motivation der Mitarbeiter erhöht werden, sich für die gleichen Ziele  wie  diejenigen  der  Geschäftsführung  einzusetzen  und  diese,  wenn  immer  möglich  sogar  zu übertreffen.

Die traditionelle Budgetierung wurde in der heute bekannten Form bereits in den ersten Jahrzehnten des 20. Jahrhunderts entwickelt, um die zunehmend diversifizierten und komplexen Unternehmen zu steuern,  allerdings  mit  der  Einschränkung,  dass  man  sich  ursprünglich  an  einem  hierarchischen, arbeitsteilig organisierten Großunternehmen orientierte.

Die wichtigsten Eigenschaften der traditionellen Budgetierung sind folgende.

Koordination durch Pläne. Die Koordination der Entscheidungseinheiten erfolgt durch die Formulierung und Kommunikation von Budgets.

Mittlerer Grad der Dezentralisierung . Es wird ein mittlerer Dezentralisierungsgrad für die Koordination gewählt, womit regelmäßig das bereits oben erläuterte Gegenstromverfahren gemeint ist.

Vollständigkeit und Detaillierung . Die klassische Budgetierung ist durch eine hohe Detaillierungstiefe gekennzeichnet. Durch die steigende Anwendung des Cashflows, Working Capital oder den Economic Value Added™ (EVA) im Zusammenhang mit der Budgetierung hat die Anzahl der zu beplanenden Position eher noch zugenommen.

Fortschreibungsplanung . In der Praxis basiert das Budget oft auf vergangenheitsorientierten Werten, welche jährlich fortgeschrieben werden. Die Neuplanung der Positionen erfolgt sehr eingeschränkt. Auch eine Verkleinerung des Budgets wird meist nicht in Betracht gezogen.

Absolute, intern orientierte Ziele . Die Budgetierung dominiert oft durch einen internen Fokus und nur die internen Ziele werden verfolgt. Die marktorientierte Budgetierung wird meist nicht angewendet.

Mittelfristplanungsfokus .  Bei  der  Budgeterstellung  ist  der  Budgetverantwortliche  meist  in  einem gewissen Umfang eingebunden. Für die Budgetkontrolle wird eher eine Fremdkontrolle angewendet, das heißt vor allem das Controlling oder Accounting erstellt die Abweichungsanalysen.

Einjahresfokus .  Im  klassischen  Verständnis bezieht sich die Budgetierung auf das Geschäftsjahr als Budgetzeitraum. Forecast oder Hochrechnungen unter dem Jahr sind immer auf das Geschäftsjahresende gerichtet.

Begrenzte Partizipation . Nur bei der Budgeterstellung ist der Budgetverantwortliche regelmäßig aktiv eingebunden,  während  die  Budgetkontrolle  im  Sinne  einer  Fremdkontrolle  primär  durch  das Controlling oder Accounting z.B. mittels Abweichungsanalysen erfolgt.

Kombination von Prognose und Motivation .  Durch die Kombination von Prognose und Motivation über  ein  Budget  können  unerwünschte  Verhaltenswirkungen  die  Verlässlichkeit  der  Budgetierung beeinträchtigen.

Starke Formalisierung, aber begrenzte Unterstützung durch Planungswerkzeuge . In der Praxis ist die Budgetierung mehrheitlich durch einen hohen Formalisierungsgrad geprägt, jedoch ohne dass dabei eine spezialisierte Planungssoftware zur Anwendung kommt.

Dadurch ergeben sich folgende Vorteile .

Hoher  Detaillierungsgrad,  Einfachheit,  Mitarbeitende  bewegen  sich  in  gewohnten  Strukturen, Eingespielter Prozess, Budgets sind stabil, Fehler im Prozess wurden bereits eliminiert

## Und folgende Nachteile .

Zeitaufwendig, Kostenintensiv, Starr und unflexibel, Fixierung auf ein Jahr, Auslöser für Budgetspiele, Fortschreibung der Kosten vom Vorjahr, Einbau von Puffern, Verfolgung von rein monetären Strategien

## Moderne Budgetierung

Moderne Budgetierung f ü hrt zur ü ck zum Planungskern. Ü ber ein integriertes Konzept, verkn ü pft mit der Strategie, den Zielen und dem Managementsystem soll das Budget konsequent, einfach, und vor allen Dingen umfeldflexibel bestimmt werden. Moderne Budgetierung bedeutet nicht, neue Tools und gar Konzepte zu erfinden.

Die Prinzipien werden in zwei Kategorien mit insgesamt sechs Dimensionen eingeteilt:

## Gestaltungsempfehlungen:

Einfach:  schlanke  Abl ä ufe,  die  sich  auf  steuerungsrelevante  Inhalte  beschr ä nken,  nur  Nutzen bringende Instrumente und Methoden einsetzen, nur wenige Eingangsgrößen, optimale Detaillierung finden, manchmal gen ügt auch 'top -down'

Flexibel: Bereitschaft f ü r  Veränderungen, Sensitivit ä ten und Szenarien, auch relative Ziele aufgrund von Benchmarks, (rollierende) Forecasts, flexibles und kontrolliertes Umschichten von Ressourcen

Integriert: Strategie, Planung, Reporting und Forecasts m ü ssen verkn ü pft sein. Konkrete, aber wenige voneinander ableitbare Vorgaben. Budget und Anreizsysteme lose koppeln. Nicht nur kurzfristige Ziele.

## Fundamente:

Organisation  abbilden:  konkrete,  eindeutige  Ziele,  Orientierung  am  Gesamtziel,  Organisation  muss kurze und schnelle Entscheidungswege finden

Wertschöpfung  abbilden:  Verständnis  der  eigenen  Wertschöpfungskette.  Ziele,  Engpässe  und Restriktionen determinieren die Planung

Absichten klar machen und kommunizieren: Ziele und Absichten klar verständlich machen, den Kern des  Plans  kommunizieren  und  leistungsebenengerecht  transformieren,  Umsetzungsverantwortung mitteilen, durch Prämissen und Top-down-Vorgaben Planungsschleifen verhindern.

## Bezüglich Einfachheit - Detaillierung verringern: Case Mineralölkonzern

Bei dem  betrachteten Unternehmen  handelt  es  sich um  eine Sparte eines internationalen Mineralölkonzerns. Hier wurden sowohl das Budgetjahr als auch die Folgejahre im Planungstool der Sparte  sehr  detailliert  geplant.  Dann  wurde  das  Budgetjahr  im  ERP-Tool  (SAP  R/3)  noch  einmal detailliert. Der hohe Detaillierungsgrad zog sich durch alle Planungen; am augenfälligsten jedoch in der Kostenartenplanung.

Die  hohe  Detaillierung  war  mit  einem  hohen  Aufwand  für  die  Erfassung  verbunden;  jeder Planungsverantwortliche musste 38 Kostenarten planen. Dieser Aufwand wäre zu rechtfertigen, wenn ihm ein entsprechen- der Steuerungsnutzen gegenübersteht. Ein solcher Nutzen wurde jedoch nur für das  Budgetjahr  gesehen;  der  Nutzen  der  hohen  Detaillierung  der  Folgejahre  wurde  durchweg  als ungenügend betrachtet.

Um  zu prüfen, inwiefern die Detaillierung der Kostenartenplanung ohne Verringerung des Steuerungsnutzens reduziert werden kann, wurde eine ABC-Analyse durchgeführt. Diese zeigte, dass über 80 % der Kosten von 8 Kostenarten ausgemacht wurden und 13 Kostenarten 90 % der Plan-Kosten repräsentierten.

Diese  Ergebnisse  konnten  dazu  genutzt  werden,  den  Detaillierungsgrad  der  Kostenartenplanung deutlich zu verringern. In der Mittelfristplanung werden jetzt nur noch 13 Kostenarten separat geplant; die restlichen Kostenarten wurden in einer PlanKostenart 'Sonstige' zusammengefasst. Damit muss der einzelne Planer statt 38 nur noch 14 Kostenarten für die Folgejahre des Budgetjahrs planen. Sofern der  Wunsch  besteht,  die  sonstigen  Kosten  aus  Informationsgr ü nden  in  grobe  Blöcke  aufzuteilen, können diese auf Basis von Vergangenheitswerten (in Prozent) geplant werden.

## Aufbau und Ablauf der Budgetierung vereinfachen: Case Medienkonzern

Das Beispielunternehmen gehört zu den führenden europäischen Medienunternehmen  und beschäftigt ca. 10.000 Mitarbeiterinnen und Mitarbeiter. Die hier präsentierten Lösungen sind das Ergebnis  eines  umfassenden  Umstrukturierungsprojektes  der  Planung  und  Budgetierung  bei  dem Beispielkonzern.

Der ursprüngliche Ablauf der Budgetierung in diesem Unternehmen gemäß Planungskalender startete im Juni eines Jahres und endete im November. Die erarbeiteten Ergebnisse wurden schließlich final im Dezember vom Vorstand verabschiedet.

Der gesamte Prozess erforderte sehr intensiv die Ressourcen der Controller und auch der Manager und sollte infolge des Umgestaltungsansatzes drastisch reduziert werden.

Folgenden  Haupterwartungen  wurden  an  eine  Neugestaltung  gestellt:  Radikale  Reduzierung  der Budgetierungszeit. Konzentration auf die wesentlichen Kostenund Ergebnistreiber. · Nutzung eines integrierten Planungstools.

Die erarbeitete Lösung überzeugt genau durch die Umsetzung dieser Erwartungen.

Der Gesamtprozess der Planung wurde von 6 Monaten auf 8 Wochen reduziert. Dies gelang durch ein Split des Planungsprozesses in eine Eckwerteplanung und eine Detailplanung. Erstere ist top-downgetrieben und maximal 2 Wochen lang, letztere erfolgt unmittelbar nach der Grobplanung und soll maximal 4-6 Wochen dauern. Vorgabe hierbei ist, dass sich kein Bereich länger als 6 Wochen mit seiner Planung beschäftigen darf. Ferner wurden Standardisierungen (z.B. einheitliche Planungstemplates bzw. -masken) geschaffen und eine Verschlankung der Planungsanalysen und -gespr ä che initiiert.

Die Konzentration auf die relevanten Ergebnistreiber (z.B. Vertriebs- und Werbeerlöse) gelang durch den  Verzicht  auf  Scheingenauigkeiten  und  die  Ableitung  belegbarer  und  vergleichbarer  Aussagen. Ferner wurde die Planungspolitik dadurch stark reduziert, dass die Budgetierung weitestgehend von der Zielvereinbarung entkoppelt wurde.

Schließlich wurde durch die Einführung von SAP BW 7.0 ein einheitliches und integriertes Planungstool geschaffen, welches durch viele Ne uerungen (z.B. 'Bierdeckel' -Handhabung, individueller Detaillierungsgrad, Verfügbarkeit aller relevanter Referenzwerte, Verzahnung von Planungsschritten) und vom Controllerbereich bereitgestellte Planungs- und Analyse-Layouts erheblichen Nutzen für die Neugestaltung des Budgetierungsprozesse sorgte.

Die Vereinfachung des Prozesses, der nach einer Pilotierungsphase im Jahr 2008 schließlich im Jahr 2009  eingeführt  wurde,  gelang  unter  anderem  durch:  Involvierung  wohlgesonnener,  interner Controllerkunden in der Pilotierungsphase, eine intensive Schulung in allen Projektphasen und eine stetige intensive Überzeugungsarbeit  der Controller. Schließlich schaffte die Integration  von Controller- und SAP-Know-How eine hohe Akzeptanz bei den Anwendern, was durch ansprechende Layouts der Planungsmasken und eine einfache und verständliche Handhabung flankiert wurde.

## Flexibilität - Forecasting kontinuierlich durchführen: Case Handel

Das Beispielunternehmen ist eine große Warenhauskette mit über 50 Filialen. In der Ausgangssituation basierte die Steuerung auf einer starren Detailplanung. In einer langen und aufwendigen Budgetierung wurden mit langem Vorlauf die verschiedenen Größen in hoher Detaillierung geplant. Diese Planung bildete -neben  einer  mechanischen  'WIRD' -Hochrechnung  (angefallene Ist-Werte zuzüglich verbleibender  Planwerte) -die  Basis  für  die  unterj ä hrige  Steuerung.  Da  aber  viele  Planwerte  wie beispielsweise der Personaleinsatz nur sehr eingeschränkt mit dem langen Vorlauf einer Budgetierung planbar  sind,  waren  große  Teile  davon  im  Planjahr  regelmäßig  veraltet  und  damit  nicht  mehr  als Vergleichsbasis brauchbar. Vor diesem Hintergrund und mit dem Ziel einer schlankeren und flexibleren Planung wurden einerseits die Budgetierung verkürzt und die im Budget zu planenden Größen deutlich reduziert. Andererseits wurde ein Forecast installiert, der viele Aufgaben der Budgetierung übernimmt (z.B.  die  Personaleinsatzplanung)  und  viermal  jährlich  dezentral  von  den  Abteilungsleitern  der Warenhäuser erstellt wird. Der Forecast ist dabei rollierend gestaltet: Es werden jeweils vier Quartale prognostiziert,  davon  zwei  in  höherer  Detaillierung und  zwei  in  gröberer Detaillierung.  Je  Forecast werden ein zusätzliches Quartal neu prognostiziert und die anderen Quartale überarbeitet (erstes und drittes Quartal) bzw. detailliert (zweites Quartal). Um den Aufwand möglichst gering zu halten, werden dabei nur sehr wenige zentrale Größen prognostiziert. Durch diese Veränderung hat sich die Flexibilität deutlich  erhöht.  Nun  sind  stets  aktualisierte,  zukunftsgerichtete  Informationen  verfügbar,  die frühzeitig Trends signalisieren und so z.B. eine unterj ä hrige Anpassung der Einkaufspolitik einleiten können.

## Szenarien und Sensitivitäten berücksichtigen: Case Bad- und Sanit ä rspezialist - Szenarien

Das Beispielunternehmen stellt hochwertige, design-orientierte Badkonzepte und umweltfreundliche Sanit ä rtechnologien her und vertreibt diese weltweit. Der Bad- und Sanit ä rspezialist beschäftigt mehr als  3.100  Mitarbeiter.  Aufgrund  der  verstärkten  Unsicherheit  der  Marktindikatoren  und  Prämissen wurde bei dem Beispielunternehmen bereits frühzeitig im Januar 2009 eine Szenarien Planung erstellt. Dabei wurden für die zusätzlichen definierten Szenarien pro Gesellschaft so genannte ContingencyPl ä ne aufgesetzt. Diese Contingency-Planung erfolgte bei Weitem nicht im selben Detaillierungsgrad wie die Budgetplanung selbst. Die Gesellschaften und Abteilungen definierten in Abhängigkeit der Stärke  der  Betroffenheit  zwei  weitere  Umsatz-Szenarien  und  erarbeiteten  dazu  entsprechende Gegenmaßnahmen  aus.  Beispielhaft  ist  im  Anschluss  ein  Auszug  aus  einer  Contingency-Planung dargestellt. Das  Beispiel  bezieht  sich  auf  das  Jahr  2009,  in  welchem  aufgrund  der  Wirtschaftskrise ausschließlich 2 negative Szenarien geplant  wurden.  In anderen  Jahren  bietet sich für das Unternehmen  eher  ein  positives  +10  %-  und  ein  negatives -10  %-Szenario  an.  Auch  um  die Abhängigkeit  von  Rohstoffpreisen  und  Fremdw ä hrungskursen  darzustellen,  wurden  verschiedene Szenarien gerechnet und entsprechende Risikoanalysen erstellt. Ziel hierbei war es insbesondere zu verstehen, welche Bedeutung ein Worst Case hätte. Es galt, sich als Unternehmen nach gründlicher Abwägung gewisse Schwellenwerte bei Kursen oder Preisen zu setzen, ab denen reagiert werden muss, um  negative  Folgen  zu  vermeiden  bzw.  zu  minimieren.  Die  zusätzliche  Szenarien  Planung  wurde übersichtlich auf max. 50 Kostenartengruppen vorgenommen.

Spätestens die Krise hat gezeigt, dass Unternehmen neben extremen Absatzschwankungen verstärkt auch mit Schwankungen  anderer Faktoren konfrontiert werden, die Auswirkungen auf die Zielerreichung haben. Für das Beispielunternehmen stieg aufgrund der internationalen Ausrichtung nochmals  die  Bedeutung  der  Wechselkursschwankungen  sowie  der  Rohstoffpreisentwicklung.  Für beide Faktoren wurden folglich Stresstest-Szenarien bzw. Sensibilit ä tsanalysen etabliert. Diese waren enorm hilfreich, um dem Unternehmen ein Gefühl für das vorhandene Risiko zu vermitteln Sie bilden eine Grundlage für die Szenario Planung und helfen somit bei der Entscheidung evtl. Rohstoff- oder W ä hrungsabsicherungen durchzuführen, was dann entsprechend eine der Contingency-Maßnahmen darstellt.

## Relative Ziele ergänzend einsetzen - Case 1 Handel

Das Beispielunternehmen ist im Handel von Möbeln und Einrichtungen aller Art tätig. Es hat rund 200 Filialen in Europa.

Im Unternehmen wurde intensiv diskutiert, wie eine Wettbewerbsorientierung zwischen den Filialen sichergestellt  werden  kann.  Bisher  hatten  die  Filialen  ausschließlich  absolute  Ziele,  ein  Vergleich zwischen den Filialen wurde nur unsystematisch und unregelmäßig vorgenommen. Aus diesem Grund wurden relative Vergleiche institutionalisiert und damit die Wettbewerbsorientierung verstärkt. Dies funktioniert über ausgewählte Kennzahlen:

Neukunden: Anzahl von Neukunden im Vergleich zur Gesamtzahl der Kunden im Betrachtungszeitraum2. Als Neukunden gelten all jene Kunden, die nicht im Kundenbindungsprogramm  ('Kundenkarte')  erfasst  sind  oder  die  im  Kundenbindungsprogra mm erfasst sind, jedoch in den letzten 3 Jahren keine Einkaufe getätigt haben.

Deckungsbeitrag pro Kunde: Durchschnittlicher Deckungsbeitrag im Betrachtungszeitraum, wobei der Deckungsbeitrag nicht pro Produkt berechnet wird, sondern unterschiedlichen Produktgruppen unterschiedliche Deckungsbeitr ä ge zugeordnet sind.3

Umsatz: Summe des Umsatzes der Filiale im Betrachtungszeitraum im Vergleich zum Vorjahreszeitraum.

Die relativen Ziele sind nicht die einzigen Ziele der Filialleiter, stellen aber ein Drittel der Gesamtziele dar. Die Ergebnisse aller Filialen werden alle zwei Monate in so genannten 'Performance -Tabellen' dargestellt. Die einzelnen Ziele fließen mit einer unterschiedlichen Gewichtung in die Gesamttabelle ein.  Für  die  Zielerreichung  und  variable  Vergütung  der  Filialleiter  wird  einerseits  die  absolute Platzierung herangezogen, andererseits die Verbesserung oder Verschlechterung der Platzierung im Vergleich zur letzten Tabelle.

## Case 2 Best-practice Unternehmen

Zahlreiche Unternehmen sind mit der klassischen Konzeption von Anreizsystemen insbesondere in marktnahen Bereichen immer weniger zufrieden. Die klassische Vorgehensweise besteht darin, die spätere Leistungsbeurteilung und Vergütung im Wesentlichen davon abhängig zu machen, inwieweit die im Planungsprozess vereinbarten Ziele verfehlt, erreicht oder gar übererfüllt wurden. Durch die Vereinbarung von Mindesteinkommen und Deckelungen der Gehaltsobergrenzen wird sichergestellt, dass die betroffenen Mitarbeiter weder unter ein bestimmtes Gehaltsniveau sinken, aber auch nicht in beträchtlicher Höhe über dem üblichen Gehaltsrahmen liegen können.

Wie  Unternehmen  relative  Ziele  zur  Performance-Beurteilung  und  Vergütung  einsetzen  können, erläutert das folgende Beispiel: Die 'Best - PracticeAG' hat e in Umsatzwachstum von 5 % geplant und am  Ende  des  Planungszeitraumes  tatsächlich  einen  Umsatzzuwachs  von  6  %  erreicht.  Mit  einem klassisch gestalteten Bonus-System leistet das Unternehmen deutlich über Plan liegende Tantieme Zahlungen.  Die  Qualität  dieser  (Vertriebs-)Leistung  ist  jedoch  relativ  stark  davon  abhängig,  ob  der Markt/die  unmittelbaren  Mitbewerber  z.B.  um  8  %  wachsen  konnten  oder  aber  mit  nur  3  % Umsatzsteigerung der 'Best - PracticeAG' den Gewinn von Marktanteilen zugestehen mussten. Dieser relative Vertriebserfolg sollte aber sinnvollerweise nicht unberücksichtigt bleiben und insbesondere auch in der Vergütung Berücksichtigung finden. In Krisenzeiten können Absatz und Umsatz rapide und unvorhergesehen negativ von den Planwerten abweichen. Gerade dann sind von Mitarbeitern hohe Anstrengungen zur Sicherung des Fortbestands des Unternehmens und zur rechtzeitigen Neupositionierung für den nächsten Aufschwung von entscheidender Bedeutung und bieten zudem oft die Chance zur Verbesserung der relativen Wettbewerbsposition. Der Präsident des Verwaltungsrates eines Mittelständlers mit mehr als 1000 Beschäftigten in der Schweiz formuliert die Notwendigkeit zur Weiterentwicklung der Verg ütungssysteme wie folgt: 'Die nächste konjunkturelle Krise können wir als Unternehmen  nicht verhindern. Wir können jedoch durch effiziente Verg ü tungssysteme unser Topmanagement besser steuern und entlohnen und damit Leistung und nicht Zufall honorieren. Dies ist ein wichtiges Signal an unsere Mitarbeiter, unsere Kunden und die Bevölkerung in unserer Region '.

In der 'klassischen Beispielsituation' vereinbart das Unternehmen, bei Erreichung des budgetierten Umsatzes  von  5  Mio.  EUR  einen  Bonus  von  50  TEUR  zu  zahlen.  Dieser  Bonus  wird  nach  unten abgesichert  durch  eine  Mindestregelung  von  z.B.  30  TEUR,  die  in  jedem  Fall  zu  zahlen  ist.  Eine Obergrenze für die Höhe des Bonus wird so gestaltet, dass pro EUR Umsatz über Budget weiter 1 % des über Budget liegenden Mehr- Umsatzes als Bonus ausgezahlt wird, maximal jedoch ein Betrag von 80 TEUR als Bonus insgesamt erreicht werden kann. Der tatsächlich erreichte Umsatz liegt nun mit 6 Mio.  EUR  zwar  über  dem  vereinbarten  Budget  i.H.v.  5  Mio.,  bleibt  aber  hinter  der  relevanten Marktentwicklung zurück. Damit ist relativ zum Markt eine Underperformance zu konstatieren, die auch  entsprechend  in  der  Vergütung  Berücksichtigung  findet  bei  der  Orientierung  an  relativ  (zur Marktentwicklung) formulierten Zielen. Rechnerisch ist dies in einfacher Form so darzustellen, dass der  sich  nach  der  klassischen  Berechnung  ergebende  Bonus  mit  der  relativen  Marktentwicklung multipliziert  würde.  Der  tatsächlich  ausgezahlte  Bonus  berücksichtigt  bei  Verwendung  relativer Zielvereinbarungen in der Basis die PlanÜ bererf ü llung, diese wird durch die hinter dem Wettbewerb zurückgebliebene Wachstumsdynamik aber wieder relativiert.

## Integration - Planungsebenen verknüpfen: Case Hersteller von Sensoren und Logistikautomation

Das Beispielunternehmen beschäftigt ca. 5.000 Mitarbeiter und ist einer der führenden Hersteller von Sensoren für Fabrik-, Logistikautomation und Prozessautomation.

Mit dem Planungsbrief des Vorstandes wird im Frühjahr der jährliche Planungsprozess gestartet. Basis dazu ist die Unternehmensstrategie. Daraus werden die Rahmenbedingungen und die übergeordneten Ziele für die Konzerneinheiten mit Strategieverantwortung (Corporate Solution Center, Division und Central Department) festgelegt. Die Visualisierung und Kommunikation erfolgt in Form einer Strategy Map und mit Hilfe von Key Performance Indicators (KPIs). Parallel wird die Organisation aufgerufen, einen Forecast (FCI) für das laufende Jahr zu erstellen. Die Ergebnisse der strategischen Planung aller Konzerneinheiten  müssen  vom  Vorstand  und  Geschäftsleitung  (Management  Board)  freigegeben werden.  Im  Anschluss  wird  im  Rahmen  eines  International  Management  Meetings  über  die strategischen Maßnahmen informiert und Inhalte dazu abgestimmt.

Nach  der  Sommerpause  startet  die  Budgetplanung  mit  der  Umsetzung  und  Quantifizierung  der strategischen Maßnahmen. Es werden konkrete operative Ziele für das folgende Jahr geplant. Darin ist ein Forecast (FCII) integriert. Alle Konzerneinheiten und Gesellschaften präsentieren die Ergebnisse ihrem internen Board-Gremium.  Mit der Freigabe durch den Konzernaufsichtsrat wird der Schlusspunkt der Jahresplanung (Budgetprozess) gesetzt.

Das  Herunterbrechen  der  Ziele  und  Maßnahmen  auf  die  Mitarbeiter  erfolgt  durch  den  jährlichen Performance-Dialog. Jede Führungskraft führt unabhängig von der Hierarchie mit ihren Mitarbeitern Gespräche hinsichtlich der Ziele, der Kompetenz, der Entwicklung/Karriere und dem Entgelt. In diesem Dialog wird die Zielverfolgung der Planungsergebnisse im Unternehmen erheblich gestärkt und die für die  Umsetzung  die  notwendige  Dynamik  entwickelt.  Mit  der  Integration  der  Planungsphasen (Strategie, Budget, Forecast) werden konkurrierende Ziele eliminiert. Bei sich veränderten Rahmenbedingungen  und  Zielen  wird  mit  Hilfe  von  'Boxen -Stopps'  zwischen  Mitarbeiter  und Führungskraft die Steuerung neu ausgerichtet, d.h. Ziele werden angepasst.

Ü ber Maßnahmen (z.B. Produktportfolio, Technologieportfolio, etc.) wird die Verbindung zwischen der strategischen und operativen Planung sichergestellt. In der strategischen Planung sind Maßnahmen formuliert, deren Wirkung über KPIs gemessen wird. In dieser Phase wird verstärkt mit relativen Zielen (z.B.  Strukturkosten  in  %  zum  Umsatz)  gearbeitet.  Somit  können  die  Bezugsgrößen  'atmen'  und flexibel auf Wachstumsver ä nderungen reagieren.

Im operativen Budget werden die Maßnahmen für das Fiskaljahr quantifiziert. Für Budget und Forecast werden  gezielt  identische  und  integrierte  Planungsinstrumente  verwendet.  Dieser  Ansatz  stellt besondere  Anforderungen  an  die  IT-gest ü tzten  Planungsinstrumente.  Sie  m ü ssen  neben  der Quantifizierung  auch  die  dazugehö rigen  qualitativen  ('weichen')  Informationen  mitfü hren.  Die Ressourcenbasis (Kosten- stellen) und die Mittelverwendung (Projekte und Maßnahmen) m ü ssen in den  Planungsinstrumenten  integriert  sein.  Der  strategische  Teil  wird  mit  der  Balanced-ScorecardMethodik, auf Basis einer einfachen, integrierten Lotus-Notes-Anwendung mit Workflow-Funktionen dokumentiert und verfolgt.

Die Ziele und Ergebnisse der Planung werden in das Standard-Reporting integriert und regelm ä ßig auf Abweichungen  analysiert.  Daraus  werden  die  notwendigen  Impulse  und  Gegenmaßnahmen  zur Zielerreichung generiert.

## Anreizsysteme ausbalancieren - Case Maschinen- und Anlagenbauer

Das  Beispielunternehmen  besch ä ftigt  800  Mitarbeiter.  Es  ist  im  Business-  to-Business-Bereich  als Teilezulieferer f ü r Maschinen- und Anlagenbauer t ä tig. Das Unternehmen ist in Familienbesitz, wobei jedoch keine Familienmitglieder im Management t ä tig sind. Die durchschnittliche Betriebszugehörigkeit des Managements und der Mitarbeiter ist hoch.

Das  Unternehmen  hat  intensiv  diskutiert,  inwieweit  die  Mitarbeiter  im  Rahmen  einer  variablen Verg ü tung am Unternehmenserfolg beteiligt werden. In der Vergangenheit waren die zu erreichenden Ziele aus- schließlich an die Budgetziele gekoppelt, was zu Verhandlungen ü ber die Zielhöhe gef ü hrt hat. Folgende Probleme traten auf: Auch wenn beide Seiten schlussendlich meist der Meinung waren, dass  die  definierten  Ziele  sowohl  anspruchsvoll  als  auch  erreichbar  waren,  wurde  der  Prozess  der Zielfindung  als  sehr  aufwendig  beschrieben  und  hat  den  j ä hrlichen  Planungszeitraum  deutlich verl ä ngert. Und durch den ausschließlichen Fokus auf Budgetziele wurde die Weiterentwicklung des Unternehmens, z.B. in Form von mehrjährigen strategischen Projekten, vernachlässigt. Zusätzlich gab es viele unterschiedliche  Zielsysteme  im  Unternehmen,  was  einen  hohen  Aufwand  für  das Personalwesen bedeutet hat und teilweise auch zu Missstimmung im Unternehmen f ü hrte, da sich einige Mitarbeiter im Vergleich mit anderen ungerecht behandelt f ü hlten. Aus diesen Gr ü nden fand im  Jahr  2007  eine Ü berarbeitung  des  Zielsystems  statt.  Beschreibung  der  Lösung:  Der  Anteil  der variablen  Verg ü tung  an  der  Gesamtverg ü tung  und  die  Ausgestaltung  dieses  Anteils  erfolgt  je

Hierarchieebene unterschiedlich. Jeder Mitarbeiter hat drei variable Verg ü tungsanteile: Unternehmensanteil, Bereichs-/Abteilungsanteil oder Persönlicher Anteil

Der  Unternehmensanteil  basiert  auf  der  Differenz  des  aktuellen  EGTs  (Ergebnis  der  gewöhnlichen Gesch ä ftst ä tigkeit: EGT = EBIT + Finanzergebnis) zum vorj ä hrigen EGT. Steigt das EGT im Vergleich zum Vorjahr an, werden 30 % der Steigerung auf die Mitarbeiter aufgeteilt. Im Falle eines negativen EGTs erfolgt  keine  Aufteilung.  Der  Aufteilungsschl ü ssel  umfasst  dabei  sowohl  die  Hierarchiestufe,  den Besch ä ftigungsumfang, das Gehalt und die Betriebszugehörigkeit. Als grundlegendes Ziel liegt in jedem Jahr  eine  5  %ige  EGT-Steigerung  zugrunde.  Wird  diese  erreicht,  können  F ü hrungskr ä fte  der  ersten Hierarchieebene mit einem variablen Anteil von rund 25 % ihres Jahresgehalts, F ü hrungskr ä fte  der zweiten/dritten Ebene mit 8 bis 12 % und ü brige Mitarbeiter mit 3 bis 5 % rechnen. Der genaue Anteil ist pro Mitarbeiter unterschiedlich und ergibt sich aus dem Aufteilungsschl ü ssel. Ist die EGT-Steigerung geringer  oder  höher, ä ndert  sich  auch  der  variable  Gehaltsanteil.  Beispielsweise  erhalten  die F ü hrungskr ä fte bei 4 % EGT einen 20 %-igen Anteil am Jahresgehalt, bei 3 % einen 15 %-igen Anteil. Ist das  EGT  negativ,  wird  kein  variabler  Anteil  am  Unternehmenserfolg  ausgesch ü ttet,  die  Bereichs/Abteilungs- und persönlichen Ziele bleiben davon aber unber ü hrt.

Der Bereichs- und Abteilungsanteil basiert auf den im Rahmen der Planung festgelegten Zielen f ü r die Bereiche;  diese  werden  je  Bereich/  Abteilung  mit  der  Gesch ä ftsf ü hrung  und  den  Eigent ü mern definiert. Dabei kann es sich sowohl um monet ä re Ziele (z.B. Produktionskosten pro Teil) als auch um nicht monet ä re Ziele (z.B. Ausschuss in der Produktion) handeln. Um das Zielsystem nicht zu komplex zu gestalten, werden maximal 3 Ziele festgelegt, wobei f ü r die Gesch ä ftsf ü hrung/ 1. F ü hrungsebene keine persönlichen Ziele festgelegt werden.

Der persönliche Anteil setzt sich bei allen Mitarbeitern aus unterschiedlichen Themen zusammen, die im  j ä hrlichen  Mitarbeitergespr ä ch  mit  ihren  Vorgesetzten  festgelegt  und  im  Folgejahr  evaluiert werden. Inhalte könnten die Umsetzung von Projekten (z.B. Einf ü hrung eines CRM- Systems) oder persönliche Weiterentwicklungsziele sein. Auch hier sind maximal 3 Ziele festzulegen. Der Ü bergang zu  Bereichszielen  ist  teilweise  fließend,  das  als  Beispiel  erw ä hnte  CRM-System  könnte  auch  als Bereichs- oder Abteilungsziel Verwendung finden.

## Wertschöpfung abbilden - Gesch ä ftsmodell abbilden: Case Energieversorger

Das betrachtete Unternehmen ist ein regionaler Energieversorger mit typischen Wertschöpfungsaktivit ä ten bzw. Gesch ä ftsfeldern: Beschaffung, Netz, Vertrieb, (externe) Dienstleistungen  und  (interne)  Shared  Services.  Das  Unternehmen  ist  als  Stammhaus-Konzern organisiert, in dem neben den F ü hrungsbereichen auch operative Funktionen zu finden sind. Neben der Stammhaus-AG gibt es acht weitere Legalgesellschaften.

Die  Planung  (wie  auch  das  Reporting)  erfolgten  bislang  prim ä r  entlang  der  Legalstrukturen.  Dabei wurden -unabh ä ngig von der Größe und der zugehörigen Wertschöpfungsaktivit ä t -je Gesellschaft eine  GuV  und  eine  Bilanz  geplant.  Dies  ist  unproblematisch,  solange  die  Gesellschaft  genau  eine Wertschöpfungsaktivit ä t repr ä sentiert. In der GuV  der  Stammhaus-AG  mit ü ber 75  % des Gesamtumsatzes vermischten sich die Effekte verschiedener Aktivit ä ten (insbesondere Beschaffung/Vertrieb und Shared Services). Dadurch wurde eine Abweichungsanalyse auf Basis der Planwerte deutlich erschwert.

Im Zuge der Neugestaltung der Planung erfolgte eine prim ä re Ausrichtung nach den Wertschöpfungsaktivit ä ten.  Im  Vordergrund  stehen  nun  die  einzelnen  Funktionen.  Dazu  wurde insbesondere  die  Stammhaus-AG  mit  Hilfe  eines  Center-Konzeptes  in  verschiedene  Teileinheiten zerschnitten. Zuk ü nftig plant der Vertrieb im Stammhaus analog zu den Vertriebs-Gesellschaften sein Vertriebsergebnis, w ä hrend Stammhaus-Service-Einheiten ihre Kosten und Auslastung planen. Damit bildet die Planung die Grundlage f ü r eine unterj ä hrige Abweichungsanalyse  gem ä ß dem Gesch ä ftsmodell.  Der  dargestellte  Ansatz  l ä sst  sich  nat ü rlich  auch  auf  andere  Branchen  und Gesch ä ftsmodelle ü bertragen. So finden sich beispielsweise in der produzierenden Industrie h ä ufig (kleinere)  Konzerngebilde,  wo Produktion, Forschung und Entwicklung sowie Vertrieb als Teile der Stammhaus-Gesellschaft vermengt gem ä ß der Legalsicht geplant werden.

## Outputfokus forcieren: Best practice aus dem Mittelstand

Startimplus  der  Budgetierung  sollte  der  Output  eines  Unternehmens  oder  der  verschiedenen Leistungseinheiten sein. Richtigerweise ist der Ausgangsund Startpunkt der Planung und Budgetierung der Markt und die absetzbaren Einheiten der Produkte oder Dienstleistungen in der zu betrachtenden Planungsperiode.

Diese Outputorientierung wird allerdings nicht durchg ä ngig im gesamten Budgetsystem gelebt. Dies h ä ngt sicherlich an den inputorientierten, traditionellen Kostenrechnungssystemen, welche oftmals die Logik der Planung und Budgetierung bestimmen. Dies hat zur Folge, dass in vielen F ä llen vor allem in  Gemeinkostenbereichen  Bereichsressourcen  geplant  werden,  ohne  eine  direkte  Beziehung  zum Bereichsoutput herzustellen. Hier hilft eine prozessorientierte Budgetierung auf Basis einer Prozesskostenrechnung. Aus der Planung und Budgetierung auf Grundlage der bewerteten Ressourcen wird  ein  outputorientierter  Ansatz.  Am  Beispiel  des  Controller-Bereichs  eines  mittelst ä ndischen Unternehmens kann die Funktionsweise skizziert werden:

Vom Management werden als Leistungen z.B. 'Kostenstellenberichte' verlangt, der dahinter stehende Prozess 'Kostenstellenbericht erstellen' wird je Kostenstelle einmal monatlich durchgefü hrt. In einer Prozesskostenrechnung wurde ermittelt, dass je Berichtserstellung 200 EUR Prozesskosten anfallen. Als Prozessgesamtkosten wurden 240 TEUR ermittelt (bei 100 Kostenstellen mit je 12 Kostenstellenberichten). Der Prozess wird von 1,5 Controllern bearbeitet.

Eine analytische, korrekte und logische Planung der Controller-Kapazit ä ten in diesem Unternehmen geht nun nicht von der Controller-Kapazit ät und deren mutmaßlichen 3/4nderungen auf Grundlage der Gesch ä ftsentwicklung, sondern von der Controllerleistung aus.

So erfordern z.B. 10 zus ä tzliche Kostenstellen im Unternehmen (statt 100 jetzt 110 Kostenstellen) auch 10 % mehr Controller-Ressourcen, vorausgesetzt die Effizienz wird nicht gesteigert oder es wirken keine  andere  Effekte.  Genau  solche  Verbesserungsvorgaben  können  auf  Grundlage  einer  Output bezogenen Betrachtung gemacht werden. So kann beispielsweise die gew ü nschte Reduzierung der Durchlaufzeiten  (z.B.  -15  %  DLZ,  Reduzierung  von  Liegezeiten)  auch  die  Prozesskosten  und  die notwendigen Controller-Ressourcen reduzieren.

Eine solche, der Arbeitsplanung ä hnlichen Vorgehensweise, durchdringt seit Jahren und Jahrzehnten bereits die produzierenden Bereiche. Es gibt wenig Argumente (z.B. nicht unbetr ä chtlicher Erfassungsund  Pflegeaufwand),  eine  solche  Logik  nicht  auch  auf  die  nicht  produzierenden  Einheiten  bzw. Gemeinkostenbereiche zu ü bertragen.

## Organisation abbilden: Pl ä ne vertikal und horizontal integrieren

Das Beispielunternehmen gehört zu den f ü hrenden europ ä ischen Medienunternehmen  und besch ä ftigt  ca.  10.000  Mitarbeiterinnen  und  Mitarbeiter.  Im  Folgenden  wird  am  Beispiel  dieses Medienunternehmens die Unternehmensplanung mittels kombinierter Eckwert- und Detailplanung erl ä utert.

Ursache f ü r die Umstellung des Planungsprozesses bei dem Unternehmen war, das der Prozess zu lang und  zu  komplex  war.  Es  gab  zu  viele  Abstimmungsschleifen  und  es  wurde  zu  detailliert  geplant, weshalb der Planungs- und Analysezeitraum auch 6 Monate betrug. Des Weiteren ber ü cksichtigte der Planungsprozess keine strategischen Fragestellungen und Kapitalmarkterwartungen. Aufgrund steigender, externer (Informationen f ü r den Kapitalmarkt und Investoren) und interner Anforderungen (Zielvereinbarung auf allen Ebenen) an die Planung sah das Unternehmen Handlungsbedarf.

Der  Gesamtplanungsprozess wurde von 6 Monaten auf 6 bis 8 Wochen verk ü rzt.  Dies  war  neben Maßnahmen wie einer verbesserten IT-Unterst ü tzung und der Reduktion von Liegezeiten vor allem durch der Aufteilung des Planungsprozesses in 2 Phasen zu verdanken: Eckwertplanung (top-down in 2 Wochen) und Detailplanung (bottom-up in 4 bis 6 Wochen).

in der Eckwertplanung wird nur grob in drei Rubriken geplant: Vertriebserlöse werden objektindividuell geplant, d.h. Preise und Mengen (Auflage · Erscheinungstage) nach Preisgebieten, Regionen oder Vertriebskan ä len. Vertriebssysteme unterst ü tzen die Planung durch Referenzwerte aus dem Vorjahr, der Mittelfristplanung und dem Forecast. Werbeerlöse werden ebenfalls objektspezifisch nach  Branchen,  Regionen  oder  Rubriken  geplant.  Die  Planung  erfolgt  auf  Basis  der  Mengen-  und Preisentwicklungen  (nach  Seitenanzahl,  Farbqualit ä t  etc.).  Analog  zu  den  Vertriebserlösen  werden ebenfalls  Referenzwerte  aus  den  Vertriebssystemen  bereitgestellt.  Bei  den  Kosten  fallen  folgende Blöcke an: Herstell- und Versandkosten, deren Planung auf Basis der Entwicklung von Preisen und Mengen  abgesch ä tzt  wird,  sonstige  Einzelkosten,  die  durch  manuelle  Anpassungen  auf  Basis  von Vorschlags-  und  Referenzwerten  entstehen  und  Gemeinkosten,  die  unter  Beachtung  bestimmter Pr ä missen (z.B. x% Steigerung/Senkung gegen ü ber dem Vorjahr) hochgerechnet werden.

Die Eckwertplanung erfolgt top-down, die Ergebnisse werden  gegen  die Kapitalmarktund Vorstandserwartungen gespiegelt. Kommt es hier nicht zu einer Ü bereinstimmung, wird die Planung ü berarbeitet. Die in der Abbildung ebenfalls dargestellte Detailplanung erfolgt bottom-up, nachdem die Vorgaben (also die Eckwertplanung) fixiert wurden. In der Detailplanung erfolgt die Ausplanung der Vorgaben auf einem deutlich höheren Detaillierungsniveau, um als unterj ä hrige Steuerungsgrundlage f ü r die verschiedenen Produkte und Gesch ä ftsfelder dienen zu können.

## Absichten klarmachen und kommunizieren - Absichten klarmachen und Mitarbeiter einbinden

Das Beispielunternehmen stellt hochwertige, design-orientierte Badkonzepte und umweltfreundliche Sanit ä rtechnologien her und vertreibt diese weltweit. Der Bad- und Sanit ä rspezialist besch ä ftigt mehr als 3.100 Mitarbeiter.

Sowohl  beim  strategischen  Plan  als  auch  beim  Budget  werden  bei  dem  Beispielunternehmen  alle relevanten  Mitarbeiter  und  F ü hrungskr ä fte fr ü hzeitig  eingebunden.  Selbst  nach  Erstellung  der entsprechenden Pl ä ne m ü ssen die darin enthaltenen Zielrichtungen und Maßnahmen entsprechend kommuniziert werden.

Der Business Plan definiert die strategischen Stoßrichtungen und wird in alle Unternehmensbereiche und Tochtergesellschaften kaskadiert. Alle Bereiche leiten aus den strategischen Unternehmenszielen ihre  Bereichs-  ziele  ab  und  legen  eine  so  genannte  Roadmap,  den  Maßnahmenplan  f ü r  die Implementierung der Strategie, fest. Quantitative Ziele und Road-map bilden dann die Basis f ü r die j ä hrliche  Budgetplanung  in  jedem  Bereich.  Nationale  und  internationale  Führungskräfte  sowie Fachspezialisten werden aktiv jedes Jahr im Rahmen eines Business-Plan-Klausur- Workshops in die Zielfestlegung und Strategieentwicklung eingebunden. Dabei wird neben einem F ü hrungskr ä ftestamm auch verst ä rkt auf eine rollierende Teilnahme von Nachwuchskr ä ften gesetzt. Inhalte des Work- shops sind  beispielsweise:  Analyse  der  Markt-  und  Kundenstruktur,  Visionen  oder  Positionierung  bei

Vertriebs-, Logistik-, Produktions- und Verwaltungsprozessen. In den Tochtergesellschaften werden eigene Business Pl ä ne, abgeleitet aus dem Business Plan der Gruppe, erstellt.

## Mitarbeiter kommunizieren - Business Plan Info Kaskade

J ä hrlich finden ü ber alle Bereiche des Beispielunternehmens so genannte Business Plan Info Kaskaden statt. Dort sind alle Bereichsleiter angehalten, neben den Gesamtzielen des Unternehmens (Umsatz, Kosten, EBIT, Investitionen etc.) auch die relevanten Business Plan Ziele sowie operativen Ziele ihres Bereichs an die Mitarbeiter zu kommunizieren und diese zu erkl ä ren! Das Beispielunternehmen ist hierbei zu allen seinen Mitarbeitern sehr offen (auch mit Unternehmenskennzahlen und Ergebnissen).

Durch diese offene Kommunikation und Einbindung werden die Ziele besser verstanden und es wird eine hohe Identifikation geschaffen.

Die obigen dargestellten Praxisbeispiele haben gezeigt, wie die Prinzipien der Modernen Budgetierung praktisch umgesetzt werden können.

Die gerade um die Jahrtausendwende und danach intensivierte kritische Diskussion zur Planung hat nicht nur zu radikal neuen Ideen gef ü hrt, wie Beyond Budgeting, sondern auch zu Vorschl ä gen, die Budgetierung weiterzuentwickeln. Einer davon ist die moderne  Budgetierung.  Die  moderne Budgetierung entstand aus folgenden Herausforderungen.

Zum einen soll der Nutzen gegen Aufwand abgewogen werden. Gegenüber dem Aufwand der Planung ist deren Nutzen schwieriger zu messen und einzuschätzen. Die Moderne Budgetierung empfiehlt hier sich auf wesentliche Inhalte  zu  beschränken  und  Instrumente,  Prozesse  und  Methoden  zu vereinfachen.

Des  weiteren Dynamik und Flexibilität  berücksichtigen .  Auf  die  laufenden  Veränderungen  sollten Unternehmen angemessen reagieren, ohne in Beliebigkeit zu verfallen. Die Moderne Budgetierung setzt hier auf Instrumente der flexiblen Planung, rollende Hochrechnung und relative Ziele.

Des weiteren Abwägen  zwischen  Verhaltenssteuerung  und  Entscheidungsunterstützung . Die Moderne  Budgetierung  setzt  hinsichtlich  der  Pläne  und Budgets  ihren  Schwerpunkt  auf  die Entscheidungsunterstützung.  Verhaltenssteuerung  sollte  durch  entsprechende  Zielvereinbarungen und Anreizsysteme erfolgen, die nicht zu eng mit der Budgetierung gekoppelt werden sollten.

Des weiteren soll die Planung und Budgetierung in das Führungssystem eingebettet werden . Planung und Budgetierung sind (nur) Teile des Führungssystems eines Unternehmens Es ist nach Ansicht der Modernen  Budgetierung  daher  wesentlich  die  konkreten  Kontextfaktoren  bei  der  Gestaltung  zu berücksichtigen.

Das Konzept der Modernen Budgetierung hat nicht die Abschaffung der Planung und Budgetierung zum Ziel, sondern die Konzentration auf das Wesentliche der Planung und Budgetierung. Sie ist damit auch  eher  ein  Rahmen  und  nicht  eine  detaillierte  Vorgabe.  Letzteres  ist  auch  gar  nicht  möglich, angesichts der Einfluss- und Kontextfaktoren.

Die Empfehlung und Vorschläge der Modernen Budgetierung unterteilen sich in zwei Gruppen.

Erstens  die  Empfehlungen  zur  Gestaltung  der  Prozesse  und  Strukturen  der  Planung,  die  vor  allem einfach, flexibel und integriert sein soll, sowie zweitens die Empfehlungen zu den Fundamenten der Planung, die die Organisation und Wertschöpfung abbilden soll sowie Ziele und Absichten stringent verdeutlichen soll.

die Empfehlungen zur Gestaltung teilt sich auf in drei Aspekte. Einfachheit, Flexibilit ä t und Integration. Die Einfachheit als Prinzip bedeutet, historisch gewachsene Prozesse und Strukturen der Planung zu hinterfragen und ggf. wieder auf das Wesentliche zur ü ckzuf ü hren.  Einfachheit  kann  beispielsweise bedeuten: Detaillierung der Planung verringern, Aufbau und Ablauf der Budgetierung vereinfachen, Planungsprozesse auch tats ä chlich so durchführen, wie sie definiert sind und bei den Instrumenten eher weniger und einfachere anzuwenden, da diese meist besser verstanden werden.

Mit Flexibilität ist in der Modernen Budgetierung die Anpassungsfähigkeit an Veränderungen gemeint. Das Konzept empfiehlt, unterjährige Plananpassungen zuzulassen und nicht starre Jahresbudgets zu verwenden.  Weiterhin  sollten  laufende  Hochrechnungen  verwendet  werden,  um  aufkommende Chancen und Risiken als auch Änderungsbedarfe zu erkennen. Schließlich wird auch empfohlen stärker Szenarien und Simulationen zu verwenden.

Die Integration verschiedener Teilpläne, die Abstimmung von Maßnahmen und Budgets ist auch im Konzept  Moderne  Budgetierung  ein  wesentlicher  Baustein.  Konkret  erfolgt das durch  die Verknüpfung verschiedener Planungsebenen, vor allem der strategischen und operativen. Eine zweite Integration betrifft die zwischen der eher auf die Entscheidungsunterstützung gerichteten Planung und den Anreizsystemen. Die Integration wird heutzutage schließlich hauptsächlich über entsprechende IT-Systeme realisiert, seien es einheitliche Datenbanken oder Workflow-Systeme.

Im Zentrum einer Planung steht die Abbildung der wesentlichen Prozesse der Leistungserstellung und -verwertung,  also  der  Wertschöpfung.  Hier  besteht  eine  Verbindung  zur  zielgetriebenen  und treiberbasierten Planung. Die Ziele leiten sich aus den wesentlichen Leistungen ab bzw. konkretisieren zum Beispiel ein Gewinnziele in Form der dafür zu erlösenden Umsätze nach Produkten (= Leistungen). Umgekehrt bilden die Treiber die wesentlichen Einflüsse auf die Wertschöpfungskette und damit die zu erzielende Wertschöpfung. Insofern wird deutlich, weshalb die Moderne Budgetierung hier auf die Abbildung  des  Geschäftsmodells  und  die  output-bezogene  Planaufstellung  abhebt.  Relative  Ziele können dieses Prinzip ergänzen, da sie den Blick auch nach außen, relativ zu Markt und Wettbewerb lenken.

Die Wertschöpfungskette bestimmt nicht vollständig die Aufbauorganisation und die Leistungsverflechtung in einem Unternehmen, sonst würden Unternehmen mit ähnlichem Produktportfolio auch ähnlich organisiert sein. Die Aufbauorganisation definiert Verantwortungen und spiegelt  die  Delegation  von  Aufgaben  wider.  Damit  Pläne  und  Budgets  auch  in  die  Tat  umgesetzt werden, benötigen sie verantwortliche Personen. Insoweit ist es wichtig, dass die Planungsstruktur auch der Organisationsstruktur entspricht.

Ab einer gewissen Größe werden Leistungen nicht nur in einer linearen Kette vom Einkauf hin zum Absatzmarkt erzeugt, sondern es findet auch ein Leistungsaustausch zwischen Organisationseinheiten statt.  Um  diesen  wirtschaftlich  zu  steuern,  ist  es  sinnvoll,  eine  Leistungsverrechnung  einzuführen. Dabei  sollte  man  wieder  dem  Prinzip  Einfachheit  folgen,  und  nur  die  wichtigsten  und  nicht  jede Leistung verrechnen.

Die Wirksamkeit der Pläne und Budgets hängt auch maßgeblich von den Zielen ab. Sind diese nicht klar formuliert und abgestuft nach Verantwortungsbereichen konkretisiert, muss ein Scheitern von Plänen nicht wundern. Förderlich für die Akzeptanz der Ziele und die Motivation der Mitarbeiter ist deren Mitwirkung und laufende Information über die Zielerreichung.

Ziel und Chance der Modernen Budgetierung ist es, die operative Planung und Budget wieder zum Kern zurückzuführen und sie auf die Hauptaufgaben auszurichten: Umsetzung der Strategien und Steuerung der Wirtschaftlichkeit des Unternehmens. Die Prinzipien sind als Leitlinien und Rahmen gedacht, der Unternehmen  eine  Orientierung  gibt,  sie  aber  nicht  von  der  Aufgabe  entbindet,  die  konkrete

Ausgestaltung  selbst  vorzunehmen.  Das  Konzept  versucht  über  die  Prinzipien  einen  aufeinander abgestimmten Rahmen vorzugeben, nicht ganz detaillierte Anweisungen. Solche Details kann man von einem Kontierungshandbuch erwarten, nicht aber von der Planung.

Eine weitere Leitidee war die Übernahme der Erkenntnisse der Wissenschaft, die aussagen, dass eine zweckmäßige Planung den Unternehmenserfolg steigern helfen kann. Das Konzept setzt damit auf die Weiterentwicklung der Planung und Budgetierung, nicht seine Abschaffung oder Überwindung.

Modern ist dieses Konzept der Budgetierung in dem Sinne, als dass es vorhandene Methoden und Instrumente auf Basis des derzeitigen Erkenntnisstands von Wissenschaft und Praxis zusammenführt. Insofern  kann  man  das  kritisch  auch  als  neue  Überschrift  für  Altbekanntes  sehen.  Dem  sei entgegengehalten, dass einerseits selbst diese im Grunde bekannten Instrumente und Themen, mögen sie auch vielen bekannt sind, nicht allen bekannt sind -und die Begründungen für ihren Einsatz auch nicht. Zweitens benötigen auch gute, wissenschaftlich fundierte Ideen einen gemeinsamen Nenner, um  bekannt  zu  werden.  Gerade  der  Versuch,  das  Konzept  stärker  in  Wissenschaft  und  Praxis  zu verankern unterscheidet es auch von advanced budgeting und beyond budgeting.

Aus  den  vielen  theoretisch  begründeten  und  praktischen  Anforderungen  an  die  Planung  und Budgetierung  wurden  sechs  wesentliche  Empfehlungen  herausgearbeitet.  Mit  ihnen  lässt  sich  die Budgetierung modernisieren und an neue Umweltbedingungen anpassen. Sie werden in zwei Gruppen eingeteilt: Gestaltungsempfehlungen und Fundamente .

Die Gestaltungsempfehlungen umfassen drei Empfehlungen für die Gestaltung der Planungsprozesse und  Planungsebenen  sowie  die  Auswahl  der  Planungsinstrumente .  Zum  einen  ' Einfach '. Schlanke Abläufe, die sich nur auf steuerungsrelevante Inhalte beschränken, nur nutzenbringende Instrumente und  Methoden  einsetzen,  nur  wenige  Eingangsgrößen,  optimale  Detaillierung  finden,  manchmal genügt  auch  'top -down'.  Außerdem  ' Flexibel '. Bereitschaft  für  Änderungen,  Sensitivitäten  und Szenarien,  auch  relative  Ziele  aufgrund  von  Benchmarks,  (rollierende)  Forecasts,  flexibles  und kontrolliertes Umschichten von Ressourcen. Und zuletzt ' Integriert '. Strategie,  Planung,  Reporting und  Forecasts  müssen  verknüpft  sein.  Konkrete,  aber  wenige  voneinander  ableitbare  Vorgaben. Budget und Anreizsysteme lose koppeln. Nicht nur kurzfristige Ziele.

Ebenso werden drei Empfehlungen zur Festlegung der wichtigsten Fundamente gegeben. Zum einen ' Organisation abbilden '. Konkrete, eindeutige Ziele, Orientierung am Gesamtziel, Organisation muss kurze und schnelle Entscheidungswege finden. Außerdem ' Wertschöpfung abbilden '. Verständnis der eigenen  Wertschöpfungskette.  Ziele,  Engpässe  und  Restriktionen  determinieren  die  Planung.  Und zuletzt ' Absichten klar machen und kommunizieren '. Ziele und Absichten klar verständlich machen, den Kern des Plans kommunizieren und leistungsebenengerecht transformieren, Umsetzungsverantwortung  mitteilen,  durch  Prämissen  und  Top-down-Vorgaben  Planungsschleifen verhindern.

Die moderne Budgetierung bietet dem operativen und dem Produktionscontrolling die Möglichkeit, Planungsund Steuerungssysteme sowie Budgetierungsinstrumente systematisch und nach individuellem Bedarf neu auszurichten. Es handelt sich dabei aber nicht um ein Patentrezept, sondern um fundierte Empfehlungen, die in vielen kleinen und großen Schritten durch ständige Bemühungen etabliert werden können.

Sie  wägt  den  Nutzen  gegen  Aufwand  ab .  Die  Komplexität  der  Budgetierung  soll  in  Bezug  auf  ITInstrumente, Methoden und Prozesse reduziert werden. Dadurch wird der Aufwand enorm reduziert, der Nutzen aber nicht viel verringert. Zudem  soll sich die Budgetierung auf wesentliche, steuerungsrelevante Planungsinhalte beschränken.

Sie  gibt  der  Dynamik  und  den  ständigen  Veränderungen einen flexiblen Rahmen geben .  Mithilfe neuer Instrumente wie Szenarien, rollierender Planung und Forecasts oder relativen Zielen soll die Flexibilität  des  Budgets  erhöht werden. Des Weiteren soll die Budgetierung gröber werden, indem Jahresziele  als  Rahmen  gesetzt,  und  kurzfristig  konkrete  Ziele  vorgegeben  werden.  Rhythmus  und Umfang von Plananpassungen sollen unternehmensindividuell festgelegt werden.

Die Verhaltenssteuerung und Entscheidungsunterstützung wird abgewägt .  Diese Herausforderung soll  durch  eine  Fokussierung  der  Budgetierung  auf  die  Entscheidungsunterstützungsfunktion  sowie eine  variable  Vergütung  auf  Basis  einer  ausbalancierten  Mischung  von  kurz-  und  langfristigen persönlichen, Bereichs- und Unternehmenszielen erreicht werden.

Die Planung und Budgetierung wird in das gesamte Führungssystem implementiert . Hierzu müssen die Kontextfaktoren (z. B. Branche, Organisation, Wertschöpfung, Marktsituation) bei der Gestaltung der Planung und Budgetierung berücksichtigt werden und kurz- und mittelfristige Planungen stärker strategisch ausgerichtet werden.

## Budgetierung Beispiel

Budgetierung beginnt mit Absatz- und Umsatzplanung . Für die meisten Unternehmen ist der Umsatz eine besonders wichtige Kennzahl, um den Unternehmenserfolg zu beschreiben. Der Umsatz ergibt sich  aus  der  Zahl  der  verkauften  Produkte  und  Dienstleistungen:  dem  Absatz.  Deshalb  erstellt  die Geschäftsleitung zunächst einen Umsatz  und  Absatzplan  für das  Unternehmen.  Dieser  Plan prognostiziert den möglichen Umsatz und Absatz in den kommenden Jahren. Im Vertrieb werden dazu spezielle Prognosen erstellt. Es wird geschätzt, welche Kunden wie viele Produkte kaufen werden. Aus dem Absatzplan und den Verkaufspreisen beziehungsweise Straßenpreisen lässt sich der Umsatzplan ermitteln. Diese Pläne sind die Grundlage für viele weitere Pläne im Unternehmen -insbesondere auch für den Budgetplan.

Jede Unternehmens- und Budgetplanung sollte mit dem Engpassfaktor beginnen. Was am knappsten oder am schwierigsten zu bekommen ist, wird zuerst geplant. Alle weiteren Pläne leiten sich dann daraus ab. Mögliche Engpassfaktoren können sein. Zum Beispiel im Bezug auf Absatzmarkt und Kunden beginnt die Planung mit der Umsatz- und Absatzplanung. Beim Personal beginnt die Planung mit der Personaleinsatzplanung. Oder Bezüglich verfügbares Kapital beginnt die Planung mit der Finanz- oder Cashflow Planung.

Ressourcenplan erstellen . Im Absatzplan ist festgehalten, wie viele Produkte und Dienstleistungen im betrachteten Jahr oder pro Quartal, pro Monat, pro Woche erstellt werden sollen. Daraus werden im nächsten Schritt der Produktionsplan und der Beschaffungsplan abgeleitet, allgemein: der Ressourcenplan.  Im  Produktionsplan  ist  aufgeführt,  welche  Ressourcen  zur  Leistungserstellung notwendig sind. Ressourcen können z.B. Personal, Räume, Maschinen, Anlagen, Computer, Einrichtungen, Möbel, Geräte, Betriebs- und Hilfsstoffe, Material und Bauteile sein.

Die Angaben in diesen Teilplänen der Produktionsplanung ergeben sich aus Berechnungsverfahren, die technische und organisatorische Zusammenhänge berücksichtigen. Die Parameter dieser Berechnungsverfahren  sind  bestimmt  durch  z.B.  das  zu  erstellende  Produkt,  die  eingesetzte Technologie, die Kompetenz der Mitarbeitenden und die verfügbare Zeit

Solche Zusammenhänge müssen ermittelt (beobachtet, gemessen, geschätzt) werden. In Produktionsunternehmen sind sie in Stücklisten und Arbeitsplänen hinterlegt.

Es  wird  geprüft,  ob  die  verfügbaren  Ressourcen  ausreichen,  um  die  prognostizierte  Absatzmenge herzustellen.  Es  wird  ermittelt,  welche  Ressourcen  durch  Verschleiß  (Maschinen)  oder  Fluktuation

(Personal) ersetzt werden müssen. Reichen die bestehenden Ressourcen für den geplanten Absatz nicht aus, müssen zusätzliche Ressourcen oder solche, die produktiver sind, beschafft werden. Die Alternative  ist:  Der  Absatzplan  wird  korrigiert.  Die  einzelnen  Teilpläne  werden  also  (ständig) aufeinander abgestimmt und miteinander verknüpft.

## Beispiel für Ressourcenplan:

Ein Unternehmen will jeden Monat 3.000 Computer verkaufen (Absatzplan). Für seinen Produktionsplan muss er unter anderem wissen:

Wie  viele  Computer  kann  eine  Maschine  oder  Mitarbeiter  pro  Stunde  produzieren?  Wie  viel  und welche  Produktionsstoffe  werden  dafür  benötigt?  Wann  kann  mit  dem  produzieren  begonnen werden? Wie viele Computer können (gleichzeitig) produziert werden?

Daraus berechnet er seinen Personalbedarf, seinen Kapazitätsbedarf, seinen Materialbedarf, seinen Lagerbedarf etc. Was ihm nicht zur Verfügung steht, muss er zusätzlich beschaffen. Mit einer neuen Maschine kann er vielleicht mehre Computer gleichzeitig produzieren. Für solche Investitionen braucht er Geld; er erstellt einen Investitionsplan mit einem Investitionsbudget.

Marketingplan und Vertriebsplan erstellen . Um die Absatzziele zu erreichen, muss das Unternehmen Marketing betreiben. Was es genau dafür plant, wird im Marketingplan festgehalten. Dort sind die Marketingaktionen beschrieben und begründet, mit denen der Vertrieb unterstützt und der Absatz angekurbelt werden sollen (Aktionsplan). Das können z.B. Werbung in Fernsehen, Zeitung oder im Internet, Public Relation, Sponsoring, Brief- oder E-Mail-Marketing, Kundenzeitschrift, Messeauftritt, Kundenveranstaltungen sein.

Konkrete  Verkaufsaktivitäten  sind  in  einem  Vertriebsplan  formuliert.  Das  können  z.B.  Kunden besuchen, Telefonverkauf (Outbound Call) intensivieren, Promotionen durchführen, Rabatte einräumen, Referenzprojekte erstellen sein.

## Beispiel für Marketingplan und Vertriebsplan:

Bislang hat das Unternehmen 1.500 Computer verkauft. Nun will es den Absatz auf 3.000 Computer erhöhen.  Das  ist  sein  Ziel  in  seinem  Absatzplan.  Dazu  möchte  er  seinen  Absatz  durch  Werbung ankurbeln. Er lässt Plakate drucken und schreibt die Kunden in seiner Nachbarschaft per Brief an.

Außerdem  druckt  er  Flyer,  die  er  in  den  Briefkästen  seiner  Stadt  verteilt.  Das  alles  soll  eine Werbeagentur für ihn planen, vorbereiten und umsetzen. Das Unternehmen stellt dann Hilfskräfte ein, die seine Flyer verteilen.

Auch diese Kosten für die Werbeagentur als Dienstleister und für das Personal kann er berechnen. Daraus ergibt sich der notwendige Geldbedarf, das Budget, für sein Marketing.

In den Verkaufsflächen muss er zusätzliches Personal einstellen, die die zusätzlichen 1.500 Computer verkaufen sollen. Auch das sind Personalkosten für den Verkauf, die er berücksichtigen muss.

Kostenplan,  Erlösplan  und  Finanzplan  aufstellen .  Der  Einsatz  von  Maschinen  und  Material  in  der Produktion,  die  Mitarbeitenden  in  Produktion,  Marketing  und  Vertrieb,  externe  Dienstleistung  für Werbung -alle damit verbundenen Aktivitäten führen zu Aufwand und Kosten. Diese werden in einem Kostenplan  zusammengestellt.  Kosten,  die  zu  Auszahlungen  führen,  sowie  die  Auszahlungen  für Investitionen gehen in den Finanzplan ein. Gleichzeitig werden im Finanzplan die Erlöse (Umsatz) und Einzahlungen beschrieben, wie sie aus dem Absatzplan hergeleitet werden. Die Differenz aus Erlös und

Kosten beziehungsweise Einzahlungen und Auszahlungen ergeben den Cashflow und den Bedarf an Geldmitteln.  Der  muss  durch  ein  entsprechendes  Budget  oder  durch  externe  Kapitalzuflüsse  (zum Beispiel Kredite) gedeckt werden. Somit sind der Kosten- und der Finanzplan die Grundlage für das Budget. Dort wird beschrieben, welche Geldmittel und andere Ressourcen in welchen Bereichen, für welche Investitionen oder für welche Projekte verwendet werden sollen.

## Beispiel für die Finanzplanung eines Unternehmens:

Im Finanzplan (Einzahlungen, Auszahlungen) fasst das Unternehmen zusammen, welche Zahlungsströme zu erwarten sind. Auf der Einnahmenseite (Einzahlungen) sind das die Erlöse aus dem Verkauf  der  3.000  Computer  zum  jeweiligen  Preis.  Auf  der  Ausgabenseite  (Auszahlungen)  stehen einmalige  Investitionen  für  eine  zusätzliche  Maschine  und  die  Werbeagentur  sowie  die  laufenden Ausgaben wie z.B. Produktionsstoffe, Personalkosten und Kosten für Miete und für Betriebsstoffe.

Schließlich berechnet das Unternehmen den monatlichen Saldo aus Einnahmen und Ausgaben und prüft,  ob  seine  verfügbaren  Geldmittel  dafür  ausreichen  oder  ob  er  sich  Geld  beschaffen  muss (Kredite). Sind alle Fragen geklärt, fasst er das Ergebnis in seinem Budgetplan zusammen.

Budgets gelten für eine definierte Zeit . In allen Plänen sind die jeweiligen Aktionen dargestellt und um die damit verbundenen Zahlen wie Stückzahlen oder Geldbeträge ergänzt. Zudem haben alle Angaben einen  zeitlichen  Bezug.  Es  wird  beispielsweise  dargestellt:  Wann  werden  die  geplanten  Aktionen durchgeführt? Wann ergeben sich welche Umsätze? Wann fallen welche Kosten an? Wann kommt es entsprechend zu Einzahlungen oder Auszahlungen? Wann sind die verfügbaren Geldmittel (Kapital) aufgebraucht? Wie lange reicht das verfügbare Budget?

Die entsprechenden Angaben werden während einer definierten Zeitperiode zusammengefasst. Die entsprechenden Pläne gelten also für ein Jahr, ein Quartal oder einen Monat. Welche Zeitperiode sinnvoll ist, hängt von den Rahmenbedingungen ab.

Manche Unternehmen erstellen einen Marketingplan nur einmal im Jahr. Ihren Finanzplan pflegen sie wöchentlich. In jedem Plan muss deutlich werden, auf welche Zeitperiode er sich bezieht. Das gilt auch für das Budget. Jeder Budgetplan hat also einen Zeitbezug.

## Beispiel für den Budgetplan eines Unternehmens

Mit  seinem  Finanzplan  kann  das  Unternehmen  erkennen,  dass  seine  verfügbaren  Geldmittel (Liquidität) nicht ausreichen, um eine neue Maschine zu kaufen. Durch die Investition in die Maschine und die Werbung ist der Cashflow in den ersten sechs Monaten negativ. Deshalb erhält er für diesen Zeitraum einen Kredit von seiner Hausbank. Wenn es dem Unternehmen gelingt, nach sechs Monaten mindestens 2.500 Computer pro Monat zu verkaufen, ist der Cashflow positiv und der Kredit kann zurückbezahlt werden. In seinem Budgetplan fasst er dies zusammen und hält fest: die Ziele, die er erreichen will, die notwendigen Investitionen und den dafür erforderlichen Geldbetrag, alle geplanten Marketing- und Vertriebsaktivitäten und deren Kosten und Kosten für Personal und Material.

Dafür benennt er für die nächsten beiden Jahre ein Budget in Form eines Geldbetrags, der dafür zur Verfügung steht. Gegenüber der Bank legt er mit dem Finanzplan und dem Budgetplan dar, welche eigenen Mittel (Rücklagen) sind und wie hoch der weitere Kapitalbedarf (Kreditsumme) ist, um das Budget zu haben. Und er zeigt, dass er Zins und Tilgung bezahlen kann (Kreditdienstfähigkeit).

Diese Zahlen sind in einer Tabelle für die nächsten zwei Jahre und pro Monat dargestellt. Anschließend plant das Unternehmen ein weiteres Budget, um den Verkauf von Computern auf 5.000 Stück pro Monat zu erhöhen.

Budgetierung  gilt  für  eine  definierte  Organisationseinheit .  Die  einzelnen  Pläne  haben  für  die unterschiedlichen  Bereiche  eines  Unternehmens  eine  jeweils  andere  Bedeutung.  Die  Produktion interessiert  sich  nicht  für  den  Marketingplan.  Sie  muss  nur  wissen,  wann  sie  welches  Produkt  in welcher Stückzahl herstellen und abliefern muss. Das Marketing ist nicht an den Kosten für die EDVAbteilung  interessiert.  Um  die  Pläne  den  jeweiligen  Unternehmensbereichen  oder  Abteilungen zuordnen zu können, müssen diese voneinander abgegrenzt werden. Es müssen die Organisationseinheiten (Abteilungen, Teams, Kostenstellen) ausgewiesen werden, für die ein Budget gelten soll -der Budgetbereich. So erhält jeder Bereich einen eigenen Budgetplan.

## Beispiel für die Budgetierung unterschiedlicher Marketingaktionen

Das Unternehmen möchte auch in Zukunft weitere Marketing- und Werbeaktionen durchführen, um den Verkauf seiner Computer zu fördern. Dazu legt er zusammen mit der Werbeagentur fest, wie viel Geld er für welche Marketingaktion ausgeben möchte. Das sind die jeweiligen Budgets.

Er kann außerdem Budgets für einzelne Filialen (Organisationseinheit) festlegen. Damit können diese eigene Werbeaktionen durchführen, die jeweils zu ihrer Situation am besten passen. Die Filialleitung kann selbstständig entscheiden, wann sie das Budget wofür einsetzt.

Detaillierung und Vollständigkeit der Budgetplanung .  Wie detailliert und differenziert die Budgets vergeben werden, hängt davon ab, wie selbstständig die einzelnen Bereiche arbeiten können. Meist entsteht  ein  hierarchisches  System  der  Budgetpläne:  Die  Geschäftsleitung  gibt  ein  Budget  für  das Marketing  vor.  Der  Marketingleiter  verteilt  dieses  Budget  auf  die  einzelnen  Produktbereiche.  Die Produktmanager verteilen das Budget auf unterschiedliche Aktionen. Das Beispiel macht deutlich, dass auch der Detaillierungsgrad der Budgetplanung bestimmt werden muss. Bis auf welche Ebene des Unternehmens  soll  geplant  werden?  Zum  Beispiel:  Ebene  von  Kostenstellen,  Teams,  Abteilungen, einzelne  Kundensegmente,  Produktgruppen  und  Projekte  oder  Aktionen.  Das  ist  eine  Frage  der organisatorischen Gliederung im Unternehmen und des Aufwands, den man für die Planung betreiben will -im Verhältnis zum Nutzen dieser Planung.

Dabei ist die Vollständigkeit bei Budgetplanung wichtiger als der Detaillierungsgrad . Die Vollständigkeit  eines  Plans  geht  immer vor  Detaillierungsgrad.  Das  bedeutet, ein  Budgetplan  muss nicht bis auf eine einzelne Person heruntergebrochen werden, aber er sollte immer den gesamten Ressourcenbedarf (Personal, Kapazität, Geld) in entsprechend zusammengefasster Form abbilden.

Wie  werden  die  Zahlen  im  Budgetplan  ermittelt? Im  Prozess  der  Budgetplanung  besteht  eine Schwierigkeit darin, die Höhe der erforderlichen Budgets (in Geldbeträgen) anzugeben. Sie basieren auf den geplanten Aktivitäten und auf den dadurch verursachten Kosten oder Auszahlungen. Beide Faktoren sind nicht vorgegeben, sondern davon abhängig, was in Zukunft passiert. Sie können also nicht  exakt  angegeben  werden -sie  müssen  geschätzt  werden.  Die  zentralen  Fragen  dabei  sind: Reichen die geplanten Aktivitäten aus, um das Ziel zu erreichen? Welche Aufwendungen und Kosten sind mit den Aktivitäten wahrscheinlich verbunden?

Schätzungen. Um mit einem vertretbaren Aufwand zu halbwegs plausiblen Schätzungen und Zahlen zu  kommen, wenden Unternehmen meistens eines der folgenden Verfahren an: Sie schreiben die bekannten Ist-Zahlen der Vorperiode fort. Sie nehmen eine messbare Kennzahl ihres Unternehmens, zum Beispiel den Umsatz, und legen davon einen festen Anteil (X Prozent) als Budgetvorgabe für die nächste  Periode  fest.  Sie  entwickeln  einen  ausführlichen  Businessplan,  indem  sie  sich  gedanklich intensiv  mit  der  Zukunft  befassen,  die  Einflussfaktoren  identifizieren,  unterschiedliche  Szenarien entwerfen und dann die notwendigen Budgets abschätzen.

Fortschreibung. Die Ist-Zahlen der Vorperiode lassen sich im Allgemeinen gut ermitteln. Diese werden ergänzt um allgemeine Vorgaben wie 'Steigerung um 10 Prozent'. Gründe für größere Budgetanpassungen  und  Veränderungen  können  sein: Produkt  ist  am  Ende  seines  Lebenszyklus , saisonale  Schwankungen , Wirtschaftskrise , Auftritt  eines  neuen  Wettbewerber  oder  zusätzliche Marketingaktionen oder Einführung eines neuen Produkts. So entsteht eine dynamische Trendfortschreibung. Sie ist dann wiederum Basis für den Budgetplan.

Marktforschung  und  Businessplan. Will  man  sich  nicht  auf  die  Werte  der  Vergangenheit  allein verlassen,  dann  müssen  für  die  Absatz-  und  Umsatzplanung  Marktstudien  durchgeführt  werden. Kunden werden befragt, Wettbewerber beobachtet und analysiert, allgemeine Trends interpretiert und  oft auch  einfach Annahmen  getroffen  oder  starke Visionen formuliert. Sie  werden  in Businessplänen zusammengeführt.

Ziele und Visionen .  Manche Unternehmen orientieren sich bei der Budgetplanung weniger an der Vergangenheit. Sie lösen sich von aktuellen Kundenwünschen und verlassen sich nicht auf die bisherige Entwicklung des Marktes. Sie gehen stattdessen mutig voran und schaffen sich ihre Märkte selbst. Sie entwickeln ganz neue Produkte, treiben Innovationen voran und überraschen ihre Kunden mit echten Neuheiten.  Ihr  Antrieb  ist  eine  eigene  Vision.  Und  die  Mittel  zur  Umsetzung  stellen  sie  in entsprechenden Innovationsbudgets zur Verfügung. Oft nach dem Prinzip: klotzen, nicht kleckern.

Was  steht  im  Budgetplan? Am  Ende  der  Budgetplanung  steht  eine  schriftliche  Aussage  darüber, welche Kosten eine einzelne Budgeteinheit (zum Beispiel Funktionsbereich, Abteilung, Profit-Center, Prozesseinheit,  Projekt  oder  Produkt)  und  welche  Auszahlungen  sie  verursachen  darf.  Das  ist  das Ergebnis der Budgetplanung. Der Budgetplan enthält dementsprechend: Ziele, die verfolgt werden, Liste aller Projekte, Aktivitäten und Maßnahmen, die geplant sind, um diese Ziele zu erreichen, dafür notwendige Ressourcen, Kosten für diese Ressourcen, mögliche Erlöse aus den Aktivitäten, Saldo aus Kosten und Erlösen und das Budget, das zur Verfügung steht,  um den Saldo auszugleichen. Diese Angaben werden differenziert nach der Zeit, wann das Budget verfügbar sein soll. Das Budget kann für ein oder mehrere Jahre, für Quartale oder Monate angegeben werden. Außerdem wird im Budgetplan die Organisationseinheit benannt, die dann selbstständig bestimmen kann, wann und wofür genau das Budget eingesetzt wird. Diese Organisationseinheit ist dann auch dafür verantwortlich, dass die zu Beginn definierten Ziele mit dem verfügbaren Budget erreicht werden.

Grundlagen  für  die  Budgetplanung  schaffen .  Stellen  Sie  im  ersten  Schritt  alle  Informationen zusammen, die Sie für die Budgetplanung brauchen. Prüfen Sie dazu, welche Pläne bereits vorliegen und aktuell sind -oder welche Planzahlen fehlen. Klären Sie dazu die folgenden Fragen:

Engpassfaktor  ermitteln:  Was  ist  in  Ihrem  Unternehmen  und  in  Ihrer  Branche  der  limitierende Engpass? Inwiefern berücksichtigen Sie diesen bei der Budgetplanung?

Planungssystematik klären: Wie erfolgt in Ihrem Unternehmen die Absatz- und Umsatzplanung? Wie zuverlässig sind diese bislang? Wie leiten Sie daraus Ressourcenpläne, Kapazitätspläne, Marketingpläne, Vertriebspläne oder Personaleinsatzpläne ab? Wie sind diese Vertriebs-, Marketing und technischen Pläne miteinander verknüpft? Welche dieser Pläne liegen bereits vor und welche Informationen sind darin enthalten? Welche Informationen fehlen noch für Ihre Budgetplanung?

Finanzplan erstellen: Wie erstellen Sie für Ihr Unternehmen Erlösplan, Kostenplan und Finanzplan? Was besagt die Finanzplanung für Ihren Bereich?

Budgetplan ableiten und zusammenstellen . Klären Sie, wie Sie aus den unterschiedlichen Plänen in Ihrem Unternehmen die Budgetpläne ableiten und zusammenstellen. Grundlage ist insbesondere der Finanzplan. Legen Sie fest: Zeitraum, für den der Budgetplan gelten soll, Organisationseinheit, für die der  Budgetplan  gelten  soll  und  Detaillierungsgrad  des  Budgetplans.  Ermitteln  Sie  dann,  wie  im jeweiligen Fall die Budgets berechnet werden. Stellen Sie alle Zahlen zusammen und legen Sie das Budget in Geldeinheiten fest.

Budgetverwendung  überwachen .  Wenn  die  Budgets  geplant  und  festgelegt  sind,  sollten  Sie überprüfen,  inwiefern  die  geplante  Mittelverwendung  auch  eingehalten  wird.  Sie  sollten  eine kontinuierliche und regelmäßige Budgetüberwachung durchführen. Damit können Sie gegensteuern, wenn  bei  der  Umsetzung  das  Budget  überschritten  wird.  Vor  allem  aber  lernen  Sie  daraus,  wie realistisch die Budgetplanung war und wo Sie zukünftig die Budgetplanung verbessern müssen.

Zielerreichung überwachen für den effektiven Budgeteinsatz . Überprüfen Sie bei der Budgetverwendung und bei der Durchführung der Aktionen und Maßnahmen insbesondere, ob und in welchem Maße diese zur Zielerreichung beitragen. Erst dann können Sie beurteilen, ob die Budgets effektiv eingesetzt werden, also eine Leistungsverbesserung in Ihrem Unternehmen bewirken. Dazu prüfen Sie für die Ziele Ihrer Aktionen und damit verknüpfte Leistungsindikatoren (Key Performance Indicators, KPI), inwiefern Sie die Soll-Vorgaben und Plan-Werte auch erreichen.

## Budgets für unterschiedliche Vorhaben planen und Verwendung auswerten .

Mit Softwarelösungen können Unternehmen die jeweiligen Budgets planen und deren Verwendung in Berichten oder Reports auswerten. Grundlage sind die jeweiligen Vorhaben und die voraussichtlichen Kosten, die für ein Vorhaben anfallen. Dabei können Folgende Fragen beantwortet werden: Wie hoch ist das Budget für die geplanten Vorhaben im Zeitverlauf? Welche Ziele werden mit dem Budget und den  Vorhaben  verfolgt?  Wofür  wird  wie  viel  Budget  investiert?  Welche  Bereiche  planen  welches Budget ein? Welche Standorte planen welches Budget ein? Welche Kostenarten gehen in welcher Höhe ins Budget ein?

## Ausführliches Beispiel Budgetierung:

Das Unternehmen plant, seine Produktionskapazität für Metallteile um 20% zu steigern. Dafür erstellt die Produktionsabteilung ein detailliertes Investitionsbudget :

Anschaffung neuer Produktionsmaschinen: 2 neue Fräsmaschinen à 150.000 € = 300.000 € und 1 neue Biegemaschine = 80.000 € . Summe Maschinenkosten: 380.000 €

Erweiterung  der  Produktionsflächen:  Umbau  und  Erweiterung  der  Produktionshalle  um  500  m²  = 250.000 € und Anschaffung von Regalsystemen und Lagertechnik = 50.000 € . Summe Flächenkosten: 300.000 €

Personalaufbau: Einstellung von 5 zusätzlichen Produktionsmitarbeitern à 40.000 €/Jahr = 200.000 € und Schulungen und Qualifizierung = 20.000 €. Summe Personalkosten: 220.000 €

Sonstige Investitionen: Erweiterung Materiallogistik = 50.000 € und IT-Infrastruktur für Produktionsplanung = 30.000 € . Summe sonstige Investitionen: 80.000 €

Gesamtinvestitionsbudget: 980.000 €

Dieses  Investitionsbudget  wird  der  Unternehmensleitung  vorgelegt,  die  es  prüft  und  genehmigt. Parallel dazu erstellt die Produktionsabteilung auch ein Budget für die laufenden Produktionskosten:

## Produktionskostenbudget

Materialkosten: Stahl:  2.500.000  € und Lacke/Beschichtungen:  500.000  € .  Summe  Materialkosten: 3.000.000 €

Energiekosten:

Strom: 300.000 € und Gas: 150.000 €

. Summe Energiekosten: 450.000 €

Personalkosten: 50 Produktionsmitarbeiter  à  40.000 €/Jahr  =  2.000.000 € und  5  Meister  à  60.000 €/Jahr = 300.000 € . Summe Personalkosten: 2.300.000 €

Sonstige  Kosten: Instandhaltung:  200.000  € und Entsorgung:  100.000  € .  Summe  sonstige  Kosten: 300.000 €

Gesamtproduktionskosten: 6.050.000 €

Dieses  detaillierte  Produktionskostenbudget  wird  dann  in  die  Gesamtplanung  des  Unternehmens integriert,  um  sicherzustellen,  dass  die  Produktionsziele  mit  den  verfügbaren  finanziellen  Mitteln erreicht werden können.

## Allgemeines Beispiel einer Budgetierung:

Ein gutes Beispiel wäre ein Unternehmen, das jährlich ein Budget plant und dabei bestimmte Ziele verfolgt. Dies kann zum Beispiel sein, die Kosten um 10% zu reduzieren oder den Umsatz um 20% zu steigern. Dazu ist es wichtig, die zur Verfügung stehenden Ressourcen zu kennen und diese effizient einzusetzen. Das Unternehmen muss seine Einnahmen und Ausgaben schätzen und kontrollieren, um den finanziellen Plan einzuhalten.

## Beispiel für eine traditionelle Budgetierung:

Ein  Unternehmen  könnte  beispielsweise  ein  festes  jährliches  Marketingbudget  von  500.000  Euro beschließen.  Unabhängig  davon,  ob  die  Marketingbemühungen  erfolgreich  sind  oder  nicht,  bleibt dieses Budget unverändert.

## Beispiel für eine moderne Budgetierung:

Angenommen,  das  genannte  Unternehmen  verwendet  flexible  Budgets  für  sein  Marketing.  Dann könnte das Budget basierend auf den Marktentwicklungen angepasst werden, z.B. wenn ein neuer Konkurrent auftaucht oder wenn neue Marketingkanäle verfügbar werden.

## Quellen:

http://www.planung-budgetierung.de/planung-und-budgetierung/Budgetierung.php

Zyder, M. (2007). Die Gestaltung der Budgetierung: Eine empirische Untersuchung in deutschen Unternehmen . Springer-Verlag.

Rieg, R. (2015). Planung und Budgetierung: Was wirklich funktioniert . Springer-Verlag.

https://www.weka.ch/themen/finanzen-controlling/controlling/planung-undbudgetierung/article/traditionelle-budgetierung-die-vor-und-nachteile-der-klassischenbudgetierung/

https://www.lexoffice.de/lexikon/moderne-budgetierung/

https://www.icv- controlling.com/index.php?eID=dumpFile&amp;t=f&amp;f=630&amp;token=182a4b7dc9749ed9ada57a1907279da 7a1f55f3c

Bleiber, Reinhard (2022): Crashkurs Controlling : Grundlagen und Instrumente. 2. Aufl., Stuttgart: Haufe (Kapitel 2, 3)

Ewert, R.; Wagenhofer, A.; Rohlfing-Bastian, A. (2023): Interne Unternehmensrechnung. 9. Aufl., Berlin: Springer Gabler (Kapitel 1, 5)

Horváth, P.; Gleich, R.; Seiter, M. (2024): Controlling. 15. Aufl., München: Verlag Franz Vahlen  (Kapitel 1, 2)

Peter R. Preißler (2020): Controlling. 15. AUfl., München: Verlag Franz Vahlen (Kapitel 6)